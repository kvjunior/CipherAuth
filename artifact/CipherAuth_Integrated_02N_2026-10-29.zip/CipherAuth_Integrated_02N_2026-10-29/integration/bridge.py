"""Research integration adapter; not a finalized scheme or security-game oracle.

Use the unmodified CEA sender/signature/delegation code and 02F proof kernel.
Translate group elements only through canonical bytes: their Python classes differ.
The proxy accepts compressed bytes only, never witnesses or individual responses.
"""
from pathlib import Path
import sys
from dataclasses import replace

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT/'components/cea/src'), str(ROOT/'components/02F/src')]
from cipherauth import group as g, schnorr, wire
from cipherauth.cea import (Submission, SUITE, statement_bytes, parse_body,
                           _opening, _kdf, _commit, _xor, _body)
from cipherauth.models import EncryptedRecord
from cipherauth.encoding import encode as cea_encode
from cipherauth02f import kernel, transcript as tr


def proof_context(system, record):
    system._record_consistent(record)
    return tr.Context(cea_encode(record.origin.fields()), record.tag, record.epoch,
                      system.dir.registry.resolve(record.origin).encoded_key)


def proof_record(record):
    _, commitment, A, _ = parse_body(record.body)
    return tr.Record(cea_encode(record.sender.fields()), commitment,
                     record.body, g.encode_point(A))


def create_submission(system, sender, owner, message, tag, epoch):
    """Generate the intake proof while the sender still knows t; never export t."""
    origin = system.dir.class_key(owner, tag, epoch)
    t = g.random_scalar()
    Q, A = g.mul(t, g.G), g.mul(t, system.dir.point(origin))
    c = _commit(message, _opening(Q))
    E = _xor(message, _kdf(Q, len(message)))
    Lam, theta = schnorr.sign(sender.x, system.dir.point(sender.ref),
                             statement_bytes(sender.ref, origin, tag, epoch, c))
    record = EncryptedRecord(sender.ref, origin, tag, epoch, _body(Lam, c, A, E))
    proof = kernel.prove(proof_context(system, record), proof_record(record), t)
    return Submission(record, theta), proof


def compress_intake(system, submissions, proofs):
    submissions, proofs = tuple(submissions), tuple(proofs)
    if not submissions or len(submissions) != len(proofs):
        raise ValueError('proof/submission count mismatch')
    context = proof_context(system, submissions[0].record)
    for sub, proof in zip(submissions, proofs):
        if proof_context(system, sub.record) != context:
            raise ValueError('mixed proof contexts')
        if proof.entry.record != proof_record(sub.record):
            raise ValueError('proof bound to a different record')
    return tr.encode(kernel.compress(context, proofs))


def verify_intake(system, aggregate, proof_bytes):
    """Reconstruct every proof field from the authenticated CEA batch.

    Checking two signatures/proofs independently is insufficient: the lists and
    contexts must match exactly. Intake is origin-only and the proof is consumed
    at that boundary; it does not purport to verify transformed Abar records.
    """
    try:
        if aggregate.context.level != 'origin' or not system.verify_public(aggregate):
            return False
        proof = tr.decode(proof_bytes)
        expected = proof_context(system, aggregate.records[0])
        if any(proof_context(system, r) != expected for r in aggregate.records):
            return False
        if tuple(e.record for e in proof.entries) != tuple(map(proof_record, aggregate.records)):
            return False
        return kernel.verify_compressed(expected, proof)
    except (ValueError, TypeError, KeyError, AttributeError):
        return False


def delegate_checked(system, token, grant, aggregate, proof_bytes):
    if not verify_intake(system, aggregate, proof_bytes):
        raise ValueError('compressed intake verification failed')
    return system.delegate_aggregate(token, grant, aggregate)


def roundtrip_origin(aggregate):
    decoded, delegation = wire.decode_aggregate(wire.encode_aggregate(aggregate))
    if delegation is not None:
        raise ValueError('origin expected')
    return decoded


def roundtrip_delegated(obj):
    from cipherauth.cea import DelegatedAggregate
    decoded, delegation = wire.decode_aggregate(wire.encode_delegated(obj))
    return DelegatedAggregate(decoded, *delegation)
