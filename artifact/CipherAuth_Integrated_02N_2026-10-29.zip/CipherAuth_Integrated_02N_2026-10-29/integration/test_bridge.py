"""Cross-component tests on real P-256 CEA records (not finite-field stand-ins)."""
import unittest
from dataclasses import replace
from unittest.mock import patch
from bridge import *
from cipherauth.cea import CEA, Directory
from cipherauth.models import BatchContext
from cipherauth02f import group as pg


def fixture():
    directory = Directory()
    system = CEA(directory)
    owner = directory.new_signing_key('owner')
    origin = directory.new_decryption_key('owner', tag=b'tag', epoch=7)
    recipient = directory.new_decryption_key('recipient')
    senders = [directory.new_signing_key('sender'+str(i)) for i in range(2)]
    messages = (b'first message', b'second message')
    pairs = [create_submission(system, s, 'owner', m, b'tag', 7)
             for s, m in zip(senders, messages)]
    submissions, proofs = tuple(zip(*pairs))
    context = BatchContext(SUITE, 'origin', origin.ref, origin.ref, 7)
    aggregate = system.aggregate(context, submissions)
    intake = compress_intake(system, submissions, proofs)
    token, grant = system.issue_grant(owner, origin, recipient.ref, b'tag', 7)
    return system, owner, origin, recipient, submissions, proofs, aggregate, intake, token, grant


class BridgeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        (cls.system, cls.owner, cls.origin, cls.recipient, cls.submissions, cls.proofs,
         cls.aggregate, cls.intake, cls.token, cls.grant) = fixture()

    def test_end_to_end_both_recipients(self):
        agg = roundtrip_origin(self.aggregate)
        self.assertEqual(agg, self.aggregate)
        self.assertTrue(verify_intake(self.system, agg, self.intake))
        out = delegate_checked(self.system, self.token, self.grant, agg, self.intake)
        delegated = roundtrip_delegated(out)
        self.assertEqual(out, delegated)
        self.assertEqual(delegated.aggregate.authenticator, agg.authenticator)
        opened = self.system.open_aggregate(self.origin, agg)
        self.assertEqual(tuple(x.message for x in opened), (b'first message', b'second message'))
        self.assertEqual(self.system.open_aggregate(self.recipient, delegated), opened)

    def test_point_and_scalar_interoperability(self):
        self.assertEqual(g.q, pg.q)
        for k in (1, 2, 17, g.q-1):
            self.assertEqual(g.encode_point(g.mul(k, g.G)), pg.encode_point(pg.mul(k, pg.G)))
        self.assertNotEqual(type(g.G), type(pg.G))

    def test_valid_unrelated_proof_is_rejected(self):
        sub, proof = create_submission(self.system, self.owner, 'owner', b'other', b'tag', 7)
        other = compress_intake(self.system, [sub], [proof])
        self.assertTrue(kernel.verify_compressed(proof_context(self.system, sub.record), tr.decode(other)))
        self.assertFalse(verify_intake(self.system, self.aggregate, other))

    def test_E_mutation_passes_authentication_but_fails_intake(self):
        r = self.aggregate.records[0]
        changed = replace(r, body=r.body[:-1]+bytes([r.body[-1]^1]))
        agg = replace(self.aggregate, records=(changed,self.aggregate.records[1]))
        self.assertTrue(self.system.verify_public(agg))
        self.assertFalse(verify_intake(self.system, agg, self.intake))
        with patch.object(self.system, 'delegate_aggregate', side_effect=AssertionError('must not transform')):
            with self.assertRaises(ValueError):
                delegate_checked(self.system,self.token,self.grant,agg,self.intake)

    def test_reordering_with_reaggregated_authentication_rejects_old_intake(self):
        agg = self.system.aggregate(self.aggregate.context, self.submissions[::-1])
        self.assertTrue(self.system.verify_public(agg))
        self.assertFalse(verify_intake(self.system,agg,self.intake))
        rebuilt = compress_intake(self.system,self.submissions[::-1],self.proofs[::-1])
        self.assertTrue(verify_intake(self.system,agg,rebuilt))

    def test_proof_response_and_framing_mutations(self):
        proof = tr.decode(self.intake)
        bad = tr.encode(replace(proof,response=(proof.response+1)%pg.q))
        for data in (bad, self.intake[:-1], self.intake+b'junk', b''):
            with self.subTest(data_length=len(data)):
                self.assertFalse(verify_intake(self.system,self.aggregate,data))

    def test_no_intake_proof_bypasses_sender_authentication(self):
        agg = replace(self.aggregate,authenticator=b'\0'*32)
        self.assertFalse(verify_intake(self.system,agg,self.intake))

    def test_wrong_key_context(self):
        proof = tr.decode(self.intake)
        bad = replace(proof,context=replace(proof.context,key=g.encode_point(g.G)))
        self.assertFalse(verify_intake(self.system,self.aggregate,tr.encode(bad)))

    def test_proof_record_must_match_body_point_and_commitment(self):
        proof=tr.decode(self.intake)
        for field,value in [('A',g.encode_point(g.G)),('commitment',b'\0'*32),('sender',b'other')]:
            e=proof.entries[0]
            bad=replace(proof,entries=(replace(e,record=replace(e.record,**{field:value})),proof.entries[1]))
            self.assertFalse(verify_intake(self.system,self.aggregate,tr.encode(bad)))

    def test_wrong_grant_and_token_rejected_after_intake(self):
        self.assertTrue(verify_intake(self.system,self.aggregate,self.intake))
        bad=replace(self.grant,signature=b'\0'*65)
        with self.assertRaises(ValueError):
            delegate_checked(self.system,self.token,bad,self.aggregate,self.intake)
        bad_token=replace(self.token,Omega=(self.token.Omega+1)%g.q)
        with self.assertRaises(ValueError):
            delegate_checked(self.system,bad_token,self.grant,self.aggregate,self.intake)

    def test_delegated_records_are_not_origin_intake(self):
        obj=delegate_checked(self.system,self.token,self.grant,self.aggregate,self.intake)
        self.assertFalse(verify_intake(self.system,obj.aggregate,self.intake))
        self.assertIsNone(self.system.open_aggregate(self.origin,obj))

    def test_opening_rejects_transformed_body_tampering(self):
        obj=delegate_checked(self.system,self.token,self.grant,self.aggregate,self.intake)
        r=obj.aggregate.records[0]
        r=replace(r,body=r.body[:-1]+bytes([r.body[-1]^1]))
        bad=replace(obj,aggregate=replace(obj.aggregate,records=(r,obj.aggregate.records[1])))
        self.assertTrue(self.system.verify_public(bad.aggregate))
        self.assertIsNone(self.system.open_aggregate(self.recipient,bad))

    def test_exact_replay_is_functionally_valid_not_an_oracle_policy(self):
        for _ in range(2):
            self.assertTrue(verify_intake(self.system,self.aggregate,self.intake))

    def test_mixed_context_rejected(self):
        other=self.system.dir.new_decryption_key('owner',tag=b'other',epoch=7)
        sub,proof=create_submission(self.system,self.owner,'owner',b'x',b'other',7)
        with self.assertRaises(ValueError):
            compress_intake(self.system,(self.submissions[0],sub),(self.proofs[0],proof))


if __name__=='__main__':
    unittest.main(verbosity=2)
