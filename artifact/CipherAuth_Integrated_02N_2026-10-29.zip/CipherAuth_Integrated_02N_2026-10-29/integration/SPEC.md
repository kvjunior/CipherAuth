# CEA to 02F research adapter

The bridge uses the unmodified CEA and 02F formats. It does not merge their two
aggregate response scalars or introduce a new complete wire envelope.

| 02F field | Source in CEA |
|---|---|
| Context.origin | Canonical `cipherauth.encoding.encode(record.origin.fields())` |
| Context.tag / epoch | Record tag / epoch after CEA class-key consistency checking |
| Context.key | Registered encoded public key for that exact origin KeyRef |
| Record.sender | Canonical encoding of the full sender KeyRef fields |
| Record.commitment | Parsed 32-byte commitment c |
| Record.body | Entire original encrypted body, including Lambda, c, A and E |
| Record.A | Parsed A encoded as canonical compressed SEC1 bytes |
| Entry.R / aggregate response | Existing 02F proof machinery |

The redundancy of A and c in both body and separate proof fields is intentional:
the wrapper reconstructs both and compares exact records before checking the
compressed proof. It never trusts an adversary-supplied mapping of those fields.
CEA's `verify_public` enforces its suite, signature and class context; 02F supplies
its own proof domain separation and canonical parsing. KeyRef identity, role,
version and fingerprint are all included, but that fact alone proves no registry
simulation lemma.

The accepted inputs for a full serialized roundtrip lie in the intersection of
the two existing formats' bounds. In particular 02F permits at most 256 records;
CEA's wire uses a 16-bit record-body length and 8-bit tag/identity byte lengths,
whereas 02F's own body limit is larger. The adapter does not enlarge CEA's wire
limits or claim serialization for every 02F-valid input. The existing serializers
raise on values outside their own bounds. The tested chain uses two short records.

Sender-side creation and compression see individual proofs. Proxy-side
`delegate_checked` receives only a CEA aggregate, encoded compressed intake proof,
token and grant. It verifies record correspondence and both public checks before
calling CEA's grant-checked transformation. The caller must not interpret this
functional method as the challenge-refusal oracle from the security game.

After delegation, A becomes Abar and the original intake proof no longer binds
the transformed record. The existing CEA sender authenticator stays unchanged.
The delegatee uses the original token/grant validation and commitment opening.
No persistent intake-proof object, post-delegation knowledge proof, or public
verification of the transformation relation is added by this adapter.
