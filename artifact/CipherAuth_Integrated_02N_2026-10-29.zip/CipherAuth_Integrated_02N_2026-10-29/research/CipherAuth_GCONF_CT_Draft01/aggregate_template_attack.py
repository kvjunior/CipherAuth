"""Reviewer evidence (not protocol code): why the compressed intake-proof template needs
list-binding coefficients.

Template (NEXT_RESEARCH_GATE.md): records (U_i, A_i, ctx_i), c_i = H(K, U_i, A_i, ctx_i),
accept iff z~ K = sum_i b_i (U_i - c_i A_i).

- UNWEIGHTED (b_i = 1): an adversary who knows neither t* nor k makes an aggregate that
  verifies and contains A* + rK, then uses the honest proxy's reply to recover the challenge.
- PREFIX-WEIGHTED (b_1 = 1, b_i = H_b(prefix_i)): the same construction fails, because the
  cancelling coefficient would have to be chosen before b_2, which depends on it.

Uses the batch's own intake-proof challenge function and binding, and CEA's real proxy
transform (inside the trusted fixture) once the proxy has accepted the aggregate.
"""
import sys, json, zipfile, tempfile
from dataclasses import replace
from pathlib import Path
B = Path(sys.argv[1]); tmp = tempfile.mkdtemp(prefix="agg-attack-")
zipfile.ZipFile(next((B / "baseline").glob("*.zip"))).extractall(tmp)
sys.path[:0] = [str(B), str(Path(tmp) / "encrypted_auth_research" / "src")]
from cipherauth import group as g
from cipherauth.cea import parse_body, _body, _kdf, _xor
from cipherauth.encoding import encode
from batch01 import intake_pok as p
from batch01.cea_adapter import binding
from batch01.experiment import Scenario, MESSAGES
from batch01.oracle_experiment import Policy

HB = "cipherauth/review/aggregate-template/b/v0"


def chal(K_enc, U, A, rec):
    return p.challenge(K_enc, g.encode_point(U), g.encode_point(A), binding(rec))


def coeffs(K_enc, entries, weighted):
    """entries: list of (U, A, rec). Prefix-bound coefficients over (K, U_j, A_j, binding_j)."""
    if not weighted:
        return [1] * len(entries)
    out, prefix = [1], []
    for i, (U, A, rec) in enumerate(entries):
        prefix.append(encode((K_enc, g.encode_point(U), g.encode_point(A), binding(rec))))
        if i:
            out.append(g.hash_to_scalar(HB, b"".join(prefix)))
    return out


def verify(K_enc, entries, z, weighted):
    K = g.decode_point(K_enc)
    b = coeffs(K_enc, entries, weighted)
    rhs = g.IDENTITY
    for bi, (U, A, rec) in zip(b, entries):
        rhs = rhs + g.mul(bi, U - g.mul(chal(K_enc, U, A, rec), A))
    return g.mul(z, K) == rhs


def attack(bit, weighted):
    s = Scenario(bit, Policy.REGISTERED_POINT, True)          # trusted fixture
    view = s.view                                            # adversary input
    K_enc = view.origin_public; K = g.decode_point(K_enc)
    rec0 = view.challenge_aggregate.records[0]
    Lam, c, A_star, E = parse_body(rec0.body)
    # record 1: the mauled challenge point, with a fresh nonce of known K-multiple
    r, u1 = g.random_scalar(), g.random_scalar()
    A1 = A_star + g.mul(r, K); U1 = g.mul(u1, K)
    rec1 = replace(rec0, body=_body(Lam, c, A1, E))
    c1 = chal(K_enc, U1, A1, rec1)
    # record 2: own point a2*K; its nonce carries +c1*A* to cancel record 1's A*-term (b_2 = 1 assumed)
    a2, u2 = g.random_scalar(), g.random_scalar()
    A2 = g.mul(a2, K); U2 = g.mul(u2, K) + g.mul(c1, A_star)
    rec2 = replace(rec0, body=_body(Lam, c, A2, E))
    c2 = chal(K_enc, U2, A2, rec2)
    z = (u1 - c1 * r + u2 - c2 * a2) % g.q                    # A*-terms cancel when b_2 = 1
    entries = [(U1, A1, rec1), (U2, A2, rec2)]
    accepted = verify(K_enc, entries, z, weighted)
    recovered = False
    if accepted:
        # The proxy accepted the compressed proof, so it transforms record 1 (fixture performs it).
        agg = replace(view.challenge_aggregate, records=(rec1,))
        out = s.system.delegate_aggregate(s.oracle._token, s.oracle._grant, agg)
        C, gamma, _ = out.token_public
        T = g.mul(g.inv(view.delegatee_secret.k), g.decode_point(gamma))
        omega = int.from_bytes(_xor(C, g.hash_bytes("cea/rk-mask", encode((g.encode_point(T), view.origin.fields())))), "big")
        Abar = parse_body(out.aggregate.records[0].body)[2]
        Q_star = g.mul(omega, Abar) - g.mul(r, g.G)
        recovered = _xor(E, _kdf(Q_star, len(E))) == MESSAGES[bit]
    return {"accepted": accepted, "challenge_recovered": recovered}


def honest_aggregate_verifies(weighted):
    s = Scenario(0, Policy.REGISTERED_POINT, True)
    K_enc = s.view.origin_public; K = g.decode_point(K_enc)
    rec0 = s.view.challenge_aggregate.records[0]
    Lam, c, _, E = parse_body(rec0.body)
    entries, zs = [], []
    for _ in range(3):
        t, w = g.random_scalar(), g.random_scalar()
        A, U = g.mul(t, K), g.mul(w, K)
        rec = replace(rec0, body=_body(Lam, c, A, E))
        zs.append((w - chal(K_enc, U, A, rec) * t) % g.q)
        entries.append((U, A, rec))
    b = coeffs(K_enc, entries, weighted)
    return verify(K_enc, entries, sum(bi * zi for bi, zi in zip(b, zs)) % g.q, weighted)


if __name__ == "__main__":
    res = {
        "honest_aggregate_verifies": {"unweighted": honest_aggregate_verifies(False), "prefix_weighted": honest_aggregate_verifies(True)},
        "unweighted_attack": [attack(bit, False) for bit in (0, 1)],
        "prefix_weighted_same_attack": [attack(bit, True) for bit in (0, 1)],
        "scope": ("Shows only that b_i = 1 is broken and that this particular cancellation fails "
                  "under prefix weighting. It does not prove the weighted template secure."),
    }
    print(json.dumps(res, indent=2))
