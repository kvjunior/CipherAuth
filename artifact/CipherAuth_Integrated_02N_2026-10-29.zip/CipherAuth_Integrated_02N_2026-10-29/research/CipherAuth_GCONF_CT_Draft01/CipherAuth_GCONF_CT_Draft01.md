# G-CONF-CT for CipherAuth: Case-3 theory draft 01

**Status: candidate lemma and proof gate.** This document is not a construction, security theorem, or novelty claim. It formalizes the missing Case-3 question identified by the CipherAuth theory gate.

## 1. Target question

G-CONF-CT is the per-ciphertext confidentiality game from the frozen CipherAuth specification. The target class may be served by an honest proxy to a corrupted delegatee on any submitted aggregate whose core is not a registered derivative of the challenge. The delegatee can use its own secret and the public grant data to decrypt the returned object. Challenge cores and their derivatives are refused by the decryption oracle, with the frozen replay masking rules.

CEA does not meet this game: its public verification authenticates sender commitments but does not validate the encryption point `A` or ciphertext `E` at the proxy. A receiver can submit a shifted challenge point `A*+rK`; the proxy transforms it, and the corrupted delegatee removes the known shift after decryption. This is the concrete A-mauling attack in the frozen workspace.

The candidate question is whether one can add a proxy-checkable proof of knowledge of the encryption randomness and half-aggregate those proofs across a batch without losing extractability under delegation.

## 2. Candidate per-record intake proof

Let the target class public key be `K=kP`, and let an origin record use `A_i=t_iK`, where `t_i` is the encryption randomness and `Q_i=t_iP` is the opening point. A Schnorr proof of knowledge of `t_i` for the relation `A_i=t_iK` has the form

\[
 R_i=r_iK,\qquad c_i=H_{pok}(context,A_i,R_i),\qquad z_i=r_i+c_it_i,
\]

with verification equation

\[
 z_iK=R_i+c_iA_i.
\]

The proof must bind the complete record context, including the origin class reference, sender reference, tag, epoch, `A_i`, commitment, ciphertext fields, and the batch position or transcript prefix. Omitting `A_i` recreates the known receiver-insider forgery pattern; omitting the ciphertext/commitment fields permits statement substitution.

This proof is checked by the proxy at the origin level, before it applies `A_i \mapsto \bar A_i=\Omega^{-1}A_i`. The proof need not remain valid after single-hop delegation for correctness, because the delegatee checks the commitment after decryption. A security proof must nevertheless define how adversary-crafted delegated objects are handled when they did not pass through the proxy.

## 3. Candidate half-aggregation

For a batch of `n` accepted proofs, choose transcript-bound coefficients `b_i`. A natural incremental choice is a prefix hash chain over the full ordered records and proof commitments, with `b_1=1` and each later coefficient derived from the preceding prefix. The compressed equation is

\[
 \widetilde z K=\sum_{i=1}^{n} b_i(R_i+c_iA_i),
 \qquad \widetilde z=\sum_{i=1}^{n} b_i z_i.
\]

The compressed object retains the records, the proof commitments `R_i`, the coefficient transcript, and the single scalar `\\widetilde z`. This is only a format candidate. The exact hash inputs, coefficient domain, rejection of zero coefficients, encoding, append semantics, and verification algorithm must be frozen before any theorem attempt.

The proxy accepts an origin aggregate only if the sender authenticator and this compressed proof equation both verify. It then transforms every `A_i` while leaving the proof payload out of the delegated verification path, or marks the delegated object as origin-certified. The delegatee opens using the transformed points and the existing commitment check.

## 4. Negative control: unweighted aggregation is unsound

If all coefficients are fixed to one, a receiver-insider can use one registered rogue sender key to cancel the honest sender's contribution. The adversary constructs a record containing a chosen challenge statement for an honest sender, chooses the rogue record's point after the coefficients are fixed, and sets the aggregate response so that the compressed equation accepts. The honest sender's secret is not used. The frozen probe reproduces this attack and the original v3 coefficient rule rejects the same aggregate.

This establishes only that fixed coefficients are insufficient. Prefix binding rejects this particular cancellation because changing a later record changes the coefficient chain, but that observation is not a knowledge-soundness proof.

## 5. Candidate aggregate-extraction lemma

The missing lemma should be stated in one fixed model, with no hidden extraction oracle.

> **Prefix-bound batch knowledge-soundness (candidate).** In the AGM+ROM, for a common class base `K`, independent sender witnesses `t_i`, malicious registered sender keys, adaptively chosen record order, and prefix coefficients binding the complete transcript, any algebraic adversary that outputs an aggregate accepted by the proxy either (i) yields a valid extraction of every accepted record's opening point `Q_i=t_iP` (or an equivalent representation of `t_i`), except for explicitly listed challenge/previously-simulated proofs, or (ii) produces a solver for the declared base assumption. The extractor must have polynomial running time and an explicit loss in the number of records, aggregation queries, and random-oracle queries.

The statement must distinguish:

- an honest proof supplied by a sender;
- a proof simulated by the reduction for the challenge;
- a replay or re-aggregation of a registered proof;
- a newly crafted proof under a malicious sender key;
- a valid origin aggregate later sent through `ReEncO`; and
- an adversary-crafted delegated object that never passed proxy intake.

A proof that extracts only the weighted sum of witnesses is insufficient. The G-CONF-CT simulator needs each accepted `Q_i` to answer the proxy transformation and the corrupted delegatee's decryption consistently.

## 6. Required security-game obligations

A complete G-CONF-CT theorem must specify all of the following.

1. **Registration and keys.** State the chosen-key and identity-authentication assumptions. No extraction of a corrupted sender secret may be assumed merely because its public key was registered.
2. **Proxy service.** Define exactly which origin aggregates the proxy accepts, whether it checks the compressed proof before transforming, and what it returns for malformed, non-extractable, or mixed-class inputs.
3. **Delegated decryption.** Define the oracle for a corrupted delegatee on adversary-crafted delegated objects that have no intake proof. The proof cannot silently assume a proof survives delegation.
4. **Derivative handling.** Register challenge cores and all allowed derivatives exactly as in the frozen game. State whether aggregate membership is per record or per compressed object.
5. **Challenge simulation.** Specify how the reduction simulates the challenge proof and which random-oracle queries are forbidden, programmed, or extracted.
6. **Aggregation adaptivity.** Handle repeated proofs, reordering, omission, append, and aggregation of records from multiple senders. Prefix coefficients must bind every field that the proxy and delegatee rely on.
7. **Model and loss.** State every AGM representation supplied by the adversary and every ROM query. Give the extraction failure probability and reduction loss rather than writing only `negligible`.

## 7. Decision gate

There are three acceptable outcomes.

- **Complete reduction:** the candidate lemma is proved with a valid extraction algorithm and the full G-CONF-CT game follows.
- **Counterexample:** a concrete algebraic adversary breaks prefix-bound aggregation or the delegated oracle, with a reproducible attack and a proof that the attack respects the stated game.
- **Known composition:** the lemma follows directly from existing signed-ElGamal extraction plus existing aggregate-signature machinery, with no new argument. In that case the candidate is a comparator and does not support a STOC novelty claim.

A passing implementation test is not evidence for any of these outcomes. The next proof attempt should begin with `n=2`, two independent witnesses, one common class base, and one adaptive delegated query. If that case is not resolved, no full construction should be implemented.

## 8. Current status

CEA remains refuted for G-CONF-CT. The prefix-bound proof candidate is open. No Batch-02 protocol, theorem, or paper claim should be built until the candidate lemma is proved, refuted, or classified as a direct known composition.
