# CipherAuth G-CONF-CT Case-3 draft 01

This package formalizes the missing Case-3 proof gate: proxy-checkable proofs of encryption randomness with prefix-bound half-aggregation. It includes the candidate lemma, the exact game obligations, and the existing unweighted-coefficient negative control.

It contains no secure construction, theorem, or novelty claim.
