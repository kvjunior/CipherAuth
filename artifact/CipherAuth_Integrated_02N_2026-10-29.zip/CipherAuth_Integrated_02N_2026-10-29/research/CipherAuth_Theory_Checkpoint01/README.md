# CipherAuth theory checkpoint 01

This checkpoint converts the unfinished Batch 01r2 theory pass into an explicit proof-or-counterexample plan. It contains the frozen Batch 01r2 archive, the existing proxy extraction note, the existing unweighted-coefficient attack probe, and the decision document.

Nothing here claims a secure construction, a confidentiality theorem, or novelty. The next review should inspect `theory/THEORY_DECISION.md` first.
