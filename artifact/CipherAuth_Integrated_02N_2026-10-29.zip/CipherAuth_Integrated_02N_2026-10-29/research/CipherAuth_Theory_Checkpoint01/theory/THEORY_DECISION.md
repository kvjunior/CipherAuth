# CipherAuth theory decision checkpoint 01

Date: 2026-10-25

## Decision

Do not write the STOC paper or a new main-construction batch yet. Freeze CipherAuth Batch 01r2 as an audited comparator and reproducibility baseline. Its 29 tests, 20 experiment cases, six proxy-reply controls, 85 baseline hashes, and v3 12/12 report establish implementation behavior; they do not establish confidentiality, extraction, or a STOC contribution.

The next deliverable is a proof-or-counterexample gate for proxy verification of compressed origin-level proofs. A passing attack script is a negative control, not evidence that the prefix-weighted candidate is secure.

## What the unfinished theory establishes

For a correctly opened record, with Q = k^{-1}A and grant mask omega,

    Abar = (omega k)^{-1} A = omega^{-1} Q.

Therefore proxy replies add no independent algebraic unknown once the reduction already has the correct Q and a consistently simulated omega. This is a conditional simulation fact. It does not solve the challenge-to-an-honest-delegatee simulation, where the reduction may not know the challenge opening or be able to sample a consistent grant transcript.

The unweighted compressed equation is concretely vulnerable to a shifted challenge point. The included probe constructs an accepted aggregate containing a chosen honest statement while using a registered rogue sender key; the original coefficient rule rejects the same aggregate. Prefix-bound coefficients reject this particular construction. That is necessary evidence for the design, not a security proof.

## Exact next gate

State one game, then either prove or refute the following lemma.

**Online aggregate-decapsulation lemma (candidate).** For an adversary that may register malicious senders, choose aggregate order, make adaptive ordinary and delegated queries, and submit adversary-crafted delegated records, a simulator given the allowed challenge interface can answer every accepted proxy/delegatee transcript with the correct distribution while extracting or otherwise obtaining each accepted record's decapsulation point Q_i. The statement must specify the token/grant interface, random-oracle programming, challenge exclusions, replay and derivative rules, and whether the target class may be served to a corrupted delegatee.

The lemma must separately cover:

1. n=1, with an exact comparison to the signed-ElGamal theorem being invoked;
2. n=2 with unweighted coefficients, including the shifted-point counterexample;
3. n=2 with prefix-bound coefficients and independent sender witnesses;
4. adaptive grants and proxy replies;
5. adversary-crafted delegated records that carry no intake proof;
6. the full aggregate and explicit reduction loss.

## Required order of work

1. Freeze the current package and record its hashes.
2. Formalize G-CONF-CLASS (the target class is never served to a corrupted party) and G-CONF-CT (per-ciphertext service). Keep them separate. CEA already fails G-CONF-CT through A-mauling; do not repair that claim by changing the game silently.
3. Verify the exact FPS20 and Chen-Zhao theorem hypotheses and compare them line by line with this setting. Chen-Zhao gives aggregate unforgeability, not this many-witness extraction lemma. Signed-ElGamal results are model-specific; state AGM+ROM, or prove a different model.
4. Attempt the six cases above in the stated order. A counterexample at any case stops the main-construction path and becomes the result.
5. Run a novelty gate against the full literature, including the IDASR26 full text and the relevant straight-line-extraction/aggregation work. If the lemma is a direct composition of known machinery, classify CipherAuth as a comparator and do not present it as a STOC theorem.
6. Only after a complete reduction or a nontrivial impossibility/lower-bound result survives this gate should a Batch 02 protocol be implemented and a paper draft begin.

## Roles and review discipline

ChatGPT should write the formal game, lemma, reduction or counterexample and its executable negative controls. Claude should independently review the concrete files and challenge every assumption. Neither passing code nor an unrebutted literature search is a proof. The authors must verify the final theorem statements and citations.

## Paper decision

The paper title should remain provisional: **CipherAuth: [the theorem that survives the gate]**. Do not choose a contribution title before the contribution exists. If the gate yields only known composition or a refutation, do not submit the current construction as a STOC 2027 main result.
