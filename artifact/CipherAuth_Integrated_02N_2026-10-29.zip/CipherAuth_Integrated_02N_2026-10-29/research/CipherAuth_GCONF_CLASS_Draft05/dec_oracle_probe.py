"""Reviewer check: in G-CONF-CLASS the DECRYPTION oracles are guarded by the commitment c,
independent of any intake proof. A mauled delegated Abar opens to None; an honestly formed
delegated record opens correctly. No intake proof is involved in opening.

Usage: python3 dec_oracle_probe.py <Batch01r2 dir containing baseline/*.zip>
(or any dir whose baseline/*.zip holds encrypted_auth_research/).
"""
import sys, zipfile, tempfile
from dataclasses import replace
from pathlib import Path

B = Path(sys.argv[1]); tmp = tempfile.mkdtemp(prefix="dec-oracle-")
zipfile.ZipFile(next((B / "baseline").glob("*.zip"))).extractall(tmp)
src = next(Path(tmp).rglob("encrypted_auth_research/src"))
sys.path.insert(0, str(src))
from cipherauth import group as g
from cipherauth.cea import CEA, Directory, SUITE, parse_body, _body
from cipherauth.models import BatchContext

D = Directory(); S = CEA(D)
sender = D.new_signing_key("sensor"); owner = D.new_signing_key("plant")
jk = D.new_decryption_key("plant", tag=b"t", epoch=1)
ell = D.new_decryption_key("auditor")              # HONEST delegatee
sub = S.signcrypt(sender, "plant", b"secret payload".ljust(32, b"\0"), b"t", 1)
agg = S.aggregate(BatchContext(SUITE, "origin", jk.ref, jk.ref, 1), [sub])
token, grant = S.issue_grant(owner, jk, ell.ref, b"t", 1)
deleg = S.delegate_aggregate(token, grant, agg)
ok = S.open_aggregate(ell, deleg)
Lam, c, Abar, E = parse_body(deleg.aggregate.records[0].body)
mauled = replace(deleg, aggregate=replace(deleg.aggregate,
         records=(replace(deleg.aggregate.records[0], body=_body(Lam, c, Abar + g.mul(7, g.G), E)),)))
print("honest_delegated_open_recovers:", ok is not None and ok[0].message.rstrip(b"\0") == b"secret payload")
print("mauled_Abar_rejected_by_commitment:", S.open_aggregate(ell, mauled) is None)
