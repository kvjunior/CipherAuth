## 6. Structural compatibility gate (D1)

The two assumptions in Section 2 cannot simply be added together and called one completed reduction. The confirmation-oracle simulation uses a DDH-deciding capability supplied to the Gap-Divisible-DH reduction: without it, the simulator cannot recognize whether a queried point `Q` satisfies `A=k*Q`. The cross-grant randomization hybrid, however, is normally justified by building a DDH distinguisher. That distinguisher does not receive a DDH oracle, because deciding DDH is the problem being reduced to. If it also receives the same oracle needed by the confirmation simulator, the reduction is no longer an ordinary DDH reduction.

Therefore the line `{DDH, Gap-Divisible-DH}` is not yet a composable theorem statement. A valid proof must use one reduction interface throughout. Candidate routes are:

1. a trapdoor or twin-DH test that answers the confirmation tests without giving the DDH distinguisher an oracle;
2. a different embedding that makes the confirmation predicate publicly simulatable;
3. a reformulated assumption that explicitly includes the required oracle and proves hardness in that oracle model; or
4. a counterexample showing that the transformed-point leakage cannot be simulated under the intended standard assumptions.

Cash, Kiltz, and Shoup's twin-Diffie–Hellman work is a relevant direction because its stated contribution is a trapdoor test that supports decision queries while retaining hardness of the underlying problem. It is only a pointer for the next proof attempt; no transfer to CipherAuth's divisible-DH, multi-grant, and confirmation setting has been established here. The exact source is the authors' ePrint paper 2008/067. 

This D1 gate changes the status of G-CONF-CLASS: completion is not routine bookkeeping. Until one of the four routes above is proved or refuted, no G-CONF-CLASS theorem should be stated, even conditionally under the separate assumptions in Section 2.
