"""Reviewer check for G-CONF-CLASS Draft 03 Section 5.

(1) Single grant: with pi = omega^-1 P and Q* = t* P, the tuple (P, pi, Q*, Abar*) is a DDH
    tuple, but the adversary lacks Q* -> not fully formable (draft's argument, correct).

(2) CROSS-GRANT: with two honest-ell target-class grants (omega1, omega2), the adversary
    computes pi1 = omega1^-1 P, pi2 = omega2^-1 P from known-witness records, and receives the
    two challenge re-encryptions Abar*_1 = omega1^-1 Q*, Abar*_2 = omega2^-1 Q*. The 4-tuple
    (pi1, Abar*_1, pi2, Abar*_2) is a DDH tuple (g, g^a, g^b, g^ab) with g=pi1, a=t*, b=omega1/omega2,
    and ALL FOUR points are adversary-known. So replacing the challenge re-encryptions by random
    points is detectable by a DDH DISTINGUISHER, with nothing hidden. The fresh-point hybrid
    therefore needs the DECISIONAL DDH assumption for the adversary, distinct from the reduction's
    Gap-Divisible-DH oracle; they coexist only because the group is pairing-free (adversary has no
    DDH oracle). Demonstrated, not a proof.

Usage: python3 gconf_crossgrant_check.py <dir with baseline/*.zip holding encrypted_auth_research/>
"""
import sys, json, zipfile, tempfile
from pathlib import Path

B = Path(sys.argv[1]); tmp = tempfile.mkdtemp(prefix="xg-")
zipfile.ZipFile(next((B / "baseline").glob("*.zip"))).extractall(tmp)
while not list(Path(tmp).rglob("encrypted_auth_research/src")):
    inner = next(Path(tmp).rglob("*.zip")); nd = tempfile.mkdtemp(prefix="xg-")
    zipfile.ZipFile(inner).extractall(nd); tmp = nd
sys.path.insert(0, str(next(Path(tmp).rglob("encrypted_auth_research/src"))))
from cipherauth import group as g
from cipherauth.cea import CEA, Directory

D = Directory(); S = CEA(D)
owner = D.new_signing_key("plant")
jk = D.new_decryption_key("plant", tag=b"t", epoch=1); k = jk.k; K = D.point(jk.ref)
ell1 = D.new_decryption_key("auditor1"); ell2 = D.new_decryption_key("auditor2")
tok1, _ = S.issue_grant(owner, jk, ell1.ref, b"t", 1)
tok2, _ = S.issue_grant(owner, jk, ell2.ref, b"t", 1)
om1 = tok1.Omega * g.inv(k) % g.q; om2 = tok2.Omega * g.inv(k) % g.q   # only to verify demo

# adversary-computable pi_g = omega_g^-1 P from a known-witness record re-encrypted under grant g
def pi(tok):
    ti = g.random_scalar()
    Abar_i = g.mul(g.inv(tok.Omega), g.mul(ti, K))
    return g.mul(g.inv(ti), Abar_i)
pi1, pi2 = pi(tok1), pi(tok2)

t_star = g.random_scalar(); Q_star = g.mul(t_star, g.G)
Abar1 = g.mul(g.inv(tok1.Omega), g.mul(t_star, K))   # = om1^-1 Q*
Abar2 = g.mul(g.inv(tok2.Omega), g.mul(t_star, K))

# (1) single-grant DDH tuple (P, pi1, Q*, Abar1): Abar1 == t*·pi1 == om1^-1·Q*
single = (Abar1 == g.mul(t_star, pi1) == g.mul(g.inv(om1), Q_star))
# (2) cross-grant 4-tuple (pi1, Abar1, pi2, Abar2) is DDH with g=pi1, a=t*, b=om1/om2 (all 4 known)
s = om1 * g.inv(om2) % g.q
cross_is_ddh = (pi2 == g.mul(s, pi1)) and (Abar2 == g.mul(s, Abar1)) and (Abar1 == g.mul(t_star, pi1))
# a random substitution for Abar2 would (whp) break the relation:
Rrand = g.mul(g.random_scalar(), g.G)
random_breaks = (Rrand != g.mul(s, Abar1))

print(json.dumps({
    "single_grant_tuple_is_DDH_but_missing_Qstar": single,
    "cross_grant_4tuple_is_DDH_and_fully_adversary_formable": cross_is_ddh,
    "random_substitution_detectably_breaks_cross_grant_relation": random_breaks,
    "implication": "fresh-point hybrid needs decisional DDH for the adversary, separate from the reduction's Gap-Divisible-DH oracle; consistent only in a pairing-free group",
}, indent=2))
