# Review of G-CONF-CLASS reduction draft 04

Reviewer: Claude, 25 Oct 2026. Diffed line by line against Draft 03 and checked against the
bundled `frozen_games.md` / `frozen_confidentiality_plan.md` (byte-identical, unchanged). Not
rewritten; **not** a theorem.

## Integration check — faithful

Draft 04 integrated the Draft-03 findings exactly:
- §2: "DDH oracle supplied to the **reduction**"; a separate paragraph adding adversarial
  decisional-DDH hardness; the `{DDH, Gap-Divisible-DH}` assumption line; the pairing-free
  restriction with the pairing-test caveat. ✓ (my H1)
- §5: the cross-grant fully-formable tuple `Ā*₁ = t*π₁, Ā*₂ = t*π₂`; "justified only by the
  adversary's ordinary decisional-DDH hardness, not by the absence of a DDH oracle or by the
  unknown `Q*`"; the random-self-reduction note; pairing-free justification. ✓ (my H1)
- §5: the non-extractable-input tightening — openability requires the `Hd/Hc` pre-queries, which
  make the input extractable at `ReEncO` time, so only the §4.1 guessing term is charged. ✓ (my H2)
- Review questions and conclusion updated; still explicitly not a theorem. ✓

No new error was introduced in the added text. If the only question were "did it integrate the
last review," the answer is yes.

## New finding — D1: the two assumptions cannot be provisioned to one reduction as written

Reviewing the *combined* reduction Draft 04 now implies, the two assumptions it lists conflict at
the level of **what oracle the reducing machine holds**. This is not bookkeeping; it is a real
design gap.

- The **confirmation / `DecO` / `ReEncO` simulation** for the target class (§4.1, §5) must decide,
  for an adversary-submitted `(A, E, c)`, whether some random-oracle query point `Q` satisfies
  `A = k*·Q` — i.e. it must **decide DDH** on `(P, K*, Q, A)`. The reduction does not know `k*`
  (the target class is the embedded honest key), so it needs a DDH-deciding capability. Draft 04
  supplies this from the Gap-Divisible-DH oracle. Fine **for the Gap reduction**.
- The **cross-grant challenge-point randomization** (§5, H1) is justified by reducing to
  **adversarial decisional DDH**. That reduction is, by definition, a **DDH distinguisher**: it
  receives one DDH instance, embeds it in the challenge re-encryption points, simulates the whole
  game for `𝒜`, and uses `𝒜`'s guess to decide its instance. A DDH distinguisher has **no**
  DDH-deciding oracle (deciding DDH is exactly its task).

The conflict: this second reduction must *also* answer target-class `DecO`/`ReEncO`, which (first
bullet) requires DDH-deciding. So the machine that proves the DDH step needs a capability that
would trivialise the very problem it is reducing to. Draft 04's reassurance — "the reduction may
use the DDH oracle supplied by Gap-Divisible-DH … while the adversary receives no DDH oracle" —
is about the *Gap* reduction; it does **not** cover the *DDH-distinguisher* reduction, which is a
different machine. "Gap-DDH" (a DDH oracle plus a DDH challenge to decide) is vacuous, so the
two-assumption split as written does not compose into one proof.

Why this is specific to CEA and not textbook DHIES: plain hashed-ElGamal (DHIES/ECIES) is
IND-CCA under Gap-CDH with **no** decisional step — `E*, c*` are random until `𝒜` queries `Q*`
(a computational, Gap event), and the decryption oracle is simulated with the gap oracle. CEA
adds something DHIES does not have: the proxy hands `𝒜` the transformed point `Ā* = ω⁻¹Q*`
(and, cross-grant, a fully formable DDH tuple). That extra leakage is what forces a decisional
step, and the decisional step is what collides with the gap-oracle-based `DecO` simulation.

## What D1 means

1. **The remaining work is not routine.** Finishing G-CONF-CLASS is not "write the DDH hybrid +
   RO bookkeeping + signature sim + bound." The DDH hybrid must be made compatible with a
   `DecO` simulation that needs no real DDH oracle. The standard escape is a **trapdoor /
   twin-DH test**: generate `K*` with a trapdoor that lets the reduction *simulate* DDH decisions
   for tuples based at `K*` using only group operations (Cash–Kiltz–Shoup, "The Twin
   Diffie-Hellman Problem and Applications," EUROCRYPT 2008 — **pointer to verify**, not a
   checked citation; I could not re-fetch it this session). With a trapdoor test the single
   reduction can both answer `DecO` and embed a decisional challenge, and the clean assumption
   becomes a (strong-twin) decisional-DH statement rather than the awkward `{DDH, Gap-Divisible-
   DH}` pair. The author must either apply that machinery and **restate the assumption line**, or
   exhibit another route. Until then the hybrid is not known to close.
2. **The assumption line in §2 is probably not the right one.** `{DDH, Gap-Divisible-DH}` reads as
   two independent assumptions, but D1 shows they are not independently usable in one reduction.
   The likely correct statement is a single trapdoor-test-compatible decisional assumption; that
   should be pinned down before any bound is written.
3. **It reopens the "known composition" question — in a useful way.** Plain DHIES is a clean known
   composition. CEA's re-encryption leakage of `ω⁻¹Q*` is *not* part of DHIES and is exactly what
   creates D1. So "G-CONF-CLASS is obviously a known composition" is no longer clear. Two
   outcomes are possible, and which one holds is worth knowing: (a) the trapdoor test absorbs the
   leakage cleanly → still a (more involved) known composition; or (b) the leakage resists the
   standard techniques → a genuine obstacle, or room for a real statement, *even in
   G-CONF-CLASS*. Either way, this is the first point in the whole thread where the answer is not
   "obviously routine," so it is the right thing to resolve.

## Honest status and one strategic note

Draft 04 is a correct, complete **skeleton** with accurate assumptions and all previously raised
subtleties integrated. It is right not to call itself a theorem. The outstanding obligations are
the ones it lists **plus D1**, and D1 is the one that is not mechanical.

Strategic (restating a point from earlier, because the effort keeps going into this piece): even
if D1 resolves cleanly via the trapdoor test, G-CONF-CLASS is at best a known composition — the
honest statement of "what CEA securely does," not a STOC contribution. With the STOC deadline on
2 Nov, the contribution question lives entirely in **Case 3 (G-CONF-CT)** and the **IDASR26 /
Kondi–shelat** literature gate, neither of which has moved. If the goal is a submission rather
than a clean internal security statement, the next drafting effort is better spent there (or on
whether D1's leakage is itself the seed of a real statement) than on further G-CONF-CLASS passes.
I'd flag D1 to ChatGPT for the next G-CONF-CLASS revision and, in parallel, start Case 3.

## Files
- `GCONF_CLASS_Draft04_Review.md` — this review.
- (prior probes `gconf_correlation_check.py`, `gconf_crossgrant_check.py` still apply; D1 is a
  proof-structure argument, so it has no new executable probe.)
