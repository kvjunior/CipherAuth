# CipherAuth Theory Checkpoint 01 — independent review and gate structuring

Reviewer: Claude, 25 Oct 2026. Role split (from the checkpoint's own decision doc): ChatGPT
writes the formal game/lemma/reduction or counterexample; Claude reviews and challenges it.
This document does the review-side work of the gate: it confirms the freeze, confirms the two
games, records the executable evidence, and pins down *where* the proof must happen and *which*
case is decisive. It deliberately does **not** contain a formal extraction reduction — that is
ChatGPT's deliverable, to be reviewed here afterward.

Nothing below is a security proof. No novelty is established.

## 1. Freeze confirmed

- `baseline/CipherAuth_Batch01r2_2026-10-25.zip` SHA-256
  `620e7f17f93f9d08c9790ee18a183bf5d203da13a4ba37d928dc9213a7b795de`, byte-identical to the
  Batch 01r2 archive reviewed and accepted for research use.
- The two confidentiality games are already written in the innermost frozen workspace
  (`encrypted_auth_research/spec/games.md`): **G-CONF-CLASS** and **G-CONF-CT**, plus
  G-AGG, G-DEL, G-SCOPE, G-KR. The confidentiality plan is `proofs/cea_confidentiality.md`.
  Step 2 of the gate (formalize the two games, keep them separate, do not silently repair
  G-CONF-CT) is therefore already satisfied by the frozen material; it needs no new game text,
  only the restatement discipline below.

## 2. The decisive structural finding: the intake proof is not load-bearing for G-CONF-CLASS

This reframes the whole gate and should be settled before any reduction is attempted.

In G-CONF-CLASS the target class is, by definition, never served to a corrupted delegatee.
The only oracles that touch the challenge class are then:
- the **decryption oracles** (origin j, and the honest delegatee ℓ that may receive target-class
  re-encryptions), and
- random-oracle and non-target grant/token queries.

The decryption oracles are guarded by the commitment `c = Hc(m, Hd(Q))`, **not** by any intake
proof. Direct check (`dec_oracle_probe.py`, run here):
- an honest delegated record opens and recovers its message;
- a mauled delegated point `Ā + 7G` opens to `None` — the commitment rejects it.

Consequently, for G-CONF-CLASS the intake proof and its aggregation are **irrelevant**: the
residual reduction is the hashed-ElGamal-with-confirmation / gap-CDH argument already sketched
in `cea_confidentiality.md`, unchanged by anything in Batch 01/01r1/01r2. The intake-proof line
exists **only** to address **G-CONF-CT** (per-ciphertext proxy service to a corrupted party),
where the proxy cannot see `c` and so cannot reject a mauled `A`.

**Recommendation.** State this split explicitly in the game file, and attempt the two games on
separate tracks:
- G-CONF-CLASS: finish the existing gap-CDH-style reduction. Candidate model: gap-CDH in the
  ROM. This does not need the intake proof and does not need any aggregate-extraction lemma.
- G-CONF-CT: this is the only track where the aggregate-decapsulation lemma is needed.

## 3. Executable evidence (reproduced here)

- Coefficient probe (`coeff_attack_output.json`, re-run against the frozen batch): honest
  aggregates verify under both unweighted and prefix-bound coefficients; the shifted-challenge
  construction is **accepted and recovers the challenge** under unweighted coefficients (both
  bits) and is **rejected** under prefix-bound coefficients (both bits). This is a necessary
  negative control for the design, not a security proof that prefix binding suffices.
- Decryption-oracle guard (`dec_oracle_probe.py`): as in Section 2.

## 4. The six cases, at status level (not proofs)

Numbering follows the checkpoint's lemma. "Signed-ElGamal" below = Schnorr-signed ElGamal; with
the relabeling `G0 = K, Y = P, x = k⁻¹` (recorded in the frozen `PROXY_EXTRACTION_NOTE.md`), a
CEA record is the signed-hashed-ElGamal shape.

1. **n = 1.** Reduces to the signed-ElGamal single-ciphertext argument. FPS20 Theorem 5 gives
   IND-CCA2 for *algebraic* adversaries in **AGM+ROM** (DL + DDH), with per-query extraction
   from the adversary's representation. ROM-only is not available: BFW15/649 rules out a broad
   class of reductions, and BFW15/648 shows Fiat–Shamir–Schnorr is not an adaptive proof. So
   case 1 is **plausible in AGM+ROM, by a known theorem**, after checking the relabeled input
   distribution and the commitment `c`. Not novel.
2. **n = 2, unweighted.** **Refuted** (coefficient probe): the shifted-point construction is
   accepted and breaks confidentiality. This is why coefficients must bind the list.
3. **n = 2, prefix-bound, independent witnesses.** **Open and decisive.** The probe shows the
   specific cancellation fails, but security needs batch knowledge-soundness: from one accepted
   compressed equation, obtain each record's decapsulation point. This is the step that is
   delicate — it is exactly where a formal AGM reduction (or a counterexample) is required, and
   it is the ChatGPT deliverable. CZ22 gives aggregate *unforgeability*, which is **not** this
   extraction statement; do not substitute it.
4. **Adaptive grants/proxy replies.** Conditional on cases 1–3: the frozen note's Lemma 2
   (`Ā = ω⁻¹Q`) shows a proxy reply adds no new algebraic unknown *once the reduction already
   has the correct Q and a consistently simulated ω*. I reviewed that algebra — it is correct as
   an equality. The open part is obtaining Q and sampling a consistent token/grant transcript
   (including `W = H(Ω)`), not the reply point itself. My 01r1 claim that proxy points are the
   likely novelty site was wrong; the checkpoint's correction stands.
5. **Adversary-crafted delegated records with no intake proof.** On the **decryption-oracle**
   side this is handled by the commitment (Section 2): a crafted `Ā` opens to `None` unless the
   adversary already knows the matching `Q`. On the **proxy** side it is the G-CONF-CT question
   (case 3). So case 5 splits cleanly and introduces nothing new beyond cases 1–3.
6. **Full aggregate + explicit loss.** Blocked on case 3.

## 5. Literature classification

- **FPS20** (EUROCRYPT 2020, Thm 5): single-ciphertext signed ElGamal, AGM+ROM, per-query
  extraction. Covers case 1. Does **not** cover a compressed multi-proof equation.
- **CZ22** (ePrint 2022/222, Thm 2): aggregate *unforgeability* of IASchnorr, AGM+ROM, tight to
  Schnorr. Not an extraction/knowledge-soundness theorem. Relevant to case 3 only by analogy.
- **BFW15/648, /649**: ROM-only adaptive extraction of Fiat–Shamir–Schnorr is blocked / a broad
  reduction class is excluded. These are the obstacles that push case 3 into the AGM (or into a
  straight-line-extractable proof system).
- **Kondi–shelat 2022/393**: straight-line extraction with signature aggregation as the
  motivating application; a ROM route for case 3 would likely route through this style (senders
  use straight-line-extractable proofs). **Full text still unread** (fetch blocked; this is my
  inference, not the paper's statement).
- **IDASR26**: still unavailable. Application overlap; may be pairing-based. Unresolved.

**Provisional classification of the candidate:** if case 3 closes by combining FPS20-style
per-proof AGM extraction with CZ22-style prefix-coefficient binding, the result is a **known
composition** and CipherAuth stays a comparator, not a STOC theorem. The one place a genuinely
new statement could appear is a batch knowledge-soundness lemma for prefix-aggregated
Fiat–Shamir proofs that is **not** a direct corollary of those two — or a counterexample/lower
bound. That has not been shown either way.

## 6. Gate decision

**The gate is not passed.** Do not write the STOC paper and do not implement Batch 02.

Remaining to pass the gate, in order:
1. Split the two games on separate tracks (Section 2). Finish G-CONF-CLASS (no intake proof,
   gap-CDH/ROM) — this is likely completable and is the honest "what CipherAuth securely does".
2. For G-CONF-CT, ChatGPT writes the case-3 lemma **or** a counterexample, with exact model,
   oracle rules, challenge exclusions, and loss. I review it against FPS20/CZ22/BFW line by line.
3. Novelty gate on the surviving statement, with IDASR26 and Kondi–shelat full texts.

A counterexample at case 3, or a "known composition" classification, is an acceptable and
publishable-elsewhere outcome; neither is a STOC 2027 main theorem. Title stays provisional.

## Files in this review package

- `THEORY_GATE_REVIEW.md` — this document.
- `dec_oracle_probe.py` — the Section 2 check (reviewer code).
- `coeff_attack_output.json` — coefficient probe output against the frozen batch.
- `aggregate_template_attack.py` — the probe source (also provided in earlier reviews).

## Sources
- FPS20, EUROCRYPT 2020: https://iacr.org/archive/eurocrypt2020/12105250/12105250.pdf (Thm 5 read via extraction)
- CZ22: https://eprint.iacr.org/2022/222
- BFW15 (adaptive PoK): https://eprint.iacr.org/2015/648 (Thm 3 read); (signed ElGamal CCA hardness): https://eprint.iacr.org/2015/649 (abstract)
- Kondi–shelat: https://eprint.iacr.org/2022/393 (abstract only; full text not retrievable here)
