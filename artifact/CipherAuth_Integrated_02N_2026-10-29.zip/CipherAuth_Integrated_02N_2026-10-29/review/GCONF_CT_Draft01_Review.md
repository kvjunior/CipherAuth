# Review of G-CONF-CT (Case 3) draft 01

Reviewer: Claude, 25 Oct 2026. Reviewed line by line against the frozen `spec/games.md`
(G-CONF-CT) and the bundled probe. Not an implementation. **Not** a theorem; I do not call the
candidate secure.

## Headline (the n=2 verdict asked for)

**n=2 looks PROVABLE in AGM+ROM — not attackable — and, more importantly, the intake-proof route
avoids the D1 obstacle that blocks G-CONF-CLASS.** But it is provable for an **augmented
construction** (CEA + aggregated intake proofs = a Batch-02 scheme), and the proof is a
composition of known pieces, so the likely classification is **known composition**, not a STOC
contribution. The single thin novelty candidate is "per-record knowledge-soundness survives
prefix half-aggregation in the AGM," which must be literature-checked before any novelty claim.

## Line checks

**Per-record proof equation (§2).** Correct. `z_iK = (r_i + c_it_i)K = R_i + c_i(t_iK) = R_i +
c_iA_i`; a Schnorr PoK of `t_i` for `A_i = t_iK` with base `K`. The binding requirements (bind
`A_i`, commitment, ciphertext, transcript prefix; omitting `A_i` → the unbound forgery; omitting
ciphertext → substitution) are right.

**Prefix-bound aggregate equation (§3).** Correct. `z̃K = Σ b_i(R_i + c_iA_i)`, `z̃ = Σ b_iz_i`.
Standard IASchnorr-style half-aggregation of the PoKs.

**Unweighted attack (§4).** Reproduced (the bundled probe is my own, verbatim):
`unweighted_attack` accepted and recovered the challenge for both bits; `prefix_weighted_same_
attack` rejected both. Correctly framed as "fixed coefficients insufficient; prefix rejection of
this cancellation is not a knowledge-soundness proof."

**Extraction lemma strength (§5) — the focus item.** The lemma is stated at the right strength
in the one respect that matters most: it demands **per-record** `Q_i`, and explicitly says a
weighted-sum extractor is insufficient. That is exactly the gap between CZ *unforgeability* and
what confidentiality needs. Two sharpenings:
1. **"…or an equivalent representation of t_i" is too loose — remove it.** The reduction needs a
   **numerically reduction-computable** `Q_i = t_iP`, because it must return the proxy response
   `Ā_i = ω⁻¹Q_i` (in G-CONF-CT it issues the corrupted-delegatee grant, so it knows ω). "The
   adversary knows `t_i`" is not enough; the extracted representation must lie over
   **reduction-known** points. Concretely (embedding `K* = aP`, challenge `A* = bP`,
   `Q* = (b/a)P`): if a served record's representation had a nonzero coefficient on `A*`, then
   `Q_i` would contain `Q*` and be uncomputable — indeed a served record depending on `A*` would
   let the corrupted delegatee back out `Q*` and win. So the lemma must force the `A*`-coefficient
   (and every unknown-log coefficient, including on earlier `Ā_j` outputs) of each served `A_i`
   to zero. State it as: *each accepted `A_i = t_iK` with `t_i` equal to its `K`-coefficient and
   zero coefficient on all other received points.*
2. **It should name the model as AGM** (the extraction is by reading algebraic representations).
   The draft says AGM+ROM in the box — good; keep the "no hidden extraction oracle" clause.

## Why n=2 is provable (sketch; the obligation to write in full)

Embedding as above; the reduction issues the corrupted-delegatee grant so it knows `ω`; it
simulates honest-origin `DecO` with the Gap-Divisible-DH DDH oracle (DHIES confirmation). For a
proxy query it must return `Ā_i = ω⁻¹Q_i` for each accepted record, so it needs each `Q_i`.

Coefficient-matching of `z̃K = Σ b_i(R_i + c_iA_i)` on the `A*`-coordinate (n=2):
`0 = (R_1[A*] + c_1A_1[A*]) + b_2(R_2[A*] + c_2A_2[A*])`, with `c_i = H_pok(ctx,A_i,R_i)` and
`b_2 = H_b(prefix)` all RO values fixed *after* the records are committed. With `b_2` independent
of a fixed record set, the two terms cancel only for one `b_2` value (prob `1/q` per prefix,
`q_agg/q` overall); otherwise each term vanishes, and within record `i`, `R_i[A*] + c_iA_i[A*]=0`
with `c_i` fixed after `A_i,R_i` forces `A_i[A*] = R_i[A*] = 0` (prob `1/q`). The same matching on
every other unknown-log basis element (`P` folded via `K*=aP`, and each `Ā_j = ω⁻¹t_jP`) forces
those coefficients to zero too, leaving `A_i = t_iK*` with `t_i = A_i[K*]` extractable and
`Q_i = t_iP` reduction-computable. The challenge `A* = bP` has `A*[K*]` not known to any submitter,
so no valid intake proof can be produced for it (or for `A*+rK`, needing `t*+r`), and the proxy
refuses it — the challenge is never transformed.

**Two bookkeeping points the full proof must nail** (this is why it is a lemma, not a line):
(a) the `P`/`a⁻¹P` and `Ā_j` folding — oracle-output points must be substituted by their known
real multiples before matching, and the matching must still force the uncomputable components to
zero; (b) the exact `1/q` terms and the per-record RO-ordering (`H_pok` and `H_b` query order),
as the draft's §6.7 demands.

I could not construct an attack on the prefix-bound n=2 case consistent with the game; I believe
it is provable, not attackable, subject to (a)–(b).

## The cross-cutting insight: G-CONF-CT avoids D1 (and the same fix would clear G-CONF-CLASS)

This is worth stating explicitly because it is counterintuitive — the "harder" per-ciphertext
game is the one that composes cleanly:

- D1 (the G-CONF-CLASS blocker) came from the adversary obtaining the **challenge's** transformed
  point `ω⁻¹Q*` (honest delegatee, no intake gate), which forced a **decisional** cross-grant
  hybrid that collided with the gap-oracle `DecO` simulation.
- In G-CONF-CT the challenge is **never transformed**: the proxy gates on the intake proof, and
  the adversary cannot prove knowledge of `t*`. So there is **no transformed-challenge leakage,
  no decisional step, and no D1**. The whole reduction is purely computational under
  Gap-Divisible-DH (plus AGM reading of representations and ROM) — the DHIES pattern.
- The intake proof converts "recognize openings via a DDH oracle" (gap) into "extract openings via
  AGM knowledge-soundness," and gates the challenge out. Adding it to the construction would
  therefore **also** remove D1 from G-CONF-CLASS (the honest-ℓ challenge re-encryption would be
  refused for the same reason). So the augmented scheme plausibly gets **both** granularities
  under one assumption set `{Gap-Divisible-DH, the per-record aggregate-extraction lemma}` in
  AGM+ROM, with no decisional DDH and no D1. This is the first coherent closure in the thread —
  but it rests entirely on the extraction lemma, and it is about the augmented (Batch-02) scheme.

## Missing restrictions / assumptions to fix

- **§5 "equivalent representation of t_i":** remove (see focus item 1).
- **Honest-origin `DecO` is still present in G-CONF-CT** (inherited from G-CONF-CLASS) and must be
  listed as simulated via the Gap oracle; the draft's §6 covers proxy service and delegated
  decryption but does not separately name the honest-origin `DecO` simulation. Add it.
- **Model caveat:** AGM is a strong idealized model and the result is about an augmented
  construction, not frozen CEA. Both facts must be stated wherever the result is cited; frozen CEA
  stays refuted for G-CONF-CT.
- **Gap-Divisible-DH** keeps the same status as elsewhere (named assumption; not gap-CDH without a
  verified reduction).

## Known-composition shortcut (flagged, as requested)

The candidate lemma most likely decomposes into: AGM Schnorr PoK knowledge-soundness
(Fuchsbauer–Kiltz–Loss / FPS20), prefix-coefficient half-aggregation (Chen–Zhao), and DHIES/ECIES
confirmation under Gap-CDH. If per-record extraction from a prefix half-aggregate is a direct
corollary of CZ's AGM argument (it looks close — the same coefficient matching, read for
representations rather than forgeries), then G-CONF-CT for the augmented scheme is a **known
composition** and not a STOC result. The only statement that might not be off-the-shelf is
"per-record knowledge-soundness (not just unforgeability) under prefix half-aggregation," which
is thin. **Literature to settle it before any novelty claim:** CZ 2022/222 (does the AGM proof
already yield per-record extraction?), FPS20 / FKL AGM Schnorr, Kondi–shelat 2022/393
(straight-line aggregate extraction, ROM), and whether any half-aggregation paper states
knowledge-soundness. And the **IDASR26 full text**, still outstanding.

## Decision

n=2 is (I believe) provable in AGM+ROM, not attackable, for the augmented scheme, and it avoids
D1 — but it is very likely a known composition. Per the draft's own gate: do **not** implement
Batch 02 or draft the paper yet. The right next artifact is the full n=2 extraction lemma with
(a)–(b) and the loss, from ChatGPT, for me to check; **in parallel**, the literature settle of
the known-composition question, which is now the thing that actually decides whether any of this
is a STOC contribution. My honest expectation remains: known composition.

## Files
- `GCONF_CT_Draft01_Review.md` — this review.
- (the unweighted-attack probe `aggregate_template_attack.py` is the bundled one, unchanged.)
