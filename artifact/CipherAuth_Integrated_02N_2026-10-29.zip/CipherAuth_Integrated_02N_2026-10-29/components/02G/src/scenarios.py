"""Public deterministic experiments. Fixture secret lives only in setup helpers."""
from dataclasses import replace
from itertools import permutations
from cipherauth02f import group as g
from cipherauth02f.transcript import Context,Record,Entry,Compressed,challenge_input,prefix_input,encode
from cipherauth02f.oracle import CHALLENGE,WEIGHT
from adaptive import Rep,Registry,TraceOracle,diagnostic


def setup(seed=0,**options):
    # Fixture x is NOT handed to Registry, TraceOracle or diagnostic.
    K=g.mul(17,g.G)
    X=g.mul(997,K)
    ctx=Context(b"origin-j",b"class-tag",7,g.encode_point(K))
    registry=Registry(ctx,g.encode_point(X))
    return ctx,registry,TraceOracle(registry,seed,**options)


def make_entry(registry,index,A_rep,R_rep):
    A=g.encode_point(registry.evaluate(A_rep))
    R=g.encode_point(registry.evaluate(R_rep))
    entry=Entry(Record(f"sender-{index}".encode(),bytes([index])*32,
                       f"opaque-{index}".encode(),A),R)
    registry.register_entry(entry,A_rep,R_rep)
    return entry


def query_order(oracle,entries,order):
    ctx=oracle.registry.context
    p=oracle.registry.register_prefix(entries)
    queries={"c1":(CHALLENGE,challenge_input(ctx,entries[0]),False),
             "c2":(CHALLENGE,challenge_input(ctx,entries[1]),False),
             "b":(WEIGHT,p,True)}
    answers={}
    for label in order:
        domain,payload,nz=queries[label]
        answers[label]=oracle.scalar(domain,payload,nonzero=nz)
    return answers


def honest(order,seed=1):
    ctx,registry,oracle=setup(seed)
    entries=(make_entry(registry,1,Rep(101,0),Rep(211,0)),
             make_entry(registry,2,Rep(102,0),Rep(212,0)))
    v=query_order(oracle,entries,order)
    Z=(211+v['c1']*101+v['b']*(212+v['c2']*102))%g.q
    agg=Compressed(ctx,entries,Z)
    result=diagnostic(agg,registry,oracle)
    return bundle("honest_"+"_".join(order),agg,registry,result)


def relation_fixture():
    ctx,registry,oracle=setup(19)
    entries=(make_entry(registry,1,Rep(3,2),Rep(211,0)),
             make_entry(registry,2,Rep(102,0),Rep(212,0)))
    v=query_order(oracle,entries,("b","c2","c1"))
    # Deliberately witness-aware adversary fixture; the diagnostic receives no 997.
    z=(211+v['c1']*(3+2*997)+v['b']*(212+v['c2']*102))%g.q
    agg=Compressed(ctx,entries,z)
    return bundle("relation_solver",agg,registry,diagnostic(agg,registry,oracle))


def simulated(position=0,duplicate=False):
    ctx,registry,oracle=setup(17,allow_programming=True)
    c,z=47,109
    special=make_entry(registry,1,Rep(0,1),Rep(z,(-c)%g.q))
    oracle.program(CHALLENGE,challenge_input(ctx,special),c)
    if duplicate:
        entries=(special,special)
        values=query_order(oracle,entries,("b","c1","c2"))
        Z=(1+values['b'])*z%g.q
    else:
        ordinary=make_entry(registry,2,Rep(102,0),Rep(212,0))
        entries=(special,ordinary) if position==0 else (ordinary,special)
        values=query_order(oracle,entries,("b","c1","c2"))
        ordinary_c=values['c2'] if position==0 else values['c1']
        ordinary_z=(212+ordinary_c*102)%g.q
        Z=(z+values['b']*ordinary_z if position==0 else ordinary_z+values['b']*z)%g.q
    agg=Compressed(ctx,entries,Z)
    return bundle("programmed_duplicate" if duplicate else f"programmed_position_{position}",
                  agg,registry,diagnostic(agg,registry,oracle))


def duplicate_exception():
    # Controlled oracle event b=-1. This is not an efficient attack on real hashes.
    ctx,registry,oracle=setup(tape=[g.q-1,23])
    entry=make_entry(registry,1,Rep(0,1),Rep(211,0))
    entries=(entry,entry)
    query_order(oracle,entries,("b","c1","c2"))
    agg=Compressed(ctx,entries,0)
    return bundle("controlled_duplicate_b_minus_one",agg,registry,diagnostic(agg,registry,oracle))


def cancellation():
    ctx,registry,oracle=setup(97)
    first=make_entry(registry,1,Rep(13,1),Rep(29,0))
    c1=oracle.scalar(CHALLENGE,challenge_input(ctx,first))
    # The second entry is chosen adaptively AFTER the first challenge answer.
    second=make_entry(registry,2,Rep(31,0),Rep(43,(-c1)%g.q))
    entries=(first,second)
    values=query_order(oracle,entries,("b","c1","c2"))
    Z=(29+c1*13+43+values['c2']*31)%g.q
    agg=Compressed(ctx,entries,Z)
    result=diagnostic(agg,registry,oracle)
    rhs=g.decode_point(first.R)+g.mul(c1,g.decode_point(first.record.A))
    rhs=rhs+g.decode_point(second.R)+g.mul(values['c2'],g.decode_point(second.record.A))
    result['unweighted_accepted']=g.mul(Z,registry.K)==rhs
    return bundle("adaptive_unweighted_cancellation",agg,registry,result)


def bundle(name,agg,registry,result):
    return {"name":name,"context_key":registry.context.key.hex(),
            "public_X":g.encode_point(registry.X).hex(),"wire":encode(agg).hex(),
            "result":result,"trace":registry.events}


def all_scenarios():
    result=[honest(order) for order in permutations(("c1","c2","b"))]
    return result+[relation_fixture(),simulated(0),simulated(1),simulated(duplicate=True),
                   duplicate_exception(),cancellation()]
