"""Rebuild each trace from public bytes/coefficients; do not trust claimed results."""
from cipherauth02f import group as g
from cipherauth02f.oracle import CHALLENGE,WEIGHT
from cipherauth02f.transcript import VERSION,MAGIC,decode,encode_context,challenge_input,prefix_input
from adaptive import Registry,TraceOracle,Rep,diagnostic


class ReplayOracle(TraceOracle):
    def scalar(self,domain,payload,*,nonzero=False):
        key=self._key(domain,payload,nonzero)
        if key not in self.table:
            raise ValueError("incomplete trace: replay may not sample missing answers")
        return super().scalar(domain,payload,nonzero=nonzero)


def replay(item):
    agg=decode(bytes.fromhex(item['wire']))
    if agg.context.key.hex()!=item['context_key']:
        raise ValueError("context mismatch")
    registry=Registry(agg.context,bytes.fromhex(item['public_X']))
    oracle=ReplayOracle(registry)
    ctx=encode_context(agg.context)
    def payload_tail(event):
        raw=bytes.fromhex(event['payload'])
        if not raw.startswith(VERSION+ctx):
            raise ValueError("wrong transcript context/version")
        return raw[len(VERSION+ctx):]
    for number,event in enumerate(item['trace']):
        if event['step']!=number:
            raise ValueError("bad event sequence")
        kind=event['kind']
        if kind=='point_register':
            registry.register_point(bytes.fromhex(event['point']),Rep(event['a'],event['b']))
        elif kind=='entry_register':
            raw=payload_tail(event)
            entry=decode(MAGIC+ctx+(1).to_bytes(4,'big')+raw+bytes(32)).entries[0]
            registry.register_entry(entry,Rep(*event['A']),Rep(*event['R']))
        elif kind=='prefix_register':
            raw=payload_tail(event)
            entries=decode(MAGIC+ctx+raw+bytes(32)).entries
            registry.register_prefix(entries)
        elif kind in ('fresh','cache','program'):
            domain=event['domain'].encode()
            payload=bytes.fromhex(event['payload'])
            key=oracle._key(domain,payload,event['nonzero'])
            value=g.validate_scalar(event['value'],nonzero=event['nonzero'])
            if kind=='cache':
                if key not in oracle.table or oracle.table[key]!=value:
                    raise ValueError("inconsistent cached answer")
            else:
                if key in oracle.table:
                    raise ValueError("overwriting assigned oracle value")
                if kind=='program':
                    if domain!=CHALLENGE:
                        raise ValueError("programmed weight outside experiment")
                    oracle.programmed.add(payload)
                oracle.table[key]=value
        else:
            raise ValueError("unknown trace event")
    # Check completeness BEFORE entering the verifier, whose public API intentionally
    # turns ValueError into False. Missing evidence is not cryptographic rejection.
    required=[(WEIGHT,prefix_input(agg.context,agg.entries),True)]
    required += [(CHALLENGE,challenge_input(agg.context,e),False) for e in agg.entries]
    if any(key not in oracle.table for key in required):
        raise ValueError("incomplete trace: final verification answer absent")
    result=diagnostic(agg,registry,oracle)
    if 'unweighted_accepted' in item['result']:
        rhs=g.IDENTITY
        for entry in agg.entries:
            key=(CHALLENGE,challenge_input(agg.context,entry),False)
            c=oracle.table[key]
            rhs=rhs+g.decode_point(entry.R)+g.mul(c,g.decode_point(entry.record.A))
        result['unweighted_accepted']=g.mul(agg.response,registry.K)==rhs
    if result!=item['result']:
        raise ValueError("claimed diagnostic does not match public trace")
    return result
