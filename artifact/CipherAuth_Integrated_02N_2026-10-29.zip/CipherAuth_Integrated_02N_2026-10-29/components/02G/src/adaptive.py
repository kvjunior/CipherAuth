"""Restricted two-point representation experiment. NOT the full CipherAuth game.

No secret class scalar, challenge logarithm or fixture witness is an input to the
registry or diagnostic. Algebraic representations must be supplied explicitly.
"""
from dataclasses import dataclass
import hashlib
import random

from cipherauth02f import group as g
from cipherauth02f.oracle import CHALLENGE, WEIGHT
from cipherauth02f.transcript import challenge_input, prefix_input, encode_entry
from cipherauth02f.kernel import verify_compressed, challenge, coefficients


@dataclass(frozen=True)
class Rep:
    a: int
    b: int

    def __post_init__(self):
        g.validate_scalar(self.a)
        g.validate_scalar(self.b)


class RepresentationConflict(ValueError):
    pass


class Registry:
    """First representation of each encoded point is immutable in this experiment."""
    def __init__(self, context, X):
        self.context = context
        self.K, self.X = g.decode_point(context.key), g.decode_point(X)
        if self.K == self.X:
            raise ValueError("distinct K and X required by this restricted fixture")
        self.points = {context.key: Rep(1, 0), X: Rep(0, 1)}
        self.entries = {}
        self.prefixes = {}
        self.events = []

    def emit(self, kind, **data):
        self.events.append({"step": len(self.events), "kind": kind, **data})

    def evaluate(self, rep):
        return g.mul(rep.a, self.K) + g.mul(rep.b, self.X)

    def register_point(self, encoded, rep):
        if type(rep) is not Rep or self.evaluate(rep) != g.decode_point(encoded):
            raise ValueError("representation does not evaluate to the supplied point")
        old = self.points.get(encoded)
        if old is not None and old != rep:
            raise RepresentationConflict("encoded point already has a different representation")
        if old is None:
            self.points[encoded] = rep
            self.emit("point_register", point=encoded.hex(), a=rep.a, b=rep.b)

    def register_entry(self, entry, A_rep, R_rep):
        self.register_point(entry.record.A, A_rep)
        self.register_point(entry.R, R_rep)
        payload = challenge_input(self.context, entry)
        if payload not in self.entries:
            self.entries[payload] = (entry, A_rep, R_rep)
            self.emit("entry_register", payload=payload.hex(), A=[A_rep.a,A_rep.b], R=[R_rep.a,R_rep.b])
        return payload

    def register_prefix(self, entries):
        if len(entries) != 2:
            raise ValueError("this experiment is restricted to two entries")
        for e in entries:
            if challenge_input(self.context,e) not in self.entries:
                raise ValueError("entries must be registered before the prefix")
        payload = prefix_input(self.context, entries)
        if payload not in self.prefixes:
            self.prefixes[payload] = entries
            self.emit("prefix_register", payload=payload.hex())
        return payload


class TraceOracle:
    """Lazy scalar ROM fixture with a complete query log.

    Seeded random.Random is for reproducibility, not cryptographic randomness.
    Optional tape and programming are labelled controlled diagnostics. Neither is
    allowed in the unprogrammed lemma. The registry is an experimental restriction.
    """
    def __init__(self, registry, seed=0, *, allow_programming=False, tape=None):
        self.registry = registry
        self.rng = random.Random(seed)
        self.allow_programming = allow_programming
        self.tape = None if tape is None else iter(tape)
        self.table = {}
        self.programmed = set()

    def _key(self, domain, payload, nonzero):
        if domain == CHALLENGE and nonzero is False and payload in self.registry.entries:
            return (domain,payload,nonzero)
        if domain == WEIGHT and nonzero is True and payload in self.registry.prefixes:
            return (domain,payload,nonzero)
        raise ValueError("query outside registered two-record experiment")

    def scalar(self, domain, payload, *, nonzero=False):
        key = self._key(domain,payload,nonzero)
        fresh = key not in self.table
        if fresh:
            value = (self.rng.randrange(1 if nonzero else 0,g.q) if self.tape is None
                     else next(self.tape))
            self.table[key] = g.validate_scalar(value,nonzero=nonzero)
        value = self.table[key]
        self.registry.emit("fresh" if fresh else "cache", domain=domain.decode(),
                           payload=payload.hex(), nonzero=nonzero, value=value,
                           source="controlled_tape" if self.tape is not None else "seeded_fixture")
        return value

    def program(self, domain, payload, value, *, nonzero=False):
        if not self.allow_programming or domain != CHALLENGE:
            raise ValueError("programming disabled or wrong domain")
        key = self._key(domain,payload,nonzero)
        if key in self.table:
            raise ValueError("programming conflict; abort")
        self.table[key] = g.validate_scalar(value,nonzero=nonzero)
        self.programmed.add(payload)
        self.registry.emit("program",domain=domain.decode(),payload=payload.hex(),
                           nonzero=nonzero,value=value)


def diagnostic(aggregate, registry, oracle):
    """Return a checked numerical opening, a DL solution, an exception, or unresolved.

    This diagnostic never asserts that a zero formal residual implies extractability.
    P=g.G is used only to turn an extracted t into Q=tP; it is not an extra symbolic
    basis input in the restricted two-point experiment.
    """
    if len(aggregate.entries) != 2:
        raise ValueError("exactly two records required")
    if not verify_compressed(registry.context,aggregate,oracle=oracle):
        return {"status":"REJECTED"}
    weights = coefficients(registry.context,aggregate.entries,oracle)
    d,e = -aggregate.response,0
    representations = []
    for weight,entry in zip(weights,aggregate.entries):
        payload=challenge_input(registry.context,entry)
        _,alpha,rho=registry.entries[payload]
        c=challenge(registry.context,entry,oracle)
        d += weight*(rho.a+c*alpha.a)
        e += weight*(rho.b+c*alpha.b)
        representations.append((alpha,payload))
    d,e=d%g.q,e%g.q
    result={"formal_K_residual":d,"formal_X_residual":e}
    if e:
        x=(-d*pow(e,-1,g.q))%g.q
        if g.mul(x,registry.K)!=registry.X:
            raise AssertionError("claimed DL solution did not verify")
        ts=[(alpha.a+alpha.b*x)%g.q for alpha,_ in representations]
        result.update(status="RELATION_SOLVED",x=x,openings=[g.encode_point(g.mul(t,g.G)).hex() for t in ts])
        return result
    if d:
        raise AssertionError("accepted equation has impossible nonzero K residual")
    unknown=[i for i,(alpha,_) in enumerate(representations) if alpha.b]
    result["unknown_positions"]=unknown
    result["openings"]=[None if alpha.b else g.encode_point(g.mul(alpha.a,g.G)).hex()
                         for alpha,_ in representations]
    if not unknown:
        result["status"]="OPENED_FROM_REPRESENTATIONS"
    elif all(representations[i][1] in oracle.programmed for i in unknown):
        result["status"]="PROGRAMMED_EXCEPTION"
    else:
        result["status"]="ZERO_RESIDUAL_UNRESOLVED"
    return result


def alias_log(old,new):
    """If two representations name the same point, recover log_K(X) when b differs.

    Caller must separately establish equality of the represented group points.
    """
    denominator=(old.b-new.b)%g.q
    return None if denominator==0 else ((new.a-old.a)*pow(denominator,-1,g.q))%g.q


def conservative_error(q,challenge_queries,prefix_queries):
    """Scoped unprogrammed lemma only; exact Fraction, no float underflow."""
    from fractions import Fraction
    if q<3 or challenge_queries<0 or prefix_queries<0:
        raise ValueError("invalid bound parameters")
    return min(Fraction(1),Fraction(challenge_queries+prefix_queries,q)
               +Fraction(2*prefix_queries,q-1))
