#!/usr/bin/env python3
import hashlib,json,subprocess,sys,tempfile,unittest,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'vendor')]
from scenarios import all_scenarios
from replay import replay


def main():
    archive=ROOT/'baseline/CipherAuth_Batch02F_Transcript_2026-10-25.zip'
    with tempfile.TemporaryDirectory() as scratch:
        with zipfile.ZipFile(archive) as z:z.extractall(scratch)
        base=Path(scratch)/'CipherAuth_Batch02F_Transcript'
        expected=(base/'results/observed.json').read_bytes()
        subprocess.run([sys.executable,str(base/'scripts/verify_manifest.py')],check=True)
        subprocess.run([sys.executable,str(base/'scripts/reproduce.py')],check=True,capture_output=True)
        if expected!=(base/'results/observed.json').read_bytes():raise RuntimeError('baseline results changed')
        baseline=json.loads(expected)
        for p in (base/'src/cipherauth02f').glob('*.py'):
            if p.read_bytes()!=(ROOT/'vendor/cipherauth02f'/p.name).read_bytes():raise RuntimeError('vendor changed')
    suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'))
    tests=unittest.TextTestRunner(verbosity=2).run(suite)
    cases=all_scenarios()
    for item in cases:replay(item)
    (ROOT/'results').mkdir(exist_ok=True)
    traces=json.dumps(cases,indent=2,sort_keys=True)+'\n'
    (ROOT/'results/traces.json').write_text(traces)
    result={'batch':'02G','baseline_tests':baseline['tests_run'],'baseline_results_byte_identical':True,
            'tests_run':tests.testsRun,'failures':len(tests.failures),'errors':len(tests.errors),
            'skipped':len(tests.skipped),'cases':len(cases),'traces_replayed':len(cases),
            'trace_sha256':hashlib.sha256(traces.encode()).hexdigest(),
            'case_statuses':{c['name']:c['result']['status'] for c in cases},
            'full_cipherauth_extraction_proved':False,'confidentiality_proved':False}
    (ROOT/'results/observed.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))
    return 0 if tests.wasSuccessful() and not tests.skipped else 1


if __name__=='__main__':sys.exit(main())
