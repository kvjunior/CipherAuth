#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
expected=json.loads((ROOT/'manifest.json').read_text())
actual={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
        for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts
        and p!=ROOT/'manifest.json'}
if actual!=expected:
    raise SystemExit('manifest mismatch: '+', '.join(sorted(k for k in set(actual)|set(expected)
                      if actual.get(k)!=expected.get(k))))
print(f'Verified {len(expected)} files.')
