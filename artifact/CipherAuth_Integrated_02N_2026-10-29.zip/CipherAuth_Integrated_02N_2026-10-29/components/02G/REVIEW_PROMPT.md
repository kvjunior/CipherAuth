# Independent review of CipherAuth Batch 02G

Start by verifying the manifest and running `scripts/reproduce.py` in a separate
copy. Confirm baseline 02F bytes/results, the new tests, and all trace replays.

The main review task is `proofs/restricted_lemma.md`, not just the code:

- Is the exact immutable two-point representation experiment well defined?
- Does the nonzero formal relation give the stated checked DL solution without
  treating group input points as a linearly independent basis?
- Are the four bad-event bounds valid for adaptively chosen prefixes, cached
  challenges, reversed query orders and identical entries sharing a hash input?
- Is counting at most one last-relevant-challenge completion per prefix justified
  even when many prefixes share an oracle query?
- Are N_c and N_b upper budgets, including verification queries, used consistently?
- Does the proof clearly exclude programmed proofs and controlled tapes?
- Does the trace checker validate registrations, all cached answers, full input bytes
  and final equations without sampling missing answers or reading hidden witnesses?
- Is the gap between this restricted experiment and ordinary AGM/PRE games stated
  accurately, especially representations inside hash-query strings, public P,
  challenge-proof exceptions and additional oracle-output points?

Try to refute the restricted lemma first. A minimal failing conditional probability
example or legal transcript is more valuable than an unsupported general assurance.
Distinguish a bad proof from a cryptanalytic attack. The b=-1 tape and programmed
challenge fixtures are known exceptions, not claimed attacks on the full scheme.

If the lemma is correct, review the proposed 02H task: specify a programmed-challenge
exception set and attempt non-exempt record extraction. Do not silently delete a
permitted query, weaken a frozen confidentiality game, or assert novelty from a
short literature search. Report patches separately; preserve the supplied archive.
