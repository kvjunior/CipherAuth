# CipherAuth Batch 02G — adaptive two-record extraction experiment

**Result:** a written extraction lemma for a restricted, unprogrammed two-point
representation experiment, plus executable traces covering adaptive query order.
The lemma needs independent review. Full CipherAuth extraction, confidentiality,
and novelty remain OPEN.

Run with Python 3.10+ and no third-party dependencies:

    python scripts/reproduce.py

This checks the unchanged nested Batch 02F, reruns its 34 tests, checks exact prior
results and vendored source bytes, then runs the new tests and replays all 12 traces.
The complete new suite has 23 tests, no failures/errors/skips. No baseline artifact
is modified. Results exclude environment-dependent timing values.

## Read first

1. `proofs/restricted_lemma.md`: full restricted argument, explicit loss, exact
   hypotheses and the programmed-challenge obstruction to extending it unchanged.
2. `spec/experiment.md`: interface and scope of the trace/registry experiment.
3. `src/adaptive.py`: public representation registry, lazy oracle and diagnostic.
4. `src/scenarios.py` and `results/traces.json`: twelve concrete experiments.
5. `src/replay.py`: independently reconstructs traces and checks declared outcomes.
6. `tests/test_adaptive.py` and `results/observed.json`: executable checks.

The restricted extractor either computes numerical openings from known K
coefficients, recovers log_K(X) from a nonzero accepted formal relation, or reports
an unresolved/explicitly programmed exception. It never reads fixture witnesses.
Its probability bound covers arbitrary order of the three relevant scalar-oracle
answers, under the written representation and freshness hypotheses. The tests do
not establish that mathematical bound; the written argument does.

The 12 trace cases are six query-order permutations, a relation-solving fixture,
three programmed-proof fixtures, a controlled rare duplicate-entry event, and an
adaptive unweighted cancellation rejected by the weighted verifier. The forced
rare event is labelled as a controlled oracle tape, not a real-hash attack.

The old transcript and construction remain frozen. There is no new decryption,
re-encryption, authorization, sender authentication, or full-game implementation.
This batch should not be described as a complete secure scheme or STOC theorem.

`manifest.json` covers shipped files except itself; run `python scripts/verify_manifest.py`.
`provenance/input_hashes.json` pins the preceding archive and copied modules;
`provenance/validation.json` records the actual runtime. `REVIEW_PROMPT.md` gives
Claude the next independent review task. No Claude review of this batch has yet occurred.

**Next: Batch 02H — attempt the programmed-challenge extension with explicit
exception/derivative rules before extending to the full oracle environment.**
