# Batch 02G experiment and trace format

The implementation imports the unchanged 02F kernel, transcript encoder, group
arithmetic and hashes from `vendor/cipherauth02f/`. The entire original 02F archive
is included under `baseline/` and rerun in a temporary directory. The 02F transcript
version remains unchanged. Batch 02G adds a restricted experimental harness, not
construction code or changes to CEA's frozen games.

`Registry(context,X)` knows only public K and X. It validates each supplied
representation Y=aK+bX using group operations. It freezes the first representation
of each point encoding; entries are registered before any query referring to them.
The trace records new point/entry/prefix registrations, every fresh/cached oracle
answer, and every explicit programmed answer. Event indices are consecutive.

`TraceOracle` accepts only the registered challenge/prefix inputs for one context
and two-entry prefixes. The ordinary seeded backend is a reproducible stand-in for
the ideal scalar ROM; Python's seeded PRNG is not a cryptographic implementation.
`allow_programming=True` and the optional value tape enable labelled negative-control
fixtures. They are excluded from the unprogrammed lemma. A previously assigned
query cannot be programmed again, even to the same value.

Hash queries include full payload bytes, not just their digests. A replay reconstructs
typed entries using the frozen decoder, validates representations and registration
order, checks cache consistency and refuses overwrites. It recomputes the aggregate
diagnostic and compares it with the declared result. Replay certifies consistency
of a concrete trace, NOT randomness of its values or honesty of an adversary.

## Diagnostic outcomes

| Outcome | Meaning |
|---|---|
| REJECTED | The frozen compressed verifier rejects the aggregate |
| OPENED_FROM_REPRESENTATIONS | Both A representations have zero X coefficient; numerical openings follow from their K coefficients |
| RELATION_SOLVED | The accepted residual supplies a checked solution to log_K X, then openings for both records |
| PROGRAMMED_EXCEPTION | Every unresolved A occurs as an exactly programmed entry; openings stay null |
| ZERO_RESIDUAL_UNRESOLVED | Accepted, zero formal residual, at least one non-exempt unresolved A; no extraction claim |

The diagnostic receives no secret k, x, t_i or individual z_i. Test setup uses
publicly documented deterministic scalars solely to build fixtures. The relation-
solver fixture deliberately constructs an accepted output using x in the fixture
author's code, then demonstrates that the separate diagnostic recovers x from
public data and representations. It is not a DL attack on a random unknown input.

## Shipped cases

Six honest cases cover every permutation of c1,c2,b first-query order. Additional
cases cover a nonzero formal relation, a programmed challenge in either position,
a duplicated programmed entry, the controlled duplicate-entry b=-1 event, and the
adaptively constructed unweighted cancellation. The last chooses R2 only after
reading c1 and is rejected by the actual weighted verifier.

No record encryption/decryption, signing keys, grants, proxy replies or full
confidentiality-game oracles are simulated. The proof ledger retains those gaps.
The code is a laboratory harness rather than a hostile-process sandbox: Python
callers are expected to use the documented methods, not mutate internal mappings.
