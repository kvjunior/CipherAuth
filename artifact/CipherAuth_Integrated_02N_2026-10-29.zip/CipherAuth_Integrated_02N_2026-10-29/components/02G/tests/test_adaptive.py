import copy
from fractions import Fraction
from itertools import permutations
import unittest
from unittest.mock import patch

from cipherauth02f import group as g
from cipherauth02f.oracle import CHALLENGE,WEIGHT
from cipherauth02f.transcript import challenge_input,prefix_input,Compressed
from adaptive import Rep,Registry,TraceOracle,RepresentationConflict,alias_log,conservative_error,diagnostic
from scenarios import setup,make_entry,honest,relation_fixture,simulated,duplicate_exception,cancellation,all_scenarios
from replay import replay


class AdaptiveTests(unittest.TestCase):
    def test_all_six_query_orders(self):
        for order in permutations(('c1','c2','b')):
            with self.subTest(order=order):
                item=honest(order)
                self.assertEqual(item['result']['status'],'OPENED_FROM_REPRESENTATIONS')
                self.assertEqual(replay(item),item['result'])
                fresh=[e for e in item['trace'] if e['kind']=='fresh']
                self.assertEqual(len(fresh),3)
                self.assertEqual(fresh[order.index('b')]['domain'],WEIGHT.decode())

    def test_unknown_log_relation_solver_uses_no_fixture_secret(self):
        item=relation_fixture()
        self.assertEqual(item['result']['status'],'RELATION_SOLVED')
        self.assertEqual(item['result']['x'],997)
        self.assertEqual(replay(item),item['result'])

    def test_numerical_openings_match_fixture_only_in_test(self):
        item=relation_fixture()
        K=g.decode_point(bytes.fromhex(item['context_key']))
        from cipherauth02f.transcript import decode
        agg=decode(bytes.fromhex(item['wire']))
        for entry,opening in zip(agg.entries,item['result']['openings']):
            # Secret 17 used only here to cross-check, never passed to diagnostic.
            self.assertEqual(g.mul(17,g.decode_point(bytes.fromhex(opening))),g.decode_point(entry.record.A))

    def test_programmed_challenge_both_positions(self):
        for position in (0,1):
            item=simulated(position)
            self.assertEqual(item['result']['status'],'PROGRAMMED_EXCEPTION')
            self.assertEqual(item['result']['unknown_positions'],[position])
            self.assertIsNone(item['result']['openings'][position])
            self.assertEqual(replay(item),item['result'])

    def test_duplicate_programmed_entry_has_two_exceptions(self):
        item=simulated(duplicate=True)
        self.assertEqual(item['result']['status'],'PROGRAMMED_EXCEPTION')
        self.assertEqual(item['result']['unknown_positions'],[0,1])
        self.assertEqual(item['result']['formal_X_residual'],0)
        replay(item)

    def test_controlled_duplicate_minus_one_event(self):
        item=duplicate_exception()
        self.assertEqual(item['result']['status'],'ZERO_RESIDUAL_UNRESOLVED')
        self.assertEqual(item['result']['unknown_positions'],[0,1])
        self.assertEqual(replay(item),item['result'])
        self.assertTrue(any(e.get('source')=='controlled_tape' for e in item['trace']))

    def test_adaptive_cancellation_public_hashes(self):
        item=cancellation()
        self.assertTrue(item['result']['unweighted_accepted'])
        self.assertEqual(item['result']['status'],'REJECTED')
        replay(item)
        steps=item['trace']
        first_c=next(e['step'] for e in steps if e['kind']=='fresh')
        entry_steps=[e['step'] for e in steps if e['kind']=='entry_register']
        self.assertLess(entry_steps[0],first_c)
        self.assertLess(first_c,entry_steps[1])

    def test_unregistered_challenge_cannot_be_queried(self):
        _,reg,ro=setup()
        with self.assertRaises(ValueError):ro.scalar(CHALLENGE,b'unknown')
        self.assertEqual(ro.table,{})

    def test_prefix_must_be_registered_before_query(self):
        ctx,reg,ro=setup()
        entries=(make_entry(reg,1,Rep(2,0),Rep(3,0)),make_entry(reg,2,Rep(4,0),Rep(5,0)))
        with self.assertRaises(ValueError):ro.scalar(WEIGHT,prefix_input(ctx,entries),nonzero=True)
        reg.register_prefix(entries)
        self.assertGreater(ro.scalar(WEIGHT,prefix_input(ctx,entries),nonzero=True),0)

    def test_wrong_domain_and_range_rejected(self):
        ctx,reg,ro=setup()
        entry=make_entry(reg,1,Rep(2,0),Rep(3,0))
        p=challenge_input(ctx,entry)
        for domain,nz in ((WEIGHT,False),(CHALLENGE,True),(b'other',False)):
            with self.assertRaises(ValueError):ro.scalar(domain,p,nonzero=nz)

    def test_invalid_representation_rejected(self):
        _,reg,_=setup()
        with self.assertRaises(ValueError):reg.register_point(g.encode_point(g.mul(2,reg.K)),Rep(3,0))
        for a,b in ((-1,0),(0,g.q),(True,0)):
            with self.assertRaises(ValueError):Rep(a,b)

    def test_alternate_representation_reveals_relation_and_is_rejected(self):
        _,reg,_=setup()
        encoded=g.encode_point(reg.X)
        with self.assertRaises(RepresentationConflict):reg.register_point(encoded,Rep(997,0))
        x=alias_log(Rep(0,1),Rep(997,0))
        self.assertEqual(g.mul(x,reg.K),reg.X)
        self.assertIsNone(alias_log(Rep(1,0),Rep(1,0)))

    def test_programming_not_default(self):
        ctx,reg,ro=setup()
        entry=make_entry(reg,1,Rep(2,0),Rep(3,0))
        with self.assertRaises(ValueError):ro.program(CHALLENGE,challenge_input(ctx,entry),17)

    def test_programming_cannot_overwrite_even_equal_answer(self):
        ctx,reg,ro=setup(allow_programming=True)
        entry=make_entry(reg,1,Rep(2,0),Rep(3,0))
        p=challenge_input(ctx,entry)
        value=ro.scalar(CHALLENGE,p)
        with self.assertRaises(ValueError):ro.program(CHALLENGE,p,value)
        self.assertEqual(ro.scalar(CHALLENGE,p),value)

    def test_duplicate_queries_are_cached(self):
        ctx,reg,ro=setup()
        entry=make_entry(reg,1,Rep(2,0),Rep(3,0))
        p=challenge_input(ctx,entry)
        self.assertEqual(ro.scalar(CHALLENGE,p),ro.scalar(CHALLENGE,p))
        self.assertEqual([e['kind'] for e in reg.events if e['kind'] in ('fresh','cache')],['fresh','cache'])

    def test_replay_detects_false_result(self):
        item=honest(('b','c1','c2'))
        item['result']['status']='RELATION_SOLVED'
        with self.assertRaises(ValueError):replay(item)

    def test_replay_never_samples_missing_answers(self):
        item=honest(('b','c1','c2'))
        # Remove every answer for c1, including cached calls. The transcript is incomplete.
        payload=next(e['payload'] for e in item['trace'] if e['kind']=='fresh' and e['domain']==CHALLENGE.decode())
        item['trace']=[e for e in item['trace'] if not (e['kind'] in ('fresh','cache') and e['payload']==payload)]
        for i,e in enumerate(item['trace']):e['step']=i
        with self.assertRaisesRegex(ValueError,'incomplete trace'):replay(item)

    def test_replay_detects_cache_corruption(self):
        item=honest(('b','c1','c2'))
        event=next(e for e in item['trace'] if e['kind']=='cache')
        event['value']=(event['value']+1)%g.q
        with self.assertRaises(ValueError):replay(item)

    def test_replay_detects_late_registration(self):
        item=honest(('b','c1','c2'))
        events=item['trace']
        first=next(i for i,e in enumerate(events) if e['kind']=='fresh')
        events.insert(0,events.pop(first))
        for i,e in enumerate(events):e['step']=i
        with self.assertRaises(ValueError):replay(item)

    def test_replay_detects_false_representation(self):
        item=honest(('b','c1','c2'))
        event=next(e for e in item['trace'] if e['kind']=='point_register')
        event['a']=(event['a']+1)%g.q
        with self.assertRaises(ValueError):replay(item)

    def test_bound_exact_and_capped(self):
        self.assertEqual(conservative_error(101,7,3),Fraction(10,101)+Fraction(6,100))
        self.assertEqual(conservative_error(5,10,10),1)
        self.assertEqual(conservative_error(5,0,0),0)

    def test_last_challenge_roots_exhaustive_f5(self):
        q=5
        for weight in range(1,q):
            for alpha in range(1,q):
                for offset in range(q):
                    roots=[c for c in range(q) if (offset+weight*alpha*c)%q==0]
                    self.assertEqual(len(roots),1)

    def test_duplicate_shared_challenge_degeneracy_exhaustive_f5(self):
        q=5
        for alpha in range(1,q):
            bad=[b for b in range(1,q) if ((1+b)*alpha)%q==0]
            self.assertEqual(bad,[q-1])


if __name__=='__main__':unittest.main()
