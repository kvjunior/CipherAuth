# A scoped two-record extraction lemma and its limit

Status: written proof for the experiment below, not yet independently reviewed.
This does not prove the full CipherAuth aggregate-extraction lemma, either
confidentiality game, or novelty. In particular, the main lemma excludes programmed
challenge proofs and additional algebraic input points.

## 1. Exact experiment

Let G be a cyclic group of prime order q>2, in additive notation, with public
nonidentity K and X=xK. For the DL-reduction interpretation, x is uniform in
F_q^* minus {1}; this matches the registry's distinct-input restriction. The
algebraic argument holds for any distinct nonidentity K,X.

The experiment fixes one context and the exact 02F entry/challenge/prefix encoding.
The only permitted symbolic input points are K and X. Before using a point Y in
a hash query, the adversary registers coefficients (a,b) satisfying Y=aK+bX.
The simulator can check that equation without x. The first representation of an
encoded point is immutable. A conflicting representation terminates the restricted
experiment; Section 6 explains why this restriction is not silently the full AGM.
Each entry's A and R representations are registered before its challenge hash or
any prefix hash containing it. The exact entry bytes determine its challenge input;
the exact ordered pair of entries determines the prefix input. Identical entries
therefore have identical registered representations and share one challenge.

Two independent ideal scalar random oracles return c in F_q and b in F_q^*,
respectively. They are lazy, cached and NEVER programmed in this lemma. Arbitrary
adaptive query order, repeated queries, and adaptive entry choices are allowed.
Final verification completes any unqueried hashes; these count toward the budgets.
There are at most N_c distinct admitted challenge inputs and N_b distinct admitted
two-entry prefix inputs throughout the experiment, including final verification.
Unrelated hash queries may be simulated independently; they do not affect an entry
except through the adversary's subsequent choices.

The adversary finally outputs two entries and Z. The standard 02F verifier tests

    ZK = R1 + c1 A1 + b (R2 + c2 A2).

The extractor receives public points, the registered coefficients, Z and the oracle
transcript. It does not receive x, the class secret k, individual responses, or
encryption witnesses. It must return t1,t2 with Ai=ti K whenever accepted, except
with the explicit error probability below. This is a restricted representation
experiment, not a PRE security game.

## 2. Straight-line algebraic extraction

Write Ai=a_i K+alpha_i X and Ri=r_i K+rho_i X. These are supplied representations,
not independent group coordinates. Define

    d = r1+c1 a1 + b(r2+c2 a2) - Z,
    e = rho1+c1 alpha1 + b(rho2+c2 alpha2).

For an accepted aggregate, the numerical group equality gives dK+eX=0.

If e!=0, calculate x_hat=-d/e in F_q. Then

    (d+e x)K=0  =>  d+e x=0  =>  x_hat=x.

The extractor checks x_hat K=X and returns t_i=a_i+alpha_i x_hat. This is an
explicit DL solver when the formal relation is nonzero; it does not equate
formal coordinates merely because the group equation holds.

If e=0, acceptance implies d=0. If alpha1=alpha2=0, return t_i=a_i.
Otherwise report extraction failure. The code reports this last case as
`ZERO_RESIDUAL_UNRESOLVED`, not a fictitious witness. Once t_i is computed, an
opening Q_i=t_i P for the original standard point P can be calculated numerically.
This last conversion is algebraic only; giving P as an additional symbolic input
to the adversary changes the experiment's proof obligations.

## 3. Adaptive error bound, including reverse hash order

Claim: in the unprogrammed experiment the probability of an accepted aggregate
on which the extractor fails is at most

    delta = min(1, (N_c+N_b)/q + 2 N_b/(q-1)).

This conservative bound is not asserted tight. It assumes ideal independent scalar
oracle answers and deterministic upper budgets N_c,N_b, not measured average counts.

For each entry define v_i=rho_i+c_i alpha_i. Consider the following events.

**E1: an individual nonzero-alpha residual vanishes.** At a fresh challenge query,
alpha_i and rho_i have already been fixed. If alpha_i!=0, the equation
rho_i+c_i alpha_i=0 fixes one c_i. A conditional union bound over fresh challenge
queries gives Pr[E1]<=N_c/q. One shared challenge counts once. Cached queries do
not create independent trials.

Fix any queried prefix containing at least one nonzero alpha_i. Its point
representations are fixed before its first weight answer. Treat challenge answers
with alpha_i=0 as irrelevant to e; those answers may still be needed by the actual
verifier but do not enter this probability calculation. The relevant oracle
assignments for e are the prefix weight and the distinct challenge answers with
nonzero alpha_i. They have a chronological last assignment. Choosing the order
adaptively does not prevent conditioning on the history before that assignment.

**E2: duplicate-entry coefficient degeneracy.** If the two entries share a challenge,
they are identical, so alpha1=alpha2 and rho1=rho2. The coefficient of the shared
c is (1+b)alpha1. For nonzero alpha1, this vanishes exactly when b=-1. At a fresh
weight query this has probability 1/(q-1). Charge at most N_b/(q-1) over prefixes.

**E3: the weight is the last relevant assignment.** At the weight query, both v_i
are already determined: any still-unqueried challenge has alpha_i=0 and therefore
does not affect v_i. Outside E1, at least one v_i is nonzero. Then v1+b v2=0 has
at most one root in F_q^*, hence conditional probability at most 1/(q-1). Charge
at most N_b/(q-1). This includes the usual challenge-before-weight order.

**E4: a challenge is the last relevant assignment.** The prefix and b have already
been assigned. If the entries have distinct challenge inputs, the coefficient
of the last relevant challenge is alpha1 or b alpha2, both nonzero in this case.
If they share an input, the coefficient is (1+b)alpha1 and is nonzero outside E2.
All other terms in e are fixed before this last fresh answer. Thus e=0 has at most
one root in F_q, with probability at most 1/q. Each prefix has at most one such
completion event, even if many prefixes share a challenge query. A union bound
over the at most N_b prefixes gives N_b/q. Independence between prefix events is
not required. This covers weight-before-challenge and the interleaved orders.

For clarity, prefix selection AFTER seeing its answers is allowed: the union is
over all queried prefixes, not just the finally selected one. Conditional event
bounds apply at each relevant assignment. No conditioning on future avoidance of
E1 or E2 is needed; bound E3/E4 only when their nonzero-coefficient conditions
already hold in the current history, and separately union with E1/E2.

If extraction fails then some alpha_i is nonzero and e=0, so E1 or E2 or E3 or E4
occurs. Summing their bounds proves the claim. The final response Z may be chosen
after all hashes; it affects d, not e, and therefore does not invalidate the bound.

## 4. Optional DL-reduction interpretation

A machine given (K,X) simulates the restricted registry and ideal scalar oracles
using public group operations. At an accepted output with e!=0 it solves the
challenge exactly as in Section 2. Therefore

    Pr[accept AND (alpha1!=0 OR alpha2!=0)] <= Adv_DL(B) + delta.

Here B has the same simulation plus polynomial overhead and uses no DDH oracle,
rewinding, or unknown class scalar. This statement is about the exact restricted
experiment, not a bound for CipherAuth confidentiality. The straight-line
extractor's failure bound itself follows from the oracle argument without assuming
DL hardness; hardness is used only for the separate acceptance inequality above.

## 5. Why a programmed challenge is outside this lemma

For A*=X choose c*,z* and form R*=z*K-c*X, then program its hash to c*. Its
representation is (r*,rho*)=(z*,-c*) and alpha*=1. Consequently

    rho*+c*alpha* = 0

with probability one. E1's fresh-uniform hypothesis is deliberately false. An
ordinary honest entry combined with this programmed entry gives a valid aggregate
in either position with d=e=0 and alpha*!=0. Duplicating the programmed entry works
too. All are reproduced by the shipped trace cases. This refutes applying the
unprogrammed lemma unchanged; it does NOT refute extraction notions that explicitly
exempt the original challenge or correctly handle challenge derivatives.

The diagnostic returns `PROGRAMMED_EXCEPTION` and a null opening at each such
position. It does not fabricate Q*. Precise exception sets for a confidentiality
game are still required: exact entry equality used by this diagnostic is not a
replacement for the frozen game's record/core/derivative rules.

The controlled trace b=-1 on duplicate ordinary unknown entries separately
demonstrates why E2 cannot be omitted. It forces a rare oracle answer as a negative
control, not a realistic efficient attack on SHA-256 or an ideal random oracle.

## 6. Transfer gap and next mathematical task

The full CipherAuth environment supplies more points than K,X, programs a valid
challenge proof, and exposes decryption and transformation interfaces. No theorem
here permits dropping those features.

If two valid representations (a,b) and (a',b') name the same point and b!=b',
then x=(a'-a)/(b-b'). The code tests this algebra and rejects representation changes
in the restricted registry. This is useful for a future reduction, but does not
alone settle when an ordinary AGM adversary is obliged to provide representations
of points occurring inside hash-query byte strings. That interface must be stated.

The next task is the **programmed-challenge extension**: define allowed challenge
replays/derivatives and try to extract every non-exempt record while retaining the
valid programmed entry. Give a precise online representation interface. Either
prove its bound or present a legal failing transcript. Only afterward extend to
additional public/oracle-output points and the exact proxy/decryption games.

This is a concrete partial lemma with a written proof, not a claim that the remaining
work is routine or that a STOC contribution has been established.
