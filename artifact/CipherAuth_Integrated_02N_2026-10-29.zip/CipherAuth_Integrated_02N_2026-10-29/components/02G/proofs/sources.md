# Prior-result check, 2026-10-25

The IACR landing-page abstracts were retrieved in this batch:

- Chen and Zhao, *Half-Aggregation of Schnorr Signatures with Tight Reductions*,
  https://eprint.iacr.org/2022/222. The abstract describes incremental half-aggregation
  with security reducing to Schnorr in AGM+ROM. It does not itself establish the
  particular extraction or PRE-game transfer needed here.
- Fuchsbauer, Plouviez and Seurin, *Blind Schnorr Signatures and Signed ElGamal
  Encryption in the Algebraic Group Model*, https://eprint.iacr.org/2019/877.
  The abstract distinguishes signed ElGamal CCA2 under DDH from signed hashed
  ElGamal key encapsulation under DL, in AGM+ROM. It does not claim aggregate PRE.

These are abstract-level checks only; no exact theorem or proof-internal transfer
was established in this batch. The restricted argument in `restricted_lemma.md`
is written out independently and makes no novelty claim. The outstanding
Kondi–shelat and IDASR26 full-text comparisons remain outstanding.
