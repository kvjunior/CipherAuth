# Independent review request for Batch 02I

Run `python scripts/reproduce.py`, then review `proofs/adaptive_extension.md` line
by line. Check that the challenge record is fixed before `(c,z)`, identity alone
is rejection-sampled, prequery/registry conflicts abort without mutation, and the
denominator `q-1` matches the conditioned nonidentity distribution.

Check the replay logic and whether every success trace really contains phase-1
queries before installation. Try to invalidate the ticket boundary or produce a
second programmed exception. Verify that the bound is described as conservative
because prequery and registry events overlap in this fixture.

Do not call this a full AGM proof or a G-CONF theorem. In particular, assess the
explicit statement that D1, the larger basis, grant/admissibility semantics and
novelty remain open.
