# Restricted adaptive-programming extension

Status: written restricted lemma and executable diagnostics, pending independent
review. No full security theorem follows.

## Statement

Adopt every restriction and conclusion of the 02H setup-first lemma, except that
the designated challenge is installed after an arbitrary phase 1 in the registered
two-point experiment. Let `N_reg` be the number of distinct registered nonidentity
points immediately before installation, including K and X. Let `q_pre` be the
number of distinct phase-1 challenge-oracle inputs. The challenge record is fixed
before the simulator samples its proof coins.

Conditioned on no adaptive-installation abort, the installed proof has the honest
Schnorr distribution and the 02H non-exempt extraction argument applies without
change. A conservative additional abort term is

`(N_reg + q_pre)/(q-1)`, capped at one.

This deliberately counts exact prequeries separately even though, in the implemented
registered-query interface, an exact prequery normally registers R and is therefore
also a point collision. The overcount makes the statement portable to a later ROM
interface where oracle queries and AGM registration are logged separately.

## Distribution and aborts

For fixed `X=xK`, the map `(c,z) -> (R=zK-cX,c)` is a bijection between
`F_q^2` and `G x F_q`. Rejection-sampling `R=O` makes `(R,c)` uniform over
`G* x F_q`, exactly the distribution from a nonzero honest nonce and a uniform
Fiat–Shamir challenge. The simulated response z then satisfies `zK=R+cX`.

For a uniform R in the q-1 encodable points, collision with the phase-1 registry
has probability at most `N_reg/(q-1)`. For the fixed challenge record, each distinct
prequery names at most one encoded R, giving `q_pre/(q-1)`. The union bound gives
the displayed term. Installation checks both conditions before changing any state.

After installation, the exact input returns the programmed value from the cache.
New entries and prefixes are handled by the same lazy oracle and coefficient rules
as 02H. The challenge ticket remains the only exception. Repetition, relabelling,
record changes and new commitments do not create another exception.

Adding the 02G/02H restricted extraction error gives

`eps <= (N_reg+q_pre)/(q-1) + (q_c+q_b)/q + 2q_b/(q-1)`,

capped at one. Query budgets include verifier queries. This is a conservative
restricted bound, not a reduction loss for the full scheme.

## Representation collisions

The experiment aborts when R* already has an encoding in the registry. If two
different `{K,X}` representations of the same point are available and their X
coefficients differ, coefficient matching directly recovers `log_K(X)`. The code
tests this algebraic fact but uses the simpler abort-and-bound proof path. An
identical representation is idempotent after installation; it is still rejected
when encountered before installation so that freshness is explicit.

## What this does not solve

1. D1 remains: the frozen game permits transforming the valid challenge for an
   honest delegatee, exposing a point the reduction still cannot compute.
2. The actual AGM basis contains P, oracle-produced points, grant material and
   aliases. `{K,X}` does not cover it.
3. The CT target-class grant/admissibility interface is ambiguous.
4. No final reduction, loss, literature comparison or novelty decision is supplied.

Thus 02I closes the timing gap only inside the restricted lemma. It must not be
quoted as completing G-CONF-CT or G-CONF-CLASS.
