# Batch 02I experiment: challenge after phase-1 queries

This batch extends the 02H two-point, two-record AGM/ROM experiment. It does not
extend the basis beyond `{K,X}`, implement the full G-CONF-CT game, or simulate
the honest-delegatee transformation of the challenge.

Phase 1 may register algebraic points and entries and query the challenge and
prefix random oracles. The challenge record, including its fields other than R,
is fixed before the simulator samples `(c*,z*)`. The simulator computes

`R* = z*K - c*X`.

It rejection-samples only the identity, matching the nonzero honest Schnorr
nonce distribution. It then aborts if the exact challenge input was already
queried or if the encoded `R*` is already in the immutable point registry.
Neither abort is resampled away. If no conflict occurs, it registers
`R* = z*K - c*X`, programs the exact challenge input to `c*`, and enters phase 2.
No further programming is allowed.

The ticket records the number of distinct phase-1 challenge queries and registered
nonidentity points before installation. The registry initially contains K and X,
so its count is at least two. Prefix queries do not themselves conflict with the
new challenge input; all later prefix and challenge queries remain lazy and cached.

Success traces contain one installed challenge, one ordinary record, all required
oracle answers and a compressed proof. Abort traces demonstrate exact prequery,
point collision and identity handling. Replay reconstructs each trace from public
bytes and refuses missing answers, altered boundaries, altered tickets, false
abort reasons and claimed results that do not match recomputation.

The implementation uses seeded randomness only for reproducible diagnostics. The
written argument concerns uniform field sampling. Passing these tests is evidence
that the stated experiment is implemented; it is not evidence of full CipherAuth
confidentiality.
