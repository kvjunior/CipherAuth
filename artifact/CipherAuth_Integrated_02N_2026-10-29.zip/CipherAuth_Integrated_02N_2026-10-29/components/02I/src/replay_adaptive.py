"""Public replay for adaptive-installation success and abort traces."""
from adaptive import Registry, Rep
from adaptive_challenge import AdaptiveAbort, AdaptiveChallengeOracle
from challenge_extension import extract_nonexempt
from cipherauth02f import group as g
from cipherauth02f.oracle import CHALLENGE, WEIGHT
from cipherauth02f.transcript import (MAGIC, VERSION, Context, Record, challenge_input,
                                      decode, encode_context, prefix_input)


def _record(data):
    return Record(bytes.fromhex(data["sender"]), bytes.fromhex(data["commitment"]),
                  bytes.fromhex(data["body"]), bytes.fromhex(data["A"]))


def _replay_events(events, reg, oracle, ctx):
    encoded_ctx = encode_context(ctx)

    def tail(value):
        raw = bytes.fromhex(value)
        if not raw.startswith(VERSION + encoded_ctx):
            raise ValueError("wrong trace context/version")
        return raw[len(VERSION + encoded_ctx):]

    for event in events:
        if event["step"] != len(reg.events):
            raise ValueError("bad event sequence")
        kind = event["kind"]
        before = len(reg.events)
        if kind == "point_register":
            reg.register_point(bytes.fromhex(event["point"]), Rep(event["a"], event["b"]))
        elif kind == "entry_register":
            raw = tail(event["payload"])
            entry = decode(MAGIC + encoded_ctx + (1).to_bytes(4, "big") + raw + bytes(32)).entries[0]
            reg.register_entry(entry, Rep(*event["A"]), Rep(*event["R"]))
        elif kind == "prefix_register":
            entries = decode(MAGIC + encoded_ctx + tail(event["payload"]) + bytes(32)).entries
            reg.register_prefix(entries)
        elif kind in ("fresh", "cache"):
            domain = event["domain"].encode()
            payload = bytes.fromhex(event["payload"])
            key = oracle._key(domain, payload, event["nonzero"])
            value = g.validate_scalar(event["value"], nonzero=event["nonzero"])
            if kind == "fresh":
                if key in oracle.table:
                    raise ValueError("oracle overwrite")
                oracle.table[key] = value
            elif oracle.table.get(key) != value:
                raise ValueError("cache mismatch")
            reg.emit(kind, domain=event["domain"], payload=event["payload"],
                     nonzero=event["nonzero"], value=value,
                     source=event.get("source", "seeded_fixture"))
        elif kind == "program":
            raise ValueError("program event must be replayed by challenge installation")
        else:
            raise ValueError("unknown trace event")
        if reg.events[before:] != [event]:
            raise ValueError("event reconstruction mismatch")


def replay(item):
    if item["kind"] == "success":
        aggregate = decode(bytes.fromhex(item["wire"]))
        ctx = aggregate.context
    elif item["kind"] == "abort":
        ctx = Context(b"origin-j", b"class-tag", 7, bytes.fromhex(item["context_key"]))
        aggregate = None
    else:
        raise ValueError("unknown case kind")
    if ctx.key.hex() != item["context_key"]:
        raise ValueError("context mismatch")
    reg = Registry(ctx, bytes.fromhex(item["public_X"]))
    oracle = AdaptiveChallengeOracle(reg)
    count = item["phase1_event_count"]
    if not 0 <= count <= len(item["trace"]):
        raise ValueError("bad phase-1 boundary")
    _replay_events(item["trace"][:count], reg, oracle, ctx)
    candidate = item["candidate"]
    before = len(reg.events)
    if item["kind"] == "abort":
        snapshot = (dict(reg.points), dict(reg.entries), dict(oracle.table), list(reg.events))
        try:
            oracle.install(_record(candidate["record"]), candidate["c"], candidate["z"])
        except AdaptiveAbort as exc:
            if exc.reason != item["abort_reason"]:
                raise ValueError("abort reason differs")
        else:
            raise ValueError("claimed abort installed a challenge")
        if snapshot != (reg.points, reg.entries, oracle.table, reg.events):
            raise ValueError("aborted installation mutated state")
        if count != len(item["trace"]):
            raise ValueError("abort trace contains post-abort events")
        return {"status": "ABORT", "reason": item["abort_reason"]}
    ticket = oracle.install(_record(candidate["record"]), candidate["c"], candidate["z"])
    installed = len(reg.events)
    if item["trace"][before:installed] != reg.events[before:installed]:
        raise ValueError("installation trace mismatch")
    expected = item["ticket"]
    if (challenge_input(ctx, ticket.entry).hex() != expected["entry"] or
            ticket.c != expected["c"] or ticket.z != expected["z"] or
            ticket.phase1_challenge_queries != expected["phase1_challenge_queries"] or
            ticket.phase1_registered_points != expected["phase1_registered_points"]):
        raise ValueError("ticket mismatch")
    _replay_events(item["trace"][installed:], reg, oracle, ctx)
    required = [(WEIGHT, prefix_input(ctx, aggregate.entries), True)]
    required += [(CHALLENGE, challenge_input(ctx, entry), False) for entry in aggregate.entries]
    if any(key not in oracle.table for key in required):
        raise ValueError("incomplete trace: final verifier answer absent")
    result = extract_nonexempt(aggregate, reg, oracle)
    if result != item["result"]:
        raise ValueError("claimed result differs from replay")
    return result
