"""Reproducible success and abort cases for Batch 02I."""
from dataclasses import asdict

from adaptive import Registry, Rep
from adaptive_challenge import AdaptiveAbort, AdaptiveChallengeOracle
from challenge_extension import extract_nonexempt
from cipherauth02f import group as g
from cipherauth02f.kernel import challenge
from cipherauth02f.oracle import CHALLENGE, WEIGHT
from cipherauth02f.transcript import (Compressed, Context, Entry, Record,
                                      challenge_input, encode, prefix_input)


def initial(seed=29):
    K = g.mul(17, g.G)
    X = g.mul(997, K)
    ctx = Context(b"origin-j", b"class-tag", 7, g.encode_point(K))
    reg = Registry(ctx, g.encode_point(X))
    return ctx, reg, AdaptiveChallengeOracle(reg, seed)


def challenge_record(reg):
    return Record(b"sender-challenge", b"C" * 32, b"challenge-body", g.encode_point(reg.X))


def entry(reg, index, alpha, rho, *, record=None):
    A = g.encode_point(reg.evaluate(alpha))
    R = g.encode_point(reg.evaluate(rho))
    if record is None:
        record = Record(f"sender-{index}".encode(), bytes([index]) * 32,
                        f"body-{index}".encode(), A)
    else:
        record = Record(record.sender, record.commitment, record.body, A)
    result = Entry(record, R)
    reg.register_entry(result, alpha, rho)
    return result


def record_json(record):
    return {"sender": record.sender.hex(), "commitment": record.commitment.hex(),
            "body": record.body.hex(), "A": record.A.hex()}


def warm_phase1(ctx, reg, oracle, *, near_miss=False):
    first = entry(reg, 2, Rep(102, 0), Rep(212, 0))
    second = entry(reg, 3, Rep(103, 0), Rep(213, 0))
    oracle.scalar(CHALLENGE, challenge_input(ctx, first))
    oracle.scalar(CHALLENGE, challenge_input(ctx, second))
    prefix = reg.register_prefix((first, second))
    oracle.scalar(WEIGHT, prefix, nonzero=True)
    if near_miss:
        # Same record core, different R: it is not the future exact hash input.
        rec = challenge_record(reg)
        near = entry(reg, 4, Rep(0, 1), Rep(313, 0), record=rec)
        oracle.scalar(CHALLENGE, challenge_input(ctx, near))
    return first, second


def success(position=0, order="weight_first", *, near_miss=False):
    ctx, reg, oracle = initial()
    first, _ = warm_phase1(ctx, reg, oracle, near_miss=near_miss)
    phase1_event_count = len(reg.events)
    ticket = oracle.install(challenge_record(reg), 47, 109)
    entries = (ticket.entry, first) if position == 0 else (first, ticket.entry)
    prefix = reg.register_prefix(entries)
    if order == "weight_first":
        b = oracle.scalar(WEIGHT, prefix, nonzero=True)
        c = oracle.scalar(CHALLENGE, challenge_input(ctx, first))
    elif order == "challenge_first":
        c = oracle.scalar(CHALLENGE, challenge_input(ctx, first))
        b = oracle.scalar(WEIGHT, prefix, nonzero=True)
    else:
        raise ValueError("unknown order")
    ordinary_z = (212 + c * 102) % g.q
    response = ((ticket.z + b * ordinary_z) if position == 0
                else (ordinary_z + b * ticket.z)) % g.q
    aggregate = Compressed(ctx, entries, response)
    # A post-install query to the programmed input must be a cache hit.
    assert challenge(ctx, ticket.entry, oracle) == ticket.c
    result = extract_nonexempt(aggregate, reg, oracle)
    return {"kind": "success", "name": f"adaptive_pos{position}_{order}"
            + ("_near_miss" if near_miss else ""),
            "wire": encode(aggregate).hex(), "context_key": ctx.key.hex(),
            "public_X": g.encode_point(reg.X).hex(),
            "phase1_event_count": phase1_event_count,
            "candidate": {"record": record_json(ticket.entry.record),
                          "c": ticket.c, "z": ticket.z},
            "ticket": {**asdict(ticket), "entry": challenge_input(ctx, ticket.entry).hex()},
            "result": result, "trace": reg.events}


def abort_case(kind):
    ctx, reg, oracle = initial()
    record = challenge_record(reg)
    c, z = 47, 109
    R = g.mul(z, reg.K) - g.mul(c, reg.X)
    if kind == "prequery":
        candidate = Entry(record, g.encode_point(R))
        reg.register_entry(candidate, Rep(0, 1), Rep(z, (-c) % g.q))
        oracle.scalar(CHALLENGE, challenge_input(ctx, candidate))
    elif kind == "representation":
        reg.register_point(g.encode_point(R), Rep(z, (-c) % g.q))
    elif kind == "identity":
        c = z = 0
    else:
        raise ValueError("unknown abort kind")
    phase1_event_count = len(reg.events)
    before = (dict(reg.points), dict(reg.entries), dict(oracle.table), list(reg.events))
    try:
        oracle.install(record, c, z)
    except AdaptiveAbort as exc:
        reason = exc.reason
    else:
        raise AssertionError("forced conflict did not abort")
    assert before == (reg.points, reg.entries, oracle.table, reg.events)
    return {"kind": "abort", "name": "adaptive_abort_" + kind,
            "context_key": ctx.key.hex(), "public_X": g.encode_point(reg.X).hex(),
            "phase1_event_count": phase1_event_count,
            "candidate": {"record": record_json(record), "c": c, "z": z},
            "abort_reason": reason, "trace": reg.events}


def all_cases():
    cases = [success(p, order) for p in (0, 1)
             for order in ("weight_first", "challenge_first")]
    cases.append(success(0, "challenge_first", near_miss=True))
    cases.extend(abort_case(kind) for kind in ("prequery", "representation", "identity"))
    return cases
