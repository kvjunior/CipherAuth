"""Adaptive challenge installation in the restricted two-point AGM/ROM experiment.

This module extends the 02H setup-first fixture.  It is deliberately not the full
CipherAuth game: points still have representations over {K,X}, batches have two
entries, and D1/honest-delegatee challenge transformation is outside its scope.
"""
from dataclasses import dataclass
from fractions import Fraction
import random

from adaptive import Rep, TraceOracle, conservative_error
from challenge_extension import Ticket
from cipherauth02f import group as g
from cipherauth02f.oracle import CHALLENGE
from cipherauth02f.transcript import Entry, challenge_input


IDENTITY = "IDENTITY_COMMITMENT"
PREQUERY = "CHALLENGE_PREQUERY"
REPRESENTATION = "REPRESENTATION_COLLISION"
ALREADY_INSTALLED = "CHALLENGE_ALREADY_INSTALLED"


class AdaptiveAbort(ValueError):
    def __init__(self, reason):
        self.reason = reason
        super().__init__(reason)


@dataclass(frozen=True)
class AdaptiveTicket(Ticket):
    phase1_challenge_queries: int
    phase1_registered_points: int


class AdaptiveChallengeOracle(TraceOracle):
    """One phase-2 challenge after arbitrary registered phase-1 queries.

    Installation is transactional: every conflict is detected before the registry
    or oracle is changed.  Later arbitrary programming remains forbidden.
    """
    def __init__(self, registry, seed=0, *, tape=None):
        super().__init__(registry, seed, allow_programming=True, tape=tape)
        self.ticket = None

    def program(self, *args, **kwargs):
        raise ValueError("only adaptive challenge installation may program an input")

    def phase1_counts(self):
        challenge_keys = {key for key in self.table if key[0] == CHALLENGE}
        return len(challenge_keys), len(self.registry.points)

    def install(self, record, c, z):
        if self.ticket is not None:
            raise AdaptiveAbort(ALREADY_INSTALLED)
        g.validate_scalar(c)
        g.validate_scalar(z)
        reg = self.registry
        if g.decode_point(record.A) != reg.X:
            raise ValueError("designated challenge must have A=X")
        R = g.mul(z, reg.K) - g.mul(c, reg.X)
        if R.is_identity:
            raise AdaptiveAbort(IDENTITY)
        entry = Entry(record, g.encode_point(R))
        payload = challenge_input(reg.context, entry)
        key = (CHALLENGE, payload, False)
        # Check the exact oracle input first.  In this registered-query model it
        # normally also implies a point collision; keeping the events separate
        # gives a conservative, auditable union bound for a more general ROM.
        if key in self.table:
            raise AdaptiveAbort(PREQUERY)
        if entry.R in reg.points:
            raise AdaptiveAbort(REPRESENTATION)
        q_pre, n_reg = self.phase1_counts()
        before_events = len(reg.events)
        reg.register_entry(entry, Rep(0, 1), Rep(z, (-c) % g.q))
        try:
            TraceOracle.program(self, CHALLENGE, payload, c)
        except Exception:
            # All possible conflicts were checked before mutation.  Reaching this
            # branch would be an implementation error, so do not disguise it as a
            # cryptographic abort.
            raise AssertionError("unexpected programming failure after preflight")
        if len(reg.events) <= before_events:
            raise AssertionError("installation emitted no trace")
        self.ticket = AdaptiveTicket(entry, c, z, q_pre, n_reg)
        return self.ticket


def sample_adaptive(oracle, record, *, seed):
    """Sample a simulated Schnorr commitment after phase 1.

    Identity is rejection-sampled because honest Schnorr uses a nonzero nonce.
    Prequery and registered-point collisions abort; they are never resampled away.
    """
    rng = random.Random(seed)
    while True:
        c, z = rng.randrange(g.q), rng.randrange(g.q)
        if not (g.mul(z, oracle.registry.K) - g.mul(c, oracle.registry.X)).is_identity:
            return oracle.install(record, c, z)


def validate_adaptive_ticket(registry, oracle):
    ticket = oracle.ticket
    if type(ticket) is not AdaptiveTicket:
        raise ValueError("missing adaptive challenge ticket")
    payload = challenge_input(registry.context, ticket.entry)
    if oracle.programmed != {payload}:
        raise ValueError("ticket is not the unique programmed challenge")
    if oracle.table.get((CHALLENGE, payload, False)) != ticket.c:
        raise ValueError("programmed value differs from ticket")
    if g.decode_point(ticket.entry.record.A) != registry.X:
        raise ValueError("ticket A is not X")
    expected = g.mul(ticket.z, registry.K) - g.mul(ticket.c, registry.X)
    if g.decode_point(ticket.entry.R) != expected:
        raise ValueError("ticket equation failed")
    return ticket, payload


def adaptive_programming_error(q, registered_points, prechallenge_queries):
    """Conservative union bound after rejection-sampling the identity.

    R* is uniform over the q-1 encodable nonidentity points.  `registered_points`
    includes the initial K and X.  In this fixture exact prequeries are a subset
    of registered-point collisions, but both terms are retained for transfer to a
    less restrictive ROM interface.
    """
    if q < 3 or registered_points < 0 or prechallenge_queries < 0:
        raise ValueError("invalid adaptive bound parameters")
    return min(Fraction(1), Fraction(registered_points + prechallenge_queries, q - 1))


def total_adaptive_error(q, registered_points, prechallenge_queries,
                         final_challenge_queries, final_prefix_queries):
    return min(Fraction(1),
               adaptive_programming_error(q, registered_points, prechallenge_queries)
               + conservative_error(q, final_challenge_queries, final_prefix_queries))
