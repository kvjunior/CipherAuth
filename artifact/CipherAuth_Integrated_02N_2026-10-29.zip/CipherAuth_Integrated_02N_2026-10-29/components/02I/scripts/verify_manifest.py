#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
expected = json.loads((ROOT / "manifest.json").read_text())
actual = {path.relative_to(ROOT).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
          for path in ROOT.rglob("*") if path.is_file() and "__pycache__" not in path.parts
          and path.suffix != ".pyc" and path != ROOT / "manifest.json"}
if actual != expected:
    changed = sorted(key for key in set(actual) | set(expected)
                     if actual.get(key) != expected.get(key))
    raise SystemExit("manifest mismatch: " + ", ".join(changed))
print(f"Verified {len(expected)} files.")
