#!/usr/bin/env python3
import hashlib
import json
import stat
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "vendor")]
from cases import all_cases
from replay_adaptive import replay


def extract_safe(archive, destination):
    with zipfile.ZipFile(archive) as handle:
        for item in handle.infolist():
            path = Path(item.filename)
            if path.is_absolute() or ".." in path.parts or stat.S_ISLNK(item.external_attr >> 16):
                raise RuntimeError("unsafe baseline archive member")
        handle.extractall(destination)


def main():
    archive = ROOT / "baseline/CipherAuth_Batch02H_Challenge_2026-10-26.zip"
    with tempfile.TemporaryDirectory() as folder:
        extract_safe(archive, folder)
        base = Path(folder) / "CipherAuth_Batch02H_Challenge"
        expected = {name: (base / "results" / name).read_bytes()
                    for name in ("observed.json", "traces.json")}
        subprocess.run([sys.executable, str(base / "scripts/verify_manifest.py")],
                       check=True, capture_output=True)
        subprocess.run([sys.executable, str(base / "scripts/reproduce.py")],
                       check=True, capture_output=True)
        for name, data in expected.items():
            if data != (base / "results" / name).read_bytes():
                raise RuntimeError("02H baseline result changed")
        comparisons = {
            base / "vendor/adaptive.py": ROOT / "vendor/adaptive.py",
            base / "src/challenge_extension.py": ROOT / "vendor/challenge_extension.py",
            base / "src/policy_projection.py": ROOT / "vendor/policy_projection.py",
        }
        for source in (base / "vendor/cipherauth02f").glob("*.py"):
            comparisons[source] = ROOT / "vendor/cipherauth02f" / source.name
        for source, copy in comparisons.items():
            if source.read_bytes() != copy.read_bytes():
                raise RuntimeError("vendored baseline module changed: " + copy.name)

    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    tests = unittest.TextTestRunner(verbosity=2).run(suite)
    cases = all_cases()
    replayed = {item["name"]: replay(item) for item in cases}
    traces = json.dumps(cases, indent=2, sort_keys=True) + "\n"
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results/traces.json").write_text(traces)
    result = {
        "batch": "02I",
        "tests_run": tests.testsRun,
        "failures": len(tests.failures),
        "errors": len(tests.errors),
        "skips": len(tests.skipped),
        "prior_tests_02H": 27,
        "prior_tests_02G": 23,
        "prior_tests_02F": 34,
        "prior_results_byte_identical": True,
        "cases": len(cases),
        "traces_replayed": len(cases),
        "trace_sha256": hashlib.sha256(traces.encode()).hexdigest(),
        "case_statuses": {name: value["status"] for name, value in replayed.items()},
        "adaptive_timing_restricted_lemma": "WRITTEN_PENDING_INDEPENDENT_REVIEW",
        "D1": "OPEN",
        "full_AGM_basis": "OPEN",
        "grant_admissibility": "OPEN",
        "full_security_proved": False,
        "frozen_games_changed": False
    }
    (ROOT / "results/observed.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if tests.wasSuccessful() and not tests.skipped else 1


if __name__ == "__main__":
    sys.exit(main())
