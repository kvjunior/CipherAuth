# CipherAuth Batch 02I — adaptive challenge timing

Batch 02I is implemented and tested as a restricted two-point, two-record
AGM/ROM experiment. It handles a challenge installed after registered phase-1
queries, with explicit exact-prequery and point-collision aborts. It does not
solve D1 or prove full CipherAuth security.

Run with Python 3.10+ and no third-party dependencies:

```sh
python scripts/reproduce.py
```

The runner first verifies and reproduces the unchanged 02H baseline, checks the
vendored 02H/02F modules byte-for-byte, runs the new tests, generates all success
and abort traces, and publicly replays them. Generated JSON is deterministic.

Read `spec/experiment.md`, `proofs/adaptive_extension.md`, and
`proofs/status.json` before using the result. The next research gate is no longer
adaptive challenge timing. It is D1, followed by the full AGM-basis transfer and
the versioned CT grant/admissibility specification.
