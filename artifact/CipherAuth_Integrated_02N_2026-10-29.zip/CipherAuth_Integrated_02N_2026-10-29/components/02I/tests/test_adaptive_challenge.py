import copy
from dataclasses import replace
from fractions import Fraction
import unittest

from adaptive import Rep, RepresentationConflict, alias_log
from adaptive_challenge import (ALREADY_INSTALLED, IDENTITY, PREQUERY, REPRESENTATION,
                                AdaptiveAbort, AdaptiveChallengeOracle,
                                adaptive_programming_error, sample_adaptive,
                                total_adaptive_error, validate_adaptive_ticket)
from cases import abort_case, all_cases, challenge_record, initial, success, warm_phase1
from cipherauth02f import group as g
from cipherauth02f.oracle import CHALLENGE, WEIGHT
from cipherauth02f.transcript import Entry, challenge_input
from replay_adaptive import replay


class AdaptiveSuccessTests(unittest.TestCase):
    def test_both_positions_and_query_orders(self):
        for position in (0, 1):
            for order in ("weight_first", "challenge_first"):
                result = replay(success(position, order))
                self.assertEqual(result["status"], "EXTRACTED_NONEXEMPT")
                self.assertEqual(result["exempt_positions"], [position])
                self.assertEqual(result["missing_nonexempt"], [])
                self.assertTrue(result["remainder"]["equation_verified"])

    def test_real_phase1_queries_precede_installation(self):
        item = success()
        kinds = [event["kind"] for event in item["trace"][:item["phase1_event_count"]]]
        self.assertIn("fresh", kinds)
        self.assertIn("prefix_register", kinds)
        self.assertGreater(item["ticket"]["phase1_challenge_queries"], 0)
        self.assertGreater(item["ticket"]["phase1_registered_points"], 2)

    def test_same_record_different_R_prequery_is_safe(self):
        item = success(near_miss=True)
        result = replay(item)
        self.assertEqual(result["status"], "EXTRACTED_NONEXEMPT")
        self.assertEqual(item["ticket"]["phase1_challenge_queries"], 3)

    def test_programmed_answer_is_cached_after_install(self):
        item = success()
        payload = item["ticket"]["entry"]
        later = [event for event in item["trace"][item["phase1_event_count"]:]
                 if event["kind"] == "cache" and event["payload"] == payload]
        self.assertTrue(later)
        self.assertTrue(all(event["value"] == item["ticket"]["c"] for event in later))

    def test_sampled_adaptive_ticket_equation(self):
        _, reg, oracle = initial()
        warm_phase1(reg.context, reg, oracle)
        ticket = sample_adaptive(oracle, challenge_record(reg), seed=405)
        validate_adaptive_ticket(reg, oracle)
        self.assertEqual(g.mul(ticket.z, reg.K),
                         g.decode_point(ticket.entry.R) + g.mul(ticket.c, reg.X))

    def test_all_cases_replay(self):
        cases = all_cases()
        self.assertEqual(len(cases), 8)
        for item in cases:
            result = replay(item)
            self.assertIn(result["status"], ("EXTRACTED_NONEXEMPT", "ABORT"))


class AdaptiveAbortTests(unittest.TestCase):
    def test_exact_prequery_aborts_transactionally(self):
        item = abort_case("prequery")
        self.assertEqual(item["abort_reason"], PREQUERY)
        self.assertEqual(replay(item), {"status": "ABORT", "reason": PREQUERY})

    def test_registered_commitment_collision_aborts(self):
        item = abort_case("representation")
        self.assertEqual(item["abort_reason"], REPRESENTATION)
        self.assertEqual(replay(item)["reason"], REPRESENTATION)

    def test_identity_commitment_aborts(self):
        item = abort_case("identity")
        self.assertEqual(item["abort_reason"], IDENTITY)
        self.assertEqual(replay(item)["reason"], IDENTITY)

    def test_second_install_aborts(self):
        _, reg, oracle = initial()
        ticket = oracle.install(challenge_record(reg), 47, 109)
        with self.assertRaises(AdaptiveAbort) as caught:
            oracle.install(ticket.entry.record, 53, 107)
        self.assertEqual(caught.exception.reason, ALREADY_INSTALLED)

    def test_late_arbitrary_programming_forbidden(self):
        ctx, reg, oracle = initial()
        ticket = oracle.install(challenge_record(reg), 47, 109)
        with self.assertRaises(ValueError):
            oracle.program(CHALLENGE, challenge_input(ctx, ticket.entry), ticket.c)

    def test_abort_priority_is_prequery_before_representation(self):
        item = abort_case("prequery")
        self.assertEqual(item["abort_reason"], PREQUERY)

    def test_wrong_A_not_counted_as_abort_event(self):
        _, reg, oracle = initial()
        bad = replace(challenge_record(reg), A=g.encode_point(g.mul(3, reg.K)))
        with self.assertRaisesRegex(ValueError, "A=X"):
            oracle.install(bad, 47, 109)


class RepresentationTests(unittest.TestCase):
    def test_post_install_alias_is_rejected_and_exposes_relation(self):
        _, reg, oracle = initial()
        ticket = oracle.install(challenge_record(reg), 47, 109)
        original = reg.points[ticket.entry.R]
        delta = 11
        alias = Rep((original.a + delta * 997) % g.q,
                    (original.b - delta) % g.q)
        self.assertEqual(reg.evaluate(original), reg.evaluate(alias))
        self.assertEqual(alias_log(original, alias), 997)
        with self.assertRaises(RepresentationConflict):
            reg.register_point(ticket.entry.R, alias)

    def test_identical_representation_reregistration_is_idempotent(self):
        _, reg, oracle = initial()
        ticket = oracle.install(challenge_record(reg), 47, 109)
        before = list(reg.events)
        reg.register_point(ticket.entry.R, reg.points[ticket.entry.R])
        self.assertEqual(before, reg.events)

    def test_ticket_records_phase1_snapshot_not_phase2_state(self):
        ctx, reg, oracle = initial()
        warm_phase1(ctx, reg, oracle)
        q_pre, n_reg = oracle.phase1_counts()
        ticket = oracle.install(challenge_record(reg), 47, 109)
        self.assertEqual((ticket.phase1_challenge_queries, ticket.phase1_registered_points),
                         (q_pre, n_reg))
        self.assertGreater(len(reg.points), n_reg)


class BoundTests(unittest.TestCase):
    def test_programming_bound_exact_fraction(self):
        self.assertEqual(adaptive_programming_error(101, 6, 3), Fraction(9, 100))

    def test_total_bound_adds_restricted_extraction_terms(self):
        self.assertEqual(total_adaptive_error(101, 6, 3, 2, 1),
                         Fraction(9, 100) + Fraction(3, 101) + Fraction(2, 100))

    def test_bounds_cap_at_one(self):
        self.assertEqual(adaptive_programming_error(5, 100, 100), 1)
        self.assertEqual(total_adaptive_error(5, 1, 1, 100, 100), 1)

    def test_invalid_bound_inputs(self):
        for args in ((2, 1, 1), (101, -1, 0), (101, 0, -1)):
            with self.assertRaises(ValueError):
                adaptive_programming_error(*args)


class ReplayIntegrityTests(unittest.TestCase):
    def test_wrong_phase1_boundary_rejected(self):
        item = success()
        item["phase1_event_count"] += 1
        with self.assertRaises(ValueError):
            replay(item)

    def test_ticket_scalar_tampering_rejected(self):
        item = success()
        item["candidate"]["z"] += 1
        with self.assertRaises(ValueError):
            replay(item)

    def test_ticket_snapshot_tampering_rejected(self):
        item = success()
        item["ticket"]["phase1_challenge_queries"] += 1
        with self.assertRaisesRegex(ValueError, "ticket mismatch"):
            replay(item)

    def test_missing_final_answer_rejected(self):
        item = success()
        payload = next(event["payload"] for event in item["trace"]
                       if event["kind"] == "fresh" and event["domain"] == WEIGHT.decode())
        item["trace"] = [event for event in item["trace"]
                         if not (event["kind"] in ("fresh", "cache") and
                                 event.get("payload") == payload)]
        for index, event in enumerate(item["trace"]):
            event["step"] = index
        with self.assertRaises(ValueError):
            replay(item)

    def test_false_abort_reason_rejected(self):
        item = abort_case("identity")
        item["abort_reason"] = PREQUERY
        with self.assertRaisesRegex(ValueError, "abort reason"):
            replay(item)

    def test_abort_trace_cannot_have_post_abort_event(self):
        item = abort_case("identity")
        extra = copy.deepcopy(item["trace"][-1]) if item["trace"] else {
            "step": 0, "kind": "point_register", "point": item["context_key"],
            "a": 1, "b": 0}
        extra["step"] = len(item["trace"])
        item["trace"].append(extra)
        with self.assertRaises(ValueError):
            replay(item)

    def test_claimed_result_tampering_rejected(self):
        item = success()
        item["result"]["status"] = "ALL_EXEMPT"
        with self.assertRaisesRegex(ValueError, "claimed result"):
            replay(item)


if __name__ == "__main__":
    unittest.main(verbosity=2)
