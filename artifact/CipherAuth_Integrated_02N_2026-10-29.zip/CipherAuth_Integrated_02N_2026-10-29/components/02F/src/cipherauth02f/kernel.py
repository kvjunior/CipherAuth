"""Compressed-only equation verifier. No claims of adaptive extraction or confidentiality."""
from . import group as g
from .errors import EncodingError
from .oracle import CHALLENGE, WEIGHT, HashOracle
from .transcript import (Entry, IndividualProof, Compressed, challenge_input,
                         prefix_input, encode, encode_context, check_entries)


def challenge(ctx, entry, oracle):
    return g.validate_scalar(oracle.scalar(CHALLENGE, challenge_input(ctx, entry)))


def coefficients(ctx, entries, oracle):
    check_entries(entries)
    encode_context(ctx)
    # Correctness-first full prefixes. This is O(n^2) hash input, not a cached chain.
    result = [1]
    for end in range(2, len(entries)+1):
        result.append(g.validate_scalar(oracle.scalar(WEIGHT, prefix_input(ctx, entries[:end]),
                                                       nonzero=True), nonzero=True))
    return tuple(result)


def prove(ctx, record, witness, *, nonce=None, oracle=None):
    """Explicit nonces are for deterministic experiments only; do not reuse them."""
    oracle = HashOracle() if oracle is None else oracle
    encode_context(ctx)
    g.validate_scalar(witness, nonzero=True)
    K = g.decode_point(ctx.key)
    if g.mul(witness, K) != g.decode_point(record.A):
        raise EncodingError("witness does not open A")
    nonce = g.random_scalar() if nonce is None else g.validate_scalar(nonce, nonzero=True)
    entry = Entry(record, g.encode_point(g.mul(nonce, K)))
    c = challenge(ctx, entry, oracle)
    return IndividualProof(entry, (nonce + c*witness) % g.q)


def verify_individual(ctx, proof, *, oracle=None):
    oracle = HashOracle() if oracle is None else oracle
    try:
        if type(proof) is not IndividualProof:
            return False
        encode_context(ctx)
        g.validate_scalar(proof.response)
        c = challenge(ctx, proof.entry, oracle)
        return g.mul(proof.response, g.decode_point(ctx.key)) == (
            g.decode_point(proof.entry.R) + g.mul(c, g.decode_point(proof.entry.record.A)))
    except (ValueError, TypeError, AttributeError):
        return False


def compress(ctx, proofs, *, oracle=None):
    oracle = HashOracle() if oracle is None else oracle
    proofs = tuple(proofs)
    entries = tuple(p.entry for p in proofs)
    check_entries(entries)
    if not all(verify_individual(ctx, p, oracle=oracle) for p in proofs):
        raise EncodingError("invalid individual proof")
    weights = coefficients(ctx, entries, oracle)
    return Compressed(ctx, entries, sum(b*p.response for b, p in zip(weights, proofs)) % g.q)


def verify_compressed(expected_context, agg, *, oracle=None):
    oracle = HashOracle() if oracle is None else oracle
    try:
        encode(agg)  # Validates every field, including scalar range and every point.
        encode_context(expected_context)
        if agg.context != expected_context:
            return False
        weights = coefficients(agg.context, agg.entries, oracle)
        rhs = g.IDENTITY
        for weight, entry in zip(weights, agg.entries):
            c = challenge(agg.context, entry, oracle)
            rhs = rhs + g.mul(weight, g.decode_point(entry.R) + g.mul(c, g.decode_point(entry.record.A)))
        return g.mul(agg.response, g.decode_point(agg.context.key)) == rhs
    except (ValueError, TypeError, AttributeError):
        return False
