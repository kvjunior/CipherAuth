"""Deterministic fixtures and an intentionally insecure unweighted negative control."""
from dataclasses import replace
import hashlib
from . import group as g
from .oracle import HashOracle
from .transcript import Context, Record, Entry, Compressed, encode
from .kernel import challenge, prove, compress, verify_compressed
from .simulation import ProgrammableOracle, simulate_challenge


def fixture(n=2):
    K = g.mul(17, g.G)
    ctx = Context(b"origin-j", b"class-tag", 7, g.encode_point(K))
    proofs = []
    for i in range(n):
        t = 101 + i
        rec = Record(b"sender-" + str(i).encode(), hashlib.sha256(bytes([i])).digest(),
                     b"opaque ciphertext " + str(i).encode(), g.encode_point(g.mul(t, K)))
        proofs.append(prove(ctx, rec, t, nonce=211+i))
    return ctx, tuple(proofs)


def cancellation(ctx, challenge_point):
    """Attack uses only K, A*, and chosen scalars. No challenge witness or class secret.

    With plus-sign Schnorr, R2=u2 K-c1 A* cancels c1 A* in the unweighted sum.
    The public hashes are recomputed on the ACTUAL records and proof commitments.
    This constructs a proof-equation counterexample, not a complete PRE attack.
    """
    oracle = HashOracle()
    K, star = g.decode_point(ctx.key), g.decode_point(challenge_point)
    r, u1, a2, u2 = 13, 29, 31, 43
    first = Entry(Record(b"attacker-1", b"1"*32, b"body-1", g.encode_point(star+g.mul(r, K))),
                  g.encode_point(g.mul(u1, K)))
    c1 = challenge(ctx, first, oracle)
    second = Entry(Record(b"attacker-2", b"2"*32, b"body-2", g.encode_point(g.mul(a2, K))),
                   g.encode_point(g.mul(u2, K)-g.mul(c1, star)))
    c2 = challenge(ctx, second, oracle)
    z = (u1+c1*r+u2+c2*a2) % g.q
    return Compressed(ctx, (first, second), z)


def verify_unweighted_control(agg):
    """Deliberately insecure test control. Never used by the real kernel verifier."""
    encode(agg)
    oracle = HashOracle()
    rhs = g.IDENTITY
    for entry in agg.entries:
        rhs = rhs + g.decode_point(entry.R) + g.mul(challenge(agg.context, entry, oracle),
                                                   g.decode_point(entry.record.A))
    return g.mul(agg.response, g.decode_point(agg.context.key)) == rhs


def report():
    ctx, proofs = fixture()
    agg = compress(ctx, proofs)
    attack = cancellation(ctx, g.encode_point(g.mul(997, g.G)))
    ro = ProgrammableOracle(1)
    simulated = simulate_challenge(ctx, proofs[0].entry.record, ro, seed=2)
    mixed_honest = prove(ctx, proofs[1].entry.record, 102, nonce=401, oracle=ro)
    simulated_agg = compress(ctx, (simulated, mixed_honest), oracle=ro)
    wire = encode(agg)
    return {
        "honest_two_record_accepted": verify_compressed(ctx, agg),
        "unweighted_cancellation_accepted": verify_unweighted_control(attack),
        "same_cancellation_prefix_weighted_accepted": verify_compressed(ctx, attack),
        "programmed_challenge_aggregate_accepted": verify_compressed(ctx, simulated_agg, oracle=ro),
        "response_tamper_accepted": verify_compressed(ctx, replace(agg, response=(agg.response+1)%g.q)),
        "wire_bytes_fixture_n2": len(wire),
        "proof_bytes_n2_excluding_records_context_framing": 2*33+32,
        "wire_sha256": hashlib.sha256(wire).hexdigest(),
        "full_extraction_proved": False,
        "confidentiality_proved": False,
    }
