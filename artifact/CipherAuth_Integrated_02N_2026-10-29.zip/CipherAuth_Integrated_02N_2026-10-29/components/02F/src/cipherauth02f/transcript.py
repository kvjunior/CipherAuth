"""Versioned canonical bytes. Public point fields are immutable SEC1 bytes."""
from dataclasses import dataclass
from . import group as g
from .errors import EncodingError

VERSION = b"CipherAuth/02F/v1"
MAGIC = b"CAF02F\x01"
MAX_META = 1024
MAX_BODY = 1 << 20
MAX_RECORDS = 256


def u32(n):
    if type(n) is not int or not 0 <= n < 2**32:
        raise EncodingError("invalid uint32")
    return n.to_bytes(4, "big")


def blob(b, limit, *, nonempty=False):
    if type(b) is not bytes or len(b) > limit or (nonempty and not b):
        raise EncodingError("invalid byte field")
    return u32(len(b)) + b


def point(b):
    g.decode_point(b)
    return b


@dataclass(frozen=True)
class Context:
    origin: bytes
    tag: bytes
    epoch: int
    key: bytes


@dataclass(frozen=True)
class Record:
    sender: bytes
    commitment: bytes
    body: bytes
    A: bytes


@dataclass(frozen=True)
class Entry:
    record: Record
    R: bytes


@dataclass(frozen=True)
class IndividualProof:
    entry: Entry
    response: int


@dataclass(frozen=True)
class Compressed:
    context: Context
    entries: tuple[Entry, ...]
    response: int


def encode_context(ctx):
    if type(ctx) is not Context or type(ctx.epoch) is not int or not 0 <= ctx.epoch < 2**64:
        raise EncodingError("invalid context")
    return (blob(ctx.origin, MAX_META, nonempty=True) + blob(ctx.tag, MAX_META, nonempty=True)
            + ctx.epoch.to_bytes(8, "big") + point(ctx.key))


def encode_record(rec):
    if type(rec) is not Record or type(rec.commitment) is not bytes or len(rec.commitment) != 32:
        raise EncodingError("invalid record")
    return (blob(rec.sender, MAX_META, nonempty=True) + rec.commitment
            + blob(rec.body, MAX_BODY) + point(rec.A))


def encode_entry(entry):
    if type(entry) is not Entry:
        raise EncodingError("invalid entry")
    return encode_record(entry.record) + point(entry.R)


def challenge_input(ctx, entry):
    return VERSION + encode_context(ctx) + encode_entry(entry)


def prefix_input(ctx, entries):
    check_entries(entries)
    return VERSION + encode_context(ctx) + u32(len(entries)) + b"".join(map(encode_entry, entries))


def check_entries(entries):
    if type(entries) is not tuple or not 1 <= len(entries) <= MAX_RECORDS:
        raise EncodingError("expected 1..256 entries in a tuple")


def encode(agg):
    if type(agg) is not Compressed:
        raise EncodingError("invalid aggregate")
    check_entries(agg.entries)
    return (MAGIC + encode_context(agg.context) + u32(len(agg.entries))
            + b"".join(map(encode_entry, agg.entries)) + g.encode_scalar(agg.response))


class Reader:
    def __init__(self, data):
        if type(data) is not bytes:
            raise EncodingError("bytes required")
        self.data, self.pos = data, 0

    def take(self, n):
        if n > len(self.data) - self.pos:
            raise EncodingError("truncated input")
        result = self.data[self.pos:self.pos+n]
        self.pos += n
        return result

    def integer(self, n):
        return int.from_bytes(self.take(n), "big")

    def blob(self, limit):
        n = self.integer(4)
        if n > limit:
            raise EncodingError("field too long")
        return self.take(n)


def decode(data):
    reader = Reader(data)
    if reader.take(len(MAGIC)) != MAGIC:
        raise EncodingError("wrong version")
    ctx = Context(reader.blob(MAX_META), reader.blob(MAX_META), reader.integer(8), reader.take(33))
    n = reader.integer(4)
    if not 1 <= n <= MAX_RECORDS:
        raise EncodingError("invalid count")
    entries = tuple(Entry(Record(reader.blob(MAX_META), reader.take(32), reader.blob(MAX_BODY),
                                 reader.take(33)), reader.take(33)) for _ in range(n))
    agg = Compressed(ctx, entries, reader.integer(32))
    if reader.pos != len(data) or encode(agg) != data:
        raise EncodingError("noncanonical encoding")
    return agg
