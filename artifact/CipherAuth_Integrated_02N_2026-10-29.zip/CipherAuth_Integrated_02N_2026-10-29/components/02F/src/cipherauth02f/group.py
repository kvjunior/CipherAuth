"""NIST P-256 group arithmetic for the research constructions, with input validation.

Pure Python, affine coordinates, NOT constant-time: research prototype only.
Separate from the frozen legacy baseline arithmetic (baselines/claude_v3/source/ec.py).
Counted: scalar-multiplication calls ("mul"), explicit inversions modulo the group order q
("scalar_inv"), hash calls and hash-input bytes. NOT counted separately: point additions and
the field inversions modulo p that affine point addition performs internally; in the cost
model those are part of a scalar multiplication. No runtime conclusion follows from counts.
"""
import hashlib
import secrets
from .errors import EncodingError

p = 0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF
a = p - 3
b = 0x5AC635D8AA3A93E7B3EBBD55769886BC651D06B0CC53B0F63BCE3C3E27D2604B
q = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551
_GX = 0x6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296
_GY = 0x4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5

POINT_BYTES = 33
SCALAR_BYTES = 32

COUNTS = {"mul": 0, "scalar_inv": 0, "hash": 0, "hash_bytes": 0}


def reset_counts():
    for k in COUNTS:
        COUNTS[k] = 0


class Point:
    __slots__ = ("x", "y")

    def __init__(self, x, y):
        self.x, self.y = x, y

    @property
    def is_identity(self):
        return self.x is None

    def __eq__(self, other):
        return isinstance(other, Point) and self.x == other.x and self.y == other.y

    def __hash__(self):
        return hash((self.x, self.y))

    def __add__(self, other):
        return _add(self, other)

    def __neg__(self):
        return self if self.is_identity else Point(self.x, (-self.y) % p)

    def __sub__(self, other):
        return _add(self, -other)

    def __repr__(self):
        return "Point(identity)" if self.is_identity else f"Point({self.x:#x})"[:24] + "...)"


IDENTITY = Point(None, None)
G = Point(_GX, _GY)


def _on_curve(x, y):
    return (y * y - (x * x * x + a * x + b)) % p == 0


def _add(P1, P2):
    if P1.is_identity:
        return P2
    if P2.is_identity:
        return P1
    if P1.x == P2.x and (P1.y + P2.y) % p == 0:
        return IDENTITY
    if P1 == P2:
        lam = (3 * P1.x * P1.x + a) * pow(2 * P1.y, -1, p) % p
    else:
        lam = (P2.y - P1.y) * pow(P2.x - P1.x, -1, p) % p
    x3 = (lam * lam - P1.x - P2.x) % p
    return Point(x3, (lam * (P1.x - x3) - P1.y) % p)


def mul(k, P):
    """Scalar multiplication (counted). P-256 has cofactor 1, so every curve point is in the group."""
    if not isinstance(k, int) or not isinstance(P, Point):
        raise TypeError("mul(int, Point) required")
    COUNTS["mul"] += 1
    k %= q
    acc, base = IDENTITY, P
    while k:
        if k & 1:
            acc = _add(acc, base)
        base = _add(base, base)
        k >>= 1
    return acc


def inv(k):
    """Modular inverse in Z_q (counted). Zero has no inverse."""
    if k % q == 0:
        raise ZeroDivisionError("zero scalar has no inverse")
    COUNTS["scalar_inv"] += 1
    return pow(k, -1, q)


def random_scalar():
    return secrets.randbelow(q - 1) + 1


def encode_point(P):
    """Compressed SEC1. The identity is never a valid encoded group element here."""
    if P.is_identity:
        raise EncodingError("the identity element is not encodable")
    return bytes([2 + (P.y & 1)]) + P.x.to_bytes(32, "big")


def decode_point(data):
    """Validate and decode a compressed point; rejects malformed, off-curve and identity encodings."""
    if not isinstance(data, bytes) or len(data) != POINT_BYTES or data[0] not in (2, 3):
        raise EncodingError("malformed point encoding")
    x = int.from_bytes(data[1:], "big")
    if x >= p:
        raise EncodingError("x coordinate out of range")
    rhs = (x * x * x + a * x + b) % p
    y = pow(rhs, (p + 1) // 4, p)          # p = 3 mod 4
    if y * y % p != rhs:
        raise EncodingError("not a curve point")
    if (y & 1) != (data[0] & 1):
        y = p - y
    return Point(x, y)


def validate_point(P):
    if not isinstance(P, Point) or P.is_identity or not (0 <= P.x < p and 0 <= P.y < p) or not _on_curve(P.x, P.y):
        raise EncodingError("invalid group element")
    return P


def validate_scalar(s, *, nonzero=False):
    if not isinstance(s, int) or isinstance(s, bool) or not (0 <= s < q) or (nonzero and s == 0):
        raise EncodingError("scalar out of range")
    return s


def encode_scalar(s):
    return validate_scalar(s).to_bytes(SCALAR_BYTES, "big")


def hash_bytes(domain, data, outlen=32):
    """Counted SHA-256 (counter mode for longer outputs) over domain-separated, pre-encoded input."""
    if not isinstance(domain, str) or not domain or not isinstance(data, bytes):
        raise EncodingError("hash requires a nonempty domain and bytes")
    out = b""
    counter = 0
    while len(out) < outlen:
        block = domain.encode() + b"\x00" + counter.to_bytes(4, "big") + data
        COUNTS["hash"] += 1
        COUNTS["hash_bytes"] += len(block)
        out += hashlib.sha256(block).digest()
        counter += 1
    return out[:outlen]


def hash_to_scalar(domain, data):
    """Wide reduction (64 bytes -> Z_q) to keep the bias negligible."""
    return int.from_bytes(hash_bytes(domain, data, 64), "big") % q
