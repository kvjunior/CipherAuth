class EncodingError(ValueError):
    pass

class KeyConflict(ValueError):
    pass

class InvalidContext(ValueError):
    pass

class OpenResearchProblem(NotImplementedError):
    """A requested cryptographic operation has no implemented, justified construction."""
