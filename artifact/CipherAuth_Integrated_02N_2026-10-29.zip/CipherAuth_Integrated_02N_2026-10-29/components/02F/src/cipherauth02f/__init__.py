"""CipherAuth 02F: experimental compressed intake-proof kernel, not a PRE scheme."""
