"""TEST ONLY: lazy programmable scalar random oracle and challenge-proof fixture.

This backend is not SHA-256 and is not a cryptographic implementation. Its PRNG
supports reproducible tests only. No full reduction or distribution theorem here.
"""
import random
from . import group as g
from .oracle import CHALLENGE
from .transcript import Entry, IndividualProof, challenge_input


class ProgrammingConflict(ValueError):
    pass


class ProgrammableOracle:
    def __init__(self, seed):
        self.rng = random.Random(seed)
        self.table = {}

    def scalar(self, domain, payload, *, nonzero=False):
        key = (domain, payload, nonzero)
        if key not in self.table:
            self.table[key] = self.rng.randrange(1 if nonzero else 0, g.q)
        return self.table[key]

    def program(self, domain, payload, value, *, nonzero=False):
        g.validate_scalar(value, nonzero=nonzero)
        key = (domain, payload, nonzero)
        if key in self.table:
            raise ProgrammingConflict("oracle input already assigned; simulation must abort")
        self.table[key] = value


def simulate_challenge(ctx, record, oracle, *, seed):
    """No witness argument. Choose c,z, construct R=zK-cA, then program one fresh input.

Reject identity R to match the parser. A prequeried hash input raises a conflict;
bounding that event and matching distributions are outstanding proof obligations.
"""
    rng = random.Random(seed)
    K, A = g.decode_point(ctx.key), g.decode_point(record.A)
    while True:
        c, z = rng.randrange(g.q), rng.randrange(g.q)
        R = g.mul(z, K) - g.mul(c, A)
        if not R.is_identity:
            break
    entry = Entry(record, g.encode_point(R))
    oracle.program(CHALLENGE, challenge_input(ctx, entry), c)
    return IndividualProof(entry, z)
