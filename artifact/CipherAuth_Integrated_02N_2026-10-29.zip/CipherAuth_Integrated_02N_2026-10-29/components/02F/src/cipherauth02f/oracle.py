"""Domain-separated SHA-256 with rejection sampling; no programmable production API."""
import hashlib
from . import group as g
from .transcript import blob, u32

CHALLENGE = b"CipherAuth/02F/challenge/v1"
WEIGHT = b"CipherAuth/02F/prefix-weight/v1"


class HashOracle:
    def scalar(self, domain, payload, *, nonzero=False):
        # Including the range flag prevents reuse between distinct scalar ranges.
        seed = blob(domain, 1024, nonempty=True) + bytes([nonzero]) + blob(payload, 2**32-1)
        for counter in range(2**32):
            value = int.from_bytes(hashlib.sha256(seed + u32(counter)).digest(), "big")
            if value < g.q and (not nonzero or value != 0):
                return value
        raise RuntimeError("hash rejection counter exhausted")
