#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def files():
    return {p.relative_to(ROOT).as_posix(): p for p in ROOT.rglob("*")
            if p.is_file() and "__pycache__" not in p.parts
            and p != ROOT / "manifest.json"}


def main():
    expected = json.loads((ROOT / "manifest.json").read_text())
    actual = {name: hashlib.sha256(p.read_bytes()).hexdigest() for name, p in files().items()}
    if actual != expected:
        differences = sorted(k for k in set(actual) | set(expected) if actual.get(k) != expected.get(k))
        raise SystemExit("manifest mismatch: " + ", ".join(differences))
    print(f"Verified {len(expected)} files.")


if __name__ == "__main__":
    main()
