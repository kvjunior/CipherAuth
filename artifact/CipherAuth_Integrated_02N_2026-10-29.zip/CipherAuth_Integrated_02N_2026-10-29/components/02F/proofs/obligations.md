# Correctness and outstanding security obligations

## What is proved here

**Honest equation correctness.** Assume validated entries use A_i=t_i K,
R_i=r_i K and z_i=r_i+c_i t_i in F_q, with the same canonical context, ordered
entries and hash outputs at the aggregator and verifier. Then the compressed
aggregate passes. Indeed, by distributivity,

    ZK = (sum_i b_i z_i)K
       = sum_i b_i(r_i+c_i t_i)K
       = sum_i b_i(R_i+c_i A_i).

This holds for every n in the implementation's permitted range, including zero
responses or challenges. The parser excludes identity R_i; honest r_i are nonzero.
This statement is an algebraic proof, not an extraction or security theorem.

**Programmed fixture correctness.** When R=zK-cA* is nonidentity and programming
the fresh challenge input succeeds, verification reads c and obtains
R+cA*=zK. This does not require knowledge of t* such that A*=t*K. It establishes
validity of the fixture, not that the full simulated view has the real distribution.

**Unweighted cancellation.** Take public K,A*, choose r,u1,a2,u2, and define
A1=A*+rK, R1=u1K. Compute c1 from the actual first entry. Then define
A2=a2K, R2=u2K-c1A* and compute c2 from the actual second entry. Provided all encoded
points are nonidentity, the response Z=u1+c1r+u2+c2a2 satisfies the unweighted
aggregate equation because the A* contributions cancel. The attack function receives
no secret class scalar or challenge witness. This proves an equation-level failure
of the unweighted negative control. It is not a newly demonstrated end-to-end PRE
break. For the shipped fixtures, the same response fails the prefix-weighted check;
that observation is not a proof that no other weighted attack exists.

## Transfer from Batch 02E: still OPEN

For n=2, write algebraic representations of A_i and R_i using coefficients alpha_ij
and rho_ij on formal symbols X_j. The residual at X_j is

    (rho_1j+c1 alpha_1j) + b2(rho_2j+c2 alpha_2j).

Batch 02E proved root-counting lemmas for vectors fixed before their fresh random
coefficients. This batch does not establish that those hypotheses hold for every
adversary in the full AGM+ROM game. In particular:

1. A cyclic-group equality is not a formal-vector equality. A nonzero formal relation
   needs an explicit hardness solver, with the actual embedded inputs and loss.
2. An adversary can query a prefix-weight input before either challenge input. The
   new ordering test explicitly exercises that legal behavior. Encoding full entries
   does not enforce the prover's preferred chronological order of queries.
3. A programmed challenge entry deliberately has a valid proof with unknown witness.
   Both list positions now have executable fixtures. Extractor exceptions and the
   game's refusal rules must handle it; one cannot assume it fails the intake check.
4. A numerical opening Q=k^-1 A can sometimes be computed from previously known
   group points without knowing their discrete logarithms. State the actual output
   algorithm; do not require zero coordinates on every unknown-log point by fiat.
5. Adaptive reuse of points, alternative representations, cached hash queries,
   reordered/duplicate entries, and repeated or cross-grant proxy queries require
   a single online invariant and an exact bad-event analysis.

The ideal scalar-RO test backend and default SHA-256 rejection backend are distinct.
A proof must state the oracle model precisely and account for any change between
them. No global numerical security bound is asserted by this package.

## Obligations ledger

| ID | Obligation | Status / evidence |
|---|---|---|
| F-COR | Honest aggregate equation | Proved above; single/two/four-record tests |
| F-WIRE | Canonical typed encoding and field binding | Implemented; decoding, ambiguity, mutation and golden-byte tests; not formally verified |
| F-COMP | Compressed verifier uses no individual responses | Implemented; schema and patched-call tests |
| F-SIM-ID | Simulated challenge equation | Proved above; both list positions tested |
| F-SIM-DIST | Full simulation distribution and programming-abort loss | OPEN |
| F-ORDER | Adaptive ROM query-order analysis | OPEN; weight-before-challenge fixture rules out assuming normal order |
| F-REL | Hardness reduction from a nonzero formal relation | OPEN |
| F-EXT | Per-record numerical opening extraction | OPEN; no extractor implemented |
| F-DEC | Origin/delegatee decryption and confirmation simulation | OPEN; absent from this kernel |
| F-TOKEN | Scalar Omega token/public W joint distribution | OPEN; absent from this kernel |
| F-CT | Full augmented G-CONF-CT theorem | OPEN; depends on the above and authorization/refusal rules |
| F-CLASS | Full G-CONF-CLASS theorem | OPEN; honest-recipient challenge transformations remain permitted |
| F-NOV | Novelty and exact prior-theorem comparison | OPEN; no new literature claims in this batch |

No test pass count upgrades an OPEN entry to proved. A full proof is not an ordinary
software test result. This batch contains no Lean/Coq or other machine-checked proof.

## Frozen-game boundary

This kernel does not change CEA's grant/token scheme or validate commitment opening.
It does not issue a security verdict on frozen CEA. In that baseline, Omega is the
scalar omega*k mod q, and W hashes the encoded scalar; replacing it by the point
omega K changes the construction. The same-grant transform F(A)=Omega^-1 A is
linear, so independently sampled replies for related inputs violate publicly
checkable linear relations. The present intake check does not by itself resolve
these simulation issues or forbid an honest-recipient challenge transformation.

## Next batch: 02G

Write an explicit n=2 adaptive extraction experiment for this exact transcript and
an auditable query/representation trace. Treat honest, adversarial, and programmed
entries separately. Attempt the hardness-transfer argument including reverse hash
query order and both simulated-challenge positions. Supply either a complete scoped
lemma with its reduction and loss, a legal counterexample, or a precisely localized
remaining gap. Do not invent an extractor that reads fixture witnesses, and do not
start a full confidentiality theorem by assuming the missing lemma.
