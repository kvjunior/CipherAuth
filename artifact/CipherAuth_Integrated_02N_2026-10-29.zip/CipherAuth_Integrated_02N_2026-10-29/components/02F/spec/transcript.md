# CipherAuth 02F transcript v1

Status: implemented research proof-equation kernel. This specification fixes the
bytes and algebra for a future extraction argument. It is not a complete signcryption,
PRE, authentication, confidentiality, or security-game specification. Frozen CEA
and its games have not been modified.

## Group, scalars, and validation

Use the vendored P-256 prime-order group, written additively, with order q and
standard generator P (`group.G`). The public class key K is a nonidentity group
point. The kernel does not know the class secret k in K=kP.
Every supplied point is a canonical 33-byte compressed SEC1 point, decoded and
curve-checked; identity is rejected. P-256 has cofactor one. Scalars are canonical
32-byte unsigned big-endian integers in [0,q); no reduction of external scalars.
Witness t and nonce r for honest proving must be nonzero. Responses and proof
challenges may be zero. Nonce selection defaults to `secrets`; explicit nonces
exist for experiments and must not be reused in applications.

## Typed fields

All lengths and counts are 4-byte unsigned big-endian. Epoch is an 8-byte unsigned
big-endian integer. `LP(x)` means length followed by raw bytes; byte fields are
not Unicode-normalized. This version supports 1..256 ordered records.

| Object | Canonical field order | Validation |
|---|---|---|
| Context | LP(origin), LP(tag), epoch, K | origin and tag 1..1024 bytes; valid K |
| Record | LP(sender), commitment, LP(body), A | sender 1..1024 bytes; commitment exactly 32 bytes; body 0..2^20 bytes; valid A |
| Entry | Record, R | valid R |
| Compressed wire | magic, Context, count, Entry[1..n], Z | magic `CAF02F` followed by byte 01; scalar Z |

No c_i, b_i, t_i, r_i, or individual z_i occurs on the compressed wire. The body
and commitment are opaque bytes here; the kernel neither checks encryption validity
nor recomputes a commitment from a message. Sender IDs are labels, not authenticated
identities. Every proof hash binds the entire context and record.

The decoder rejects truncation, trailing bytes, bad version/count/lengths,
noncanonical scalars and invalid points. Re-encoding a decoded object must reproduce
the original bytes. The verifier also validates in-memory objects and compares the
aggregate context against its separately supplied expected context.

## Hashes and ordered prefixes

Let V be ASCII `CipherAuth/02F/v1`, with no terminator. Let enc denote the
field encodings above. The proof hash input is

    M_i = V || enc(Context) || enc(Entry_i).

For i>=2, the prefix input is

    B_i = V || enc(Context) || uint32(i) || enc(Entry_1) || ... || enc(Entry_i).

Define `Scalar(D,M,nz)` by SHA-256 rejection sampling. For counter j=0,1,...,2^32-1,
hash `LP(D) || byte(nz) || LP(M) || uint32(j)`. Interpret the digest as a big-endian
integer x. Accept x<q, additionally requiring x!=0 when nz=1; otherwise try the next
counter. Exhaustion raises an error. There is no `% q or 1` remapping.

    c_i = Scalar("CipherAuth/02F/challenge/v1", M_i, 0)
    b_1 = 1
    b_i = Scalar("CipherAuth/02F/prefix-weight/v1", B_i, 1), i>=2.

Domain strings are ASCII bytes. Rejection sampling avoids modulo bias for ideal
uniform digest blocks, conditional on success; SHA-256 itself is a fixed function,
not a mathematical random oracle. The finite counter exhaustion event would also
need accounting in a concrete theorem. A separate programmable scalar-RO test
backend models independent lazy uniform outputs, not SHA-256 programming.

This implementation hashes complete prefixes: total prefix input is quadratic in
batch length. It does not implement the historical cached-chain optimization and
makes no claim of two hash calls per append. Changing to a chain changes this frozen
transcript and requires separate analysis. Records can be permuted and recompressed
with their individual responses; simply permuting an existing compressed object
generally invalidates it.

## Honest proving and compression

For record A_i=t_i K choose r_i uniformly in F_q^*, set R_i=r_i K, compute c_i, and
return z_i=r_i+c_i t_i mod q. The prover checks A_i=t_i K.
An aggregator checks each individual equation z_i K=R_i+c_i A_i and recomputes the
weights. It outputs all entries and

    Z = sum_i b_i z_i mod q.

The public compressed verifier checks exactly

    Z K = sum_i b_i (R_i + c_i A_i).

It has neither individual z_i nor witnesses and does not call the individual
verifier. It recomputes c_i and b_i; it does not trust caller-supplied coefficients.
The intended knowledge claim is an OPEN proof obligation. Equation acceptance
alone must not be presented as an established proof of every witness.

Replay and duplicate entries are allowed by this equation interface. A deployment's
freshness, challenge-derivative exclusions, and authorization policy must be defined
elsewhere. This batch does not silently add or remove any frozen game restriction.

## Simulated challenge fixtures

In the test-only programmable oracle, choose independent c,z in F_q, form
R=zK-cA*, retry if R is identity, and program the fresh M* to c. Prequeried inputs
cause an explicit abort rather than overwriting a past answer. The resulting proof
is valid and can be compressed with an honest proof in either position. The API
requires no t*; this verifies an algebraic identity, not a full simulation theorem.
Distribution matching, prequery probabilities, and the effects of programmed
queries on extraction are unproved. Such fixtures generally do not verify against
the default SHA-256 backend.

## Costs within this interface

Proof material contributes exactly 33n+32 bytes (R_i plus Z), excluding all context,
records, body points, commitments and framing. The shipped n=2 fixture is 375 bytes
in total and has 98 bytes of this proof material. These are serialization sizes,
not CEA end-to-end sizes or security/performance comparisons. No timing benchmark
is claimed. The pure-Python affine arithmetic is not constant-time.
