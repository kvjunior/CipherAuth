import dataclasses
from dataclasses import replace
import hashlib
import unittest
from unittest.mock import patch

from cipherauth02f import group as g
from cipherauth02f.errors import EncodingError
from cipherauth02f.transcript import (Context, Record, Entry, IndividualProof, Compressed,
    encode, decode, encode_context, encode_entry, prefix_input, challenge_input,
    MAX_META, MAX_BODY, MAGIC)
from cipherauth02f.oracle import HashOracle, CHALLENGE, WEIGHT
from cipherauth02f.kernel import prove, compress, verify_compressed, verify_individual, challenge, coefficients
from cipherauth02f.simulation import ProgrammableOracle, ProgrammingConflict, simulate_challenge
from cipherauth02f.experiments import fixture, cancellation, verify_unweighted_control


class KernelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ctx, cls.proofs = fixture()
        cls.agg = compress(cls.ctx, cls.proofs)
        cls.ro = HashOracle()

    def test_honest_single_and_two(self):
        for proofs in (self.proofs[:1], self.proofs):
            self.assertTrue(verify_compressed(self.ctx, compress(self.ctx, proofs)))

    def test_honest_four_records(self):
        ctx, proofs = fixture(4)
        self.assertTrue(verify_compressed(ctx, compress(ctx, proofs)))

    def test_compressed_schema_has_no_witness_or_individual_response(self):
        self.assertEqual([f.name for f in dataclasses.fields(Compressed)], ["context", "entries", "response"])
        self.assertEqual([f.name for f in dataclasses.fields(Entry)], ["record", "R"])
        with patch("cipherauth02f.kernel.verify_individual", side_effect=AssertionError("must not be called")):
            self.assertTrue(verify_compressed(self.ctx, decode(encode(self.agg))))

    def test_wrong_witness_rejected(self):
        with self.assertRaises(EncodingError):
            prove(self.ctx, self.proofs[0].entry.record, 100, nonce=3)

    def test_bad_individual_not_compressed(self):
        bad = replace(self.proofs[0], response=(self.proofs[0].response+1)%g.q)
        self.assertFalse(verify_individual(self.ctx, bad))
        with self.assertRaises(EncodingError):
            compress(self.ctx, (bad, self.proofs[1]))

    def test_response_tamper(self):
        self.assertFalse(verify_compressed(self.ctx, replace(self.agg, response=(self.agg.response+1)%g.q)))

    def test_each_record_field_bound(self):
        for index in range(2):
            entry = self.agg.entries[index]
            changes = {"sender": b"other", "commitment": b"X"*32, "body": b"changed",
                       "A": g.encode_point(g.decode_point(entry.record.A)+g.decode_point(self.ctx.key))}
            for name, value in changes.items():
                with self.subTest(index=index, field=name):
                    entries = list(self.agg.entries)
                    entries[index] = replace(entry, record=replace(entry.record, **{name: value}))
                    self.assertFalse(verify_compressed(self.ctx, replace(self.agg, entries=tuple(entries))))

    def test_proof_commitment_bound(self):
        for i in range(2):
            entries = list(self.agg.entries)
            entries[i] = replace(entries[i], R=g.encode_point(g.mul(900+i, g.G)))
            self.assertFalse(verify_compressed(self.ctx, replace(self.agg, entries=tuple(entries))))

    def test_each_context_field_bound(self):
        for name, value in {"origin": b"other", "tag": b"other", "epoch": 8,
                            "key": g.encode_point(g.mul(18, g.G))}.items():
            with self.subTest(field=name):
                ctx = replace(self.ctx, **{name: value})
                # Even when the expected context is the new one, old responses fail.
                self.assertFalse(verify_compressed(ctx, replace(self.agg, context=ctx)))

    def test_expected_context_mismatch(self):
        self.assertFalse(verify_compressed(replace(self.ctx, epoch=9), self.agg))

    def test_reordering_requires_recompression(self):
        self.assertFalse(verify_compressed(self.ctx, replace(self.agg, entries=self.agg.entries[::-1])))
        self.assertTrue(verify_compressed(self.ctx, compress(self.ctx, self.proofs[::-1])))

    def test_replay_is_allowed_equation_not_freshness_policy(self):
        for _ in range(2):
            self.assertTrue(verify_compressed(self.ctx, self.agg))
        duplicate = compress(self.ctx, (self.proofs[0], self.proofs[0]))
        self.assertTrue(verify_compressed(self.ctx, duplicate))

    def test_length_prefix_ambiguity_and_epoch_encoding(self):
        self.assertNotEqual(encode_context(replace(self.ctx, origin=b"a", tag=b"bc")),
                            encode_context(replace(self.ctx, origin=b"ab", tag=b"c")))
        ctx = Context(b"o", b"t", 0x0102030405060708, self.ctx.key)
        self.assertEqual(encode_context(ctx)[10:18], bytes.fromhex("0102030405060708"))

    def test_challenge_payload_golden_structure(self):
        from cipherauth02f.transcript import VERSION
        e = self.proofs[0].entry
        # Independent byte assembly catches accidental field/order changes.
        expected = (VERSION + (8).to_bytes(4,"big") + b"origin-j" + (9).to_bytes(4,"big")
                    + b"class-tag" + (7).to_bytes(8,"big") + self.ctx.key
                    + (8).to_bytes(4,"big") + b"sender-0" + hashlib.sha256(b"\x00").digest()
                    + (19).to_bytes(4,"big") + b"opaque ciphertext 0" + e.record.A + e.R)
        self.assertEqual(challenge_input(self.ctx, e), expected)

    def test_prefix_binds_entire_list_and_first_weight_one(self):
        weights = coefficients(self.ctx, self.agg.entries, self.ro)
        self.assertEqual(weights[0], 1)
        self.assertTrue(0 < weights[1] < g.q)
        entries = (replace(self.agg.entries[0], R=g.encode_point(g.mul(100, g.G))), self.agg.entries[1])
        self.assertNotEqual(coefficients(self.ctx, entries, self.ro)[1], weights[1])
        self.assertNotEqual(prefix_input(self.ctx, self.agg.entries), prefix_input(self.ctx, self.agg.entries[::-1]))

    def test_hash_domain_separation(self):
        self.assertNotEqual(self.ro.scalar(CHALLENGE, b"data"), self.ro.scalar(WEIGHT, b"data"))
        self.assertNotEqual(self.ro.scalar(WEIGHT, b"data"), self.ro.scalar(WEIGHT, b"data", nonzero=True))

    def test_hash_rejects_out_of_range_and_zero_for_weight(self):
        class Digest:
            def __init__(self, n): self.n = n
            def digest(self): return self.n.to_bytes(32, "big")
        with patch("cipherauth02f.oracle.hashlib.sha256", side_effect=[Digest(g.q), Digest(0), Digest(5)]) as h:
            self.assertEqual(self.ro.scalar(WEIGHT, b"x", nonzero=True), 5)
            self.assertEqual(h.call_count, 3)
        with patch("cipherauth02f.oracle.hashlib.sha256", return_value=Digest(0)):
            self.assertEqual(self.ro.scalar(CHALLENGE, b"x"), 0)

    def test_roundtrip_and_exact_proof_size(self):
        wire = encode(self.agg)
        self.assertEqual(decode(wire), self.agg)
        self.assertEqual(encode(decode(wire)), wire)
        from cipherauth02f.transcript import encode_record
        base = len(MAGIC)+len(encode_context(self.ctx))+4+sum(len(encode_record(e.record)) for e in self.agg.entries)
        self.assertEqual(len(wire)-base, 33*2+32)

    def test_every_truncation_rejected(self):
        wire = encode(self.agg)
        for cut in range(len(wire)):
            with self.subTest(cut=cut), self.assertRaises(EncodingError):
                decode(wire[:cut])

    def test_trailing_wrong_version_and_scalar_overflow(self):
        wire = encode(self.agg)
        for bad in (wire+b"\x00", b"X"+wire[1:], wire[:-32]+g.q.to_bytes(32,"big")):
            with self.assertRaises(EncodingError): decode(bad)

    def test_bad_points_rejected(self):
        for point in (b"\x00", b"\x04"+b"\x00"*32, b"\x02"+g.p.to_bytes(32,"big")):
            entry = replace(self.agg.entries[0], R=point)
            self.assertFalse(verify_compressed(self.ctx, replace(self.agg, entries=(entry,))))

    def test_scalars_not_reduced_on_input(self):
        for scalar in (-1, g.q, True, "1"):
            self.assertFalse(verify_compressed(self.ctx, replace(self.agg, response=scalar)))

    def test_empty_and_oversized_inputs(self):
        for entries in ((), (self.agg.entries[0],)*257):
            self.assertFalse(verify_compressed(self.ctx, replace(self.agg, entries=entries)))
        for ctx in (replace(self.ctx, origin=b""), replace(self.ctx, tag=b"x"*(MAX_META+1)),
                    replace(self.ctx, epoch=-1), replace(self.ctx, epoch=2**64)):
            self.assertFalse(verify_compressed(ctx, replace(self.agg, context=ctx)))
        e = self.agg.entries[0]
        bad = replace(e, record=replace(e.record, body=b"x"*(MAX_BODY+1)))
        self.assertFalse(verify_compressed(self.ctx, replace(self.agg, entries=(bad,))))

    def test_zero_count_and_oversized_field_on_wire(self):
        wire = encode(self.agg)
        count_pos = len(MAGIC)+len(encode_context(self.ctx))
        for count in (0, 257):
            bad = wire[:count_pos]+count.to_bytes(4,"big")+wire[count_pos+4:]
            with self.assertRaises(EncodingError): decode(bad)
        bad = MAGIC + (MAX_META+1).to_bytes(4,"big") + wire[len(MAGIC)+4:]
        with self.assertRaises(EncodingError): decode(bad)

    def test_unweighted_cancellation_with_real_hashes(self):
        attack = cancellation(self.ctx, g.encode_point(g.mul(997, g.G)))
        self.assertTrue(verify_unweighted_control(attack))
        self.assertFalse(verify_compressed(self.ctx, attack))

    def test_cancellation_rejected_across_fixture_challenge_points(self):
        for b in (881, 991, 1013):
            attack = cancellation(self.ctx, g.encode_point(g.mul(b, g.G)))
            self.assertTrue(verify_unweighted_control(attack))
            self.assertFalse(verify_compressed(self.ctx, attack))

    def test_old_challenge_coefficient_cannot_be_reused(self):
        # Equation-only verifier would accept after z'=z+c, A'=A+K. Real FS must change c.
        old = self.proofs[0]
        c = challenge(self.ctx, old.entry, self.ro)
        record = replace(old.entry.record, A=g.encode_point(g.decode_point(old.entry.record.A)+g.decode_point(self.ctx.key)))
        changed = IndividualProof(replace(old.entry, record=record), (old.response+c)%g.q)
        self.assertEqual(g.mul(changed.response, g.decode_point(self.ctx.key)),
                         g.decode_point(changed.entry.R)+g.mul(c, g.decode_point(record.A)))
        self.assertNotEqual(challenge(self.ctx, changed.entry, self.ro), c)
        self.assertFalse(verify_individual(self.ctx, changed))


class SimulationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ctx, cls.proofs = fixture()

    def test_valid_simulated_challenge_without_witness_argument(self):
        ro = ProgrammableOracle(123)
        record = self.proofs[0].entry.record
        proof = simulate_challenge(self.ctx, record, ro, seed=321)
        self.assertTrue(verify_individual(self.ctx, proof, oracle=ro))
        self.assertTrue(verify_compressed(self.ctx, compress(self.ctx, (proof,), oracle=ro), oracle=ro))

    def test_simulated_challenge_and_honest_entry_aggregate(self):
        ro = ProgrammableOracle(15)
        simulated = simulate_challenge(self.ctx, self.proofs[0].entry.record, ro, seed=23)
        honest = prove(self.ctx, self.proofs[1].entry.record, 102, nonce=19, oracle=ro)
        agg = compress(self.ctx, (simulated, honest), oracle=ro)
        self.assertTrue(verify_compressed(self.ctx, agg, oracle=ro))
        # No claim that programmable fixtures verify under unprogrammed SHA-256.
        self.assertFalse(verify_compressed(self.ctx, agg))

    def test_simulated_challenge_in_second_position(self):
        ro = ProgrammableOracle(15)
        simulated = simulate_challenge(self.ctx, self.proofs[0].entry.record, ro, seed=23)
        honest = prove(self.ctx, self.proofs[1].entry.record, 102, nonce=19, oracle=ro)
        agg = compress(self.ctx, (honest, simulated), oracle=ro)
        self.assertTrue(verify_compressed(self.ctx, agg, oracle=ro))

    def test_weight_may_be_queried_before_challenges(self):
        # A hash-input encoding does NOT force the adversary to query c before b.
        ro = ProgrammableOracle(505)
        entries = tuple(p.entry for p in self.proofs)
        weights = coefficients(self.ctx, entries, ro)
        self.assertEqual(len(ro.table), 1)
        self.assertEqual(next(iter(ro.table))[0], WEIGHT)
        rebuilt = []
        for i, entry in enumerate(entries):
            c = challenge(self.ctx, entry, ro)
            rebuilt.append(IndividualProof(entry, ((211+i)+c*(101+i))%g.q))
        agg = compress(self.ctx, rebuilt, oracle=ro)
        self.assertEqual(coefficients(self.ctx, entries, ro), weights)
        self.assertTrue(verify_compressed(self.ctx, agg, oracle=ro))

    def test_programming_conflict_is_explicit_abort(self):
        ro = ProgrammableOracle(1)
        proof = simulate_challenge(self.ctx, self.proofs[0].entry.record, ro, seed=3)
        before = dict(ro.table)
        with self.assertRaises(ProgrammingConflict):
            simulate_challenge(self.ctx, self.proofs[0].entry.record, ro, seed=3)
        self.assertEqual(ro.table, before)
        self.assertTrue(verify_individual(self.ctx, proof, oracle=ro))

    def test_prequeried_input_cannot_be_reprogrammed(self):
        ro = ProgrammableOracle(10)
        v = ro.scalar(CHALLENGE, b"already seen")
        with self.assertRaises(ProgrammingConflict):
            ro.program(CHALLENGE, b"already seen", v)
        self.assertEqual(ro.scalar(CHALLENGE, b"already seen"), v)

    def test_lazy_consistency_and_nonzero_weight(self):
        ro = ProgrammableOracle(12)
        self.assertEqual(ro.scalar(CHALLENGE, b"x"), ro.scalar(CHALLENGE, b"x"))
        self.assertGreater(ro.scalar(WEIGHT, b"x", nonzero=True), 0)
        with self.assertRaises(EncodingError): ro.program(WEIGHT, b"y", 0, nonzero=True)


if __name__ == "__main__":
    unittest.main()
