# CipherAuth Batch 02F — canonical transcript and compressed verification

**Research implementation complete for this batch. Full extraction, confidentiality,
and novelty remain OPEN.** This is a standalone intake-proof equation kernel, not a
complete CEA integration or a submission-ready paper artifact.

Run from any directory with Python 3.10+; no third-party dependencies:

    python scripts/reproduce.py

The command runs 34 tests and writes `results/observed.json`. Shipped results record
zero failures, errors or skips. The test suite covers honest aggregates, simulated
challenge proofs in either position, full transcript binding, strict decoding,
reordering, replay semantics, and the unweighted cancellation control. It does not
prove security.

## Read in this order

1. `spec/transcript.md`: exact field/hash/wire format and scope.
2. `proofs/obligations.md`: proved correctness identities and every remaining gap.
3. `src/cipherauth02f/kernel.py`: honest proving, compression and compressed-only verification.
4. `src/cipherauth02f/simulation.py`: explicitly separate test-only programmable oracle.
5. `tests/test_kernel.py` and `results/observed.json`: executable evidence.
6. `REVIEW_PROMPT.md`: independent-review checklist.

Other modules: `transcript.py` implements strict canonical encoding; `oracle.py`
provides domain-separated SHA-256 rejection sampling; `experiments.py` contains
deterministic public fixtures and an intentionally insecure unweighted control.
`group.py` and `errors.py` are unchanged copies from the frozen research workspace,
identified by hashes in `provenance/input_hashes.json`. The arithmetic is not
constant-time. Explicit nonces and seeded oracle randomness are test conveniences.

The verifier sees entries plus one aggregate response; it receives neither
individual responses nor witnesses. The default implementation recomputes all
hashes. The programmable backend is only an injected test dependency and is never
the default. No game-policy oracle, token generation, sender-signature validation,
or message decryption is added here.

Replay and duplicate records are intentionally accepted if their equations verify;
freshness/authorization belong to a separately specified surrounding protocol.
Complete-prefix hashing is quadratic in batch length. This batch makes no optimized
append-cost claim and no equivalence claim with an exact published construction.

The n=2 fixture occupies 375 wire bytes; 98 are proof material (two 33-byte R points
and one 32-byte response). These are kernel sizes, not end-to-end CEA sizes.

Earlier batch archives and frozen CEA source remain untouched. A copy of Batch 02E's
corrective notes is included under `provenance/prior_02e/` for review continuity.
`manifest.json` hashes every shipped regular file except itself. Verify it with
`python scripts/verify_manifest.py`; it ignores only generated Python cache files
and rejects other unlisted files. `provenance/validation.json` records the actual
runtime used. The assistance log records the scope of AI authorship.

**Next: Batch 02G — the adaptive n=2 extraction experiment and proof attempt,
including reverse hash-query order and programmed challenge proofs.**
