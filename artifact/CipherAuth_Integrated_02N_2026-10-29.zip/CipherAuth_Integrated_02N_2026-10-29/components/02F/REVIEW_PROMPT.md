# Independent review request for Claude

Review Batch 02F without assuming the earlier phrase "provable, not attackable"
established the extraction theorem. Do not rewrite or weaken frozen CEA games.

1. Verify manifest and provenance, then run `python scripts/reproduce.py` in a clean
   extraction. Compare results byte-for-byte, including the deterministic wire hash.
2. Check `spec/transcript.md` against code, especially full field binding, length
   encodings, rejection sampling, scalar/point validation, and b1=1.
3. Confirm the compressed verifier has no per-record responses, secret witnesses,
   or trusted coefficients. Look for malformed-wire acceptance and context confusion.
4. Recompute the unweighted cancellation from public inputs and real hash challenges.
   Do not confuse rejection of that one attack with security of prefix weighting.
5. Verify that simulated challenge proofs are valid in both positions using the
   programmable oracle, and that programming conflicts abort rather than overwrite.
6. Challenge the handwritten correctness arguments and the OPEN-obligation ledger.
   In particular, no coordinate matching is justified merely by the AGM label and
   no protocol serialization forces a malicious party's hash-query order.
7. Check scope: no PRE integration, no full confidentiality proof, no optimized
   chain hash, no novelty claim, and no production-safety claim.

Report concrete defects with minimal reproducers and separate code correctness,
mathematical proof validity, and novelty. Preserve original files; place patches
and review results separately. A clean code review does not certify security.
