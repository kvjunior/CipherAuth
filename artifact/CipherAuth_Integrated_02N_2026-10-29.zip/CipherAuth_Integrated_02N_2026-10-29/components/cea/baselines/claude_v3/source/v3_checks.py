"""Checks V1-V12 for candidate_v3. Run: python3 v3_checks.py. Behaviour only, never security."""
import json
import ec
from ec import G, O, q, mul, rand_scalar, reset_counts, COUNT, xor
import adspre as S
import candidate_v3 as V

res = {}


def record(key, claim, ok, detail=""):
    res[key] = {"claim": claim, "confirmed": bool(ok), "detail": detail}
    print(f"[{'CONFIRMED' if ok else 'NOT CONFIRMED'}] {key}: {claim}")
    if detail:
        print(f"      {detail}")


pp = S.setup()
pk, sk = {}, {}
for ID in ["j", "l", "evil-r"] + [f"s{i}" for i in range(8)]:
    pk[ID], sk[ID] = S.keygen(pp, ID)
tau = b"2026-W43"
M = lambda s: s.encode().ljust(32, b"\0")[:32]

# V1 first-level correctness
c = V.signcrypt(pp, pk["s0"], sk["s0"], pk["j"], M("pressure=4.2"), tau)
record("V1_first_level_correct", "Signcrypt, Check and Unsigncrypt are correct in the decoupled representation",
       V.check(pp, pk["s0"], "j", c) and V.unsigncrypt(pp, pk["j"], sk["j"], pk["s0"], c) == M("pressure=4.2"))

# V2 Lemma B: simulation from a Schnorr signing oracle, recipient secret never used
x_hidden = S.x_of(sk["s1"])
queried = []
def schnorr_oracle(stmt):                      # the only access to the sender's key
    queried.append(stmt[0])
    return V.schnorr_sign(x_hidden, stmt)
sim = V.signcrypt_with_oracle(pp, pk["s1"], pk["evil-r"], M("sim"), tau, schnorr_oracle)
record("V2_lemmaB_simulation_without_recipient_key",
       "An honest-sender ciphertext to an adversarial recipient is produced from two Schnorr-oracle calls and the recipient's public key only",
       V.check(pp, pk["s1"], "evil-r", sim) and V.unsigncrypt(pp, pk["evil-r"], sk["evil-r"], pk["s1"], sim) == M("sim")
       and queried == ["inner", "outer"],
       "the recipient decrypts and verifies; the simulator code path has no access to k_r")

# V3 Lemma A: compact representation, local equivalence with CDH(X, K)
X, K, kr = S.X_of(pp, pk["s1"]), S.K_of(pp, pk["evil-r"]), S.k_of(pp, pk["evil-r"], sk["evil-r"])
theta, h = rand_scalar(), rand_scalar()
Lam = mul(theta, G) - mul(h, X)
D = mul(kr, Lam)
T = mul(kr, X)
record("V3_lemmaA_compact_step_equals_CDH",
       "In the compact representation, D = k*Lambda for a programmed Lambda = theta P - h X is computable iff CDH(X, K) is",
       (mul(theta, K) - D) / h == T and mul(theta, K) - mul(h, T) == D)

# V4 second-level correctness (individual)
rk, _ = V.rkg(pp, pk["j"], sk["j"], pk["l"])
c2 = V.reenc(pp, rk, pk["s0"], "j", c)
record("V4_second_level_correct", "Re-encryption then Unsigncrypt2 recovers the message; the certified statement names j",
       V.unsigncrypt2(pp, pk["l"], sk["l"], rk, pk["s0"], pk["j"], c2) == M("pressure=4.2"))

# V5 first-level prefix aggregation with cached append
cts = [(pk[f"s{i % 8}"], V.signcrypt(pp, pk[f"s{i % 8}"], sk[f"s{i % 8}"], pk["j"], M(f"r{i}"), tau)) for i in range(32)]
def build(n):
    ag = V.agg_new(("L1", "j", None, None))
    for p, ct in cts[:n]:
        ag = V.agg_append(ag, (p, ct.A, ct.B, ct.E, ct.tau), ct.theta)
    return ag
opener1 = lambda rec: V.open_first(pp, pk["j"], sk["j"], rec[0], rec[1], rec[2], rec[3], rec[4])
append_hashes = []
for n in [8, 16, 31]:
    ag = build(n)
    orig = ec._h
    cnt = {"n": 0}
    def meas(tag, *parts):
        if tag.startswith("H7"):
            cnt["n"] += 1
        return orig(tag, *parts)
    ec._h = meas
    p, ct = cts[n]
    ag2 = V.agg_append(ag, (p, ct.A, ct.B, ct.E, ct.tau), ct.theta)
    ec._h = orig
    append_hashes.append(cnt["n"])
ok_all = V.agg_verify(pp, build(32), opener1, pk["j"]) == [M(f"r{i}") for i in range(32)]
record("V5_prefix_aggregate_cached_append",
       "Prefix aggregate verifies; Append makes a constant number of H7 calls (cached chain state)",
       ok_all and append_hashes == [2, 2, 2], f"H7 calls per append at n = 8, 16, 31: {append_hashes}")

# V6 second-level aggregate verification
ag2 = V.agg_new(("L2", "l", "j", "rk-group-1"))
for p, ct in cts[:6]:
    r2 = V.reenc(pp, rk, p, "j", ct)
    ag2 = V.agg_append(ag2, (p, r2.Abar, r2.B, r2.E, r2.tau), r2.theta)
opener2 = lambda rec: V.open_second(pp, pk["l"], sk["l"], "j", rk.C, rk.gamma, rec[0], rec[1], rec[2], rec[3])
record("V6_second_level_aggregate", "A second-level prefix aggregate for one re-key group verifies at the delegatee",
       V.agg_verify(pp, ag2, opener2, pk["j"]) == [M(f"r{i}") for i in range(6)])

# V7 Blame
ev = cts[:5]
ag = build(5)
honest = V.blame(pp, pk["j"], sk["j"], ag, ev)
tampered = V.Agg(ag.context, ag.records, ag.chain, (ag.Theta + 1) % q)
cloud_fault = V.blame(pp, pk["j"], sk["j"], tampered, ev)
withheld = V.blame(pp, pk["j"], sk["j"], ag, None)
# poisoned sender: valid outer signature over a bad theta
p6, x6 = pk["s6"], S.x_of(sk["s6"])
good6 = V.signcrypt(pp, p6, sk["s6"], pk["j"], M("bad"), tau)
bad_theta = (good6.theta + 1) % q
Delta, f = V.schnorr_sign(x6, V.outer_stmt(p6.ID, "j", tau, good6.A, good6.B, good6.E, bad_theta))
poison = V.CT(good6.A, good6.B, good6.E, tau, Delta, f, bad_theta)
ev_p = ev[:4] + [(p6, poison)]
ag_p = V.agg_new(("L1", "j", None, None))
for p, ct in ev_p:
    ag_p = V.agg_append(ag_p, (p, ct.A, ct.B, ct.E, ct.tau), ct.theta)
poisoned = V.blame(pp, pk["j"], sk["j"], ag_p, ev_p)
# aggregator supplies altered evidence (theta changed, so the sender's outer signature breaks)
p0, c0 = ev[0]
fake_ev = [(p0, V.CT(c0.A, c0.B, c0.E, c0.tau, c0.Delta, c0.f, (c0.theta + 1) % q))] + ev[1:]
fake = V.blame(pp, pk["j"], sk["j"], ag, fake_ev)
record("V7_blame_attribution",
       "Blame: honest -> nobody; altered Theta -> aggregator; withheld evidence -> aggregator; poisoned record -> its sender; altered evidence -> aggregator",
       honest == set() and cloud_fault == {"AGGREGATOR"} and withheld == {"AGGREGATOR"}
       and poisoned == {"s6"} and fake == {"AGGREGATOR"} and V.check(pp, p6, "j", poison),
       f"{honest or 'none'} / {cloud_fault} / {withheld} / {poisoned} / {fake}")

# V8 tag binding
c_t = V.CT(c.A, c.B, c.E, b"2026-W44", c.Delta, c.f, c.theta)
record("V8_tag_bound", "Changing the tag breaks both the outer check and the inner signature",
       not V.check(pp, pk["s0"], "j", c_t) and V.unsigncrypt(pp, pk["j"], sk["j"], pk["s0"], c_t) is None)

# V9 inner layer is publicly re-randomizable (relevant to RCCA); the outer signature is not
s_ = rand_scalar()
c_r = V.CT(c.A + mul(s_, S.K_of(pp, pk["j"])), c.B + mul(s_, G), c.E, c.tau, c.Delta, c.f, c.theta)
record("V9_inner_rerandomizable",
       "(A + sK, B + sP) still decrypts and verifies for the recipient, but fails the outer check",
       V.unsigncrypt(pp, pk["j"], sk["j"], pk["s0"], c_r) == M("pressure=4.2") and not V.check(pp, pk["s0"], "j", c_r),
       "so confidentiality must be RCCA-style even without aggregation; the cloud's outer check pins one representation")

# V10 the naive C9 cancellation, adapted, against v3 prefix aggregation (sanity only)
tgt, rog = pk["s3"], pk["s4"]
lam_b = rand_scalar(); Lb = mul(lam_b, G)
mb = M("shutdown line 3")
hb = V.H_S(Lb, V.inner_stmt(mb, tau, tgt, pk["j"]))
tb = rand_scalar(); Ab, Bb = mul(tb, S.K_of(pp, pk["j"])), Lb + mul(tb, G); Eb = xor(mb, V.H3(tgt.ID, Lb))
lam_a = rand_scalar(); La = mul(lam_a, G) - mul(hb, S.X_of(pp, tgt))
ta = rand_scalar(); Aa, Ba = mul(ta, S.K_of(pp, pk["j"])), La + mul(ta, G); Ea = xor(M("filler"), V.H3(rog.ID, La))
ha = V.H_S(La, V.inner_stmt(M("filler"), tau, rog, pk["j"]))
agf = V.agg_new(("L1", "j", None, None))
recs = [(tgt, Ab, Bb, Eb, tau), (rog, Aa, Ba, Ea, tau)]
c_ = V.chain_start(agf.context); zs = []
for i, r in enumerate(recs, 1):
    c_ = V.chain_next(c_, r); zs.append(V.coeff(i, c_))
Theta = (zs[0] * lam_b + zs[1] * (lam_a + ha * S.x_of(sk["s4"]))) % q
forged = V.Agg(agf.context, recs, c_, Theta)
record("V10_naive_cancellation_rejected", "The C9-style cancellation, adapted to v3 prefix weights, is rejected (sanity only)",
       V.agg_verify(pp, forged, opener1, pk["j"]) is None)

# V11 sizes (bytes), compressed P-256 points
PT, SC = 33, 32
first_to_cloud = 2 * PT + 32 + TAG if (TAG := V.TAG_BYTES) else 0
first_to_cloud += PT + SC + SC                     # Delta, f, theta
per_record_agg = V.ID_BYTES + PT + PT + 32 + V.TAG_BYTES
compact_per_record = V.ID_BYTES + PT + 32 + V.TAG_BYTES
agg_fixed = SC + 32 + 3 * V.ID_BYTES               # Theta, cached chain value, context IDs
record("V11_sizes",
       "Decoupled representation costs one extra point (33 bytes) per record over the compact one",
       per_record_agg - compact_per_record == PT,
       f"submitted ciphertext {first_to_cloud} B; aggregate {per_record_agg} B/record + {agg_fixed} B fixed "
       f"(compact: {compact_per_record} B/record); second level adds C, gamma (65 B) per re-key group")

# V12 factored verification multiplications, cached sender points
Xc = {f"s{i}": S.X_of(pp, pk[f"s{i}"]) for i in range(8)}
counts = {}
for u in [1, 8]:
    ag = V.agg_new(("L1", "j", None, f"u{u}"))
    for i in range(8):
        p = pk[f"s{i % u}"]
        ct = V.signcrypt(pp, p, sk[f"s{i % u}"], pk["j"], M(f"u{u}-{i}"), tau)
        ag = V.agg_append(ag, (p, ct.A, ct.B, ct.E, ct.tau), ct.theta)
    reset_counts()
    ok = V.agg_verify(pp, ag, opener1, pk["j"], X_cache=Xc) is not None
    counts[u] = (ok, COUNT["mul"])
record("V12_verification_cost", "Factored verification costs 2n + u + 1 multiplications (n = 8)",
       counts[1] == (True, 18) and counts[8] == (True, 25), f"u=1: {counts[1][1]}, u=8: {counts[8][1]}")

json.dump(res, open("v3_results.json", "w"), indent=2)
