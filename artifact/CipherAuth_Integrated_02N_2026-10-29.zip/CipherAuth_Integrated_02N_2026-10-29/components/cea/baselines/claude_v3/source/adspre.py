"""ADS-PRE as written in the manuscripts, plus a minimally repaired variant.

Line comments cite the algorithm and line in the revised manuscript
(Updated-Article.pdf, Dec 2025) unless marked "v1" (round-1 manuscript, Mar 2025).
Messages are kappa = 256-bit strings, as forced by E_i = m_i XOR H3(.).
"""
from dataclasses import dataclass
from ec import (G, O, Point, q, mul, rand_scalar, hash_to_zq, hash_to_bits, xor)

# ---------------- hash functions (Algorithm 1) ----------------
def H1(ID, R, P):             return hash_to_zq("H1", ID, R, P)          # {0,1}* x G^2 -> Zq*
def H2(ID, Ppub):             return hash_to_zq("H2", ID, Ppub)          # {0,1}* x G   -> Zq*
def H3(ID, X):                return hash_to_bits("H3", ID, X)           # {0,1}* x G   -> {0,1}^k
def H4(m, ID, E, D, Lam, R, P): return hash_to_zq("H4", m, ID, E, D, Lam, R, P)
def H5(D, E, Delta, theta):   return hash_to_zq("H5", D, E, Delta, theta)


# ---------------- setup and keys (Algorithms 1-4) ----------------
@dataclass
class Params:
    alpha: int
    Ppub: Point


def setup():
    alpha = rand_scalar()
    return Params(alpha, mul(alpha, G))


@dataclass
class PK:
    ID: str
    P: Point   # P_ID = Phi P
    R: Point   # R_ID = r P
    V: Point   # V_ID = d P


@dataclass
class SK:
    Phi: int
    d: int


def keygen(pp, ID):
    Phi = rand_scalar()                          # Alg 2
    P_ID = mul(Phi, G)
    r = rand_scalar()                            # Alg 3
    R = mul(r, G)
    psi = H1(ID, R, P_ID)
    d = (r + pp.alpha * psi) % q
    V = mul(d, G)
    assert mul(d, G) == R + mul(H1(ID, R, P_ID), pp.Ppub)   # Alg 4 line 1
    return PK(ID, P_ID, R, V), SK(Phi, d)


def pk_valid(pp, pk):
    """The 'public key validation' check (Alg 5 line 1, Alg 6 line 1)."""
    return pk.V == pk.R + mul(H1(pk.ID, pk.R, pk.P), pp.Ppub)


def X_of(pp, pk):
    """Signing public key X = P + R + psi Ppub = (Phi + d) P."""
    return pk.P + pk.R + mul(H1(pk.ID, pk.R, pk.P), pp.Ppub)


def K_of(pp, pk):
    """Encryption public key K = R + psi Ppub + H2 P = (d + H2 Phi) P."""
    return pk.R + mul(H1(pk.ID, pk.R, pk.P), pp.Ppub) + mul(H2(pk.ID, pp.Ppub), pk.P)


def x_of(sk):            return (sk.Phi + sk.d) % q              # signing scalar
def k_of(pp, pk, sk):    return (sk.d + sk.Phi * H2(pk.ID, pp.Ppub)) % q   # decryption scalar


# ---------------- signcryption (Algorithm 5) ----------------
@dataclass
class CT1:            # first-level ciphertext sigma_ij
    D: Point
    E: bytes
    Delta: Point
    f: int
    theta: int


def signcrypt(pp, pki, ski, pkj, m, leak=None):
    if not pk_valid(pp, pkj):                                   # line 1
        return None
    lam, mu = rand_scalar(), rand_scalar()                      # line 4
    Lam, Delta = mul(lam, G), mul(mu, G)                        # line 5
    psij = H1(pkj.ID, pkj.R, pkj.P)                             # line 6
    D = mul(lam, pkj.R + mul(psij, pp.Ppub) + mul(H2(pkj.ID, pp.Ppub), pkj.P))  # line 7
    Z = H3(pki.ID, Lam)                                         # line 8
    E = xor(m, Z)
    h = H4(m, pki.ID, E, D, Lam, pki.R, pki.P)                  # line 9
    theta = (lam + h * (ski.Phi + ski.d)) % q                   # line 10
    Psi = H5(D, E, Delta, theta)                                # line 11
    f = (mu + Psi * (ski.Phi + ski.d)) % q                      # line 12
    if leak is not None:
        leak["lambda"], leak["mu"] = lam, mu
    return CT1(D, E, Delta, f, theta)


def cloud_check(pp, pki, ct):
    """Ciphertext validation by the cloud (Alg 8 lines 1-3, Alg 10 lines 4-6)."""
    psi = H1(pki.ID, pki.R, pki.P)
    Psi = H5(ct.D, ct.E, ct.Delta, ct.theta)
    return mul(ct.f, G) == ct.Delta + mul(Psi, pki.P + pki.R + mul(psi, pp.Ppub))


# ---------------- unsigncryption 1 (Algorithm 7) ----------------
def dec1(pp, pkj, skj, pki, D, E):
    Lam = D / k_of(pp, pkj, skj)                                # line 8 (scalar inverse)
    m = xor(E, H3(pki.ID, Lam))                                 # line 9
    h = H4(m, pki.ID, E, D, Lam, pki.R, pki.P)                  # line 10
    return m, h, Lam


def unsigncrypt1(pp, pkj, skj, pki, ct):
    m, h, Lam = dec1(pp, pkj, skj, pki, ct.D, ct.E)
    psi = H1(pki.ID, pki.R, pki.P)                              # line 2
    if mul(ct.theta, G) != Lam + mul(h, pki.P + pki.R + mul(psi, pp.Ppub)):  # line 3
        return None
    return m


# ---------------- re-encryption, ROUND-1 version (v1 Algorithms 6, 8, 9) ----------------
@dataclass
class RK:
    C: bytes
    Omega: object      # int in v1 (scalar); Point in the revised manuscript
    gamma: Point


def rkg_v1(pp, pkj, skj, pkl):
    if not pk_valid(pp, pkl):
        return None, None
    omega_bits = hash_to_bits("rand", rand_scalar())            # v1: omega <-$ {0,1}^kappa
    omega = int.from_bytes(omega_bits, "big") % q               # only reading under which
    t = rand_scalar()                                           #  'omega * scalar' is defined
    T = mul(t, G)
    Zj = H3(pkj.ID, T)
    Omega = (omega * k_of(pp, pkj, skj)) % q                    # v1 line 6 (scalar)
    psil = H1(pkl.ID, pkl.R, pkl.P)
    gamma = mul(t, pkl.R + mul(psil, pp.Ppub) + mul(H2(pkl.ID, pp.Ppub), pkl.P))
    C = xor(omega.to_bytes(32, "big"), Zj)
    return RK(C, Omega, gamma), omega


@dataclass
class CT2:           # second-level ciphertext, Alg 8 line 7: (D_bar, E, Delta, f, theta, C, gamma)
    Dbar: Point
    E: bytes
    Delta: Point
    f: int
    theta: int
    C: bytes
    gamma: Point
    D: Point = None  # NOT in the manuscript; added by the repaired variant


def reenc_v1(pp, rk, pki, ct, ship_D=False):
    if not cloud_check(pp, pki, ct):                            # lines 1-5
        return None
    Dbar = ct.D / rk.Omega                                      # line 6 (Omega scalar in v1)
    return CT2(Dbar, ct.E, ct.Delta, ct.f, ct.theta, rk.C, rk.gamma,
               D=ct.D if ship_D else None)


def dec2(pp, pkl, skl, pki, pkj_ID, ct2, D_for_hash):
    T = ct2.gamma / k_of(pp, pkl, skl)                          # line 8
    omega = int.from_bytes(xor(ct2.C, H3(pkj_ID, T)), "big")    # line 9
    Lam = mul(omega, ct2.Dbar)                                  # line 9: Lambda = D_bar(omega)
    m = xor(ct2.E, H3(pki.ID, Lam))                             # line 10
    h = H4(m, pki.ID, ct2.E, D_for_hash, Lam, pki.R, pki.P)     # line 11 uses D_i
    return m, h, Lam, omega


def unsigncrypt2(pp, pkl, skl, pki, pkj_ID, ct2):
    """As written: the second-level ciphertext carries only D_bar, so line 11
    can only hash D_bar. If the repaired variant shipped D, hash D."""
    D_for_hash = ct2.D if ct2.D is not None else ct2.Dbar
    m, h, Lam, _ = dec2(pp, pkl, skl, pki, pkj_ID, ct2, D_for_hash)
    psi = H1(pki.ID, pki.R, pki.P)
    if mul(ct2.theta, G) != Lam + mul(h, pki.P + pki.R + mul(psi, pp.Ppub)):
        return None
    return m


# ---------------- re-key generation, REPAIRED (consistent specification) ----------------
def rkg_fixed(pp, pkj, skj, pkl):
    """omega in Zq*, masked directly as a 32-byte string; Omega = omega * k_j mod q (scalar)."""
    omega, t = rand_scalar(), rand_scalar()
    T = mul(t, G)
    C = xor(omega.to_bytes(32, "big"), H3(pkj.ID, T))
    Omega = (omega * k_of(pp, pkj, skj)) % q
    gamma = mul(t, K_of(pp, pkl))
    return RK(C, Omega, gamma), omega


# ---------------- re-encryption, REVISED version (Algorithms 6, 8) ----------------
def H4_of_omega(omega):
    # Alg 6 line 7 'k_j <- H4(omega_j)'; H4's declared domain does not accept a single
    # scalar, so we model it as a hash of omega to a kappa-bit string.
    return hash_to_bits("H4w", omega)


def rkg_v2(pp, pkj, skj, pkl):
    if not pk_valid(pp, pkl):                                   # lines 1-3
        return None, None
    omega, t = rand_scalar(), rand_scalar()                     # line 4 (omega now in Zq*)
    T = mul(t, G)                                               # line 5
    Zj = H3(pkj.ID, T)
    Omega = mul((omega * k_of(pp, pkj, skj)) % q, G)            # line 6: ... P  -> a POINT
    kj = H4_of_omega(omega)                                     # line 7
    psil = H1(pkl.ID, pkl.R, pkl.P)                             # line 8
    gamma = mul(t, pkl.R + mul(psil, pp.Ppub) + mul(H2(pkl.ID, pp.Ppub), pkl.P))  # line 9
    C = xor(kj, Zj)                                             # line 10
    return RK(C, Omega, gamma), omega


def reenc_v2(pp, rk, pki, ct):
    if not cloud_check(pp, pki, ct):
        return None
    Dbar = ct.D / rk.Omega                                      # line 6: point / point
    return CT2(Dbar, ct.E, ct.Delta, ct.f, ct.theta, rk.C, rk.gamma)


# ---------------- aggregation (Algorithms 10, 11) ----------------
def agg_as_written(pp, items):
    """items: list of (pk_i, ct_i). Alg 10 lines 1-17 (first-level branch)."""
    Theta, err = 0, []
    for pki, ct in items:
        if not cloud_check(pp, pki, ct):                        # line 6
            err.append(pki.ID)                                  # line 7
        else:
            Theta = (Theta + ct.theta) % q                      # line 9 (Theta_i read as theta_i)
    Sigma = ([(ct.D, ct.E) for _, ct in items], Theta)          # line 16: ALL i in 1..n
    return Sigma, err


def agg_fixed(pp, items):
    """Repair: keep only validated elements in Sigma, together with their sender keys."""
    Theta, kept, err = 0, [], []
    for pki, ct in items:
        if cloud_check(pp, pki, ct):
            Theta = (Theta + ct.theta) % q
            kept.append((pki, ct.D, ct.E))
        else:
            err.append(pki.ID)
    return (kept, Theta), err


def aunsigncrypt1(pp, pkj, skj, senders, Sigma):
    """Alg 11, with the aggregate check moved outside the loop (as written it sits inside)."""
    pairs, Theta = Sigma
    msgs, rhs = [], O
    for pki, (D, E) in zip(senders, pairs):
        m, h, Lam = dec1(pp, pkj, skj, pki, D, E)
        psi = H1(pki.ID, pki.R, pki.P)
        rhs = rhs + Lam + mul(h, pki.P + pki.R + mul(psi, pp.Ppub))
        msgs.append(m)
    if mul(Theta, G) != rhs:
        return None
    return msgs


# ---------------- coefficient-weighted aggregation (proposed repair; needs a proof) ----------------
def z_coeffs(items_pub):
    """z_i = H6(manifest digest, i). The batch manifest (ID, D, E for every record, in order)
    is hashed ONCE, so hashing is linear in n. (The first version hashed the whole batch per
    coefficient: quadratic input volume.) Candidate construction only: what the manifest must
    bind (public keys, recipient, delegation context) is a model decision, not settled here."""
    blob = [x for (ID, D, E) in items_pub for x in (ID, D, E)]
    digest = hash_to_bits("H6-manifest", len(items_pub), *blob)
    return [hash_to_zq("H6", digest, i) for i in range(len(items_pub))]


def z_prefix(items_pub):
    """Prefix weights: z_i = H7(i, chain_i) where chain_i commits to records 1..i only.
    Appending a record leaves earlier weights unchanged (append-only incremental).
    Candidate construction; no security proof."""
    out, chain = [], b"\0" * 32
    for i, (ID, D, E) in enumerate(items_pub):
        chain = hash_to_bits("H7-chain", chain, ID, D, E)
        out.append(hash_to_zq("H7", i, chain))
    return out


def agg_prefix(pp, items):
    kept = [(pki, ct) for pki, ct in items if cloud_check(pp, pki, ct)]
    z = z_prefix([(pk.ID, ct.D, ct.E) for pk, ct in kept])
    Theta = sum(zi * ct.theta for zi, (_, ct) in zip(z, kept)) % q
    return ([(pk, ct.D, ct.E) for pk, ct in kept], Theta)


def append_prefix(pp, Sigma, pki, ct):
    """Extend a compressed prefix-weighted aggregate by one record, without the old theta_i."""
    kept, Theta = Sigma
    if not cloud_check(pp, pki, ct):
        return None
    new = kept + [(pki, ct.D, ct.E)]
    z = z_prefix([(pk.ID, D, E) for pk, D, E in new])
    return (new, (Theta + z[-1] * ct.theta) % q)


def aunsigncrypt1_prefix(pp, pkj, skj, Sigma):
    kept, Theta = Sigma
    z = z_prefix([(pk.ID, D, E) for pk, D, E in kept])
    msgs, rhs = [], O
    for zi, (pki, D, E) in zip(z, kept):
        m, h, Lam = dec1(pp, pkj, skj, pki, D, E)
        rhs = rhs + mul(zi, Lam + mul(h, X_of(pp, pki)))
        msgs.append(m)
    return msgs if mul(Theta, G) == rhs else None


def agg_weighted(pp, items):
    kept = [(pki, ct) for pki, ct in items if cloud_check(pp, pki, ct)]
    z = z_coeffs([(pk.ID, ct.D, ct.E) for pk, ct in kept])
    Theta = sum(zi * ct.theta for zi, (_, ct) in zip(z, kept)) % q
    return ([(pk, ct.D, ct.E) for pk, ct in kept], Theta)


def aunsigncrypt1_weighted(pp, pkj, skj, Sigma):
    kept, Theta = Sigma
    z = z_coeffs([(pk.ID, D, E) for pk, D, E in kept])
    msgs, rhs = [], O
    for zi, (pki, D, E) in zip(z, kept):
        m, h, Lam = dec1(pp, pkj, skj, pki, D, E)
        psi = H1(pki.ID, pki.R, pki.P)
        rhs = rhs + mul(zi, Lam + mul(h, pki.P + pki.R + mul(psi, pp.Ppub)))
        msgs.append(m)
    return msgs if mul(Theta, G) == rhs else None
