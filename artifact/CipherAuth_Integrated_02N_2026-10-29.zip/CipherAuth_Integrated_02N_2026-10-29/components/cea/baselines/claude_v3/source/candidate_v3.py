"""Candidate v3: decoupled-commitment representation, for feasibility study only.

NOT a validated construction. Differences from the audited ADS-PRE:
  * The Schnorr commitment Lambda is encrypted with separate randomness t:
        A = t * K_r,  B = Lambda + t * P        (BBS/ElGamal-style point encryption)
    instead of the compact D = lambda * K_r, where lambda is also the signature nonce.
  * The inner challenge is a plain Schnorr challenge on a statement
        h = H_S(Lambda, ("inner", m, tau, sender, recipient))
    so an honest-sender signcryption can be produced from a Schnorr signing
    oracle without the recipient's secret key (Lemma B in the note).
  * The outer signature is a second Schnorr signature by the same key on
        ("outer", sender, recipient, tau, A, B, E, theta).
  * Tags tau are explicit; aggregation uses Chen-Zhao-style prefix coefficients over
    PUBLIC record data with cached chain state, so Append costs O(1) hashes.
Keys reuse the audited certificateless structure: x = Phi + d (signing), k = d + H2*Phi (decryption).
"""
from dataclasses import dataclass, field
from ec import G, O, Point, q, mul, rand_scalar, hash_to_zq, hash_to_bits, xor, enc
import adspre as S

TAG_BYTES = 8
ID_BYTES = 16


def H_S(R, stmt):            # the Schnorr challenge hash, shared by inner and outer signatures
    return hash_to_zq("HS", R, *stmt)


def H3(ID, X):
    return hash_to_bits("H3v3", ID, X)


def inner_stmt(m, tau, pki, pkr):
    return ("inner", m, tau, pki.ID, pki.R, pki.P, pkr.ID, pkr.R, pkr.P)


def outer_stmt(pki_ID, pkr_ID, tau, A, B, E, theta):
    return ("outer", pki_ID, pkr_ID, tau, A, B, E, theta)


@dataclass
class CT:
    A: Point
    B: Point
    E: bytes
    tau: bytes
    Delta: Point
    f: int
    theta: int


# ---------------- a Schnorr signer, used directly and as the oracle in Lemma B ----------------
def schnorr_sign(x, stmt):
    r = rand_scalar()
    R = mul(r, G)
    return R, (r + H_S(R, stmt) * x) % q


def signcrypt(pp, pki, ski, pkr, m, tau):
    """Real algorithm: the sender knows its key x."""
    x = S.x_of(ski)
    return signcrypt_with_oracle(pp, pki, pkr, m, tau, lambda st: schnorr_sign(x, st))


def signcrypt_with_oracle(pp, pki, pkr, m, tau, sign_oracle):
    """Produces a ciphertext using ONLY a Schnorr signing oracle for the sender's key and
    the recipient's PUBLIC key. Used both by the real sender and by the Lemma B simulator."""
    Lam, theta = sign_oracle(inner_stmt(m, tau, pki, pkr))
    t = rand_scalar()
    A = mul(t, S.K_of(pp, pkr))
    B = Lam + mul(t, G)
    E = xor(m, H3(pki.ID, Lam))
    Delta, f = sign_oracle(outer_stmt(pki.ID, pkr.ID, tau, A, B, E, theta))
    return CT(A, B, E, tau, Delta, f, theta)


def check(pp, pki, pkr_ID, ct):
    X = S.X_of(pp, pki)
    Psi = H_S(ct.Delta, outer_stmt(pki.ID, pkr_ID, ct.tau, ct.A, ct.B, ct.E, ct.theta))
    return mul(ct.f, G) == ct.Delta + mul(Psi, X)


def open_first(pp, pkr, skr, pki, A, B, E, tau):
    tP = A / S.k_of(pp, pkr, skr)
    Lam = B - tP
    m = xor(E, H3(pki.ID, Lam))
    return m, Lam


def unsigncrypt(pp, pkr, skr, pki, ct):
    m, Lam = open_first(pp, pkr, skr, pki, ct.A, ct.B, ct.E, ct.tau)
    h = H_S(Lam, inner_stmt(m, ct.tau, pki, pkr))
    return m if mul(ct.theta, G) == Lam + mul(h, S.X_of(pp, pki)) else None


# ---------------- delegation (repaired re-key from the audit; still leaks k_j to proxy+delegatee) ----------------
def rkg(pp, pkj, skj, pkl):
    return S.rkg_fixed(pp, pkj, skj, pkl)


@dataclass
class CT2:
    Abar: Point
    B: Point
    E: bytes
    tau: bytes
    theta: int
    origin: str          # original recipient j; the certified statement names j


def reenc(pp, rk, pki, pkj_ID, ct):
    if not check(pp, pki, pkj_ID, ct):
        return None
    return CT2(ct.A / rk.Omega, ct.B, ct.E, ct.tau, ct.theta, pkj_ID)


def open_second(pp, pkl, skl, origin_ID, rk_C, rk_gamma, pki, Abar, B, E):
    T = rk_gamma / S.k_of(pp, pkl, skl)
    omega = int.from_bytes(xor(rk_C, S.H3(origin_ID, T)), "big")
    tP = mul(omega, Abar)
    Lam = B - tP
    return xor(E, H3(pki.ID, Lam)), Lam


def unsigncrypt2(pp, pkl, skl, rk, pki, pkj, ct2):
    m, Lam = open_second(pp, pkl, skl, pkj.ID, rk.C, rk.gamma, pki, ct2.Abar, ct2.B, ct2.E)
    h = H_S(Lam, inner_stmt(m, ct2.tau, pki, pkj))      # statement certifies "for j"
    return m if mul(ct2.theta, G) == Lam + mul(h, S.X_of(pp, pki)) else None


# ---------------- prefix aggregation with cached chain state ----------------
@dataclass
class Agg:
    context: tuple                  # (level, recipient ID, origin ID or None, delegation group id)
    records: list = field(default_factory=list)   # (sender_pk, first point (A or Abar), B, E, tau)
    chain: bytes = b""              # c_n, cached so Append needs O(1) hashes
    Theta: int = 0


def chain_start(context):
    return hash_to_bits("H7-start", *[c if c is not None else "-" for c in context])


def coeff(i, c_i):
    return hash_to_zq("H7", i, c_i)


def chain_next(c, rec):
    pk, P1, B, E, tau = rec
    return hash_to_bits("H7-chain", c, pk.ID, P1, B, E, tau)


def agg_new(context):
    return Agg(context, [], chain_start(context), 0)


def agg_append(ag, rec, theta):
    """O(1) hashing: one chain step and one coefficient, independent of len(ag.records)."""
    c = chain_next(ag.chain, rec)
    z = coeff(len(ag.records) + 1, c)
    return Agg(ag.context, ag.records + [rec], c, (ag.Theta + z * theta) % q)


def agg_verify(pp, ag, opener, statement_recipient, X_cache=None):
    """opener(rec) -> (m, Lambda). Factored per sender: sum z_i*Lambda_i + sum_s (sum z_i h_i) X_s."""
    c = chain_start(ag.context)
    L, hsum, msgs, pks = O, {}, [], {}
    for idx, rec in enumerate(ag.records, start=1):
        c = chain_next(c, rec)
        z = coeff(idx, c)
        pk = rec[0]
        m, Lam = opener(rec)
        h = H_S(Lam, inner_stmt(m, rec[4], pk, statement_recipient))
        L = L + mul(z, Lam)
        hsum[pk.ID] = (hsum.get(pk.ID, 0) + z * h) % q
        pks[pk.ID] = pk
        msgs.append(m)
    if c != ag.chain:
        return None
    rhs = L
    for ID, s in hsum.items():
        X = X_cache[ID] if X_cache else S.X_of(pp, pks[ID])
        rhs = rhs + mul(s, X)
    return msgs if mul(ag.Theta, G) == rhs else None


# ---------------- Blame (G4 candidate procedure) ----------------
def blame(pp, pkr, skr, ag, evidence):
    """evidence: list of (sender_pk, CT) the aggregator claims it aggregated, in order.
    Returns a set drawn from sender IDs and 'AGGREGATOR'. Receiver-verifiable only (uses sk_r)."""
    if evidence is None or len(evidence) != len(ag.records):
        return {"AGGREGATOR"}                                     # withheld or incomplete evidence
    for (pk, ct), rec in zip(evidence, ag.records):
        if not check(pp, pk, pkr.ID, ct):                         # sender-authenticated? if not, aggregator fault
            return {"AGGREGATOR"}
        if rec != (pk, ct.A, ct.B, ct.E, ct.tau):                 # evidence must match delivered records
            return {"AGGREGATOR"}
    bad = {pk.ID for pk, ct in evidence if unsigncrypt(pp, pkr, skr, pk, ct) is None}
    if bad:
        return bad                                                # valid outer f proves the sender submitted it
    recomputed = agg_new(ag.context)
    for pk, ct in evidence:
        recomputed = agg_append(recomputed, (pk, ct.A, ct.B, ct.E, ct.tau), ct.theta)
    return set() if recomputed.Theta == ag.Theta and recomputed.chain == ag.chain else {"AGGREGATOR"}
