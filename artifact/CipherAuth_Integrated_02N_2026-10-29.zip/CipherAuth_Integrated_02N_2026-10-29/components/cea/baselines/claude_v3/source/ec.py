"""Minimal NIST P-256 arithmetic with operation counters.

Pure Python, affine coordinates. Correctness-oriented, not constant-time,
not for production. Every scalar multiplication and hash call is counted
so that operation counts can be read off the algorithms as published.
"""
import hashlib
import secrets

# NIST P-256 (secp256r1) domain parameters
p = 0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF
a = p - 3
b = 0x5AC635D8AA3A93E7B3EBBD55769886BC651D06B0CC53B0F63BCE3C3E27D2604B
q = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551  # group order
Gx = 0x6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296
Gy = 0x4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5

COUNT = {"mul": 0, "hash": 0}


def reset_counts():
    COUNT["mul"] = 0
    COUNT["hash"] = 0


class Point:
    __slots__ = ("x", "y")

    def __init__(self, x, y):
        self.x, self.y = x, y

    @property
    def inf(self):
        return self.x is None

    def __eq__(self, o):
        return isinstance(o, Point) and self.x == o.x and self.y == o.y

    def __hash__(self):
        return hash((self.x, self.y))

    def __add__(self, o):
        return add(self, o)

    def __neg__(self):
        return O if self.inf else Point(self.x, (-self.y) % p)

    def __sub__(self, o):
        return add(self, -o)

    def __rmul__(self, k):
        if not isinstance(k, int):
            raise TypeError(f"scalar * point needs an int scalar, got {type(k).__name__}")
        return mul(k, self)

    def __truediv__(self, o):
        # Dividing a point by a point is not a group operation. Algorithm 8 of the
        # revised manuscript (D_i / Omega_j with Omega_j a point) needs exactly this.
        if isinstance(o, Point):
            raise TypeError("point / point is undefined in an elliptic-curve group")
        if isinstance(o, int):
            return mul(pow(o % q, -1, q), self)
        raise TypeError(f"cannot divide a point by {type(o).__name__}")

    def __repr__(self):
        return "O" if self.inf else f"Point({hex(self.x)[:12]}...)"


O = Point(None, None)
G = Point(Gx, Gy)


def on_curve(P):
    return P.inf or (P.y * P.y - (P.x ** 3 + a * P.x + b)) % p == 0


def add(P, Q):
    if P.inf:
        return Q
    if Q.inf:
        return P
    if P.x == Q.x and (P.y + Q.y) % p == 0:
        return O
    if P == Q:
        lam = (3 * P.x * P.x + a) * pow(2 * P.y, -1, p) % p
    else:
        lam = (Q.y - P.y) * pow(Q.x - P.x, -1, p) % p
    x3 = (lam * lam - P.x - Q.x) % p
    y3 = (lam * (P.x - x3) - P.y) % p
    return Point(x3, y3)


def mul(k, P):
    """Scalar multiplication (counted)."""
    COUNT["mul"] += 1
    k %= q
    R, Qp = O, P
    while k:
        if k & 1:
            R = add(R, Qp)
        Qp = add(Qp, Qp)
        k >>= 1
    return R


def enc(P):
    """Compressed SEC1 encoding, 33 bytes."""
    if P.inf:
        return b"\x00"
    return bytes([2 + (P.y & 1)]) + P.x.to_bytes(32, "big")


def rand_scalar():
    return secrets.randbelow(q - 1) + 1


def _h(tag, *parts):
    COUNT["hash"] += 1
    h = hashlib.sha256(tag.encode())
    for x in parts:
        if isinstance(x, Point):
            x = enc(x)
        elif isinstance(x, int):
            x = x.to_bytes(32, "big")
        elif isinstance(x, str):
            x = x.encode()
        h.update(len(x).to_bytes(4, "big") + x)
    return h.digest()


def hash_to_zq(tag, *parts):
    v = int.from_bytes(_h(tag, *parts), "big") % q
    return v if v else 1


def hash_to_bits(tag, *parts):
    return _h(tag, *parts)  # kappa = 256 bits


def xor(x, y):
    assert len(x) == len(y)
    return bytes(i ^ j for i, j in zip(x, y))
