# Frozen v3 snapshot

source/candidate_v3.py and source/v3_checks.py are the supplied v3 bytes.
source/ec.py and source/adspre.py are their previously supplied dependencies.
Their exact origins and hashes appear in source_manifest.json.
expected/v3_results.json is the supplied report; do not overwrite it during reproduction.

This snapshot uses the old key infrastructure although the note's simple authenticity
argument is for ordinary independent public keys. It has no authenticated scoped grant,
no complete confidentiality proof, and no compressed-aggregate delegation algorithm.
