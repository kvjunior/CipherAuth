# Baselines

claude_v3 is a frozen supplied diagnostic prototype, not the proposed new construction.
Its original check report is reproduced exactly in an isolated directory.

Additional baselines must be implemented only after reading their exact algorithms and games:
public Schnorr half-aggregation, a generic signcryption/PRE/aggregate/proof composition,
and a direct aggregate-signcryption-with-re-encryption comparator. Mark unavailable source
or unimplemented baselines explicitly rather than substituting invented operation counts.
