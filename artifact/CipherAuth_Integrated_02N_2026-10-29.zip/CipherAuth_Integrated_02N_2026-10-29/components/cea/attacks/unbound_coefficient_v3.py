"""Removing the mutable component A from v3's coefficient hash is UNSOUND.

Motivation: in v3, delegation changes A to Abar, so a compressed Theta survives delegation only
if the coefficients do not bind A. This script shows the obvious way to get that invariance
(hash only ID, B, E, tau) lets a receiver who knows k_j, plus one registered rogue sender key,
forge an aggregate that attributes a chosen message to an honest sender. The same aggregate is
rejected by the original v3 verifier, whose coefficients bind A.

Uses the frozen baseline primitives read-only. This is a concrete attack on the modified
coefficient rule, not a claim about every possible invariant-coefficient design.
"""
import json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "baselines/claude_v3/source"))
from ec import G, O, q, mul, rand_scalar, xor, hash_to_bits, hash_to_zq
import adspre as S
import candidate_v3 as V


def unbound_coeffs(context, records):
    """Prefix coefficients over (ID, B, E, tau) only: A deliberately omitted."""
    c = hash_to_bits("H7u-start", *context)
    out = []
    for i, (pk, A, B, E, tau) in enumerate(records, 1):
        c = hash_to_bits("H7u-chain", c, pk.ID, B, E, tau)
        out.append(hash_to_zq("H7u", i, c))
    return out


def verify_unbound(pp, pkj, skj, context, records, Theta):
    z = unbound_coeffs(context, records)
    rhs, msgs = O, []
    for zi, (pk, A, B, E, tau) in zip(z, records):
        m, Lam = V.open_first(pp, pkj, skj, pk, A, B, E, tau)
        h = V.H_S(Lam, V.inner_stmt(m, tau, pk, pkj))
        rhs = rhs + mul(zi, Lam + mul(h, S.X_of(pp, pk)))
        msgs.append(m)
    return msgs if mul(Theta, G) == rhs else None


def run():
    pp = S.setup()
    pkj, skj = S.keygen(pp, "j")
    honest, _honest_sk = S.keygen(pp, "honest-device")       # secret never used below
    rogue, rogue_sk = S.keygen(pp, "rogue")                   # adversary-registered key
    kj = S.k_of(pp, pkj, skj)                                 # adversary is the receiver j
    tau, ctx = b"epoch001", ("L1", "j")
    target = b"shutdown line 3".ljust(32, b"\0")

    # honest-looking record for the target statement, built by the adversary
    lam_b, t_b = rand_scalar(), rand_scalar()
    L_b = mul(lam_b, G)
    A_b, B_b = mul(t_b, S.K_of(pp, pkj)), L_b + mul(t_b, G)
    E_b = xor(target, V.H3(honest.ID, L_b))
    h_b = V.H_S(L_b, V.inner_stmt(target, tau, honest, pkj))

    # rogue record: fix the hashed fields first, choose A (hence Lambda) after the coefficients
    B_a, E_a = mul(rand_scalar(), G), hash_to_bits("filler", rand_scalar())
    placeholder = [(honest, A_b, B_b, E_b, tau), (rogue, None, B_a, E_a, tau)]
    z_b, z_a = unbound_coeffs(ctx, placeholder)
    lam_a = rand_scalar()
    L_a = mul(lam_a, G) - mul(z_b * h_b * pow(z_a, -1, q) % q, S.X_of(pp, honest))
    A_a = mul(kj, B_a - L_a)                                  # so that B_a - k_j^{-1} A_a = L_a
    m_a = xor(E_a, V.H3(rogue.ID, L_a))
    h_a = V.H_S(L_a, V.inner_stmt(m_a, tau, rogue, pkj))
    Theta = (z_a * (lam_a + h_a * S.x_of(rogue_sk)) + z_b * lam_b) % q
    records = [(honest, A_b, B_b, E_b, tau), (rogue, A_a, B_a, E_a, tau)]

    forged = verify_unbound(pp, pkj, skj, ctx, records, Theta)
    # the original v3 rule (coefficients bind A) on the same records and Theta
    ag = V.agg_new(("L1", "j", None, None))
    ag.records = [(pk, A, B, E, t) for pk, A, B, E, t in records]
    c = V.chain_start(ag.context)
    for r in ag.records:
        c = V.chain_next(c, r)
    ag.chain, ag.Theta = c, Theta
    opener = lambda rec: V.open_first(pp, pkj, skj, rec[0], rec[1], rec[2], rec[3], rec[4])
    bound_result = V.agg_verify(pp, ag, opener, pkj)

    result = {
        "unbound_coefficients_accept_forgery": forged is not None and forged[0] == target,
        "forged_statement_attributed_to_honest_sender": forged is not None and forged[0] == target,
        "honest_sender_secret_used": False,
        "original_v3_binding_rejects_same_aggregate": bound_result is None,
        "scope": "Attack on the specific A-free coefficient rule; does not cover every invariant design.",
    }
    if not (result["unbound_coefficients_accept_forgery"] and result["original_v3_binding_rejects_same_aggregate"]):
        raise RuntimeError(json.dumps(result))
    return result


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
