"""CEA does NOT meet a Canetti-Hohenberger-style per-ciphertext confidentiality game.

Setting: the honest proxy holds a token from the target class (j, tau, e) to a delegatee l
that is corrupted, and serves re-encryption requests, refusing only the challenge itself
(and its exact derivatives), as CH07's re-encryption oracle does. A is not covered by the
sender's signature, so a re-randomised challenge A' = A* + r*K still passes VerifyPublic.
Its re-encryption opens under l to Q* + r*P, which reveals Q* and hence m*.

Consequence: CEA's confidentiality can hold at most at CLASS granularity (no corrupted
party is ever served for the target class, neither by token nor by re-encryption). It gives
no per-ciphertext delegation control. Uses only public APIs plus the corrupted delegatee's key.
"""
import json, sys
from dataclasses import replace
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from cipherauth import group as g
from cipherauth.cea import CEA, Directory, SUITE, parse_body, _body, _kdf, _xor
from cipherauth.encoding import encode
from cipherauth.games.privacy import DerivativeLedger
from cipherauth.models import BatchContext

TAG, EPOCH = b"vibration", 7


def run():
    D = Directory()
    S = CEA(D)
    sender = D.new_signing_key("sensor")
    owner = D.new_signing_key("plant")
    jk = D.new_decryption_key("plant", tag=TAG, epoch=EPOCH)
    corrupted = D.new_decryption_key("contractor")          # adversary knows corrupted.k
    token, grant = S.issue_grant(owner, jk, corrupted.ref, TAG, EPOCH)   # held by the honest proxy

    m0, m1 = b"valve A open".ljust(32, b"\0"), b"valve B open".ljust(32, b"\0")
    b = g.random_scalar() & 1
    challenge = S.signcrypt(sender, "plant", (m0, m1)[b], TAG, EPOCH)
    ctx = BatchContext(SUITE, "origin", jk.ref, jk.ref, EPOCH)
    core = lambda rec: (rec.origin, parse_body(rec.body)[2], parse_body(rec.body)[3])
    ledger = DerivativeLedger()
    ledger.register(core(challenge.record))

    def reenc_oracle(agg):                                  # honest proxy, CH07-style refusal
        if ledger.batch_refused([core(r) for r in agg.records]):
            return None
        return S.delegate_aggregate(token, grant, agg)

    assert reenc_oracle(S.aggregate(ctx, [challenge])) is None          # the challenge itself is refused

    # adversary: re-randomise A only; Lambda, c, E and the signature are untouched
    Lam, c, A, E = parse_body(challenge.record.body)
    r = g.random_scalar()
    K = D.point(jk.ref)
    mauled = replace(challenge.record, body=_body(Lam, c, A + g.mul(r, K), E))
    agg = replace(S.aggregate(ctx, [challenge]), records=(mauled,))     # same authenticator
    public_ok = S.verify_public(agg)
    out = reenc_oracle(agg)

    # corrupted delegatee decrypts locally (no decryption oracle involved)
    C, gamma, _ = out.token_public
    T = g.mul(g.inv(corrupted.k), g.decode_point(gamma))
    omega = int.from_bytes(_xor(C, g.hash_bytes("cea/rk-mask", encode((g.encode_point(T), jk.ref.fields())))), "big")
    Abar = parse_body(out.aggregate.records[0].body)[2]
    Q_star = g.mul(omega, Abar) - g.mul(r, g.G)
    recovered = _xor(E, _kdf(Q_star, len(E)))
    guess = 0 if recovered == m0 else 1

    result = {
        "mauled_record_is_not_a_registered_derivative": not ledger.batch_refused([core(mauled)]),
        "mauled_record_passes_public_verification": public_ok,
        "proxy_reencrypts_mauled_record": out is not None,
        "corrupted_delegatee_recovers_challenge_message": recovered == (m0, m1)[b],
        "adversary_guess_correct": guess == b,
        "scope": ("Refutes a CH07-style per-ciphertext G-CONF for CEA when a corrupted delegatee is served "
                  "for the target class. Does not affect the class-granularity game G-CONF-CLASS."),
    }
    if not all(v for k, v in result.items() if k != "scope"):
        raise RuntimeError(json.dumps(result))
    return result


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
