# Negative controls

commutation_v3.py: re-encrypt records and carry the old aggregate scalar; verification fails.
Rebuilding with the individual scalars succeeds. This is a specific update failure, not a
general impossibility theorem.

unrestricted_token_scope.py: a proxy/delegatee coalition derives the inherited effective
key and reads a record outside a declared label set. This shows why unrestricted tokens
cannot acquire cryptographic scope merely through a policy label or a signature wrapper.

Preserve a failing design as a negative control. A green diagnostic means the stated
behavior reproduced, not that a candidate passes a security game.

unbound_coefficient_v3.py (added 25 Oct 2026): the obvious way to make v3's Theta survive
delegation, namely dropping the mutable A from the coefficient hash, is unsound. A receiver who
knows k_j and registers one rogue key picks A (hence the hidden nonce) after the coefficients
are fixed, and forges an aggregate attributing a chosen message to an honest sender, without
the sender's secret. The original v3 rule rejects the same aggregate. The attack covers this
specific coefficient rule only.

cea_reenc_mauling.py (added 25 Oct 2026): CEA fails a per-ciphertext (Canetti-Hohenberger
style) confidentiality game. The honest proxy, serving a corrupted delegatee for the target
class and refusing only the challenge, re-encrypts a re-randomised challenge (A + rK passes
VerifyPublic because A is not signed); the delegatee decrypts it locally. CEA's delegation
control is therefore per class, never per ciphertext.
