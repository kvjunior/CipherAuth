"""An unrestricted v3 token does not become scoped by attaching a policy label or grant."""
import json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "baselines/claude_v3/source"))
import ec
import adspre as S
import candidate_v3 as V

def run():
    pp = S.setup()
    sender, ss = S.keygen(pp, "sender")
    j, sj = S.keygen(pp, "j")
    l, sl = S.keygen(pp, "l")
    rk, _ = V.rkg(pp, j, sj, l)
    T = rk.gamma / S.k_of(pp, l, sl)
    omega = int.from_bytes(ec.xor(rk.C, S.H3(j.ID, T)), "big")
    recovered_k = rk.Omega * pow(omega, -1, ec.q) % ec.q
    allowed_tags = {b"allowed"}
    target_tag = b"outside"
    m = b"outside grant".ljust(32, b"\0")
    c = V.signcrypt(pp, sender, ss, j, m, target_tag)
    commitment = c.B - c.A / recovered_k
    recovered_message = ec.xor(c.E, V.H3(sender.ID, commitment))
    result = {
        "declared_scope_excludes_target_tag": target_tag not in allowed_tags,
        "coalition_decrypts_target_using_unrestricted_token": recovered_message == m,
        "scope": "Unrestricted-token negative control, not a break of an implemented scoped-PRE scheme."
    }
    if not all(v for k, v in result.items() if k != "scope"):
        raise RuntimeError(json.dumps(result))
    return result

if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
