"""Reproduce failure of the direct carry-Theta transformation of a compressed v3 aggregate.
This is NOT a general impossibility theorem.
"""
import json, sys
from pathlib import Path
from dataclasses import replace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "baselines/claude_v3/source"))
import adspre as S
import candidate_v3 as V

def run():
    pp = S.setup()
    j, sj = S.keygen(pp, "j")
    l, sl = S.keygen(pp, "l")
    items = []
    for i in range(4):
        p, s = S.keygen(pp, "s" + str(i))
        c = V.signcrypt(pp, p, s, j, bytes([i])*32, b"epoch001")
        items.append((p, c))
    first = V.agg_new(("L1", "j", None, None))
    for p, c in items:
        first = V.agg_append(first, (p, c.A, c.B, c.E, c.tau), c.theta)
    rk, _ = V.rkg(pp, j, sj, l)
    rebuilt = V.agg_new(("L2", "l", "j", "grant-1"))
    for p, c in items:
        transformed = V.reenc(pp, rk, p, j.ID, c)
        rebuilt = V.agg_append(rebuilt,
                  (p, transformed.Abar, transformed.B, transformed.E, transformed.tau),
                  transformed.theta)
    carried = replace(rebuilt, Theta=first.Theta)
    opener = lambda r: V.open_second(pp, l, sl, j.ID, rk.C, rk.gamma, r[0], r[1], r[2], r[3])
    result = {
        "reaggregation_with_individual_scalars_accepts":
            V.agg_verify(pp, rebuilt, opener, j) == [bytes([i])*32 for i in range(4)],
        "transformed_records_with_original_compressed_scalar_reject":
            V.agg_verify(pp, carried, opener, j) is None,
        "compressed_scalar_changes": first.Theta != rebuilt.Theta,
        "scope": "Direct carry-Theta transformation only; alternate constructions are not excluded."
    }
    if not all(v for k, v in result.items() if k != "scope"):
        raise RuntimeError(json.dumps(result))
    return result

if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
