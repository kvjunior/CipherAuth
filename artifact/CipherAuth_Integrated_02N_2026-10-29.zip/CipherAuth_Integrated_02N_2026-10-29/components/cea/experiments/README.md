# Experiments after the construction is stable

Initial experiments are algebraic diagnostics and operation/byte accounting, not an IoT
deployment or a claim to beat old unexplained timings.

Once a proven construction exists, implement identical-baseline interfaces and evaluate
n, distinct sender count, grant groups, message sizes, preprocessing, cold/warm state,
hash-input bytes, real serialized bytes, and multiscalar multiplication.
Add public seeds for reproducible experiments only; do not present seeded keys as production randomness.

No benchmark implementation is provided for an unresolved construction.
