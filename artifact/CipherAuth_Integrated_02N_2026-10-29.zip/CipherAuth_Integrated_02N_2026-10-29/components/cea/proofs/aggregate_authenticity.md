# Aggregate proof obligations

Compare exact prior coefficients and oracle interfaces; state AGM+ROM if inherited.
Handle adversarial public keys, key aliases/versions, repeated senders, hidden commitments,
online hash queries, re-randomization, transformed records, and cross-level freshness.

A final forgery relabelling does not establish online oracle consistency.
Any forking argument must identify the terms fixed across forks and its actual loss.
If an AGM argument avoids rewinding, state precisely what algebraic representations are
available and when, particularly for recipient keys and transformed commitments.
