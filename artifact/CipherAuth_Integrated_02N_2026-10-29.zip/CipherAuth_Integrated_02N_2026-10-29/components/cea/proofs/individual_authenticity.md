# Individual authenticity comparator

For a plain-key v3 variant, obtain the inner and outer signatures through a Schnorr oracle.
Encrypt the known inner commitment using independent randomness and the recipient's public
key. A successful individual forgery, opened with the output recipient key, yields a Schnorr
signature on a fresh domain-separated origin statement.

This is the known sign-then-encrypt authenticity idea, not the intended contribution.
For a singleton weighted aggregate, explicitly recover theta=Theta/z using nonzero z.
Do not conflate this argument with a reduction for the inherited certificateless key code.
Second-level sender authenticity does not prove that the origin authorized the delegation.
