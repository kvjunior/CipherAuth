# CEA confidentiality (G-CONF, G-SCOPE): reduction plan, OPEN

**Status: OPEN. A plan only, not a proof.** Ledger: `S-CEA-CONF` (class granularity, open),
`S-CEA-CONF-CT` (per-ciphertext, **refuted**), `S-CEA-SCOPE`.

## Correction, 25 Oct 2026

The first version of G-CONF left `ReEncO` unrestricted, which made the game trivially
winnable through local decryption by a corrupted recipient. `spec/games.md` now separates
G-CONF-CLASS (the target class is never served to a corrupted party) from G-CONF-CT
(CH07-style: the proxy serves corrupted delegatees for non-derivative records).
CEA **fails** G-CONF-CT by the mauling attack `attacks/cea_reenc_mauling.py`: the proxy
re-encrypts A*+rK, which passes VerifyPublic because A is not signed. The plan below targets
G-CONF-CLASS only. A scheme for G-CONF-CT needs ciphertext validity that the proxy can check.
The known tool is a proof of knowledge of the encryption randomness (Schnorr-signed ElGamal,
IND-CCA in AGM+ROM: Fuchsbauer–Plouviez–Seurin, EUROCRYPT 2020, ePrint 2019/877). Whether
such proofs can be half-aggregated within one class batch (all records share the class key K
as base) without losing extractability is a candidate technical question. Its novelty is
**unverified**.

## Intended statement (G-CONF-CLASS)

G-CONF-CLASS advantage ≤ (gap-CDH advantage) + (ROM query terms) in the ROM, with a polynomial loss
in the number of class keys and delegatees. This is the expected shape for hashed-ElGamal
with confirmation (DHIES/ECIES-KEM-style) plus Canetti–Hohenberger-style single-hop
re-encryption. It is *expected*, not established.

## Planned hybrid argument (each step still to be written and checked)

1. Embedding. Take an instance (P, aP, bP). Set the target class key K* = aP and the
   challenge A* = bP (implicitly t = b/a), so Q* = t·P = a⁻¹·bP. Computing Q* is the
   "divisible" DH problem, polynomially (not tightly) equivalent to CDH; the exact variant and
   its loss must be fixed in the write-up. KDF(Q*), Hd(Q*) are uniform until 𝒜 queries Q*;
   the reduction recognises a query Q with A* = a·Q via its DDH oracle on (P, aP, Q, A*).
   Note that A* = t·K* cannot be computed directly with Q* embedded as bP, which is why the
   instance goes into A*.
2. Decryption oracle for the target class: for a queried (A, E, c), scan the KDF/Hd/Hc query
   lists for Q with DDH(K*, Q, A) true; if none, reject (fails only if 𝒜 guessed Hc without
   querying, ≤ q/2^256).
3. Tokens from the target class to honest ℓ (held by the honest proxy; only C, γ, W and the grant reach 𝒜): Ω = ω·a is unknown. Sample Ω uniformly; C
   uniformly; γ = t′·K_ℓ. Hmask(T) is never queried unless 𝒜 computes T = k_ℓ⁻¹γ, which is a
   second (honest-ℓ) gap-CDH event. Delegated decryption at ℓ then reduces to target-class
   decryption, since ω·Ā = a⁻¹A for Ā = Ω⁻¹A.
4. Derivatives: re-signed/re-aggregated challenge cores are refused by `DerivativeLedger`;
   `ReEncO` outputs on them are registered. 𝒜 holds no target-class token in G-CONF-CLASS.
   Mauled challenges (A*+rK) fail the commitment check at every opener; `ReplayMask` is a
   conservative extra.
   Check the adequacy of this relation against RCCA (CKN03) and CH07's derivative definition.
5. The public commitment c* = Hc(m_b, Hd(Q*)) must be shown independent of b until Q* is
   queried (ROM).


## G-SCOPE

Class keys for different (τ, e) are independent, and a token reveals only a function of its
own class key. Plan: a hybrid over classes, where the reduction generates all non-target class
keys itself (so it can answer any token query for them, including to corrupted delegatees and
with a corrupted proxy), and uses the G-CONF reduction for the target class. Conditional on
G-CONF; OPEN.

## Explicit non-claims

- In-class collusion safety is false (G-KR attack, tested).
- No revocation: deleting a token revokes nothing against a coalition that retained it.
- Public verifiability of the authenticator reveals sender identities and batch sizes; G-CONF
  protects messages only.
