# Established local identity

Let X=xP, K=kP, h nonzero, Lambda=theta P-hX, and T=kX.
Then D=k Lambda=theta K-hT, and T=h^{-1}(theta K-D).
Both directions follow by distributing scalar multiplication and rearranging.

This equates one simulator task with computing a CDH value. It does not show that all
simulators require recipient-key extraction or that the compact scheme is insecure.
