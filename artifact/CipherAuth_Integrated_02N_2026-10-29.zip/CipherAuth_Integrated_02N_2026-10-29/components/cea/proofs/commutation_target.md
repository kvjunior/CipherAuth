# Main open lemma: status after the novelty gate (25 Oct 2026)

## What was asked

Can Aggregate-then-Delegate and Delegate-then-Aggregate certify the same ordered original
sender statements and origin-issued grant, without recovering individual signature scalars
and without decryption at the proxy?

## Answer for the question as posed: yes, by a known generic composition

CEA (`spec/cea_construction.md`): sign a statement that contains a hiding, binding
commitment c = Hc(m, Hd(tP)) (not the ciphertext), encrypt with single-hop re-encryptable
hashed ElGamal, and aggregate the Schnorr signatures with Chen–Zhao IASchnorr. The commuting
property is Lemma 0 of `proofs/cea_authenticity.md` (one line). Aggregate insider
authenticity reduces to CZ22 Theorem 2 (AGM+ROM) plus collision resistance of Hc
(Theorem 1, sketch, unreviewed); grant authenticity to Schnorr EUF-CMA (Theorem 2, sketch).
Each ingredient is known: commit-then-encrypt-and-sign / signing a commitment (An–Dodis–Rabin
2002), CH07-style single-hop PRE, CZ22 incremental half-aggregation.

**Implication.** Commutation alone is not a novel result, and the paper cannot claim it.
Novelty claim `N-COMMUTATION` has status `defeated_by_known_composition`.

## What the v3 diagnostics show (kept as negative results)

- Direct carry-Θ fails for v3 (`attacks/commutation_v3.py`), because v3's coefficients bind
  the mutable component A.
- Removing A from the v3 coefficient hash is **unsound**: a receiver who knows k_j picks A
  (hence the hidden nonce Λ = B − k_j⁻¹A) after the coefficients are fixed, and cancels an
  honest sender's challenge term (`attacks/unbound_coefficient_v3.py`, concrete forgery).
- A delegatable v3 that keeps A bound must ship the original A (or an equivalent) plus a
  batch DLEQ proof of re-encryption, about 131 B per record, against CEA's 130 B record body
  (Λ 33, c 32, Ā 33, E 32 for 32-byte messages). Hiding the nonce buys no saving once
  compressed delegation is required. (Counting estimate from the earlier analysis; not
  measured.)

## Cost of CEA (prototype layout, counted, `scripts/cea_demo.py`)

Per record: 65 authentication-dependent bytes (Λ, c) on top of the hashed-ElGamal core
(A, E); per batch: 32 B (s̃). Delegation adds the signed grant and the 97-byte token public part
(C, γ, W). Field-level model: 330 B. The earlier figure of 362 B omitted W; under its own
assumptions it should have been 394 B. **Measured** with the canonical wire format
`cipherauth.wire` at n = 8, 32-byte messages: origin aggregate 1337 B, delegated 1665 B, so
delegation adds 328 B. Public verification of n records from u senders: n − 1 + u + 1 scalar
multiplications (11 for n = 8, u = 3, counted). DelegateAggregate: verification, one grant
verification, n multiplications and one inversion (21 for n = 8). No timings are claimed.

## Refined question (OPEN; not yet shown to be new)

In a pairing-free prime-order group, with records re-encryptable by a single-hop proxy and
authentication that commutes with re-encryption:

**Q-R.** What is the minimum per-record authentication overhead, beyond a plain re-encryptable
ciphertext, for aggregate insider authenticity against a receiver who knows the decryption
key? CEA spends one group element (Λ) plus 2κ bits (c). Two sub-questions:

1. *Nonce term.* Can the per-record group element be avoided? CGKN21 (Chalkias–Garillot–
   Kondi–Nikolaenko, ePrint 2021/350) give "strong evidence" that Schnorr-type aggregation
   below half size needs hash-function-specific proofs. That is evidence, not a theorem.
   Whether a formal lower bound exists in a stated model (e.g. generic group plus programmable
   ROM, or black-box use of the hash) must be checked in the literature before any claim.
   With pairings (BLS) the term vanishes, so pairing-freeness is essential to Q-R.
2. *Binding term.* Can the group element itself carry the delegation-invariant binding to
   the plaintext (as v3's hidden B = Λ + tP tries to), so that no separate c is needed while
   the scheme still commutes? The unbound-coefficient attack rules out the obvious way; it
   does not rule out every design. A proof would need a model of which values a malicious
   receiver can choose after the coefficients are fixed.

3. *Recipient-only verification.* CEA's authenticator is publicly verifiable; v3's was
   checkable only by the recipient. Neither hides sender identities from the aggregator: v3
   records carry the sender ID too. Recipient-only verifiability is therefore a different
   property from sender anonymity, and neither has been defined or claimed here. Either one
   would need a definition and a fresh novelty gate.
4. *Per-ciphertext delegation (G-CONF-CT).* CEA fails it (mauling attack). Meeting it
   seems to require ciphertext validity that the proxy can check. Can a per-record proof of
   knowledge of the encryption randomness (Schnorr-signed-ElGamal style, FPS20) be
   half-aggregated across a class batch, where all records share the base K, with
   extractability intact and with the result surviving DelegateAggregate? This is a candidate
   technical question; its novelty and value are unverified.

## Honest assessment (does not change the venue)

The originally posed question is answered by known techniques. The composition's
confidentiality is **not** settled by that answer. It is open at class granularity and
refuted at per-ciphertext granularity (G-CONF-CT). Of the refined sub-questions:
- Sub-question 1 appears close to the CGKN21 evidence.
- Sub-question 2 is unsettled. Its significance is not decided by the bytes it might save; it
  would matter only through a representation theorem or a lower bound.
- Sub-question 4 (aggregated, delegation-surviving ciphertext validity) is the first point
  where a non-trivial security argument seems unavoidable. Its novelty is unchecked.

None of these has a verified novelty gap or a theorem. STOC 2027 remains the stated target;
a theory result here would need one of these turned into a precise construction class with
a prior-work comparison and a complete proof. **No candidate main theorem is stated,** because
none is concrete yet. Further implementation or passing tests cannot supply one.

IDASR26 (Choi–Jeong–Byun, Inf. Sci. 2026) is still an unresolved comparison: the full text
was inaccessible from this environment.
