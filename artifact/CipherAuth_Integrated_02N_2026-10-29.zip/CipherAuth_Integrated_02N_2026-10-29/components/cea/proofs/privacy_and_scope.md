# Privacy and scope obligations

Choose an existing definition as a starting point and formalize the vector/recipient-change
adaptation. Show the simulator answers all permitted queries and justify every exclusion.
Give separate in-scope, out-of-scope, and key-recovery statements.

Public grant signatures do not stop a malicious proxy from applying an unrestricted token.
Do not claim revocation after a malicious coalition retains old decryption material.
Do not claim a decisional gap oracle computes a computational DH value.

## CEA comparator (added 25 Oct 2026)

The games are now fixed in `spec/games.md` (G-CONF, G-SCOPE, G-KR) and the reduction plan is
in `proofs/cea_confidentiality.md`. Status: G-CONF open; G-SCOPE open and conditional on
G-CONF; in-class key recovery is a tested attack (`test_coalition_recovers_only_its_class_key`).
Scope is enforced cryptographically only at class granularity (independent decryption keys per
origin, tag and epoch); the grant signature adds authentication, not scope. The executable
`DerivativeLedger` and `ReplayMask` fragments implement only the bookkeeping of the oracle
restrictions; their adequacy against RCCA/CH07 definitions is itself an open obligation.
