# Proof ledger

Labels: **proved-identity** (elementary algebra, checked), **sketch-unreviewed** (complete
argument written, composes known theorems, not yet reviewed by a human author),
**open** (plan or nothing), **refuted** (concrete attack). Tests never change a label.

## v3 baseline (unchanged from the frozen record)

| Item | Status |
| --- | --- |
| Local compact-simulation CDH identity | proved-identity; not novel |
| Oracle-based v3 signcryption simulation | elementary conditional argument |
| Individual v3 authenticity | familiar Schnorr extraction for an idealised plain-key variant; legacy embeddings must be stated precisely |
| Aggregate authenticity of v3 | open |
| Confidentiality of v3 | open |
| Cryptographic scope in v3 | refuted (`attacks/unrestricted_token_scope.py`) |
| v3 with A removed from coefficients | refuted (`attacks/unbound_coefficient_v3.py`) |
| Carry-Θ delegation of v3 | fails (`attacks/commutation_v3.py`); no impossibility claimed |

## CEA comparator (generic composition; `spec/cea_construction.md`)

| Item | Status | Assumptions / model | Where |
| --- | --- | --- | --- |
| Lemma 0: exact commutation | proved-identity (trivial) | none | `proofs/cea_authenticity.md` |
| Thm 1: aggregate insider authenticity (G-AGG) | sketch-unreviewed | CZ22 Thm 2 (AGM+ROM, chosen key) + CR of Hc; loss abs(𝓗) | same |
| Thm 2: grant/delegation authenticity (G-DEL) | sketch-unreviewed | Schnorr EUF-CMA; identity-authenticated registration | same |
| G-CONF-CLASS per-record confidentiality, class granularity | open (plan; game corrected 25 Oct) | expected gap-CDH-type, ROM | `proofs/cea_confidentiality.md` |
| G-CONF-CT per-ciphertext (CH07-style ReEncO to corrupted delegatee) | refuted (mauling) | — | `attacks/cea_reenc_mauling.py` |
| G-SCOPE out-of-class confidentiality | open, conditional on G-CONF-CLASS | independent class keys | same |
| G-KR in-class collusion safety | refuted (key recovery) | — | `tests/unit/test_cea.py` |
| Revocation | not claimed | — | — |

## Research direction

| Item | Status |
| --- | --- |
| Novelty of commutation | defeated by known composition |
| Refined question Q-R incl. sub-question 4, aggregated proxy-checkable validity (`proofs/commutation_target.md`) | open; novelty unverified |
| Candidate main theorem | none stated |

Every proof must map to the exact specification, algorithm version, adversary, oracle model,
query counts, loss and exceptional events. A sketch becomes a reviewed proof only after an
author checks it line by line against the transcribed CZ22 theorem.
