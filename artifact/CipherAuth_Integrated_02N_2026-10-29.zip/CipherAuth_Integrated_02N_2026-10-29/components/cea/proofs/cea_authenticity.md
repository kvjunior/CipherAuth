# CEA authenticity: commutation lemma, aggregate insider authenticity, grant authenticity

**Status: proof sketches written by an AI assistant, NOT reviewed by the human authors.**
They are compositions of known results; none is claimed as a new technical contribution.
Ledger entries: `S-CEA-AGG`, `S-CEA-DEL`, `A-CEA-COMMUTE` in `claims/claims.json`.
Games: `spec/games.md`. Construction: `spec/cea_construction.md`.

External result used (CZ22 = Chen–Zhao, ePrint 2022/222, Sec. 4, Fig. 2, Theorem 2):
IASchnorr is CK-AEUF-CMA secure (chosen-key aggregate unforgeability: one honest target key
X*, signing oracle for X*, all other keys adversarial and unrestricted), with a *tight*
reduction from Schnorr EUF-CMA, in the **AGM + ROM** (H1, H2 random oracles). The exact
additive terms of Theorem 2 must be transcribed from the paper before this text is used;
they are written below as ε_CZ. Schnorr EUF-CMA is tightly implied by DL in AGM+ROM
(Fuchsbauer–Plouviez–Seurin, EUROCRYPT 2020).

## Lemma 0 (commutation; trivial)

For every valid token/grant for class (j, τ, e) and every list of valid submissions
sub_1..sub_n for that class:
`DelegateAggregate(tok, G, Aggregate(ctx, sub))` and
`AggregateDelegated(G, tok.pub, [DelegateRecord(tok, G, sub_i)])` have identical records and
identical s̃, and both open under ℓ to the list returned by `Open(j, Aggregate(ctx, sub))`.

Proof. The IASchnorr entry of record i is (Λ_i, X_i, st_i) with
st_i = enc(…, ref_S, ref_K, τ, e, c_i). DelegateRecord changes only A_i, deterministically
(A_i ↦ Ω⁻¹A_i). So both orders hash the same entries, get the same a_i, and s̃ = Σ a_i θ_i in
both. Correctness of re-encryption: ω·Ω⁻¹·A = ω(ωk)⁻¹·t·k·P = t·P = Q, so m and c are
recovered identically. ∎ (Checked by `test_both_orders_certify_identical_statements`.)

**Remark.** The lemma holds only because the signature binds an *invariant* commitment
instead of the ciphertext. Making a design whose coefficients bind a *mutable* component
invariant by deleting that component from the hash is unsound for v3:
`attacks/unbound_coefficient_v3.py` gives a concrete receiver-insider forgery.

## Theorem 1 (G-AGG). For every algebraic PPT 𝒜 with q_S Signcrypt queries and |𝓗| honest senders,

  Adv^{G-AGG}(𝒜) ≤ |𝓗| · Adv^{CK-AEUF}_{IASchnorr}(ℬ) + Adv^{CR}_{Hc}(ℬ′),

with ℬ algebraic, running in time ≈ time(𝒜) + O(q_S + n) group operations, and making q_S
signing queries; ℬ′ is a collision finder of similar running time. Combined with CZ22 Thm 2,
the first term is bounded by Schnorr EUF-CMA (hence DL) in AGM+ROM up to ε_CZ.

Proof sketch.
1. *Guess.* ℬ picks S* ∈ 𝓗 uniformly; it receives X* from the CK-AEUF challenger and sets
   X_{S*} = X*. Other honest senders' keys ℬ generates itself. H1, H2 queries of 𝒜 are
   forwarded to the challenger's oracles; Hd, Hc, KDF, Hmask are simulated by ℬ (or are
   concrete hash functions; only collision resistance of Hc is used).
2. *Signcrypt simulation (perfect, no extraction).* On SigncryptO(S*, ref_K, m, τ, e), ℬ looks
   up K (a public, possibly adversarial, group element), samples t, computes Q, A, d, E, c
   honestly, forms st, and obtains (Λ, θ) from the signing oracle on st. It records
   st ↦ (m, d). The distribution is exactly the real one. Registration of adversarial keys is
   plain storage; ℬ never needs a corrupted secret.
3. *Algebraicity.* Every group element 𝒜 receives is P, X*, an oracle R value, an element
   𝒜 itself output, or A = t·K with t known to ℬ and K an element 𝒜 output (with
   representation) or ℬ generated. Hence ℬ can translate 𝒜's representations into
   representations over its own inputs, so ℬ is algebraic.
4. *Output.* 𝒜 outputs Z and dk such that Open(dk, Z) contains (S*, ref_K, τ, e, m) ∉ 𝒬 at
   index i (with probability ≥ 1/|𝓗| the forged sender is S*, independently of 𝒜's view).
   Open succeeded, so (a) every record lies in the batch class, (b) the IASchnorr equation
   holds for the entries (Λ_k, X_k, st_k) recomputed from the record fields, with X_i = X*
   because ref_{S*} resolves (fingerprint-checked) to X*, and (c) c_i = Hc(m, Hd(Q_i)) where
   Q_i = Open's decryption with dk.
   - Case A: st_i was never queried to the signing oracle. Then ((X_k, st_k)_k, (Λ_k)_k, s̃)
     is a valid CK-AEUF forgery for X* (index i is a target-key entry with a fresh message).
   - Case B: st_i was queried. st_i determines (S*, ref_K, τ, e, c_i), so there is a query
     (S*, ref_K, m′, τ, e) ∈ 𝒬 with commitment c′ = c_i = Hc(m′, d′). Because
     (S*, ref_K, τ, e, m) ∉ 𝒬 we have m ≠ m′, so (m, Hd(Q_i)) ≠ (m′, d′) are distinct inputs
     (encoding is injective) with equal Hc outputs. ℬ′ (running the same simulation with its
     own S* key) computes Q_i from dk, which 𝒜 outputs, and returns the collision.
   Cases A and B are exhaustive. ∎

What the theorem does **not** say: nothing about order/completeness against a malicious
aggregator; statements of corrupted senders are not authenticated; confidentiality is separate.
Dropping `dk` from the output (an honest-recipient variant) is easier for the reduction:
ℬ generates that recipient key itself.

Delegated-level outputs: the same proof applies verbatim, since the delegated opener runs the
same VerifyPublic on the same entries and the same commitment check.

## Theorem 2 (G-DEL). Under the identity-authentication assumption of `spec/games.md`,

  Adv^{G-DEL}(𝒜) ≤ n_j · Adv^{EUF-CMA}_{Schnorr}(ℬ),

where n_j is the number of honest signing-key versions of origin j (ℬ guesses which one).

Proof sketch. ℬ embeds its Schnorr challenge key as the guessed version of j's signing key,
generates all class decryption keys itself, and answers GrantO by building the token itself
and signing `grant.message()` with its signing oracle. If the delegated opener accepts Z, then
`verify_grant` accepted a Schnorr signature under an issuer key with identity j (by the
assumption, an honest version of j's key), and the payload tuple is not in 𝒢. `Grant.message()`
is an injective encoding of the full payload, so the message was never queried: an EUF-CMA
forgery. The token digest in the payload binds the public token part the delegatee uses, so a
proxy cannot pair an issued grant with a different token without changing the payload. ∎

Not claimed: anything about tokens retained after "revocation" (no revocation exists);
anything inside a class against a proxy–delegatee coalition (they recover the class key, see
G-KR). Authenticity of statements under a valid grant still follows from Theorem 1.

## Review obligations before any use in a paper

- Transcribe CZ22 Thm 2 (exact game, H1/H2 inputs, additive terms) and check that this
  implementation's H1(R, st) and H2(prefix of (R, X, st)) match Fig. 2 exactly, including
  a_1 = 1 and the encoding of L_i.
- Check that st's key-reference prefix does not interact with CZ's chosen-key analysis.
- Independent human review of both sketches. Tests passing is not evidence for them.
