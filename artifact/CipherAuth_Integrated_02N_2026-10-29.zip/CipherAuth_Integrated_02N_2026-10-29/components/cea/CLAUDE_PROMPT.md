# Claude prompt

Continue exclusively with our ADS-PRE research project. Keep STOC 2027 as my requested target.
Use the attached encrypted_auth_research workspace as the starting artifact and preserve its
frozen baselines. Our working title is:

**Commuting Aggregation and Delegation for Encrypted Authentication**

This is a provisional research title, not a claim that a new theorem exists. The chosen
direction is public aggregation that remains usable when an already compressed aggregate
is delegated to another recipient, with authenticated scope and precisely stated security.
Do not ask me to choose again between Q1-prime and the existing v3 aggregate proof.
Treat those as supporting issues within this selected direction.

## What has been independently checked

Your twelve v3 Boolean checks reproduce exactly. A new negative control also reproduces:
after a first-level aggregate is compressed, transforming its records while retaining its
old Theta fails verification, whereas re-aggregating using the individual theta_i succeeds.
The coefficients change with the transformed records/context. This is failure of a direct
update, not a general impossibility result.

The individual-signature argument is a known Schnorr/sign-then-encrypt route. The supplied
code still uses the old certificateless key infrastructure, so align it with the plain-key
theorem before making security claims. Prefix weighting is published; a grant signature
alone does not make the inherited unrestricted re-key cryptographically scoped.

## Selected question and initial scope

Can Aggregate-then-Delegate and Delegate-then-Aggregate certify the same ordered original
sender statements and origin-issued grant, without recovering individual signature scalars
or decrypting messages at the proxy?

Use ordinary versioned public keys, static corruptions, malicious recipients/proxy/senders,
single-hop unidirectional delegation, and initially one original recipient, one grant group,
and one tag/epoch scope per batch. Require cryptographic out-of-scope protection if it is
claimed. Randomized ciphertexts need not be byte-identical across the two paths.
Separate sender authenticity, delegation authenticity, confidentiality, and key recovery.

## Do the work in this order

1. Read README.md, RESEARCH_DIRECTION.md, CODEBASE_MAP.md, spec/, proofs/, claims/, and the
   frozen source before editing. Run the one-command reproduction and report actual results.
2. Complete a precise novelty comparison before inventing a construction. Inspect the exact
   games and algorithms of the direct 2026 IDASR baseline (Choi–Jeong–Byun, DOI
   10.1016/j.ins.2026.123676), incremental half-aggregation, fully succinct MKHS, malleable and
   policy signatures, verifiable/conditional PRE, recent transcript rebinding, and HRA work.
   Verify each claim in a primary source. Mark full-text access failures and unknowns explicitly.
   A generic composition providing the same guarantees/costs defeats the proposed novelty;
   demonstrate that comparator instead of manufacturing a gap.
3. Finalize the syntax and games. Include full key/identity/version, original recipient, tag,
   epoch, suite, token digest, grant ID and evidence bindings. Define all oracle phases and
   transformation-related challenge restrictions. State ROM/AGM/other model assumptions.
   Never turn a possession proof into an available extraction oracle without justification.
4. Identify the genuinely new technical lemma. Give a complete proof or a concrete attack.
   Distinguish a simulator limitation from a scheme-security impossibility. Do not force
   commutation by removing hash bindings without a soundness argument.
5. Implement the justified candidate behind the existing interface. DelegateAggregate may
   receive only the compressed object, public inputs, token, and grant. Any retained original
   ciphertexts, signatures, auxiliary proofs, or archive access must be explicit and costed.
   Keep an unresolved operation explicit when its mathematics is unresolved.
6. Build complete authenticity and confidentiality reductions. Model scoped-token collusion
   cryptographically. Do not claim revocation from deleting a re-key held by a malicious party.
   Add adversarial tests for context/key/scope substitution, malformed inputs, cancellation,
   aggregate extension, re-randomization, and both operation orders.
7. Measure a stable construction only after its claims and baselines are clear. Count all
   signature-dependent material, including encrypted commitments/responses, metadata, grant
   proofs, preprocessing, hash-input bytes, inversions, and MSM. Do not reconstruct lost
   historical timings or invent improvements.

## Required outputs

Return an updated runnable directory, an exact change/provenance report, actual test outputs,
the completed novelty matrix, formal games, and a proof-status ledger. State one candidate
main theorem only when its assumptions, costs and new idea are concrete. Label unproved
claims and never use passing tests as a security proof.

Structure the eventual paper around the problem, closest prior result, new theorem and
technical idea, with fully verifiable proofs and clear limits. Follow the current official
STOC 2027 call, including its presentation and assistance-disclosure requirements. Maintain
the assistance log accurately. Do not promise acceptance, rename the project to imply novelty,
add unrelated application experiments, or change the conference/year on my behalf.

Proceed autonomously on this direction. If the intended novelty is already known, document
the exact implication and refine the precise compatibility question within this direction;
do not fabricate a theorem or silently weaken the adversary to make a claim pass.
