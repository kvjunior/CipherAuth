# Change and provenance report — 25 Oct 2026

Base: Encrypted_Authentication_Research_Workspace_2026-10-24.zip (72 files; manifest verified
before any edit: all hashes matched; 12 unit tests passed; v3 baseline 12/12 exact match;
both negative controls reproduced).

## Frozen material: untouched

baselines/claude_v3/source/*, baselines/claude_v3/expected/v3_results.json,
baselines/claude_v3/source_manifest.json, archive/review/*. The new attack imports the frozen
baseline read-only from its directory. No expected output was regenerated or edited.
provenance/source_manifest.json was regenerated with scripts/build_manifest.py *after* these
intentional edits (it records the new snapshot; it is not used to hide changes).

## Added

| File | Purpose |
| --- | --- |
| src/cipherauth/group.py | Validated P-256 arithmetic, encodings, hash-to-scalar, operation counters |
| src/cipherauth/schnorr.py | Schnorr + IASchnorr (CZ22 Fig. 2), streaming prefix coefficients |
| src/cipherauth/cea.py | CEA comparator: signcrypt, aggregate, append, public verify, grant, DelegateAggregate, both orders, open |
| attacks/unbound_coefficient_v3.py | Concrete forgery on v3 with A removed from coefficients |
| scripts/cea_demo.py | Both orders, Θ invariance, counted operations, size model (no timings) |
| tests/unit/test_cea.py | 21 behavioural/adversarial tests (substitution, malformed input, grants, scope, cancellation sanity check, extension, derivatives, size model) |
| spec/games.md | G-AGG, G-DEL, G-CONF, G-SCOPE, G-KR with oracle phases, ROM/AGM labels, registration and PKI assumptions |
| spec/cea_construction.md | Exact algorithms, retained material, non-claims |
| proofs/cea_authenticity.md | Lemma 0; Theorems 1–2 (sketches, unreviewed) |
| proofs/cea_confidentiality.md | Reduction plan (open) |
| CHANGES.md | This report |

## Modified

| File | Change |
| --- | --- |
| src/cipherauth/games/privacy.py | Added `DerivativeLedger` (existing `ReplayMask` unchanged) |
| src/cipherauth/claims.py | New statuses `sketch_unreviewed` (security), `defeated_by_known_composition` (novelty) |
| tests/unit/test_claims.py | Accepts the two new statuses; still forbids `reviewed_proof`/`reviewed_gap`; test renamed accordingly |
| claims/claims.json, claims/README.md | N-COMMUTATION → defeated_by_known_composition; ten new entries; semantics documented |
| scripts/reproduce.py | Runs the new attack and the CEA demo; status strings updated |
| proofs/commutation_target.md, proofs/status.md, proofs/privacy_and_scope.md | Gate result, refined question Q-R, ledger |
| literature/novelty_matrix.md, sources.json, search_log.md | Completed matrix with reading scope; new sources |
| RESEARCH_DIRECTION.md, README.md, attacks/README.md | Status notes and run instructions (title and venue unchanged) |
| paper/ai_assistance_log.md | Session record |
| CODEBASE_MAP.md, development_status.json | New files listed |

## Defects found during this session (in new code only)

1. *CEA batch-class binding (fixed).* The first draft of `CEA.verify_public` did not check
   that every record's origin class key and epoch equal the batch context. A coalition knowing
   ω (corrupt origin plus proxy) could have placed a validly signed record addressed to another
   class inside a batch delegated under this class's grant. Fixed; regression test
   `test_record_from_another_class_cannot_join_a_batch`.
2. *Token digest recomputation (fixed before the first test run).* The delegatee could not
   recompute a digest that hashed Ω; the public part now carries W = H(Ω).
3. *Test vector error (fixed).* A test assumed x = 5 is not a P-256 x-coordinate; it is. The
   test now searches for a non-residue x. The decoder was correct.

## Unexpected results

None of the frozen expected outputs changed. The only unexpected outcomes were defects 1–3.

# Addendum — 25 Oct 2026, after an independent readiness review

The review reran the archive (Python 3.12.14, cryptography 50.0.2): 83 hashes, 33 tests,
12/12 baseline, three controls and the CEA counts all reproduced; frozen files identical.
Each finding was checked against the code before changing anything.

| Review finding | Check | Action |
| --- | --- | --- |
| G-CONF `ReEncO` unrestricted, so local decryption by a corrupted recipient makes it trivial | Correct | Game split into G-CONF-CLASS (target class never served to a corrupted party) and G-CONF-CT (CH07-style). Checking it further showed **CEA fails G-CONF-CT**: new attack `attacks/cea_reenc_mauling.py` (re-randomised A passes VerifyPublic; proxy re-encrypts; delegatee decrypts). Claim `S-CEA-CONF-CT` = refuted |
| Delegation size omits W (362 → 394 B under the same assumptions) | Correct | `cea.sizes` corrected and relabelled field-level (token public part 97 B). New canonical wire format `src/cipherauth/wire.py` with round-trip and strict-decoding tests; measured n = 8: 1337 B origin, 1665 B delegated, +328 B |
| `inv` counter is only scalar inversions mod q | Correct (affine addition does field inversions) | Counter renamed `scalar_inv`; scope documented in `group.py` and the demo output |
| Scope test checks only key inequality | Correct | Added functional cross-class test (`test_recovered_class_key_does_not_open_another_class`) |
| Recipient-only verification ≠ sender anonymity; v3 exposes sender IDs | Correct; my wording "as v3 intended" was wrong | Fixed in `proofs/commutation_target.md` and the novelty matrix |
| Publicly verified sender commitments ≠ ciphertext validity | Correct | Stated in `spec/cea_construction.md`; new test for re-randomised A |
| Run summary hides skipped tests and optional dependency | Correct | `reproduce.py` records skipped tests and the `cryptography` version |
| Directory is not an authenticated CA | Correct | Stated in `spec/games.md` |
| Standalone exported Docs (model/theorem note, audit) are stale | Correct | Not changed here: those are earlier published documents outside the archive; they predate CEA and are superseded by `spec/` and `proofs/` |

Also corrected: a sentence I wrote while editing (that CEA is "RCCA at best" at the decryption oracles) was wrong. The opening check rejects a mauled A because c binds Hd(Q); only the proxy is exposed.
