# Provenance

source_manifest.json records hashes of listed source/input files, excluding generated local
outputs and Python caches. verify_manifest checks those listed hashes; it is not an
authenticity certificate or a mathematical proof checker.

baselines/claude_v3/source_manifest.json separately identifies the original supplied bytes.
archive/review/ preserves the model and audit provided with v3.

After intentional reviewed code changes, record the reason and make a new source snapshot.
Never regenerate expected outputs simply to conceal an unexpected result.
