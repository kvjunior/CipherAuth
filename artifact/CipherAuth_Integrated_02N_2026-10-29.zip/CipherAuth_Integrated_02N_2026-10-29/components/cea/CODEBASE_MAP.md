# Complete codebase directory structure

The following inventory is complete for the delivered workspace. Roles and statuses are explicit.
Implemented infrastructure is separate from an unresolved cryptographic construction.
Generated observation files appear after the verification command.

## Project root

| File | Current status | Purpose |
| --- | --- | --- |
| CHANGES.md | research-record | Change and provenance report for the 25 Oct 2026 session, including defects found. |
| CLAUDE_PROMPT.md | user-prompt | Complete selected-direction instruction, including novelty and proof gates. |
| CODEBASE_MAP.md | complete-directory-map | Every actual directory/file, role, and current implementation status. |
| Makefile | implemented | Small reproducibility entry points; no network or service calls. |
| README.md | research-blueprint | Entry point, run instructions, research scope, and distinction between infrastructure and unproved cryptography. |
| RESEARCH_DIRECTION.md | research-blueprint | One selected research direction with a concrete compatibility gap and explicit novelty gate. |
| development_status.json | status-register | Machine-readable implementation status for the directory map. |
| pyproject.toml | implemented | Package definition; executable research infrastructure uses only the standard library. |

## archive/

| File | Current status | Purpose |
| --- | --- | --- |
| archive/README.md | provenance | Distinguishes historical notes from the current research specification. |

## archive/review/

| File | Current status | Purpose |
| --- | --- | --- |
| archive/review/audit_v3.md | frozen-supplied-note | Original v3 note, preserved as context rather than adopted proof. |
| archive/review/model_v3.md | frozen-supplied-note | Original v3 note, preserved as context rather than adopted proof. |

## attacks/

| File | Current status | Purpose |
| --- | --- | --- |
| attacks/README.md | research-blueprint | Interpretation of the included adversarial diagnostics. |
| attacks/cea_reenc_mauling.py | implemented | CEA fails per-ciphertext (CH07-style) confidentiality: proxy re-encrypts a re-randomised challenge for a corrupted delegatee. |
| attacks/commutation_v3.py | implemented | Concrete v3 compatibility gap motivating the selected research direction. |
| attacks/unbound_coefficient_v3.py | implemented | Concrete receiver-insider forgery when v3 coefficients omit the mutable A; the original v3 rule rejects it. |
| attacks/unrestricted_token_scope.py | implemented | Negative control preventing a software scope check from being mistaken for cryptographic scoping. |

## baselines/

| File | Current status | Purpose |
| --- | --- | --- |
| baselines/README.md | research-blueprint | Baseline inventory and limits. |

## baselines/claude_v3/

| File | Current status | Purpose |
| --- | --- | --- |
| baselines/claude_v3/README.md | baseline-description | Original-byte provenance and limitations of the retained prototype. |
| baselines/claude_v3/source_manifest.json | provenance | Hashes and original filenames of the frozen upstream prototype. |

## baselines/claude_v3/expected/

| File | Current status | Purpose |
| --- | --- | --- |
| baselines/claude_v3/expected/v3_results.json | frozen-expected-output | Original v3 report; never overwritten by a rerun. |

## baselines/claude_v3/source/

| File | Current status | Purpose |
| --- | --- | --- |
| baselines/claude_v3/source/adspre.py | frozen-supplied-code | Byte-preserved supplied baseline; original name: adspre(1).py |
| baselines/claude_v3/source/candidate_v3.py | frozen-supplied-code | Byte-preserved supplied baseline; original name: candidate_v3.py |
| baselines/claude_v3/source/ec.py | frozen-supplied-code | Byte-preserved supplied baseline; original name: ec.py |
| baselines/claude_v3/source/v3_checks.py | frozen-supplied-code | Byte-preserved supplied baseline; original name: v3_checks.py |

## claims/

| File | Current status | Purpose |
| --- | --- | --- |
| claims/README.md | research-record | Claim semantics and limitations of automated validation. |
| claims/claims.json | implemented | Machine-readable claim status; test success never becomes proof status. |

## experiments/

| File | Current status | Purpose |
| --- | --- | --- |
| experiments/README.md | planned-experiments | Narrow, relevant evaluation plan and measurement prerequisites. |

## literature/

| File | Current status | Purpose |
| --- | --- | --- |
| literature/novelty_matrix.md | novelty-gate-result | Completed comparison: commutation defeated by a generic composition; reading scope stated per row. |
| literature/search_log.md | literature-register | Search scope, new direct baseline, and access limitations. |
| literature/sources.json | literature-register | Primary-source register with exact reading/access limits. |

## paper/

| File | Current status | Purpose |
| --- | --- | --- |
| paper/README.md | paper-plan | Theory-first paper organization and verified conference requirements. |
| paper/ai_assistance_log.md | research-record | Accurate assistance provenance for the intended venue. |

## proofs/

| File | Current status | Purpose |
| --- | --- | --- |
| proofs/aggregate_authenticity.md | proof-obligations | Detailed missing aggregate-security obligations. |
| proofs/cea_authenticity.md | proof-sketch-unreviewed | Commutation lemma and authenticity reductions to CZ22 Thm 2 + CR and to Schnorr EUF-CMA; not reviewed by the authors. |
| proofs/cea_confidentiality.md | proof-obligations | Reduction plan for per-record and out-of-class confidentiality; open. |
| proofs/commutation_target.md | proof-obligations | Gate result, v3 negative results, CEA costs and the refined open question Q-R. |
| proofs/compact_cdh_equivalence.md | proved-local-algebra | Complete elementary identity with deliberately limited scope. |
| proofs/individual_authenticity.md | proof-obligations | Conditional individual-authenticity argument and its implementation/model limits. |
| proofs/privacy_and_scope.md | proof-obligations | Missing confidentiality and cryptographic-scope reductions. |
| proofs/status.md | proof-obligations | Explicit status of each mathematical/security claim. |

## provenance/

| File | Current status | Purpose |
| --- | --- | --- |
| provenance/README.md | research-record | Source-byte provenance and snapshot limitations. |
| provenance/source_manifest.json | generated-provenance | Source snapshot generated after intentional edits. |
| provenance/uploaded_inputs.json | provenance | Byte hashes of all source attachments and dependencies used in this workspace. |

## results/

| File | Current status | Purpose |
| --- | --- | --- |
| results/README.md | research-blueprint | Observed-output location and provenance rules. |

## results/local/

| File | Current status | Purpose |
| --- | --- | --- |
| results/local/run_summary.json | generated-observation | Actual output of the one-command verification. |
| results/local/unit_tests.txt | generated-observation | Actual focused-unit-test output. |

## scripts/

| File | Current status | Purpose |
| --- | --- | --- |
| scripts/build_manifest.py | implemented | Records a new reviewed source snapshot; separates mutable results from immutable inputs. |
| scripts/cea_demo.py | implemented | Both operation orders, Theta invariance, counted operations and size model for CEA; no timings. |
| scripts/reproduce.py | implemented | Runs source integrity, unit tests (recording skips and optional dependency), exact v3 replay, four negative controls and the CEA demo. |
| scripts/run_baseline.py | implemented | Isolated replay and exact JSON comparison; frozen baseline sources are never executed in place. |
| scripts/verify_manifest.py | implemented | Checks byte integrity of the recorded source snapshot, not proof correctness. |

## spec/

| File | Current status | Purpose |
| --- | --- | --- |
| spec/authentication.md | specification | Distinct sender and delegator authenticity statements. |
| spec/canonical_encoding.md | specification | Encoding definition and outstanding wire-format obligations. |
| spec/cea_construction.md | specification | Exact CEA algorithms, retained material and explicit non-claims. |
| spec/commutation.md | specification | Exact research property; semantic commutation without hidden access to discarded signatures. |
| spec/complexity_model.md | specification | Prevents misleading cost and performance claims. |
| spec/corruption_model.md | specification | Frozen initial corruption model and admissibility boundaries. |
| spec/delegation_scope.md | specification | Cryptographic scope versus policy checking and key-recovery goals. |
| spec/games.md | specification | Formal games G-AGG, G-DEL, G-CONF, G-SCOPE, G-KR with oracle phases, ROM/AGM labels and registration/PKI assumptions. |
| spec/interfaces.md | specification | Secret/public separation, registry policy, and state ownership. |
| spec/notation.md | specification | Notation and accounting vocabulary. |
| spec/privacy_game.md | specification | Confidentiality obligations and the limited role of the executable redaction fragment. |

## src/cipherauth/

| File | Current status | Purpose |
| --- | --- | --- |
| src/cipherauth/__init__.py | implemented | Package identity and scope. |
| src/cipherauth/candidate.py | open-research-interface | Fail-closed entry point for a NEW construction; CEA (a comparator) does not replace it. |
| src/cipherauth/cea.py | implemented-comparator | CEA generic composition (commit-then-encrypt-and-sign + single-hop PRE + IASchnorr) achieving exact commutation; a comparator, not a new construction. |
| src/cipherauth/claims.py | implemented | Keeps behavioral observations, algebra, security, and novelty in distinct categories. Adds sketch_unreviewed and defeated_by_known_composition labels. |
| src/cipherauth/costs.py | implemented | Keeps operation counts distinct from runtime and from optimality claims. |
| src/cipherauth/encoding.py | implemented | Canonical typed encoding and domain separation; no random-oracle proof is implied. |
| src/cipherauth/errors.py | implemented | Explicit errors; unresolved cryptography cannot silently fall back. |
| src/cipherauth/grants.py | implemented | Canonical grant messages and explicit public-signature verification interface; scoped PRE remains open. |
| src/cipherauth/group.py | implemented | Validated P-256 arithmetic, point/scalar encodings, hash-to-scalar and operation counters; pure Python, not constant time. |
| src/cipherauth/interfaces.py | implemented | Public API including delegation of an already compressed aggregate; no individual signatures in that API. |
| src/cipherauth/models.py | implemented | Immutable key versions, original-recipient statements, batch context, and opaque encrypted records. |
| src/cipherauth/registry.py | implemented | Rejects key-version substitution and fingerprint mismatch; no hidden extractor. |
| src/cipherauth/schnorr.py | implemented | Schnorr signatures and Chen-Zhao IASchnorr (ePrint 2022/222 Fig. 2) with streamed prefix coefficients; verification never trusts the stream. |
| src/cipherauth/wire.py | implemented | Canonical binary wire format for CEA aggregates and delegated aggregates; strict decoder; basis of measured sizes. |

## src/cipherauth/games/

| File | Current status | Purpose |
| --- | --- | --- |
| src/cipherauth/games/__init__.py | implemented | Scope of executable game fragments. |
| src/cipherauth/games/authenticity.py | implemented | Tracks exact origin-statement freshness; no security reduction is asserted. |
| src/cipherauth/games/delegation.py | implemented | Separates delegation-origin authentication from sender unforgeability. |
| src/cipherauth/games/faults.py | implemented | Represents sender and aggregator faults without treating attribution tests as proofs. |
| src/cipherauth/games/privacy.py | implemented | Both-alternative masking and per-record derivative bookkeeping; not a complete A-RCCA game. |

## tests/

| File | Current status | Purpose |
| --- | --- | --- |
| tests/README.md | research-blueprint | Test scope and the separation of policy checks from security evidence. |

## tests/integration/

| File | Current status | Purpose |
| --- | --- | --- |
| tests/integration/test_baseline.py | implemented | Optional standalone integration replay; the main reproduce command already runs this baseline once. |
| tests/integration/test_commutation.py | implemented | Green means the stated baseline limitation reproduced, not that commutation was achieved. |

## tests/unit/

| File | Current status | Purpose |
| --- | --- | --- |
| tests/unit/test_cea.py | implemented | Behavioural and adversarial CEA tests; passing them is not a security proof. |
| tests/unit/test_claims.py | implemented | Checks that no claim is marked reviewed (proof or gap) without human review. |
| tests/unit/test_grants_and_games.py | implemented | Grant message bindings, oracle-output policy, authorization ledger, and explicit unresolved-target checks. |
| tests/unit/test_statements.py | implemented | Meaningful encoding, registry, statement-freshness, and context consistency checks. |
