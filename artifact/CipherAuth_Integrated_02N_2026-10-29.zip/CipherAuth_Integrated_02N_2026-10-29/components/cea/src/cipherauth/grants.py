"""Authorization statement binding only.

Signature verification is supplied by an independent backend. This policy layer
does not provide cryptographic out-of-scope confidentiality to a colluding proxy.
"""
from dataclasses import dataclass
from typing import Callable
from .models import KeyRef
from .encoding import encode
from .registry import Registry
from .errors import InvalidContext, KeyConflict

@dataclass(frozen=True)
class Grant:
    issuer: KeyRef
    origin: KeyRef
    delegatee: KeyRef
    tags: tuple[bytes, ...]
    epoch: int
    token_digest: bytes
    grant_id: bytes
    suite: str

    def __post_init__(self):
        if self.issuer.role != "signing" or self.origin.role != "decryption" or self.delegatee.role != "decryption":
            raise InvalidContext("incorrect grant key roles")
        if self.issuer.identity != self.origin.identity:
            raise InvalidContext("issuer must be the origin owner's signing identity")
        if not isinstance(self.tags, tuple) or not self.tags or any(not isinstance(t, bytes) or not t for t in self.tags):
            raise InvalidContext("scope must contain nonempty byte tags")
        if self.tags != tuple(sorted(set(self.tags))):
            raise InvalidContext("scope tags must be sorted and unique")
        if type(self.epoch) is not int or self.epoch < 0 or not self.suite:
            raise InvalidContext("invalid epoch or suite")
        if any(not isinstance(v, bytes) or len(v) != 32 for v in (self.token_digest, self.grant_id)):
            raise InvalidContext("grant and token digests must have 32 bytes")

    def message(self):
        return encode(("recipient-delegation-grant/v0", self.suite, self.issuer.fields(),
                       self.origin.fields(), self.delegatee.fields(), self.tags,
                       self.epoch, self.token_digest, self.grant_id))

@dataclass(frozen=True)
class SignedGrant:
    payload: Grant
    signature: bytes

def verify_grant(signed: SignedGrant, registry: Registry, *, origin: KeyRef,
                 delegatee: KeyRef, tag: bytes, epoch: int, token_digest: bytes,
                 suite: str, verify_signature: Callable[[bytes, bytes, bytes], bool]) -> bool:
    g = signed.payload
    if (g.origin != origin or g.delegatee != delegatee or g.epoch != epoch
            or tag not in g.tags or g.token_digest != token_digest or g.suite != suite
            or not isinstance(signed.signature, bytes) or not signed.signature):
        return False
    try:
        issuer = registry.resolve(g.issuer)
        origin_record = registry.resolve(g.origin)
        delegatee_record = registry.resolve(g.delegatee)
    except (KeyError, KeyConflict):
        return False
    if any(record.suite != suite for record in (issuer, origin_record, delegatee_record)):
        return False
    return bool(verify_signature(issuer.encoded_key, g.message(), signed.signature))
