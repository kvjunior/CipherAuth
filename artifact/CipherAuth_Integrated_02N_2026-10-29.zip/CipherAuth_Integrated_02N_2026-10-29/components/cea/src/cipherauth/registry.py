"""Structural key registry; does not prove possession or validate cryptographic group membership."""
from dataclasses import dataclass
from .models import KeyRef
from .encoding import digest
from .errors import KeyConflict

@dataclass(frozen=True)
class PublicKey:
    ref: KeyRef
    suite: str
    encoded_key: bytes

class Registry:
    def __init__(self):
        self._keys = {}

    def register(self, identity, role, version, suite, encoded_key):
        if not suite or not isinstance(encoded_key, bytes) or not encoded_key:
            raise ValueError("suite and public key bytes are required")
        ref = KeyRef(identity, role, version, digest("public-key", suite, role, encoded_key))
        index = (identity, role, version)
        candidate = PublicKey(ref, suite, encoded_key)
        if index in self._keys and self._keys[index] != candidate:
            raise KeyConflict("an existing identity/role/version cannot change keys")
        self._keys[index] = candidate
        return ref

    def resolve(self, ref):
        record = self._keys[(ref.identity, ref.role, ref.version)]
        if record.ref != ref:
            raise KeyConflict("key fingerprint does not match the registry")
        return record
