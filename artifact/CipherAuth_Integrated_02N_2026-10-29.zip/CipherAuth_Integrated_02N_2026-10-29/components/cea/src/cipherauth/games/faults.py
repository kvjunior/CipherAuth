"""Party names for fault attribution. The full adversarial evidence game is not implemented."""
from dataclasses import dataclass

@dataclass(frozen=True)
class FaultParty:
    role: str
    identity: str

    def __post_init__(self):
        if self.role not in ("sender", "aggregator") or not self.identity:
            raise ValueError("invalid fault party")
