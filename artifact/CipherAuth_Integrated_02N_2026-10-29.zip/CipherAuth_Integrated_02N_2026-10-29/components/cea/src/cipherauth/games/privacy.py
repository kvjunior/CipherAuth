"""RCCA-style output-redaction fragment, applied only after complete verification.
The full oracle/game compatibility and its relationship to published RCCA remain proof obligations.
"""
from enum import Enum

class Mask(Enum):
    TEST = "challenge-alternative"

class DerivativeLedger:
    """Per-record derivative bookkeeping for the CEA confidentiality game (spec/games.md, G-CONF).

    In CEA the aggregate authenticator never affects decryption, so confidentiality is defined per
    record. A record's decryption-relevant core is (origin key, encryption point, E). Challenge
    cores are registered at challenge time; every core the ReEnc oracle produces from a registered
    core is registered too (Canetti-Hohenberger derivatives). Decryption oracles refuse a batch
    that contains any registered core. Bookkeeping only; not a proof of the game's adequacy.
    """

    def __init__(self):
        self._cores = set()

    def register(self, core):
        self._cores.add(core)

    def register_derived(self, parent, child):
        if parent in self._cores:
            self._cores.add(child)

    def batch_refused(self, cores):
        return any(c in self._cores for c in cores)


class ReplayMask:
    def __init__(self, left: tuple[bytes, ...], right: tuple[bytes, ...]):
        if not left or len(left) != len(right):
            raise ValueError("nonempty challenge vectors must have equal lengths")
        if any(not isinstance(m, bytes) for m in left + right):
            raise TypeError("challenge entries must be bytes")
        if any(len(a) != len(b) for a, b in zip(left, right)):
            raise ValueError("corresponding challenge messages must have equal lengths")
        self.alternatives = frozenset(left + right)

    def after_verification(self, messages: tuple[bytes, ...] | None, *, protected_recipient: bool):
        if messages is None:
            return None
        if not protected_recipient:
            return messages
        return tuple(Mask.TEST if m in self.alternatives else m for m in messages)
