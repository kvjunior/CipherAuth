"""Executable fragments of proposed games. These are not complete security experiments or proofs."""
