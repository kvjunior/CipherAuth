from ..models import OriginStatement

class FreshnessLedger:
    """Tracks full original statements, including key versions and receiver identity."""
    def __init__(self):
        self._queries = set()

    def record_query(self, statement: OriginStatement):
        self._queries.add(statement)

    def is_fresh(self, statement: OriginStatement):
        return statement not in self._queries
