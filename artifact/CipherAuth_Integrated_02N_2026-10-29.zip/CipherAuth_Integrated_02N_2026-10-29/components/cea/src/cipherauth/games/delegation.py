"""A ledger of authorized grant statements, separate from sender-message freshness."""
from ..encoding import digest

class AuthorizationLedger:
    def __init__(self):
        self._issued = set()

    def record_issued(self, grant):
        self._issued.add(digest("issued-grant", grant.message()))

    def was_issued(self, grant):
        return digest("issued-grant", grant.message()) in self._issued
