"""Schnorr signatures and incremental half-aggregation (IASchnorr) as in Chen-Zhao.

Reference: Y. Chen, Y. Zhao, "Half-Aggregation of Schnorr Signatures with Tight Reductions",
ePrint 2022/222, Section 4, Figure 2 (IASchnorr), Theorem 2 (AGM+ROM, CK-AEUF-CMA tightly
from Schnorr EUF-CMA). This module follows that figure:
    challenge  c_i = H1(R_i, m_i)
    a_1 = 1,   a_i = H2(L_i) for i >= 2,  L_i = ((R_1,X_1,m_1), ..., (R_i,X_i,m_i))
    aggregate  s~ = sum a_i s_i ;  accept iff s~ P = sum a_i (R_i + c_i X_i)
H2 is evaluated on the encoding of the whole prefix L_i. CoefficientStream keeps the
SHA-256 state of that prefix so an append hashes only the new entry; it computes the same
function as hashing L_i from scratch (checked in tests). Messages are expected to contain
the signer's key reference, so challenges are effectively key-prefixed.
"""
import hashlib
from dataclasses import dataclass, field
from . import group as g
from .encoding import encode

H1_DOMAIN = "cipherauth/schnorr/H1/v0"
H2_DOMAIN = "cipherauth/iaschnorr/H2/v0"


def challenge(R, message):
    return g.hash_to_scalar(H1_DOMAIN, encode((g.encode_point(R), message)))


def sign(x, X, message):
    """Schnorr signature (R, s) on bytes `message` under secret x (X = xP is not hashed separately)."""
    r = g.random_scalar()
    R = g.mul(r, g.G)
    return R, (r + challenge(R, message) * x) % g.q


def verify(X, message, signature):
    R, s = signature
    try:
        g.validate_point(R)
        g.validate_point(X)
        g.validate_scalar(s)
    except Exception:
        return False
    return g.mul(s, g.G) == R + g.mul(challenge(R, message), X)


def entry_encoding(R, X, message):
    """Self-delimiting encoding of one (R, X, m) entry; concatenations are uniquely decodable."""
    return encode(("ias-entry", g.encode_point(R), g.encode_point(X), message))


class CoefficientStream:
    """Incremental evaluation of a_i = H2(L_i) for i = 1, 2, ... (a_1 = 1 by definition)."""

    def __init__(self):
        self._states = []
        for counter in (0, 1):            # hash_to_scalar uses two counter blocks (64 bytes)
            h = hashlib.sha256()
            h.update(H2_DOMAIN.encode() + b"\x00" + counter.to_bytes(4, "big"))
            self._states.append(h)
        self._prefix_len = len(H2_DOMAIN) + 5
        self.count = 0

    def copy(self):
        other = CoefficientStream.__new__(CoefficientStream)
        other._states = [h.copy() for h in self._states]
        other._prefix_len = self._prefix_len
        other.count = self.count
        return other

    def push(self, R, X, message):
        data = entry_encoding(R, X, message)
        for h in self._states:
            h.update(data)
        self._prefix_len += len(data)
        self.count += 1
        if self.count == 1:
            return 1
        g.COUNTS["hash"] += 2
        g.COUNTS["hash_bytes"] += 2 * len(data)   # new bytes hashed by this append
        digest = b"".join(h.copy().digest() for h in self._states)
        return int.from_bytes(digest, "big") % g.q


def coefficient_from_scratch(entries):
    """a_i for the full prefix `entries`, recomputed without cached state (reference definition)."""
    if len(entries) == 1:
        return 1
    return g.hash_to_scalar(H2_DOMAIN, b"".join(entry_encoding(*e) for e in entries))


@dataclass
class HalfAggregate:
    entries: list = field(default_factory=list)      # (R_i, X_i, m_i)
    s: int = 0
    stream: CoefficientStream = field(default_factory=CoefficientStream)   # append hint, not trusted

    def append(self, X, message, signature):
        """IncrAgg: existing coefficients are not recomputed."""
        R, s_i = signature
        a_i = self.stream.push(R, X, message)
        self.entries.append((R, X, message))
        self.s = (self.s + a_i * s_i) % g.q
        return self


def aggregate(items):
    agg = HalfAggregate()
    for X, message, signature in items:
        agg.append(X, message, signature)
    return agg


def verify_aggregate(entries, s):
    """AggVf, factored per distinct signing key: sum a_i R_i + sum_X (sum a_i c_i) X.
    Recomputes all coefficients from the entries; never trusts a supplied stream."""
    if not entries:
        return False
    try:
        g.validate_scalar(s)
        for R, X, m in entries:
            g.validate_point(R)
            g.validate_point(X)
            if not isinstance(m, bytes):
                return False
    except Exception:
        return False
    stream = CoefficientStream()
    lhs_R = g.IDENTITY
    per_key = {}
    for R, X, m in entries:
        a_i = stream.push(R, X, m)
        lhs_R = lhs_R + (R if a_i == 1 else g.mul(a_i, R))
        key = g.encode_point(X)
        coeff, _ = per_key.get(key, (0, X))
        per_key[key] = ((coeff + a_i * challenge(R, m)) % g.q, X)
    rhs = lhs_R
    for coeff, X in per_key.values():
        rhs = rhs + g.mul(coeff, X)
    return g.mul(s, g.G) == rhs
