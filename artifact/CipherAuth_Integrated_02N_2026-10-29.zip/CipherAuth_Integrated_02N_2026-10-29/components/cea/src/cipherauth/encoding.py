"""Typed, length-delimited research encoding. This is not an adopted wire-format standard."""
from hashlib import sha256
from .errors import EncodingError

def _frame(payload: bytes) -> bytes:
    if len(payload) >= 2**32:
        raise EncodingError("field is too long")
    return len(payload).to_bytes(4, "big") + payload

def encode(value) -> bytes:
    if value is None:
        return b"N"
    if isinstance(value, bool):
        return b"Y" if value else b"Z"
    if isinstance(value, int):
        return b"I" + _frame(str(value).encode("ascii"))
    if isinstance(value, bytes):
        return b"B" + _frame(value)
    if isinstance(value, str):
        return b"S" + _frame(value.encode("utf-8", errors="strict"))
    if isinstance(value, (list, tuple)):
        tag = b"L" if isinstance(value, list) else b"T"
        return tag + len(value).to_bytes(4, "big") + b"".join(encode(x) for x in value)
    if isinstance(value, dict):
        if not all(isinstance(k, str) for k in value):
            raise EncodingError("map keys must be strings")
        keys = sorted(value)
        return b"D" + len(keys).to_bytes(4, "big") + b"".join(
            encode(k) + encode(value[k]) for k in keys)
    raise EncodingError(f"unsupported type: {type(value).__name__}")

def digest(domain: str, *values) -> bytes:
    if not isinstance(domain, str) or not domain:
        raise EncodingError("a nonempty domain string is required")
    return sha256(encode(("cipherauth-research/v0", domain, values))).digest()
