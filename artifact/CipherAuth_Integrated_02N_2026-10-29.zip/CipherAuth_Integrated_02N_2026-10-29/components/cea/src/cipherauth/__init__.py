"""Research infrastructure. No new secure aggregate-delegation construction is implemented."""
__version__ = "0.1.0"
