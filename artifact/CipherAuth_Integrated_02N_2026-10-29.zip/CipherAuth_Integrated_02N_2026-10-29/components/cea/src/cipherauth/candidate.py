from .errors import OpenResearchProblem

class OpenConstruction:
    """Explicitly unresolved. Baseline v3 is separate and must not be relabelled as this construction."""
    def delegate_aggregate(self, token, grant, aggregate):
        raise OpenResearchProblem(
            "No justified compressed-aggregate delegation algorithm is implemented. "
            "Provide the construction and proof obligations before implementing this operation.")
