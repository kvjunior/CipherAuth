"""Claim metadata validation. It does not validate mathematical proofs."""
import json
from pathlib import Path

ALLOWED = {
    "behavior": {"reproduced", "pending"},
    "algebra": {"proved_identity", "pending"},
    "security": {"open", "refuted", "sketch_unreviewed", "reviewed_proof"},
    "novelty": {"unverified", "comparison_pending", "defeated_by_known_composition", "reviewed_gap"},
}

def validate_claims(path: Path):
    data = json.loads(path.read_text())
    seen = set()
    for item in data["claims"]:
        if item["id"] in seen:
            raise ValueError("duplicate claim ID")
        seen.add(item["id"])
        if item["status"] not in ALLOWED[item["kind"]]:
            raise ValueError("invalid status for claim kind")
        if not item.get("evidence") or not item.get("scope"):
            raise ValueError("claim evidence and scope are required")
    return data
