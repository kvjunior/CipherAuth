"""Analytical call counts in the existing factoring model; not latency predictions or lower bounds."""
def _validate(n, u):
    if type(n) is not int or type(u) is not int or not 1 <= u <= n:
        raise ValueError("require integers 1 <= u <= n")

def weighted_calls(n, u):
    _validate(n, u)
    return 2*n + u + 1

def unweighted_calls(n, u):
    _validate(n, u)
    return n + u + 1

def independent_calls(n):
    if type(n) is not int or n < 1:
        raise ValueError("positive batch length required")
    return 3*n
