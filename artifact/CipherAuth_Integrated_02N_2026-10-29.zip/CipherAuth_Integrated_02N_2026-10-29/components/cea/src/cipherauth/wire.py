"""Complete, canonical binary wire format for CEA aggregates and delegated aggregates.

This is the format against which transmission sizes are MEASURED (scripts/cea_demo.py).
It is a research format, not a standard. Layout (all integers big-endian):

    magic "CEA0" | kind (1: aggregate, 2: delegated)
    suite        : u8 length | utf-8
    key table    : u16 count | per key: u8 id length | id | role u8 (0 signing, 1 decryption)
                   | version u32 | fingerprint 32
    context      : origin index u16 | recipient index u16 | epoch u64
    tag          : u8 length | bytes                       (one tag per batch)
    records      : u32 count | per record: sender index u16 | u16 body length | body
    authenticator: 32
    kind 2 only  : grant issuer index u16 | grant tags u8 count | (u8 length | tag)*
                   | token digest 32 | grant id 32 | signature u8 length | signature
                   | token public part: C 32 | gamma 33 | W 32

Fields that the verifier requires to be equal are sent once: every record's origin and epoch
are the context's, the grant's origin, delegatee, epoch and suite are the context's, and the
context's grant id is the grant's. Objects that violate these equalities are not encodable
(they would be rejected by verification anyway). The key table lists each key once, in
first-use order (context origin, recipient, record senders, grant issuer), which makes the
encoding canonical: decode(encode(x)) == x and encode(decode(b)) == b.
"""
from .models import KeyRef, BatchContext, EncryptedRecord, CompressedAggregate
from .grants import Grant, SignedGrant
from .errors import EncodingError

MAGIC = b"CEA0"
_ROLES = {"signing": 0, "decryption": 1}
_ROLE_NAMES = {v: k for k, v in _ROLES.items()}


def _u(n, width):
    if not isinstance(n, int) or n < 0 or n >= 1 << (8 * width):
        raise EncodingError("integer out of range for wire field")
    return n.to_bytes(width, "big")


def _short(b, width=1):
    return _u(len(b), width) + b


class _Table:
    def __init__(self):
        self.keys, self.index = [], {}

    def ref(self, key):
        if key not in self.index:
            self.index[key] = len(self.keys)
            self.keys.append(key)
        return _u(self.index[key], 2)

    def encode(self):
        out = [_u(len(self.keys), 2)]
        for k in self.keys:
            out += [_short(k.identity.encode("utf-8")), _u(_ROLES[k.role], 1), _u(k.version, 4), k.fingerprint]
        return b"".join(out)


def encode_aggregate(agg: CompressedAggregate, *, delegated=None):
    """delegated = (SignedGrant, token_public) for a delegated aggregate, else None."""
    ctx = agg.context
    if agg.append_hint:
        raise EncodingError("append hints are local state and are not transmitted")
    if (ctx.level == "delegated") != (delegated is not None):
        raise EncodingError("level and delegation material disagree")
    tag = agg.records[0].tag
    t = _Table()
    head = t.ref(ctx.origin) + t.ref(ctx.recipient) + _u(ctx.epoch, 8)
    recs = []
    for r in agg.records:
        if r.origin != ctx.origin or r.epoch != ctx.epoch or r.tag != tag:
            raise EncodingError("record does not belong to the batch class")
        recs.append(t.ref(r.sender) + _short(r.body, 2))
    if len(agg.authenticator) != 32:
        raise EncodingError("authenticator must have 32 bytes")
    tail = b""
    if delegated is not None:
        signed, token_public = delegated
        gp = signed.payload
        if (gp.origin != ctx.origin or gp.delegatee != ctx.recipient or gp.epoch != ctx.epoch
                or gp.suite != ctx.suite or gp.grant_id != ctx.grant_id):
            raise EncodingError("grant does not match the delegated context")
        C, gamma, W = token_public
        if (len(C), len(gamma), len(W)) != (32, 33, 32):
            raise EncodingError("token public part has the wrong shape")
        tail = (t.ref(gp.issuer) + _u(len(gp.tags), 1) + b"".join(_short(x) for x in gp.tags)
                + gp.token_digest + gp.grant_id + _short(signed.signature) + C + gamma + W)
    kind = b"\x02" if delegated is not None else b"\x01"
    return (MAGIC + kind + _short(ctx.suite.encode("utf-8")) + t.encode() + head + _short(tag)
            + _u(len(recs), 4) + b"".join(recs) + agg.authenticator + tail)


class _Reader:
    def __init__(self, data):
        self.d, self.i = data, 0

    def take(self, n):
        if n < 0 or self.i + n > len(self.d):
            raise EncodingError("truncated wire object")
        out = self.d[self.i:self.i + n]
        self.i += n
        return out

    def u(self, width):
        return int.from_bytes(self.take(width), "big")

    def short(self, width=1):
        return self.take(self.u(width))


def decode_aggregate(data: bytes):
    """Returns (CompressedAggregate, delegated) where delegated is (SignedGrant, token_public) or None.
    Strict: rejects truncation, trailing bytes, bad indices/roles and non-canonical encodings."""
    if not isinstance(data, bytes):
        raise EncodingError("wire input must be bytes")
    rd = _Reader(data)
    if rd.take(4) != MAGIC:
        raise EncodingError("bad magic")
    kind = rd.u(1)
    if kind not in (1, 2):
        raise EncodingError("unknown kind")
    try:
        suite = rd.short().decode("utf-8")
        keys = []
        for _ in range(rd.u(2)):
            ident = rd.short().decode("utf-8")
            role = _ROLE_NAMES.get(rd.u(1))
            if role is None:
                raise EncodingError("unknown role")
            keys.append(KeyRef(ident, role, rd.u(4), rd.take(32)))
    except UnicodeDecodeError as exc:
        raise EncodingError("invalid utf-8") from exc
    key = lambda: keys[_index(rd.u(2), keys)]
    origin, recipient, epoch = key(), key(), rd.u(8)
    tag = rd.short()
    records = tuple(EncryptedRecord(key(), origin, tag, epoch, rd.short(2)) for _ in range(rd.u(4)))
    if not records:
        raise EncodingError("empty batch")
    authenticator = rd.take(32)
    delegated = None
    if kind == 2:
        issuer = key()
        tags = tuple(rd.short() for _ in range(rd.u(1)))
        token_digest, grant_id, signature = rd.take(32), rd.take(32), rd.short()
        token_public = (rd.take(32), rd.take(33), rd.take(32))
        grant = Grant(issuer, origin, recipient, tags, epoch, token_digest, grant_id, suite)
        delegated = (SignedGrant(grant, signature), token_public)
        ctx = BatchContext(suite, "delegated", origin, recipient, epoch, grant_id)
    else:
        ctx = BatchContext(suite, "origin", origin, recipient, epoch)
    if rd.i != len(data):
        raise EncodingError("trailing bytes")
    agg = CompressedAggregate(ctx, records, authenticator)
    if encode_aggregate(agg, delegated=delegated) != data:
        raise EncodingError("non-canonical encoding")
    return agg, delegated


def _index(i, keys):
    if i >= len(keys):
        raise EncodingError("key index out of range")
    return i


def encode_delegated(obj):
    """Convenience wrapper for cea.DelegatedAggregate."""
    return encode_aggregate(obj.aggregate, delegated=(obj.grant, obj.token_public))
