"""Public statement types. These objects contain no secret key or per-record signature scalar."""
from dataclasses import dataclass
from .encoding import digest
from .errors import InvalidContext

@dataclass(frozen=True)
class KeyRef:
    identity: str
    role: str
    version: int
    fingerprint: bytes

    def __post_init__(self):
        if not self.identity or self.role not in ("signing", "decryption"):
            raise InvalidContext("invalid identity or role")
        if not isinstance(self.version, int) or isinstance(self.version, bool) or self.version < 1:
            raise InvalidContext("key versions start at one")
        if not isinstance(self.fingerprint, bytes) or len(self.fingerprint) != 32:
            raise InvalidContext("key fingerprint must have 32 bytes")

    def fields(self):
        return (self.identity, self.role, self.version, self.fingerprint)

@dataclass(frozen=True)
class OriginStatement:
    sender: KeyRef
    origin: KeyRef
    tag: bytes
    epoch: int
    message: bytes

    def __post_init__(self):
        if self.sender.role != "signing" or self.origin.role != "decryption":
            raise InvalidContext("incorrect statement key roles")
        if not isinstance(self.tag, bytes) or not self.tag:
            raise InvalidContext("a nonempty tag is required")
        if type(self.epoch) is not int or self.epoch < 0 or not isinstance(self.message, bytes):
            raise InvalidContext("invalid epoch or message")

    def fields(self):
        return ("origin-authentication/v0", self.sender.fields(), self.origin.fields(),
                self.tag, self.epoch, self.message)

@dataclass(frozen=True)
class BatchContext:
    suite: str
    level: str
    origin: KeyRef
    recipient: KeyRef
    epoch: int
    grant_id: bytes | None = None

    def __post_init__(self):
        if not self.suite or self.level not in ("origin", "delegated"):
            raise InvalidContext("unknown suite or level")
        if self.origin.role != "decryption" or self.recipient.role != "decryption":
            raise InvalidContext("incorrect recipient key role")
        if type(self.epoch) is not int or self.epoch < 0:
            raise InvalidContext("invalid epoch")
        if self.level == "origin" and (self.origin != self.recipient or self.grant_id is not None):
            raise InvalidContext("origin context must name its origin as recipient")
        if self.level == "delegated" and (not isinstance(self.grant_id, bytes) or len(self.grant_id) != 32):
            raise InvalidContext("delegated context must name a 32-byte grant ID")

    def fields(self):
        return (self.suite, self.level, self.origin.fields(), self.recipient.fields(),
                self.epoch, self.grant_id)

    def commitment(self):
        return digest("batch-context", self.fields())

@dataclass(frozen=True)
class EncryptedRecord:
    sender: KeyRef
    origin: KeyRef
    tag: bytes
    epoch: int
    body: bytes

    def __post_init__(self):
        if self.sender.role != "signing" or self.origin.role != "decryption":
            raise InvalidContext("incorrect record key role")
        if not isinstance(self.tag, bytes) or not self.tag or not isinstance(self.body, bytes):
            raise InvalidContext("invalid record tag or body")
        if type(self.epoch) is not int or self.epoch < 0:
            raise InvalidContext("invalid record epoch")

@dataclass(frozen=True)
class CompressedAggregate:
    context: BatchContext
    records: tuple[EncryptedRecord, ...]
    authenticator: bytes
    append_hint: bytes = b""

    def validate_shape(self):
        if not isinstance(self.records, tuple) or not self.records:
            raise InvalidContext("empty or mutable record collection")
        if not isinstance(self.authenticator, bytes) or not self.authenticator:
            raise InvalidContext("missing authenticator")
        if not isinstance(self.append_hint, bytes):
            raise InvalidContext("invalid append hint")
        for record in self.records:
            if record.origin != self.context.origin or record.epoch != self.context.epoch:
                raise InvalidContext("record/context mismatch")
        return True
