"""CEA: commit-encrypt-aggregate, a GENERIC-COMPOSITION COMPARATOR (not a new construction).

Composition of known tools:
  * An-Dodis-Rabin commit-then-encrypt-and-sign: the sender signs a statement containing a
    hiding, binding commitment c = Hc(m, d) to the message, not the message itself;
  * Chen-Zhao IASchnorr incremental half-aggregation of those (public) signatures;
  * ElGamal-style point encryption of the commitment opening with a delegation token
    (the audited ADS-PRE re-key shape), using one decryption key per (tag, epoch) class.

Everything the aggregate authenticates (Lambda_i, sender key, origin class key, tag, epoch,
c_i) is untouched by re-encryption, so a compressed aggregate is delegated by transforming
only the encryption components: Theta is carried unchanged and the proxy needs neither the
individual responses theta_i nor any plaintext. This is why the commutation property is not,
by itself, a novelty claim (see proofs/commutation_lemma.md).

Research prototype: pure-Python P-256, not constant-time. Security status: see proofs/status.md.
"""
from dataclasses import dataclass, replace
from . import group as g
from . import schnorr
from .encoding import encode, digest
from .errors import InvalidContext, EncodingError
from .grants import Grant, SignedGrant, verify_grant
from .models import KeyRef, OriginStatement, BatchContext, EncryptedRecord, CompressedAggregate
from .registry import Registry

SUITE = "cea-p256-sha256/v0"
_LAM, _C, _A = g.POINT_BYTES, 32, g.POINT_BYTES      # record body layout: Lambda || c || A(or Abar) || E


# ---------------------------------------------------------------- keys and directory
@dataclass(frozen=True)
class SigningSecret:
    ref: KeyRef
    x: int


@dataclass(frozen=True)
class DecryptionSecret:
    ref: KeyRef
    k: int


@dataclass(frozen=True)
class Token:
    """Delegation token. Omega is the proxy's secret part; (C, gamma) travel to the delegatee."""
    origin: KeyRef
    delegatee: KeyRef
    Omega: int
    C: bytes
    gamma: g.Point

    def public_part(self):
        """(C, gamma, W) with W = H(Omega): lets the delegatee recompute the grant's token digest."""
        return (self.C, g.encode_point(self.gamma), digest("cea-token-omega", self.Omega))

    def digest(self):
        return token_digest(self.origin, self.delegatee, self.public_part())


def token_digest(origin, delegatee, public_part):
    C, gamma_bytes, W = public_part
    return digest("cea-token", origin.fields(), delegatee.fields(), C, gamma_bytes, W)


@dataclass(frozen=True)
class Submission:
    """An individual signcryption as submitted to the aggregator (theta still present)."""
    record: EncryptedRecord
    theta: int


@dataclass(frozen=True)
class DelegatedAggregate:
    """Interface extension: a delegated aggregate must carry its grant and the token's public part."""
    aggregate: CompressedAggregate
    grant: SignedGrant
    token_public: tuple


class Directory:
    """Public directory: registry plus the (owner, tag, epoch) -> class decryption key mapping."""

    def __init__(self):
        self.registry = Registry()
        self.class_keys = {}
        self._versions = {}

    def _next_version(self, identity, role):
        v = self._versions.get((identity, role), 0) + 1
        self._versions[(identity, role)] = v
        return v

    def new_signing_key(self, identity):
        x = g.random_scalar()
        ref = self.registry.register(identity, "signing", self._next_version(identity, "signing"),
                                     SUITE, g.encode_point(g.mul(x, g.G)))
        return SigningSecret(ref, x)

    def new_decryption_key(self, identity, *, tag=None, epoch=None):
        """A delegatee's key (tag=None) or an origin's class key for one (tag, epoch)."""
        k = g.random_scalar()
        ref = self.registry.register(identity, "decryption", self._next_version(identity, "decryption"),
                                     SUITE, g.encode_point(g.mul(k, g.G)))
        if tag is not None:
            if (identity, tag, epoch) in self.class_keys:
                raise InvalidContext("class key already exists for this tag and epoch")
            self.class_keys[(identity, tag, epoch)] = ref
        return DecryptionSecret(ref, k)

    def point(self, ref):
        return g.decode_point(self.registry.resolve(ref).encoded_key)

    def class_key(self, identity, tag, epoch):
        return self.class_keys[(identity, tag, epoch)]


# ---------------------------------------------------------------- record helpers
def statement_bytes(sender, origin, tag, epoch, commitment):
    return encode(("cea-origin/v0", SUITE, sender.fields(), origin.fields(), tag, epoch, commitment))


def _kdf(Q, n):
    return g.hash_bytes("cea/kdf", g.encode_point(Q), n)


def _opening(Q):
    return g.hash_bytes("cea/d", g.encode_point(Q))


def _commit(message, d):
    return g.hash_bytes("cea/commit", encode((message, d)))


def _body(Lam, c, A, E):
    return g.encode_point(Lam) + c + g.encode_point(A) + E


def parse_body(body):
    if not isinstance(body, bytes) or len(body) < _LAM + _C + _A:
        raise EncodingError("record body too short")
    Lam = g.decode_point(body[:_LAM])
    c = body[_LAM:_LAM + _C]
    A = g.decode_point(body[_LAM + _C:_LAM + _C + _A])
    return Lam, c, A, body[_LAM + _C + _A:]


def _xor(x, y):
    return bytes(i ^ j for i, j in zip(x, y))


# ---------------------------------------------------------------- the construction
class CEA:
    """Implements the cipherauth.interfaces.Construction operations for the comparator."""

    def __init__(self, directory: Directory):
        self.dir = directory

    # -- sender side
    def signcrypt(self, sender: SigningSecret, origin_identity: str, message: bytes, tag: bytes, epoch: int):
        origin = self.dir.class_key(origin_identity, tag, epoch)
        K = self.dir.point(origin)
        t = g.random_scalar()
        Q = g.mul(t, g.G)
        A = g.mul(t, K)
        d = _opening(Q)
        E = _xor(message, _kdf(Q, len(message)))
        c = _commit(message, d)
        stmt = statement_bytes(sender.ref, origin, tag, epoch, c)
        X = self.dir.point(sender.ref)
        Lam, theta = schnorr.sign(sender.x, X, stmt)
        record = EncryptedRecord(sender.ref, origin, tag, epoch, _body(Lam, c, A, E))
        return Submission(record, theta)

    # -- public checks (anyone)
    def _entry(self, record):
        Lam, c, _, _ = parse_body(record.body)
        stmt = statement_bytes(record.sender, record.origin, record.tag, record.epoch, c)
        return Lam, self.dir.point(record.sender), stmt

    def _record_consistent(self, record):
        """Registry resolution, roles, and the class-key mapping for (origin owner, tag, epoch)."""
        self.dir.registry.resolve(record.sender)
        self.dir.registry.resolve(record.origin)
        if self.dir.class_keys.get((record.origin.identity, record.tag, record.epoch)) != record.origin:
            raise InvalidContext("origin key is not the registered class key for this tag and epoch")

    def check_submission(self, submission: Submission):
        try:
            self._record_consistent(submission.record)
            g.validate_scalar(submission.theta)
            Lam, X, stmt = self._entry(submission.record)
        except Exception:
            return False
        return schnorr.verify(X, stmt, (Lam, submission.theta))

    def aggregate(self, context: BatchContext, submissions):
        if not submissions:
            raise InvalidContext("empty batch")
        agg = schnorr.HalfAggregate()
        records = []
        for sub in submissions:
            self._check_against_context(context, sub.record, submissions[0].record.tag)
            if not self.check_submission(sub):
                raise InvalidContext("invalid submission rejected at intake")
            Lam, X, stmt = self._entry(sub.record)
            agg.append(X, stmt, (Lam, sub.theta))
            records.append(sub.record)
        return CompressedAggregate(context, tuple(records), g.encode_scalar(agg.s))

    def append(self, aggregate: CompressedAggregate, submission: Submission, *, stream=None):
        """IncrAgg. Without a cached stream the prefix coefficients are rehashed (O(n) bytes);
        with `stream` (an untrusted, unserialized CoefficientStream for exactly these records)
        only the new entry is hashed. Verification never trusts the stream."""
        self._check_against_context(aggregate.context, submission.record, aggregate.records[0].tag)
        if not self.check_submission(submission):
            raise InvalidContext("invalid submission rejected at intake")
        if stream is None:
            stream = schnorr.CoefficientStream()
            for r in aggregate.records:
                stream.push(*self._entry(r))
        Lam, X, stmt = self._entry(submission.record)
        a_new = stream.push(Lam, X, stmt)
        s = (int.from_bytes(aggregate.authenticator, "big") + a_new * submission.theta) % g.q
        return replace(aggregate, records=aggregate.records + (submission.record,),
                       authenticator=g.encode_scalar(s)), stream

    def _check_against_context(self, context, record, batch_tag):
        if record.origin != context.origin or record.epoch != context.epoch or record.tag != batch_tag:
            raise InvalidContext("record does not match batch origin, epoch or tag")

    def verify_public(self, aggregate: CompressedAggregate):
        """Sender authenticity of every record, checkable by anyone (no secret key)."""
        try:
            aggregate.validate_shape()
            tag = aggregate.records[0].tag
            entries = []
            ctx = aggregate.context
            for r in aggregate.records:
                # every record must belong to the batch's single class (origin key, tag, epoch);
                # otherwise a grant for one class could carry statements addressed to another
                if r.tag != tag or r.origin != ctx.origin or r.epoch != ctx.epoch or ctx.suite != SUITE:
                    return False
                self._record_consistent(r)
                entries.append(self._entry(r))
            s = int.from_bytes(aggregate.authenticator, "big")
            if len(aggregate.authenticator) != 32:
                return False
            return schnorr.verify_aggregate(entries, s)
        except Exception:
            return False

    # -- delegation
    def issue_grant(self, owner_signing: SigningSecret, origin_secret: DecryptionSecret,
                    delegatee: KeyRef, tag: bytes, epoch: int):
        """Re-key for ONE class key plus a grant signed by the origin owner's signing key."""
        if owner_signing.ref.identity != origin_secret.ref.identity:
            raise InvalidContext("grant issuer must own the origin key")
        if self.dir.class_key(origin_secret.ref.identity, tag, epoch) != origin_secret.ref:
            raise InvalidContext("origin secret is not the class key for this tag and epoch")
        K_l = self.dir.point(delegatee)
        omega, t2 = g.random_scalar(), g.random_scalar()
        T = g.mul(t2, g.G)
        C = _xor(omega.to_bytes(32, "big"),
                 g.hash_bytes("cea/rk-mask", encode((g.encode_point(T), origin_secret.ref.fields()))))
        token = Token(origin_secret.ref, delegatee, omega * origin_secret.k % g.q, C, g.mul(t2, K_l))
        gid = digest("cea-grant-id", g.random_scalar())
        grant = Grant(owner_signing.ref, origin_secret.ref, delegatee, (tag,), epoch, token.digest(), gid, SUITE)
        X = self.dir.point(owner_signing.ref)
        R, s = schnorr.sign(owner_signing.x, X, grant.message())
        return token, SignedGrant(grant, g.encode_point(R) + g.encode_scalar(s))

    def _grant_sig_ok(self, encoded_key, message, signature):
        try:
            X = g.decode_point(encoded_key)
            R = g.decode_point(signature[:g.POINT_BYTES])
            s = int.from_bytes(signature[g.POINT_BYTES:], "big")
            if len(signature) != g.POINT_BYTES + g.SCALAR_BYTES:
                return False
        except Exception:
            return False
        return schnorr.verify(X, message, (R, s))

    def _grant_valid(self, token_public_digest_check, signed: SignedGrant, origin, delegatee, tag, epoch):
        return verify_grant(signed, self.dir.registry, origin=origin, delegatee=delegatee, tag=tag,
                            epoch=epoch, token_digest=token_public_digest_check, suite=SUITE,
                            verify_signature=self._grant_sig_ok)

    def _transform(self, token: Token, record: EncryptedRecord, omega_inv):
        Lam, c, A, E = parse_body(record.body)
        return replace(record, body=_body(Lam, c, g.mul(omega_inv, A), E))

    def delegate_record(self, token: Token, grant: SignedGrant, submission: Submission):
        """Re-encrypt one submission (theta kept, so it can still be aggregated later)."""
        self._proxy_checks(token, grant, submission.record.origin, submission.record.tag, submission.record.epoch)
        return Submission(self._transform(token, submission.record, g.inv(token.Omega)), submission.theta)

    def delegate_aggregate(self, token: Token, grant: SignedGrant, aggregate: CompressedAggregate):
        """Uses ONLY the compressed aggregate, the token and the grant. Theta is carried unchanged."""
        ctx = aggregate.context
        if ctx.level != "origin":
            raise InvalidContext("single-hop: only origin-level aggregates can be delegated")
        if not self.verify_public(aggregate):
            raise InvalidContext("proxy refuses an aggregate that fails public verification")
        tag = aggregate.records[0].tag
        self._proxy_checks(token, grant, ctx.origin, tag, ctx.epoch)
        omega_inv = g.inv(token.Omega)
        records = tuple(self._transform(token, r, omega_inv) for r in aggregate.records)
        new_ctx = BatchContext(ctx.suite, "delegated", ctx.origin, token.delegatee, ctx.epoch,
                               grant.payload.grant_id)
        return DelegatedAggregate(CompressedAggregate(new_ctx, records, aggregate.authenticator),
                                  grant, token.public_part())

    def aggregate_delegated(self, grant: SignedGrant, token_public, submissions):
        """Delegate-then-aggregate path: aggregate already re-encrypted submissions."""
        first = submissions[0].record
        ctx = BatchContext(SUITE, "delegated", first.origin, grant.payload.delegatee, first.epoch,
                           grant.payload.grant_id)
        origin_ctx = BatchContext(SUITE, "origin", first.origin, first.origin, first.epoch)
        inner = self.aggregate(origin_ctx, submissions)      # coefficients bind only invariant data
        return DelegatedAggregate(replace(inner, context=ctx), grant, token_public)

    def _proxy_checks(self, token, grant, origin, tag, epoch):
        if token.origin != origin or grant.payload.token_digest != token.digest():
            raise InvalidContext("token does not match the grant or the origin key")
        if not self._grant_valid(token.digest(), grant, origin, token.delegatee, tag, epoch):
            raise InvalidContext("grant does not authorize this delegation")

    # -- opening (recipient side)
    def open_aggregate(self, recipient: DecryptionSecret, obj):
        """Returns the ordered OriginStatements, or None if anything fails (all-or-nothing)."""
        try:
            if isinstance(obj, DelegatedAggregate):
                agg, Q_of = obj.aggregate, self._delegated_opener(recipient, obj)
            else:
                agg = obj
                if agg.context.level != "origin" or recipient.ref != agg.context.origin:
                    return None
                k_inv = g.inv(recipient.k)
                Q_of = lambda A: g.mul(k_inv, A)
            if Q_of is None or agg.context.recipient != recipient.ref or not self.verify_public(agg):
                return None
            out = []
            for r in agg.records:
                Lam, c, A, E = parse_body(r.body)
                Q = Q_of(A)
                m = _xor(E, _kdf(Q, len(E)))
                if _commit(m, _opening(Q)) != c:
                    return None
                out.append(OriginStatement(r.sender, r.origin, r.tag, r.epoch, m))
            return tuple(out)
        except Exception:
            return None

    def _delegated_opener(self, recipient, obj):
        agg, grant = obj.aggregate, obj.grant
        C, gamma_bytes, _W = obj.token_public
        ctx = agg.context
        if ctx.level != "delegated" or ctx.grant_id != grant.payload.grant_id:
            return None
        if grant.payload.delegatee != recipient.ref or grant.payload.origin != ctx.origin:
            return None
        # The grant's token digest must match the public token part shipped with the aggregate.
        if not self._grant_valid(token_digest(ctx.origin, recipient.ref, obj.token_public), grant,
                                 ctx.origin, recipient.ref, agg.records[0].tag, ctx.epoch):
            return None
        T = g.mul(g.inv(recipient.k), g.decode_point(gamma_bytes))
        omega = int.from_bytes(_xor(C, g.hash_bytes("cea/rk-mask", encode((g.encode_point(T), ctx.origin.fields())))), "big")
        if not 0 < omega < g.q:
            return None
        return lambda Abar: g.mul(omega, Abar)


# ---------------------------------------------------------------- sizes (bytes)
def sizes(message_len, n, u, identity_bytes=16):
    """FIELD-LEVEL model only (no framing, counts or suite string); the measured wire size comes
    from cipherauth.wire. Key references are counted once per DISTINCT key as identity +
    version (4) + fingerprint (32); per-record sender indices are counted as 2 bytes.
    Corrected 25 Oct 2026: the token public part is C (32) + gamma (33) + W (32) = 97 bytes;
    the earlier model omitted W."""
    keyref = identity_bytes + 4 + 32
    record_body = _LAM + _C + _A + message_len
    token_public = 32 + g.POINT_BYTES + 32
    grant_sig = g.POINT_BYTES + g.SCALAR_BYTES
    return {
        "model": "field-level, unframed; see wire_* entries in scripts/cea_demo.py for measured bytes",
        "submission_fields": record_body + g.SCALAR_BYTES + 2 * keyref + 8 + 4,
        "record_body": record_body,
        "aggregate_fields": n * (record_body + 2) + g.SCALAR_BYTES + (u + 1) * keyref + 8 + 4,
        "token_public_part": token_public,
        "delegation_extra_fields": token_public + grant_sig + 2 * keyref + 32 + 32,
        "auth_bytes_per_record": _LAM + _C,       # Lambda_i and c_i: signature-dependent, not ciphertext
        "auth_bytes_per_batch": g.SCALAR_BYTES,
    }
