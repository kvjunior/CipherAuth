# Claim categories

Behavior: an executable observation reproduced.
Algebra: a stated local identity has an elementary argument.
Security: a complete theorem for a specific construction/game is needed.
Novelty: exact literature comparison and a new contribution are needed.

Status values (`src/cipherauth/claims.py`):

- security `open`, `refuted`, `sketch_unreviewed`, `reviewed_proof`.
  `sketch_unreviewed` (added 25 Oct 2026) means a complete argument is written down and
  composes cited theorems, but no human author has checked it. It is not "proved".
- novelty `unverified`, `comparison_pending`, `defeated_by_known_composition`, `reviewed_gap`.
  `defeated_by_known_composition` (added 25 Oct 2026) means a generic composition of known
  techniques already achieves the claimed property; the claim must not appear as a
  contribution.

`tests/unit/test_claims.py` still forbids `reviewed_proof` and `reviewed_gap`: only human
review may set those. The metadata validator checks labels and required fields only. It is
not a proof checker.
