# Central compatibility contract

For an admissible ordered list C encrypted for origin j and an authenticated grant G from j
to ell, compare:

    left  = DelegateAggregate(rk, G, Aggregate_j(C))
    right = Aggregate_ell([ReEncrypt(rk, G, c) for c in C])

Both paths must accept and recover the same ordered origin statements
(sender identity/key/version, original recipient identity/key/version, message, tag, epoch),
and verify the same authorization meaning. Randomized ciphertext bytes may differ.

The DelegateAggregate API receives only the compressed aggregate, public inputs, token,
and grant. Individual theta_i, plaintexts, recipient secrets, and an archive oracle are not
implicit inputs. Any additional retained evidence must be declared and included in costs.

This contract alone is not a novelty claim. Existing homomorphic/malleable authentication
and PRE compositions may satisfy it. The theorem must state what is newly achieved.

The v3 negative control changes A to Abar and changes the batch context. Its coefficients
therefore change. Preserving the old Theta fails in the observed test; rebuilding with the
individual theta_i succeeds. This diagnoses one proposed update, not all possible updates.

Do not force invariance by deleting key, ciphertext, or recipient bindings from a hash
without proving the resulting authentication relation sound.
