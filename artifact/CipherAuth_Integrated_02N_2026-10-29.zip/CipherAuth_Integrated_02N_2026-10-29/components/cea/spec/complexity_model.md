# Complexity and experiments

Report both asymptotic costs and concrete field sizes. Constant compressed scalar length
does not mean constant total authentication, ciphertext, metadata, or verification work.
Encrypted commitments and encrypted signature responses cannot be hidden in a payload budget.

The existing weighted verifier uses 2n+u+1 multiplication calls in one factoring model;
independent checks use 3n. Strict savings require u<n-1. The unweighted model gives n+u+1,
but its authentication is insecure. These are implementation call counts, not optimality
results, fixed-base/MSM costs, or runtime predictions.

Future measurements must record operation type, preprocessing, inversion, hash bytes,
serialization, messages, n, u, grant groups, warm/cold caches, runtime, library/curve versions,
machine details, randomness policy, repetitions, and uncertainty summaries.

No new timing results are provided. Historical manuscript timings cannot be reconstructed
from unavailable raw measurements. Benchmark only an explicit stable construction.
