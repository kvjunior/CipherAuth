# Confidentiality proof target

Start from a published RCCA/PRE definition and specify the exact adaptation.
Public append and inner rerandomization preclude a naive exact-challenge exclusion rule.
The final choice must avoid both trivial extension attacks and vacuous over-exclusion.

Specify setup, static corruptions, keys, signcryption/decryption/re-key/re-encryption
oracles in each phase, one vector challenge, authorization closure, invalid-input policy,
scope and epoch handling, all-or-nothing batch verification, duplicate records, and leakage.
Both candidate challenge vectors must be handled symmetrically by the post-challenge rule.

ReplayMask implements one post-verification redaction fragment only. Its existence does
not show that the resulting full game is achievable, composable, or the strongest notion.
Do not treat an arbitrary relation picked to reject an attack as a security theorem.

Ordinary insider confidentiality gives sender keys, not the challenge-generation coins.
Do not claim that a public tag contributes hidden entropy.
