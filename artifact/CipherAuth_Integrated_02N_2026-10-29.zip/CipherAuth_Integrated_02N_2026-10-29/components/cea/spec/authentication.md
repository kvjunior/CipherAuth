# Authentication games to formalize

Origin authentication certifies that sender i authored m for original recipient j under
tag tau and epoch e. The immutable statement includes both key identities and versions.
Current delegatee identity belongs in the separate grant/transport statement.

Aggregate insider unforgeability must allow corrupt recipient/proxy, malicious non-target
senders, arbitrary admissible registered keys, chosen statements, and repeated senders.
Record all honest signcryption queries and define freshness on the full origin statement.

Delegation authenticity is a separate game: acceptance must not assert a grant by j that j
did not issue, even if origin sender authentication remains valid. Bind the origin and
delegatee keys, scope, epoch, protocol/suite, grant ID, and exact token commitment.

AuthorizationLedger and FreshnessLedger are bookkeeping fragments, not complete games.
Formalize cross-level queries and registry aliases before any reduction.
