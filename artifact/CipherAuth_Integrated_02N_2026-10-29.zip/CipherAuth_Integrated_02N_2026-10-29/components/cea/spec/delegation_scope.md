# Grant scope and collusion

Initial grants concern one tag/epoch class and one origin/delegatee pair. A grant signature
authenticates the permission statement. It does not make an unrestricted re-key unable
to decrypt outside that permission.

Out-of-scope confidentiality must hold against proxy+delegatee holding the token and
delegatee key. Key recovery is distinct: specify which decryption or signing scalar is a target.
In-scope offline decryption is inherent to a coalition holding those materials.

verify_grant implements statement and policy checks using an external signature verifier.
It is not a scoped PRE construction. The unrestricted-token negative control reproduces
why the inherited v3 token cannot satisfy cryptographic scope merely by adding labels.

A viable backend might use a published scoped PRE primitive or separated class/epoch keys.
Those are comparators, not a claimed new technique. All per-class keys and metadata count.
