# Canonical research encoding

encoding.encode uses disjoint type tags and length delimiters. Map keys are strings sorted
lexicographically; bytes and strings remain different types; tuples and lists remain different.
Floating-point values are rejected. Identities are exact UTF-8 strings and are not implicitly
normalized into aliases. Integers have a canonical decimal encoding.

This is a local research encoding, not an RFC claim or a complete parser for untrusted wire data.
Before a concrete protocol is frozen, specify point/scalar encodings, curve/subgroup checks,
message/tag limits, field bounds, protocol versions, and parse rejection.

Grant messages bind suite, issuer, origin, delegatee, scope, epoch, token digest, and grant ID.
Signature verification is an external backend contract returning a Boolean.
