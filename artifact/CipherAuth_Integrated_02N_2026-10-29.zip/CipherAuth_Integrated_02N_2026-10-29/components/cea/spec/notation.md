# Objects and costs

P is the prime-order group generator; q is its order. X_i is a signing point and K_r a
decryption public point. Lambda_i is a Schnorr commitment and theta_i its response.
Do not reuse the word commitment for the public manifest digest without distinguishing it.

n: records in an ordered batch; u: distinct signing keys, including versions; g: grant groups.
The initial target fixes g=1. lambda is the security parameter, not a nonce name.
Tags and epochs are authenticated context, not secret entropy.

Separate ciphertext data, sender-authentication data, grant evidence, public-key metadata,
append hints, preprocessing, group operations, scalar inversions, hash calls, hash-input bytes,
and measured runtime. Count encrypted signatures and retained original ciphertext components.
