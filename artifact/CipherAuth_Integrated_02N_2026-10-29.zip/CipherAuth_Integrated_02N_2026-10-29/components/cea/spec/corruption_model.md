# Initial adversary

Static corruptions; malicious senders, recipients, proxy, and aggregator where relevant.
Key registration binds identity, role, suite, and version. State any proof-of-possession
assumption separately from availability of an extractor in a reduction.

The initial target is not certificateless. KGC master keys and Type I/II games are not
silently imported from the legacy prototype. Any later extension requires a separate theorem.

The adversary may submit malformed encodings, mix key versions, alter context, repeat
records, reorder records, or provide inconsistent evidence. Define rejection at each API.
Fault attribution requires an explicit evidence-delivery model and includes aggregator faults.
