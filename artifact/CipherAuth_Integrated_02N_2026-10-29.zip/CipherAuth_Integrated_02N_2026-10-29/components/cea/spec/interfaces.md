# API and state boundaries

src/cipherauth/interfaces.py specifies the intended construction interface.
Public aggregates carry opaque encrypted records, compressed authentication, context, and
an optional append hint. They do not carry secret keys or per-record signature responses.

Backend responsibilities: validate group elements and scalars; separate public/secret key
types; provide a canonical wire encoding; implement origin signatures, scoped tokens,
record transformations, aggregation, aggregate delegation, and complete verification.

Do not install legacy Params.alpha as public setup output in a new implementation.
The legacy prototype's key structure differs from the independent public keys in Lemma C.

Registry responsibilities: stable identities, roles, explicit key versions, fingerprints,
and consistent resolution. Structural registration is implemented; cryptographic key
validation belongs to the backend. No extraction oracle is available by default.

Append hints are cached state, not trusted proofs. Validate them on acceptance.
O(1) new hash calls do not imply O(1) copying or serializing all batch metadata.
