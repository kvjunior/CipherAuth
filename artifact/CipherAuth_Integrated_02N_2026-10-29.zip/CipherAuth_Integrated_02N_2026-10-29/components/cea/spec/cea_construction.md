# CEA comparator: commit, encrypt, sign the commitment, half-aggregate

Status: **generic composition, not a new construction.** It is implemented
(`src/cipherauth/cea.py`) because the work order asks for any generic composition that
already achieves the target guarantees to be demonstrated. Its existence defeats novelty for
the operation-order (commutation) question; see `literature/novelty_matrix.md`.

## Parameters and keys

Prime-order group P-256, generator P, order q. Hash functions, all domain-separated and
modelled as independent random oracles when used in the ROM: `H1` (Schnorr challenge),
`H2` (IASchnorr prefix coefficient), `Hd` (opening), `Hc` (commitment), `KDF`, `Hmask`
(token mask). Encodings are typed and length-delimited (`spec/canonical_encoding.md`).

- Sender S: signing key x_S, X_S = x_S·P, registered as versioned `KeyRef(S, signing, v, fp)`.
- Origin j: one signing key (grant issuer) and one **class decryption key** k_{j,τ,e},
  K = k·P, per (tag τ, epoch e). Class keys are independent; they are versioned KeyRefs.
- Delegatee ℓ: a decryption key k_ℓ, K_ℓ = k_ℓ·P.
- Registration is plain: the registry stores keys and fingerprints and rejects version/
  fingerprint conflicts. **No proof of possession, no knowledge extraction.** The adversary
  may register any group element (chosen-key model).

## Algorithms

`Signcrypt(x_S, ref_S, K-ref of (j,τ,e), m)`:
t ← Z_q*; Q = t·P; A = t·K; d = Hd(Q); E = m ⊕ KDF(Q, |m|); c = Hc(m, d);
st = enc("cea-origin/v0", suite, ref_S, ref_K, τ, e, c); (Λ, θ) = Schnorr.Sign(x_S, st).
Record body = Λ ‖ c ‖ A ‖ E; submission = (record, θ).

`Aggregate(ctx, submissions)`: checks each record's (origin, tag, epoch) against the batch and
verifies each Schnorr signature at intake; s̃ = Σ a_i θ_i with IASchnorr coefficients
a_1 = 1, a_i = H2((Λ_1,X_1,st_1),…,(Λ_i,X_i,st_i)). Output: records and s̃ (32 bytes).

`Append`: one more IASchnorr step; with the cached SHA-256 prefix state only the new entry is
hashed; without it the prefix is rehashed. Verification never uses the cache.

`VerifyPublic(agg)`: every record has the batch's (origin key, tag, epoch) and suite, every
key reference resolves, and the IASchnorr equation holds. Uses no secret.

`IssueGrant(j)` for one class (τ, e) and delegatee ℓ: ω, t' ← Z_q*; T = t'·P;
C = ω ⊕ Hmask(T, ref_K); Ω = ω·k; γ = t'·K_ℓ. Token = (Ω, C, γ); its public part is
(C, γ, W = H(Ω)); token digest = H(ref_K, ref_ℓ, C, γ, W). Grant = (issuer = j's signing key,
origin class key, delegatee, tags = (τ), epoch e, token digest, fresh grant id, suite), signed
with Schnorr under j's signing key.

`DelegateAggregate(token, grant, agg)`: input is **only** the compressed aggregate, the token
and the signed grant. Checks: origin level; VerifyPublic; token matches grant digest and
origin; grant signature and scope (origin, delegatee, τ, e). For each record A ↦ Ā = Ω⁻¹·A;
Λ, c, E unchanged; **s̃ unchanged**; context becomes delegated with the grant id. Output
carries the signed grant and the token's public part.

`AggregateDelegated`: the same IASchnorr aggregation over already transformed submissions.

`Open` (origin j): VerifyPublic; Q = k⁻¹A; m = E ⊕ KDF(Q); accept iff c = Hc(m, Hd(Q)).
`Open` (delegatee ℓ): additionally checks the grant (signature, delegatee, origin, τ, e, grant
id, token digest recomputed from the shipped public part); T = k_ℓ⁻¹γ; ω = C ⊕ Hmask(T, ref_K);
Q = ω·Ā. Opening is all-or-nothing; output is the ordered list of
`OriginStatement(sender, origin, τ, e, m)`. Delegated statements still name origin j.

## Why the two orders commute (exact)

The IASchnorr entries (Λ_i, X_i, st_i) contain only fields that delegation does not change:
st_i binds c_i, not A_i or E_i. Hence the coefficient sequence, s̃, the entries and the
certified statements are identical in both orders, and the record bodies are byte-identical.
This is a one-line observation (`proofs/cea_authenticity.md`, Lemma 0), not a technical result.

## Retained material and what is *not* claimed

- The proxy retains the token (Ω, C, γ). A proxy–delegatee coalition recovers k_{j,τ,e}
  (`test_coalition_recovers_only_its_class_key`). Scope is cryptographic **only at class
  granularity**: other tags/epochs use independent keys. Inside the class there is no
  revocation; deleting the token revokes nothing against a coalition that kept it.
- The authenticator is publicly verifiable: anyone learns which registered sender signed some
  record for origin class (j, τ, e), and how many. This is **sender-public**, unlike v3's
  receiver-verifiable design. It is a semantic difference, not hidden.
- Anyone can append validly signed records (public aggregation) or reorder/drop records and
  re-aggregate from individual submissions they hold. Order and completeness are not certified
  beyond "this ordered list of statements was each signed by its sender".
- E and A are not signed; integrity of (A, E) is enforced at opening via c. VerifyPublic
  therefore certifies *sender commitments*, not *ciphertext validity*: a re-randomised A or a
  modified E passes VerifyPublic and fails Open (tests). The proxy cannot detect this.
- Consequence for delegation: an honest proxy serving a corrupted delegatee for a class gives
  that delegatee every record of the class, including mauled versions of records the proxy
  was told to withhold (`attacks/cea_reenc_mauling.py`). Delegation control is per class
  (tag, epoch), never per ciphertext.
- Sizes: field-level model in `cea.sizes` (token public part 97 B, including W; corrected);
  measured canonical wire format in `cipherauth.wire` (`scripts/cea_demo.py`).
