"""One-command research-infrastructure verification; no security theorem is certified."""
import json, os, platform, re, subprocess, sys
from pathlib import Path
from run_baseline import run as baseline
from verify_manifest import run as integrity
from cea_demo import run as cea_demo

ROOT = Path(__file__).resolve().parents[1]

def diagnostic(name):
    p = subprocess.run([sys.executable, str(ROOT / "attacks" / name)], cwd=ROOT,
                       capture_output=True, text=True, timeout=120)
    if p.returncode:
        raise RuntimeError(p.stderr or p.stdout)
    return json.loads(p.stdout)

def run():
    source = integrity()
    environment = os.environ.copy()
    environment["PYTHONPATH"] = str(ROOT / "src")
    tests = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "tests/unit", "-v"],
                           cwd=ROOT, env=environment, capture_output=True, text=True, timeout=120)
    if tests.returncode:
        raise RuntimeError(tests.stdout + tests.stderr)
    found = re.search(r"Ran (\d+) tests?", tests.stderr)
    skipped = re.findall(r"^(test\S+) .*\.\.\. skipped", tests.stderr, re.M)
    try:
        import importlib.metadata as md
        crypto_version = md.version("cryptography")
    except Exception:
        crypto_version = None
    result = {
        "python": platform.python_version(),
        "source_integrity": source,
        "unit_tests": {"exit_code": tests.returncode, "count": int(found.group(1)) if found else None,
                       "skipped": skipped,
                       "optional_dependency_cryptography": crypto_version or "absent (P-256 cross-check skipped)"},
        "v3_baseline": baseline(),
        "v3_commutation_gap": diagnostic("commutation_v3.py"),
        "scope_negative_control": diagnostic("unrestricted_token_scope.py"),
        "v3_unbound_coefficient_attack": diagnostic("unbound_coefficient_v3.py"),
        "cea_reencryption_mauling": diagnostic("cea_reenc_mauling.py"),
        "cea_comparator": cea_demo(),
        "new_construction": "NONE (CEA is a generic composition used as the comparator; see claims/claims.json)",
        "aggregate_security": "UNPROVEN in this repository (CEA proof sketch reduces to Chen-Zhao Thm 2; see proofs/status.md)",
        "novelty": "Commutation question DEFEATED by known composition; refined question open (proofs/commutation_target.md)",
        "meaning": "Infrastructure and stated observations verified; no submission-readiness or security certification."
    }
    out = ROOT / "results/local"
    out.mkdir(parents=True, exist_ok=True)
    (out / "run_summary.json").write_text(json.dumps(result, indent=2) + "\n")
    (out / "unit_tests.txt").write_text(tests.stdout + tests.stderr)
    print(json.dumps(result, indent=2))
    return result

if __name__ == "__main__":
    run()
