import hashlib, json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def run():
    expected = json.loads((ROOT / "provenance/source_manifest.json").read_text())
    failures = []
    for name, sha in expected["sha256"].items():
        p = ROOT / name
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest() != sha:
            failures.append(name)
    if failures:
        raise RuntimeError("source snapshot differs: " + ", ".join(failures))
    return {"checked_files": len(expected["sha256"]), "all_listed_hashes_match": True}

if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
