"""Create a new source snapshot after intentional reviewed edits.
Never use this to conceal changes to the separately frozen baseline.
"""
import hashlib, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

def eligible(p):
    name = p.relative_to(ROOT).as_posix()
    return (p.is_file() and "__pycache__" not in p.parts
            and p.suffix != ".pyc" and not name.startswith("results/local/")
            and name != "provenance/source_manifest.json")

sha = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
       for p in sorted(ROOT.rglob("*")) if eligible(p)}
output = ROOT / "provenance/source_manifest.json"
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(json.dumps({"algorithm": "sha256", "scope": "listed source and input files; generated local results excluded", "sha256": sha}, indent=2) + "\n")
print(json.dumps({"source_files": len(sha)}))
