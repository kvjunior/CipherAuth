"""Run the immutable v3 artifact in a temporary working directory."""
import argparse, hashlib, json, shutil, subprocess, sys, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def run():
    source = ROOT / "baselines/claude_v3/source"
    manifest = json.loads((ROOT / "baselines/claude_v3/source_manifest.json").read_text())
    expected_path = ROOT / "baselines/claude_v3/expected/v3_results.json"
    if hashlib.sha256(expected_path.read_bytes()).hexdigest() != manifest["expected_report_sha256"]:
        raise RuntimeError("the frozen expected report changed")
    expected = json.loads(expected_path.read_text())
    for name, sha in manifest["sha256"].items():
        if hashlib.sha256((source / name).read_bytes()).hexdigest() != sha:
            raise RuntimeError("frozen baseline changed: " + name)
    with tempfile.TemporaryDirectory(prefix="cipherauth-v3-") as directory:
        work = Path(directory)
        for name in manifest["sha256"]:
            shutil.copyfile(source / name, work / name)
        process = subprocess.run([sys.executable, "v3_checks.py"], cwd=work,
                                 capture_output=True, text=True, timeout=120)
        if process.returncode:
            raise RuntimeError(process.stderr or process.stdout)
        actual = json.loads((work / "v3_results.json").read_text())
    result = {
        "script_exit_code": process.returncode,
        "exact_report_match": actual == expected,
        "boolean_conditions": len(actual),
        "conditions_true": sum(bool(v["confirmed"]) for v in actual.values()),
        "interpretation": "Reproduced program behavior, not a cryptographic security proof."
    }
    if not result["exact_report_match"] or result["conditions_true"] != len(actual):
        raise RuntimeError(json.dumps(result))
    return result

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = run()
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
