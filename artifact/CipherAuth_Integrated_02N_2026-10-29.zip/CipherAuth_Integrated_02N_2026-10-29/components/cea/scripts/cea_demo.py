"""CEA comparator demo: both operation orders, Theta invariance, and COUNTED operations.

Reports scalar multiplications, inversions, hash calls and hashed bytes as counted by
cipherauth.group. No wall-clock timings are reported or claimed. The CEA comparator is a
generic composition (sign a commitment, encrypt, IASchnorr-aggregate); see spec/cea_construction.md.
"""
import json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from cipherauth import group as g
from cipherauth.cea import CEA, Directory, SUITE, sizes
from cipherauth.models import BatchContext
from cipherauth import wire

TAG, EPOCH, N, U, MSG = b"vibration", 7, 8, 3, 32


def counted(fn, *args, **kw):
    g.reset_counts()
    out = fn(*args, **kw)
    return out, dict(g.COUNTS)


def run():
    D = Directory()
    S = CEA(D)
    senders = [D.new_signing_key(f"sensor-{i}") for i in range(U)]
    owner = D.new_signing_key("plant")
    jk = D.new_decryption_key("plant", tag=TAG, epoch=EPOCH)
    l = D.new_decryption_key("auditor")
    msgs = [bytes([i]) * MSG for i in range(N)]

    sub0, c_signcrypt = counted(S.signcrypt, senders[0], "plant", msgs[0], TAG, EPOCH)
    subs = [sub0] + [S.signcrypt(senders[i % U], "plant", m, TAG, EPOCH) for i, m in enumerate(msgs) if i]
    ctx = BatchContext(SUITE, "origin", jk.ref, jk.ref, EPOCH)
    agg, c_aggregate = counted(S.aggregate, ctx, subs)
    ok, c_verify = counted(S.verify_public, agg)
    (token, grant), c_grant = counted(S.issue_grant, owner, jk, l.ref, TAG, EPOCH)
    left, c_delegate_agg = counted(S.delegate_aggregate, token, grant, agg)
    delegated = [S.delegate_record(token, grant, s) for s in subs]
    right, c_agg_delegated = counted(S.aggregate_delegated, grant, token.public_part(), delegated)
    L, c_open_delegated = counted(S.open_aggregate, l, left)
    R = S.open_aggregate(l, right)
    O, c_open_origin = counted(S.open_aggregate, jk, agg)
    wire_agg, wire_left, wire_right = wire.encode_aggregate(agg), wire.encode_delegated(left), wire.encode_delegated(right)
    back, deleg = wire.decode_aggregate(wire_left)
    roundtrip = back == left.aggregate and deleg == (left.grant, left.token_public)

    result = {
        "parameters": {"n_records": N, "distinct_senders": U, "message_bytes": MSG, "curve": "P-256"},
        "public_verification": ok,
        "origin_open_recovers_messages": O is not None and [s.message for s in O] == msgs,
        "both_orders_certify_identical_statements": L is not None and L == R,
        "theta_unchanged_by_delegation": left.aggregate.authenticator == agg.authenticator == right.aggregate.authenticator,
        "record_bodies_identical_across_orders": left.aggregate.records == right.aggregate.records,
        "wire_roundtrip_delegated": roundtrip,
        "delegate_aggregate_inputs": "compressed aggregate, token, signed grant (no theta_i, no plaintext)",
        "operation_counts": {
            "signcrypt_one_record": c_signcrypt,
            "aggregate_n_with_intake_verification": c_aggregate,
            "verify_public_aggregate": c_verify,
            "issue_grant": c_grant,
            "delegate_aggregate": c_delegate_agg,
            "aggregate_delegated_records": c_agg_delegated,
            "open_delegated_aggregate": c_open_delegated,
            "open_origin_aggregate": c_open_origin,
        },
        "size_model_bytes": sizes(MSG, N, U),
        "wire_bytes_measured": {
            "origin_aggregate": len(wire_agg),
            "delegated_aggregate_left": len(wire_left),
            "delegated_aggregate_right": len(wire_right),
            "delegation_extra": len(wire_left) - len(wire_agg),
            "format": "cipherauth.wire (canonical, round-trip tested); identity strings as generated here",
        },
        "timings": "NOT_MEASURED",
        "counter_scope": "mul = scalar-multiplication calls; scalar_inv = inversions mod q only; field inversions inside point addition are part of mul",
        "meaning": "Functional behaviour and counted operations only; not a security proof.",
    }
    required = ("public_verification", "origin_open_recovers_messages", "both_orders_certify_identical_statements",
                "theta_unchanged_by_delegation", "record_bodies_identical_across_orders", "wire_roundtrip_delegated")
    if not all(result[k] for k in required):
        raise RuntimeError(json.dumps(result, indent=2))
    return result


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
