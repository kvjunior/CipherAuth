# Encrypted authentication research workspace

Working paper title: **Commuting Aggregation and Delegation for Encrypted Authentication**

Target: STOC 2027. This is a runnable starting workspace for a theory-led investigation,
not a completed cryptographic construction or submission-ready paper.

The selected question is whether already compressed encrypted authentication can be
delegated without recovering individual signature scalars, while preserving the original
sender statement, an authenticated scoped grant, and a suitable confidentiality notion.
The two operation orders must certify the same original statements. Ciphertexts need not
be byte-identical when their algorithms are randomized.

## Run

Python 3.11 or newer; verification was performed on the runtime recorded in results/local.
The research infrastructure has no third-party runtime dependencies.

    python3 scripts/reproduce.py

For individual steps:

    python3 scripts/run_baseline.py
    PYTHONPATH=src python3 -m unittest discover -s tests/unit -v
    python3 attacks/commutation_v3.py
    python3 attacks/unrestricted_token_scope.py
    python3 attacks/unbound_coefficient_v3.py
    python3 attacks/cea_reenc_mauling.py
    python3 scripts/cea_demo.py

The command verifies the source snapshot, executes focused infrastructure tests, reruns
Claude's frozen twelve-check v3 artifact in a temporary directory, reproduces four
negative controls, and runs the CEA comparator demo. A successful run does not prove any cryptographic security claim.

## Start reading here

- RESEARCH_DIRECTION.md: selected question, scope, novelty gate, and milestones.
- CODEBASE_MAP.md: the complete actual file tree, every file's role, and implementation status.
- CLAUDE_PROMPT.md: the complete next instruction for Claude.
- spec/: statement syntax, API, corruption, confidentiality, and composition requirements.
- proofs/: established local algebra and unresolved security arguments.
- literature/: verified references, access limitations, and comparison questions.
- claims/claims.json: separates behavior, algebra, security, and novelty.

## Implemented now

Typed public statements and key versions; structural registry; canonical grant-message
binding with an external signature-verification interface; freshness and RCCA-style
redaction fragments; analytical cost accounting; isolated baseline replay; diagnostics;
and a source/provenance manifest.

## CEA comparator (added 25 Oct 2026)

src/cipherauth/{group,schnorr,cea}.py implement a generic composition that already achieves
exact commutation (spec/cea_construction.md): P-256, Schnorr with Chen–Zhao IASchnorr
half-aggregation, a commitment-signing signcryption and single-hop re-encryption with
per-(tag, epoch) class keys. It is a comparator, not a new construction; see
literature/novelty_matrix.md, proofs/cea_authenticity.md (unreviewed sketches),
proofs/cea_confidentiality.md (open) and CHANGES.md. Pure Python, not constant time, for
research only.

## Open construction

src/cipherauth/candidate.py raises OpenResearchProblem for compressed-aggregate delegation.
It does not silently reuse the unproved v3 construction, and it is not silently replaced by CEA. The full games and security
reductions remain to be completed. A signed grant alone does not make the inherited
unrestricted re-key cryptographically scoped.

## Evidence discipline

Original source bytes are preserved under baselines/ and archive/. Generated runs are
written under results/local/. Do not overwrite expected results to obtain passing tests.
Include all signature-dependent bytes, even encrypted ones, in the relevant cost budget.
Handwritten legacy curve arithmetic is retained only to reproduce the supplied prototype.
