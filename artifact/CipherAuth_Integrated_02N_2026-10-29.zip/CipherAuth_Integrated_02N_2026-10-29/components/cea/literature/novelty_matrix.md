# Novelty matrix (completed 25 Oct 2026)

Question tested: *do Aggregate-then-Delegate and Delegate-then-Aggregate certify the same
ordered sender statements and origin grant, without individual signature scalars and without
proxy decryption?* Result: **yes, by a generic composition (CEA)**, so commutation is not a
contribution. The last column says what is left for the refined question Q-R
(`proofs/commutation_target.md`).

Reading-scope key: **R** read in full or in the relevant section in this project; **A**
abstract/metadata only; **K** cited from general knowledge in this session, bibliographic
details not re-verified; **X** inaccessible.

| Comparator | Scope | What it gives for our target | Implication | Left open for Q-R |
| --- | --- | --- | --- | --- |
| ADR02 An–Dodis–Rabin, joint signature and encryption (ePrint 2002/046) | R | Commit-then-encrypt-and-sign: sign a commitment, not the ciphertext; insider security; multi-user identity binding | Supplies the invariant signed object CEA uses | none |
| CH07 Canetti–Hohenberger CCA PRE (ePrint 2007/171) | R | Single-hop PRE game, derivatives, rekey restrictions | Supplies the G-CONF template; CEA's re-encryption is of this family | adequacy of the vector/derivative adaptation (open obligation) |
| CKN03 RCCA (ePrint 2003/174) | A | Replayable CCA: decryptions equal to a challenge message are masked | Basis of `ReplayMask` | exact adaptation |
| CZ22 Chen–Zhao IASchnorr (ePrint 2022/222) | R (Sec. 4, Fig. 2, Thm 2) | Incremental half-aggregation; prefix coefficients over (R, X, m); CK-AEUF tight from Schnorr in AGM+ROM | With invariant m, delegation keeps the aggregate unchanged: **this plus ADR02 plus CH07 gives exact commutation** | none for commutation; Q-R nonce term |
| CGKN21 Chalkias–Garillot–Kondi–Nikolaenko half-aggregation of EdDSA/Schnorr (ePrint 2021/350) | A | Half aggregation; "strong evidence" that better compression needs hash-specific proofs | Per-record group element is expected to be necessary for Schnorr-type schemes | whether a *formal* lower bound exists (to check) |
| BGLS03 BLS aggregate signatures | K | Constant-size aggregate, publicly aggregatable, order-free | With pairings, sign c with BLS: commutation with per-record overhead only c | Q-R is meaningful only pairing-free |
| ABF24 fully succinct multi-key homomorphic signatures (ePrint 2024/895) | A | Succinct multi-key authentication of computations | Overkill for an identity function; would also commute if applied to invariant c | no gap identified |
| Malleable signatures / proofs (Chase–Kohlweiss–Lysyanskaya–Meiklejohn, EUROCRYPT 2012, CSF 2014) | K | Signatures that survive allowed transformations | Not needed: CEA's signed object is invariant, so no malleability is required | none |
| Signatures on randomizable ciphertexts (Blazy–Fuchsbauer–Pointcheval–Vergnaud, PKC 2011) | K | Signatures that follow ciphertext re-randomization (pairing-based) | An alternative route if one insists on signing the ciphertext; costlier than signing c | none |
| Policy / monotone-policy aggregate signatures (MPAS24) | A | Expressive policies with succinct authentication | No grant/re-encryption semantics; no implication found | none |
| Conditional PRE (e.g. Weng et al., ASIACCS 2009) and verifiable PRE (e.g. Ohata et al., CT-RSA 2015) | K | Conditions/tags restrict which ciphertexts a rekey transforms; proxies can be checked | CEA's class keys give tag/epoch scope by independent keys, which is simpler; verifiability would add cost | a conditional-PRE token instead of per-class keys could reduce key management; not a novelty |
| FPS20 Fuchsbauer–Plouviez–Seurin, blind Schnorr and signed ElGamal in the AGM (EUROCRYPT 2020, ePrint 2019/877) | A | Schnorr-signed ElGamal is IND-CCA in AGM+ROM: a proof of knowledge of the randomness makes the ciphertext non-malleable and publicly checkable | Known remedy for CEA's proxy-side malleability (G-CONF-CT failure), per record, at about 64 B | whether such proofs can be half-aggregated per class batch and survive delegation (sub-question 4); literature on aggregating Fiat–Shamir proofs of knowledge not yet checked |
| HRA (Cohen, PKC 2019) | K | CPA is inadequate for PRE; honest re-encryption attacks | G-CONF is CCA-style with re-encryption oracle, so HRA is covered by design (still to prove) | none |
| ZWL26 transcript rebinding (ICICS 2026) | A | Composable Schnorr aggregation via rebinding transcripts | Not needed when statements are invariant; possibly relevant to Q-R sub-question 2 | read full text |
| IDASR26 Choi–Jeong–Byun, ID-based aggregate signcryption with re-encryption for UAV networks (Inf. Sci. 2026, doi 10.1016/j.ins.2026.123676) | X (abstract via institutional record) | Combines aggregation, re-encryption and collusion resistance (abstract) | Directly overlaps the application; exact aggregate input, insider game and costs unknown | **unresolved; full text required** |
| v3 baseline (this project) | R | Receiver-verifiable hidden-nonce design | Does not commute; unbinding A is attacked; a delegatable fix costs about as much as CEA | Q-R sub-question 2 |

## Generic composition that achieves the target (demonstrated)

CEA = ADR02 commit-then-encrypt-and-sign, with a single-hop hashed-ElGamal PRE in the CH07
family, and CZ22 IASchnorr over the signed statements. Implemented in `src/cipherauth/cea.py`
and exercised by `tests/unit/test_cea.py` and `scripts/cea_demo.py`. Authenticity theorems are
compositions (`proofs/cea_authenticity.md`, unreviewed sketches); confidentiality is open.

## Correction, 25 Oct 2026

The composition achieves *commutation* and (by unreviewed sketches) authenticity. It does
**not** achieve per-ciphertext PRE confidentiality: G-CONF-CT is refuted by mauling, and only
the class-granularity game G-CONF-CLASS remains a plausible (unproved) target. The novelty
defeat applies to commutation only, not to a full secure instantiation.

## Differences from the posed interface (stated, not hidden)

- CEA's authenticity is publicly verifiable, while v3 was receiver-verifiable. Neither hides sender
  identities (v3 records carry the sender ID). Recipient-only verification and sender anonymity
  are different properties; neither is defined or claimed, and either would need a new gate.
- Order and completeness are not certified against a malicious aggregator, as in CZ22.

No absence of results in this table is evidence of an open problem.
