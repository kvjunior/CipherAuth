# Focused search record, 24 October 2026

Primary searches covered aggregate signcryption with proxy re-encryption, authentication of
encrypted transformations, incremental aggregation, and recent composition/policy work.
The direct IDASR26 record was found at its publisher and verified through Korea University's
institutional record. The publisher's direct fetch returned HTTP 403; its full proof was not read.

The transcript-rebinding and policy-aggregate references were checked at Springer; MKHS at IACR;
the conference requirements at the official call. Sources and their reading scope are recorded
in sources.json. Previously supplied papers remain relevant.

This is not an exhaustive novelty search. No absence-of-results argument establishes priority.

# Update, 25 October 2026

- IDASR26 full text: further attempts (author PDF, pure.korea.ac.kr, api.openalex.org) were
  blocked from this environment. The comparison stays unresolved; the PDF has been requested.
- Searched for formal lower bounds on Schnorr half-aggregation. Found CGKN21 (ePrint 2021/350):
  its abstract offers evidence, not a theorem. No formal lower bound was found in this short
  search; that is not evidence that none exists.
- A generic composition (CEA) was built and tested; it achieves the posed commutation property.
  Entries marked K in the novelty matrix were not fetched in this session.

# Update 2, 25 October 2026 (after independent readiness review)

- Searched signed ElGamal in the AGM: FPS20 (ePrint 2019/877) located (metadata only).
- Searched aggregation / simulation extractability of Fiat–Shamir proofs: results were
  generic (simulation-extractability of multi-round Fiat–Shamir and of zkSNARKs) and none was
  read. The question of half-aggregating proofs of knowledge per class batch is unchecked.
