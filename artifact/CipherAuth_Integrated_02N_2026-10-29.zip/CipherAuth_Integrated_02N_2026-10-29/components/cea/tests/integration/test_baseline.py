import subprocess, sys, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]

class FrozenBaseline(unittest.TestCase):
    def test_original_v3_report_reproduces(self):
        p = subprocess.run([sys.executable, str(ROOT/"scripts/run_baseline.py")],
                           capture_output=True, text=True, timeout=120)
        self.assertEqual(p.returncode, 0, p.stderr)
