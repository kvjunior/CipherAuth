import json, subprocess, sys, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]

class CommutationNegativeControl(unittest.TestCase):
    def test_direct_v3_transformation_gap_is_reproduced(self):
        p = subprocess.run([sys.executable, str(ROOT/"attacks/commutation_v3.py")],
                           capture_output=True, text=True, timeout=120)
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertTrue(json.loads(p.stdout)["transformed_records_with_original_compressed_scalar_reject"])
