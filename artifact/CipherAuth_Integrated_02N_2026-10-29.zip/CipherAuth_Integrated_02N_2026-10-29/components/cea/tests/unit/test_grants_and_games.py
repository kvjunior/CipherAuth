import unittest
from dataclasses import replace
from unittest.mock import Mock
from cipherauth.registry import Registry
from cipherauth.grants import Grant, SignedGrant, verify_grant
from cipherauth.games.delegation import AuthorizationLedger
from cipherauth.games.privacy import ReplayMask, Mask
from cipherauth.errors import InvalidContext, OpenResearchProblem
from cipherauth.candidate import OpenConstruction
from cipherauth.costs import weighted_calls, independent_calls

class GrantsAndGames(unittest.TestCase):
    def setUp(self):
        self.registry = Registry()
        self.signer = self.registry.register("j", "signing", 1, "suite", b"j-signing")
        self.j = self.registry.register("j", "decryption", 1, "suite", b"j-decryption")
        self.l = self.registry.register("l", "decryption", 1, "suite", b"l-decryption")
        self.g = Grant(self.signer, self.j, self.l, (b"a", b"b"), 4, b"t"*32, b"g"*32, "suite")
        self.signed = SignedGrant(self.g, b"signature-fixture")

    def verify(self, **overrides):
        args = dict(origin=self.j, delegatee=self.l, tag=b"a", epoch=4,
                    token_digest=b"t"*32, suite="suite", verify_signature=Mock(return_value=True))
        args.update(overrides)
        return verify_grant(self.signed, self.registry, **args)

    def test_grant_policy_binding_and_signature_callback(self):
        verifier = Mock(return_value=True)
        self.assertTrue(self.verify(verify_signature=verifier))
        verifier.assert_called_once_with(b"j-signing", self.g.message(), b"signature-fixture")
        self.assertFalse(self.verify(verify_signature=Mock(return_value=False)))
        for alteration in (dict(tag=b"outside"), dict(epoch=5), dict(token_digest=b"z"*32),
                           dict(delegatee=self.j), dict(suite="different-suite")):
            self.assertFalse(self.verify(**alteration))

    def test_every_grant_field_is_in_signed_message(self):
        variants = [replace(self.g, epoch=5), replace(self.g, tags=(b"a",)),
                    replace(self.g, token_digest=b"z"*32), replace(self.g, grant_id=b"h"*32),
                    replace(self.g, delegatee=self.j)]
        self.assertTrue(all(v.message() != self.g.message() for v in variants))
        with self.assertRaises(InvalidContext):
            replace(self.g, tags=(b"b", b"a"))

    def test_cross_suite_recipient_is_rejected(self):
        other = self.registry.register("other", "decryption", 1, "different-suite", b"key")
        mixed = SignedGrant(replace(self.g, delegatee=other), b"fixture")
        self.assertFalse(verify_grant(
            mixed, self.registry, origin=self.j, delegatee=other, tag=b"a",
            epoch=4, token_digest=b"t"*32, suite="suite",
            verify_signature=Mock(return_value=True)))

    def test_authorization_is_not_sender_freshness(self):
        ledger = AuthorizationLedger()
        self.assertFalse(ledger.was_issued(self.g))
        ledger.record_issued(self.g)
        self.assertTrue(ledger.was_issued(self.g))
        self.assertFalse(ledger.was_issued(replace(self.g, epoch=5)))

    def test_redaction_covers_both_alternatives_after_verification(self):
        mask = ReplayMask((b"A",), (b"B",))
        self.assertEqual(mask.after_verification((b"A", b"B", b"C"), protected_recipient=True),
                         (Mask.TEST, Mask.TEST, b"C"))
        self.assertIsNone(mask.after_verification(None, protected_recipient=True))
        self.assertEqual(mask.after_verification((b"A",), protected_recipient=False), (b"A",))
        with self.assertRaises(ValueError):
            ReplayMask((b"A",), (b"BB",))

    def test_unresolved_construction_fails_explicitly(self):
        with self.assertRaises(OpenResearchProblem):
            OpenConstruction().delegate_aggregate(None, None, None)

    def test_count_model_boundary(self):
        self.assertEqual(weighted_calls(8, 1), 18)
        self.assertEqual(weighted_calls(8, 7), independent_calls(8))
        self.assertGreater(weighted_calls(8, 8), independent_calls(8))
