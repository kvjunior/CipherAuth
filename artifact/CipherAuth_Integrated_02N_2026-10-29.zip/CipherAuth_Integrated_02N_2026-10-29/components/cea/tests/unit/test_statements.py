import unittest
from dataclasses import replace
from cipherauth.encoding import encode, digest
from cipherauth.models import KeyRef, OriginStatement, BatchContext, EncryptedRecord, CompressedAggregate
from cipherauth.registry import Registry
from cipherauth.errors import EncodingError, KeyConflict, InvalidContext
from cipherauth.games.authenticity import FreshnessLedger

class Statements(unittest.TestCase):
    def setUp(self):
        self.r = Registry()
        self.s = self.r.register("sender", "signing", 1, "suite", b"sender-public")
        self.j = self.r.register("j", "decryption", 1, "suite", b"j-public")

    def test_encoding_separates_ambiguous_values(self):
        values = [None, False, True, 0, 1, b"1", "1", (1,), [1], {"a": 1}]
        self.assertEqual(len({encode(v) for v in values}), len(values))
        self.assertNotEqual(encode((b"ab", b"c")), encode((b"a", b"bc")))
        self.assertEqual(encode({"b": 2, "a": 1}), encode({"a": 1, "b": 2}))
        self.assertNotEqual(digest("a", b"x"), digest("b", b"x"))
        with self.assertRaises(EncodingError):
            encode(1.0)

    def test_registry_cannot_replace_existing_version(self):
        with self.assertRaises(KeyConflict):
            self.r.register("j", "decryption", 1, "suite", b"replacement")
        with self.assertRaises(KeyConflict):
            self.r.resolve(replace(self.j, fingerprint=b"x"*32))

    def test_freshness_binds_receiver_aliases_and_versions(self):
        st = OriginStatement(self.s, self.j, b"tag", 0, b"m")
        ledger = FreshnessLedger(); ledger.record_query(st)
        self.assertFalse(ledger.is_fresh(st))
        alias = self.r.register("other-id", "decryption", 1, "suite", b"j-public")
        self.assertTrue(ledger.is_fresh(replace(st, origin=alias)))
        new = self.r.register("j", "decryption", 2, "suite", b"next-key")
        self.assertTrue(ledger.is_fresh(replace(st, origin=new)))
        self.assertTrue(ledger.is_fresh(replace(st, epoch=1)))

    def test_context_and_record_shape(self):
        ctx = BatchContext("suite", "origin", self.j, self.j, 0)
        record = EncryptedRecord(self.s, self.j, b"tag", 0, b"encrypted")
        self.assertTrue(CompressedAggregate(ctx, (record,), b"auth").validate_shape())
        with self.assertRaises(InvalidContext):
            CompressedAggregate(ctx, (), b"auth").validate_shape()
        with self.assertRaises(InvalidContext):
            CompressedAggregate(ctx, (replace(record, epoch=1),), b"auth").validate_shape()
        with self.assertRaises(InvalidContext):
            BatchContext("suite", "delegated", self.j, self.j, 0)
