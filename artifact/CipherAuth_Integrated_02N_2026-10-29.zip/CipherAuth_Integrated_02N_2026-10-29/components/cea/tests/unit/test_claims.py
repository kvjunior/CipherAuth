import unittest
from pathlib import Path
from cipherauth.claims import validate_claims

class Claims(unittest.TestCase):
    def test_no_claim_is_marked_reviewed_without_human_review(self):
        root = Path(__file__).resolve().parents[2]
        data = validate_claims(root / "claims/claims.json")
        for claim in data["claims"]:
            if claim["kind"] == "security":
                self.assertIn(claim["status"], ("open", "refuted", "sketch_unreviewed"))
            if claim["kind"] == "novelty":
                self.assertIn(claim["status"], ("unverified", "comparison_pending", "defeated_by_known_composition"))
