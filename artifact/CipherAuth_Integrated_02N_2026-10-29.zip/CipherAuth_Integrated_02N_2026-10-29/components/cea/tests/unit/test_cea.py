"""Behavioural and adversarial tests for the CEA comparator. Passing tests are NOT security proofs."""
import unittest
from dataclasses import replace
from cipherauth import group as g, schnorr
from cipherauth.cea import CEA, Directory, Submission, DelegatedAggregate, SUITE, parse_body, sizes
from cipherauth.models import BatchContext
from cipherauth.games.privacy import DerivativeLedger
from cipherauth.errors import InvalidContext, EncodingError

TAG, EPOCH = b"vibration", 7


class Fixture(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.D = Directory()
        cls.S = CEA(cls.D)
        cls.senders = [cls.D.new_signing_key(f"sensor-{i}") for i in range(3)]
        cls.j_sig = cls.D.new_signing_key("plant")
        cls.jk = cls.D.new_decryption_key("plant", tag=TAG, epoch=EPOCH)
        cls.jk_other = cls.D.new_decryption_key("plant", tag=b"temperature", epoch=EPOCH)
        cls.l = cls.D.new_decryption_key("auditor")
        cls.l2 = cls.D.new_decryption_key("contractor")
        cls.msgs = [f"reading {i}: 4.{i} mm/s".encode() for i in range(5)]
        cls.subs = [cls.S.signcrypt(cls.senders[i % 3], "plant", m, TAG, EPOCH) for i, m in enumerate(cls.msgs)]
        cls.ctx = BatchContext(SUITE, "origin", cls.jk.ref, cls.jk.ref, EPOCH)
        cls.agg = cls.S.aggregate(cls.ctx, cls.subs)
        cls.token, cls.grant = cls.S.issue_grant(cls.j_sig, cls.jk, cls.l.ref, TAG, EPOCH)


class GroupAndAggregation(Fixture):
    def test_point_decoding_rejects_malformed(self):
        good = g.encode_point(g.mul(5, g.G))
        x_off = next(x for x in range(1, 100) if pow((x ** 3 - 3 * x + g.b) % g.p, (g.p - 1) // 2, g.p) == g.p - 1)
        for bad in (b"", good[:-1], b"\x04" + good[1:], b"\x02" + b"\xff" * 32, b"\x02" + x_off.to_bytes(32, "big")):
            with self.assertRaises(EncodingError):
                g.decode_point(bad)
        with self.assertRaises(EncodingError):
            g.encode_point(g.IDENTITY)
        self.assertEqual(g.decode_point(good), g.mul(5, g.G))

    def test_scalar_multiplication_matches_reference_library(self):
        try:
            from cryptography.hazmat.primitives.asymmetric import ec
        except ImportError:
            self.skipTest("cryptography not installed")
        for k in (1, 2, 3, g.q - 1, 123456789, g.random_scalar()):
            n = ec.derive_private_key(k, ec.SECP256R1()).public_key().public_numbers()
            self.assertEqual(g.mul(k, g.G), g.Point(n.x, n.y))

    def test_streamed_coefficients_equal_definition(self):
        stream, entries = schnorr.CoefficientStream(), []
        for s in self.subs:
            e = self.S._entry(s.record)
            entries.append(e)
            self.assertEqual(stream.push(*e), schnorr.coefficient_from_scratch(entries))

    def test_append_with_and_without_cached_state_agree(self):
        base = self.S.aggregate(self.ctx, self.subs[:3])
        a1, stream = self.S.append(base, self.subs[3])
        a2, _ = self.S.append(base, self.subs[3], stream=None)
        self.assertEqual(a1, a2)
        a3, _ = self.S.append(a1, self.subs[4], stream=stream)
        self.assertEqual(a3, self.agg)
        self.assertTrue(self.S.verify_public(a3))


class Commutation(Fixture):
    def test_both_orders_certify_identical_statements(self):
        left = self.S.delegate_aggregate(self.token, self.grant, self.agg)
        right = self.S.aggregate_delegated(self.grant, self.token.public_part(),
                                           [self.S.delegate_record(self.token, self.grant, s) for s in self.subs])
        L, R = self.S.open_aggregate(self.l, left), self.S.open_aggregate(self.l, right)
        self.assertIsNotNone(L)
        self.assertEqual(L, R)
        self.assertEqual([st.message for st in L], self.msgs)
        self.assertTrue(all(st.origin == self.jk.ref for st in L))      # statements still name origin j
        self.assertEqual(left.aggregate.authenticator, self.agg.authenticator)   # Theta carried unchanged
        self.assertEqual(left.aggregate.authenticator, right.aggregate.authenticator)

    def test_delegate_aggregate_needs_no_individual_scalars(self):
        stripped = replace(self.agg)                     # the public object holds no theta_i
        self.assertFalse(any(hasattr(r, "theta") for r in stripped.records))
        out = self.S.delegate_aggregate(self.token, self.grant, stripped)
        self.assertIsInstance(out, DelegatedAggregate)
        self.assertIsNotNone(self.S.open_aggregate(self.l, out))

    def test_origin_still_opens_and_delegatee_cannot_open_origin_level(self):
        self.assertEqual([s.message for s in self.S.open_aggregate(self.jk, self.agg)], self.msgs)
        self.assertIsNone(self.S.open_aggregate(self.l, self.agg))
        left = self.S.delegate_aggregate(self.token, self.grant, self.agg)
        self.assertIsNone(self.S.open_aggregate(self.jk, left))
        self.assertIsNone(self.S.open_aggregate(self.l2, left))


class Substitution(Fixture):
    def test_reordering_dropping_and_theta_changes_fail_public_verification(self):
        r = self.agg.records
        for bad in (replace(self.agg, records=(r[1], r[0]) + r[2:]),
                    replace(self.agg, records=r[:-1]),
                    replace(self.agg, authenticator=g.encode_scalar((int.from_bytes(self.agg.authenticator, "big") + 1) % g.q))):
            self.assertFalse(self.S.verify_public(bad))

    def test_sender_tag_epoch_and_origin_substitution_fail(self):
        r0 = self.agg.records[0]
        for field, value in (("sender", self.senders[1].ref if r0.sender != self.senders[1].ref else self.senders[2].ref),
                             ("tag", b"temperature"), ("epoch", EPOCH + 1), ("origin", self.jk_other.ref)):
            bad = replace(self.agg, records=(replace(r0, **{field: value}),) + self.agg.records[1:])
            self.assertFalse(self.S.verify_public(bad), field)

    def test_record_from_another_class_cannot_join_a_batch(self):
        """Regression: a validly signed record addressed to another origin class key (or epoch) must
        not verify inside this batch, at origin or delegated level."""
        foreign = self.S.signcrypt(self.senders[0], "plant", b"temp 81C", b"temperature", EPOCH)
        same_tag = replace(foreign.record, tag=TAG)        # breaks its own signature; checked below too
        self.assertFalse(self.S.verify_public(replace(self.agg, records=self.agg.records + (foreign.record,))))
        self.assertFalse(self.S.verify_public(replace(self.agg, records=self.agg.records + (same_tag,))))
        other_epoch_key = self.D.new_decryption_key("plant", tag=TAG, epoch=EPOCH + 1)
        r = self.S.signcrypt(self.senders[1], "plant", b"late", TAG, EPOCH + 1)
        self.assertEqual(r.record.origin, other_epoch_key.ref)
        single = self.S.aggregate(BatchContext(SUITE, "origin", other_epoch_key.ref, other_epoch_key.ref, EPOCH + 1), [r])
        mixed = replace(single, context=self.ctx)
        self.assertFalse(self.S.verify_public(mixed))

    def test_mauled_ciphertext_passes_public_check_but_fails_opening(self):
        Lam, c, A, E = parse_body(self.agg.records[0].body)
        flipped = bytes([E[0] ^ 1]) + E[1:]
        body = self.agg.records[0].body[:-len(E)] + flipped
        bad = replace(self.agg, records=(replace(self.agg.records[0], body=body),) + self.agg.records[1:])
        self.assertTrue(self.S.verify_public(bad))          # E is outside the signed statement
        self.assertIsNone(self.S.open_aggregate(self.jk, bad))   # the commitment catches it

    def test_rerandomised_A_passes_public_check_but_fails_opening(self):
        from cipherauth.cea import _body
        Lam, c, A, E = parse_body(self.agg.records[0].body)
        mauled = _body(Lam, c, A + g.mul(g.random_scalar(), self.D.point(self.jk.ref)), E)
        bad = replace(self.agg, records=(replace(self.agg.records[0], body=mauled),) + self.agg.records[1:])
        self.assertTrue(self.S.verify_public(bad))          # A is not signed: the proxy cannot tell
        self.assertIsNone(self.S.open_aggregate(self.jk, bad))   # c binds Hd(Q): the opener can

    def test_malformed_bodies_rejected(self):
        for body in (b"", self.agg.records[0].body[:40], b"\x05" + self.agg.records[0].body[1:]):
            bad = replace(self.agg, records=(replace(self.agg.records[0], body=body),) + self.agg.records[1:])
            self.assertFalse(self.S.verify_public(bad))
            self.assertIsNone(self.S.open_aggregate(self.jk, bad))

    def test_intake_rejects_invalid_submission(self):
        bad = Submission(self.subs[0].record, (self.subs[0].theta + 1) % g.q)
        self.assertFalse(self.S.check_submission(bad))
        with self.assertRaises(InvalidContext):
            self.S.aggregate(self.ctx, [bad])
        with self.assertRaises(InvalidContext):
            self.S.aggregate(self.ctx, [self.S.signcrypt(self.senders[0], "plant", b"x", b"temperature", EPOCH)])


class GrantsAndScope(Fixture):
    def test_proxy_refuses_wrong_grant_or_token(self):
        other_token, other_grant = self.S.issue_grant(self.j_sig, self.jk, self.l2.ref, TAG, EPOCH)
        with self.assertRaises(InvalidContext):
            self.S.delegate_aggregate(self.token, other_grant, self.agg)
        forged = replace(self.grant, signature=self.grant.signature[:-1] + bytes([self.grant.signature[-1] ^ 1]))
        with self.assertRaises(InvalidContext):
            self.S.delegate_aggregate(self.token, forged, self.agg)

    def test_grant_signed_by_someone_else_is_rejected(self):
        mallory = self.D.new_signing_key("mallory")
        with self.assertRaises(InvalidContext):
            self.S.issue_grant(mallory, self.jk, self.l.ref, TAG, EPOCH)

    def test_delegatee_rejects_tampered_token_part_or_context(self):
        left = self.S.delegate_aggregate(self.token, self.grant, self.agg)
        C, gamma, W = left.token_public
        for bad in (replace(left, token_public=(bytes([C[0] ^ 1]) + C[1:], gamma, W)),
                    replace(left, aggregate=replace(left.aggregate, context=replace(left.aggregate.context, grant_id=b"x" * 32)))):
            self.assertIsNone(self.S.open_aggregate(self.l, bad))

    def test_out_of_scope_class_is_not_delegated(self):
        other = [self.S.signcrypt(self.senders[0], "plant", b"temp 81C", b"temperature", EPOCH)]
        agg_other = self.S.aggregate(BatchContext(SUITE, "origin", self.jk_other.ref, self.jk_other.ref, EPOCH), other)
        with self.assertRaises(InvalidContext):
            self.S.delegate_aggregate(self.token, self.grant, agg_other)

    def test_coalition_recovers_only_its_class_key(self):
        """Known leak of this token shape (audit C16) is confined to the granted class key."""
        from cipherauth.encoding import encode
        C, gamma, _ = self.token.public_part()
        T = g.mul(g.inv(self.l.k), g.decode_point(gamma))
        mask = g.hash_bytes("cea/rk-mask", encode((g.encode_point(T), self.jk.ref.fields())))
        omega = int.from_bytes(bytes(a ^ b for a, b in zip(C, mask)), "big")
        k_rec = self.token.Omega * g.inv(omega) % g.q
        self.assertEqual(k_rec, self.jk.k)                  # in-class key recovery: a stated limitation
        self.assertNotEqual(k_rec, self.jk_other.k)          # other classes use independent keys


class AggregateAttacks(Fixture):
    def test_naive_cancellation_with_rogue_key_is_rejected(self):
        """Receiver-insider C9-style cancellation against IASchnorr (sanity check, not a proof)."""
        honest, rogue = self.senders[0], self.D.new_signing_key("rogue")
        X_h, X_r = self.D.point(honest.ref), self.D.point(rogue.ref)
        from cipherauth.cea import statement_bytes
        st_h = statement_bytes(honest.ref, self.jk.ref, TAG, EPOCH, b"\x00" * 32)
        lam_h = g.random_scalar(); R_h = g.mul(lam_h, g.G); c_h = schnorr.challenge(R_h, st_h)
        st_r = statement_bytes(rogue.ref, self.jk.ref, TAG, EPOCH, b"\x01" * 32)
        # a_2 depends on R_r, so choose R_r to cancel using a guessed a_2, then recompute
        guess = 1
        lam_r = g.random_scalar()
        R_r = g.mul(lam_r, g.G) - g.mul(c_h * g.inv(guess) % g.q, X_h)
        c_r = schnorr.challenge(R_r, st_r)
        s = (lam_h + guess * (lam_r + c_r * rogue.x)) % g.q
        self.assertFalse(schnorr.verify_aggregate([(R_h, X_h, st_h), (R_r, X_r, st_r)], s))

    def test_public_extension_and_derivative_ledger(self):
        """Anyone can append a valid record (public aggregation); the confidentiality game refuses
        any decryption query containing a challenge core or its re-encryption."""
        ledger = DerivativeLedger()
        core = lambda r: (r.origin, parse_body(r.body)[2], parse_body(r.body)[3])
        for r in self.agg.records:
            ledger.register(core(r))
        extra = self.S.signcrypt(self.senders[2], "plant", b"adversary's own", TAG, EPOCH)
        extended, _ = self.S.append(self.agg, extra)
        self.assertTrue(self.S.verify_public(extended))
        self.assertTrue(ledger.batch_refused([core(r) for r in extended.records]))
        delegated = self.S.delegate_aggregate(self.token, self.grant, self.agg)
        for parent, child in zip(self.agg.records, delegated.aggregate.records):
            ledger.register_derived(core(parent), core(child))
        self.assertTrue(ledger.batch_refused([core(delegated.aggregate.records[0])]))
        self.assertFalse(ledger.batch_refused([core(extra.record)]))


class Sizes(unittest.TestCase):
    def test_size_model_counts_authentication_bytes(self):
        s = sizes(32, 8, 3)
        self.assertEqual(s["auth_bytes_per_record"], 65)
        self.assertEqual(s["record_body"], 33 + 32 + 33 + 32)
        self.assertEqual(s["token_public_part"], 97)            # C, gamma and W (W was omitted before)


if __name__ == "__main__":
    unittest.main()


class Wire(Fixture):
    def test_roundtrip_origin_and_delegated(self):
        from cipherauth import wire
        left = self.S.delegate_aggregate(self.token, self.grant, self.agg)
        for obj, enc in ((self.agg, wire.encode_aggregate(self.agg)), (left, wire.encode_delegated(left))):
            back, deleg = wire.decode_aggregate(enc)
            if isinstance(obj, DelegatedAggregate):
                obj2 = DelegatedAggregate(back, *deleg)
                self.assertEqual(obj2, obj)
                self.assertEqual([s.message for s in self.S.open_aggregate(self.l, obj2)], self.msgs)
            else:
                self.assertEqual(back, obj)
                self.assertTrue(self.S.verify_public(back))

    def test_strict_decoding(self):
        from cipherauth import wire
        enc = wire.encode_aggregate(self.agg)
        for bad in (enc[:-1], enc + b"\x00", b"XXXX" + enc[4:], enc[:4] + b"\x03" + enc[5:]):
            with self.assertRaises(Exception):
                wire.decode_aggregate(bad)

    def test_inconsistent_objects_are_not_encodable(self):
        from cipherauth import wire
        from cipherauth.errors import EncodingError
        with self.assertRaises(EncodingError):
            wire.encode_aggregate(replace(self.agg, append_hint=b"x"))
        foreign = replace(self.agg.records[0], tag=b"temperature")
        with self.assertRaises(EncodingError):
            wire.encode_aggregate(replace(self.agg, records=self.agg.records + (foreign,)))


class ConfidentialityDiagnostics(Fixture):
    def test_recovered_class_key_does_not_open_another_class(self):
        """Finite functional check (reviewer suggestion); not a G-SCOPE proof."""
        from cipherauth.cea import _kdf, _opening, _commit, _xor
        from cipherauth.encoding import encode
        C, gamma, _ = self.token.public_part()
        T = g.mul(g.inv(self.l.k), g.decode_point(gamma))
        omega = int.from_bytes(_xor(C, g.hash_bytes("cea/rk-mask", encode((g.encode_point(T), self.jk.ref.fields())))), "big")
        k_rec = self.token.Omega * g.inv(omega) % g.q
        other = self.S.signcrypt(self.senders[0], "plant", b"temp 81C".ljust(32, b"\0"), b"temperature", EPOCH)
        _, c, A, E = parse_body(other.record.body)
        Q = g.mul(g.inv(k_rec), A)
        self.assertNotEqual(_commit(_xor(E, _kdf(Q, len(E))), _opening(Q)), c)

    def test_ch07_style_reencryption_oracle_is_bypassed_by_mauling(self):
        """Documents a NEGATIVE result: CEA fails a per-ciphertext (CH07-style) game; see attacks/cea_reenc_mauling.py."""
        import importlib.util, pathlib
        path = pathlib.Path(__file__).resolve().parents[2] / "attacks" / "cea_reenc_mauling.py"
        spec = importlib.util.spec_from_file_location("cea_reenc_mauling", path)
        mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        self.assertTrue(mod.run()["corrupted_delegatee_recovers_challenge_message"])
