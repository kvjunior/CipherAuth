# Tests

unit/: encoding, full statement/key binding, grant-policy validation, freshness ledger,
post-verification redaction, operation-count boundaries, and honest claim statuses.
The mocked grant signature verifier tests policy plumbing, not Schnorr security.

integration/: optional isolated v3 replay and commutation-gap reproduction.
scripts/reproduce.py runs the unit suite and each baseline/diagnostic once.

Future security-game tests must use meaningful attacks and boundary cases. Do not create
tests that equate absence of a known attack with a proof of unforgeability or privacy.
