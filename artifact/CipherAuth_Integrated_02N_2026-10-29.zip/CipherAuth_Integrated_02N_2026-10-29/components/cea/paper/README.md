# Paper organization after a theorem exists

Use a clear problem statement, exact prior-work comparison, main result, new technical idea,
definitions, construction, complete security arguments, complexity, and limitations.
Experiments support the theorem; they do not replace it.

The official STOC 2027 call asks that the main merits and ideas be clear in the initial
twelve pages after the title page, with proofs sufficient for verification. Full submissions
have no page limit. Use the current official call for exact formatting and policy details:
https://acm-stoc.org/stoc2027/stoc2027-cfp.html

The conference uses identified authors and requires disclosure of substantive generative-AI
assistance. Record that assistance accurately. A short-paper page cap from another venue
or an anonymous manuscript template does not apply automatically.

No submission-ready manuscript or unsupported main theorem is supplied here.
