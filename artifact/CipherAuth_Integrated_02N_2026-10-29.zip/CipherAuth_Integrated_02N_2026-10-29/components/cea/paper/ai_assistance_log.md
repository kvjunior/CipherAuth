# Assistance record to maintain

Claude supplied the v3 candidate, audit note, model note, and diagnostic scripts.
ChatGPT independently inspected and reran the supplied checks, identified the direct
carry-Theta compatibility gap, and created this research blueprint, infrastructure,
diagnostics, and Claude prompt.

Human authors must verify statements, own the final arguments, and accurately update the
paper's required substantive-assistance disclosure. This log is not a list of paper authors.

## 25 Oct 2026 session (Claude, Anthropic; model configured as claude-opus-5-5)

Claude, working from the user's work order and this workspace:
- implemented src/cipherauth/group.py (P-256 arithmetic with counters), schnorr.py (Schnorr
  and Chen–Zhao IASchnorr following ePrint 2022/222 Fig. 2) and cea.py (the CEA generic
  composition used as a comparator);
- wrote attacks/unbound_coefficient_v3.py (a forgery against an A-free v3 coefficient rule);
- wrote tests/unit/test_cea.py and scripts/cea_demo.py, and extended scripts/reproduce.py;
- found and fixed a binding gap in its own first CEA draft (records of another class could
  join a batch; see CHANGES.md);
- wrote spec/games.md, spec/cea_construction.md, proofs/cea_authenticity.md (unreviewed
  sketches), proofs/cea_confidentiality.md (plan, open), and the refined question in
  proofs/commutation_target.md;
- completed literature/novelty_matrix.md, partly from general knowledge (marked K) and partly
  from sources it could not fully read (marked A/X).

Substantive: the conclusion that commutation is achieved by a known composition, the proof
sketches, the attack and the refined question are AI-generated and must be checked by the
human authors before they appear in any paper. The required substantive-assistance disclosure
of the target venue must reflect this.

## 25 Oct 2026, second session (Claude)

An independent review (another AI system, supplied by the user) found five correctable issues.
Claude verified each one against the code and fixed it (CHANGES.md addendum). While checking
the G-CONF finding, Claude found and implemented the per-ciphertext mauling attack
(attacks/cea_reenc_mauling.py), wrote the wire format (src/cipherauth/wire.py), and proposed
the candidate question on aggregated proxy-checkable validity (novelty unverified). All of
this is AI-generated and requires human verification.
