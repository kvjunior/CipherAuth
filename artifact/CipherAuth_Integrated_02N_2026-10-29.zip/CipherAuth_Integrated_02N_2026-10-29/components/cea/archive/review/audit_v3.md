# ADS-PRE Construction Audit

Oct 23, 2026 · @kfgateway

## Summary

The revised ADS-PRE construction is not correct as published: honest re-encrypted ciphertexts cannot be decrypted, and several stated security properties fail under concrete attacks. All findings below were reproduced on NIST P-256 with a self-contained implementation of the algorithms as printed, under the readings of ambiguous notation listed in Method. An independent rerun on 24 October 2026 matched every result exactly.

- **Re-encryption is undefined.** Revised Algorithm 8 divides a curve point by a curve point, and the delegatee recovers H4(ω) instead of ω (C3). The round-1 version also fails unless the original D\_i is sent (C2).
- **Collusion leaks a decryption key.** Under the scalar reading of round 1, and under the repaired re-key below, the cloud and a delegatee together recover j's decryption key k\_j (C4, C16). The threat model excludes KGC–cloud collusion, for which we found no attack, but not this one. Under the manuscript's unrestricted grant, though, the same coalition can already decrypt everything sent to j by re-encrypting and decrypting locally; recovering k\_j matters for key-recovery (master-secret) security and once delegation is scoped.
- **Aggregation is weak.** A receiver can forge aggregates that attribute messages to honest devices (C9). One malicious sender can poison a batch (C8). For the unweighted construction, a CCA2 game that excludes only the exact challenge cannot hold (C10).
- **Two claims are overstated.** "Public key validation" is only a consistency check that any attacker-built key passes (C5); this alone is not a Type-I break. Leaked λ\_i or μ\_i reveals the sender's signing scalar (C6, C17), and the manuscript's narrower claim about ω and t also fails: a leaked ω plus the proxy's Ω gives k\_j (C17).
- **Costs are undercounted.** Signcryption uses 6 scalar multiplications as written, not 4. As written, aggregate unsigncryption saves 22% of multiplications at n = 8. Factored per sender, unweighted verification needs only n + u + 1 multiplications against 3n, so operation counts do not rule out the manuscript's 75.3%; that figure is unexplained and must be re-measured. The unweighted design is insecure in any case (C9).

A repaired, fully typed specification follows. It restores correctness on honest inputs but is a candidate under investigation: it still leaks k\_j to proxy–delegatee collusion, its weighted aggregation has no proof, and CCA for aggregates still needs a justified definition.

## Method

Every algorithm was typed and implemented as printed, with the readings below where the notation is ambiguous, then exercised with honest and adversarial inputs. The source is the revised manuscript (Updated-Article.pdf, Dec 2025) and its supplement, whose text is identical to the round-1 supplement; round-1 algorithms are used where the revision still relies on them.

- **Implementation.** Pure Python on NIST P-256 with no cryptographic library; H1–H5 are SHA-256 with domain separation; messages are 256-bit strings, as E\_i = m\_i ⊕ H3(·) forces. Every scalar multiplication and hash call is counted.
- **Files.** ec.py (curve and counters), adspre.py (algorithms, with manuscript line references), checks.py (C1–C15), followup\_checks.py (C16–C23), results.json (outputs).
- **Readings of ambiguous notation.** "D/k" for a scalar k is read as k⁻¹·D. The round-1 ω ∈ {0,1}^κ is read as an integer mod q, the only reading under which ω times a scalar is defined. The revised "H4(ω)" is modelled as a hash of ω to 256 bits, since H4's declared domain does not accept a single scalar. Algorithm 10's "Θ\_i" is read as θ\_i, and Algorithm 11's aggregate check is placed after the loop.

Tests can confirm a correctness failure or an attack; passing tests never establish security.

## Defect register

Twenty-six defects remain in the revised manuscript: five break correctness, eight break or overstate a security claim, and the rest are model, proof or presentation errors. Rows are ordered by effect; "C" numbers refer to the executable checks in the next section.

| # | Where | Defect | Effect | Evidence | Resolution |
| --- | --- | --- | --- | --- | --- |
| D1 | Alg 6 l.6, Alg 8 l.6 | Ω\_j is a point, so D̄\_i = D\_i/Ω\_j divides a point by a point | Breaks correctness | C3 | Ω\_j = ω\_j·k\_j mod q (scalar) |
| D2 | Alg 6 l.7–10, Alg 9 l.9 | C\_j masks H4(ω\_j); the delegatee recovers H4(ω\_j), not ω\_j | Breaks correctness | C3 | Mask ω\_j itself |
| D3 | Alg 8 l.7, Alg 9 l.11, Alg 12 | h\_i hashes the original D\_i, which the second-level ciphertext does not carry | Breaks correctness | C2 | Send D\_i, or drop D\_i from H4 and re-prove |
| D4 | Alg 10 l.9, 12, 16 | Θ adds Θ\_i (typo for θ\_i); Σ keeps invalid elements while Θ omits them | Any batch with one invalid element is rejected whole | C7 | Keep only validated elements |
| D5 | Alg 9 l.11 vs §V-E | Second-level ciphertext is (D̄, E, θ, C, γ) in §V-E but (D̄, E, Δ, f, θ, C, γ) in Alg 8 | Format undefined | Read | One format |
| D6 | §IV-B, Table I, Eq. 3 | Excludes KGC–cloud collusion; cloud–delegatee collusion recovers k\_j | Confidentiality claim fails | C4 | State targets; redesign or bound scope |
| D7 | §VI-D, Table II | Aggregate non-repudiation; a receiver can forge aggregates | Authenticity claim fails | C9 | Weighted aggregation + proof |
| D8 | Alg 10, §III-B | Cloud check covers f only; a bad θ passes and poisons the batch, culprit not identifiable | Availability claim fails | C8 | Per-element fallback |
| D9 | §IV-C Games 1–2 | Phase 2 bans aggregate-unsigncryption queries for j, so aggregate decryption is not adaptive; relaxing it to exact-challenge exclusion is broken by extension | IND-CCA2 claim ill-posed | C10 | Derivative-based restriction |
| D10 | Alg 5 l.1, Table II | "Public key validation" accepts any key whose V' is computed from R', P'; a consistency check, not by itself a Type-I break | Overclaim | C5 | Call it a well-formedness check |
| D11 | §VI-E.3, §II | Leakage resistance claimed for ω, t; leaked ω plus the proxy's Ω gives k\_j (C17); leaked λ\_i or μ\_i gives x\_i (C6) | False claim | C6 | Remove; drop ESL criticism of \[18\], \[24\] |
| D12 | §VI-E.1 | Forward secrecy claimed; SK\_j decrypts every past ciphertext (§VI-E.2 says so) | False claim | Read | Remove |
| D13 | §VI-E.4 | Replay resistance claimed; no nonce or timestamp; (C, Ω, γ) called ciphertext components | False claim | Read | Add freshness or remove |
| D14 | §VI-D, Table V | "O(1)" verification; Table V counts | Overclaim | C11 | Report counted operations |
| D15 | Table IV vs Fig. 3, §VIII | 2.41 ms vs 38 ms per signcryption; 54% vs 75.3% saving; new "45%" | Inconsistent numbers | Read | Re-measure |
| D16 | Supplement | Unchanged from round 1; old RKG; simulator cannot compute D\* = ab\_i·K\_j | Proof invalid | Read | Rewrite proofs |
| D17 | Main text Eq. 12, 15 | Extraction formulas wrong; forks use different keys | Proof invalid | Read | Corrected formulas (model section) |
| D18 | §III-C, §IV-B, §VI | ECCDH, ECDDH, CDH and DBDH all named; DBDH needs pairings | Model error | Read | One assumption |
| D19 | Definition 3 | Logic inverted ("secure if an adversary wins") | Model error | Read | Negate |
| D20 | Games 1–2, Guess | Guess is Σ′ or σ′ rather than a bit | Model error | Read | Bit guess |
| D21 | Games 1–4 | Sender keys forbidden: outsider security only | Weaker than standard | Read | Insider security |
| D22 | §III-A item 3 | Re-keys "from the data owner"; RKG needs SK\_j | Model inconsistency | Read | Delegator is j only |
| D23 | Alg 11 l.3–5, Phase 6 | Check inside loop; Dec1 cited as Alg 8; second-level step cites Alg 6 | Presentation | Read | Fix references |
| D24 | Alg 5, Setup | E = m ⊕ H3 limits messages to 256 bits | Design limit | Read | KEM-DEM |
| D25 | §IV-B Eq. 1 | External adversary goal written m′ ≠ m | Presentation | Read | m′ = m |
| D26 | §IV-A, Game 4 | "G1" in RKG text; Game 4 titled "Type-I adversary F\_II" | Presentation | Read | Fix |

## Executable results

All 23 checks (C1–C23) confirmed the claimed behaviour. C16–C20 reproduce and extend the independent review of 24 October 2026; that rerun matched results.json exactly. Checks show behaviour, never security.

| Check | What it tests | Outcome |
| --- | --- | --- |
| C1 | Signcryption, cloud check, Unsigncryption1 on honest inputs | Correct |
| C2 | Round-1 re-encryption as written | Delegatee rejects honest ciphertexts; accepts once D\_i is added |
| C3 | Revised re-encryption (Alg 6, 8, 9) | Point/point division undefined; delegatee recovers H4(ω) ≠ ω and rejects |
| C4 | Cloud (Ω) + delegatee (ω) collusion, round-1 scalar reading | k\_j recovered exactly; a fresh ciphertext to j that was never re-encrypted is read; x\_j not revealed in this attack |
| C5 | Replacement key built from random R′, P′ | Passes "public key validation"; sender encrypts to it; j can no longer decrypt |
| C6 | One leaked λ\_i | x\_i = (θ\_i − λ\_i)·h\_i⁻¹ recovered; forged ciphertexts pass cloud and receiver checks |
| C7 | Alg 10 with one invalid ciphertext | Whole aggregate rejected; filtering by the cloud check recovers both valid messages |
| C8 | Sender signs a valid f over a bad θ | Cloud accepts; aggregate rejected; only per-element checks find the sender (filtering does not fix this) |
| C9 | Receiver with k\_j and one registered sender key | Forged aggregate verifies and attributes "shutdown line 3" to an honest device; no honest individual ciphertext is forged |
| C9b | Same attack on batch-weighted aggregation | Rejected; honest first-level batch accepted (one sanity test, not a proof) |
| C10 | Unweighted challenge aggregate extended with the adversary's own ciphertext | A different aggregate; its decryption returns both challenge messages |
| C12 | Operation counts with caching, and unfactored weighted check | 3 / 3 / 3 multiplications; weighted check 33 vs 32 individual at n = 8 |
| C13 | KGC joins the C4 collusion | Φ\_j and the signing scalar x\_j recovered |
| C14 | Forking extraction algebra, corrected vs manuscript Eq. 12 and 15 | Corrected identities recover the secret; manuscript's do not (algebra only, not a reduction) |
| C15 | Repaired re-key generation, D\_i shipped, single ciphertexts | Delegatee decrypts and verifies all three test ciphertexts |
| C16 | Proxy + delegatee against the repaired re-key | k\_j recovered: the repair does not fix collusion |
| C17 | Leaked μ\_i; leaked ω with the proxy's Ω | Signing scalar recovered; k\_j recovered |
| C18 | Weighted check factored per sender, n = 8 | 2n + u + 1 vs 3n: 18, 19, 21, 25 vs 24 for u = 1, 2, 4, 8 distinct senders |
| C19 | Bytes hashed for the weights | Per-coefficient hashing quadratic (82,112 bytes at n = 32); manifest hashing linear (4,943) |
| C20 | Appending to a batch-weighted aggregate | Adding one term fails; re-aggregating from individual θ\_i works |
| C21 | Prefix weights (Chen–Zhao style) over ciphertext records | Appending to a compressed aggregate works and equals direct aggregation; this code recomputes the chain on append |
| C22 | C9-style cancellation against prefix weights | Rejected in both record orders (sanity only) |
| C23 | Prefix-weighted challenge aggregate extended publicly | Decrypts to the challenge messages, so an RCCA-style notion is needed |

The manuscript's Table V undercounts every algorithm, even when every reusable value is cached.

| Algorithm | Table V | Counted, as written | Counted, best case with caching |
| --- | --- | --- | --- |
| Signcryption | 4 Mp + 3 H | 6 Mp + 6 H | 3 Mp |
| Unsigncryption1 | 2 Mp + 2 H | 4 Mp + 4 H | 3 Mp |
| Re-encryption | 2 Mp | 4 Mp | 3 Mp |
| Aggregation (n ciphertexts) | 1 Mp | 3n Mp | 2n Mp |
| Aggregate unsigncryption (n) | — | 3n + 1 Mp | 2n + 1 Mp |

As written, aggregate unsigncryption saves 22% of scalar multiplications at n = 8. The saving depends on accounting: factored per sender, unweighted verification needs only n + u + 1 multiplications against 3n, so the 75.3% (text) and 54% (Table IV) figures are not ruled out by counts, only unexplained. Counts are not run times. Re-key generation costs 5 Mp and Unsigncryption2 costs 5 Mp. Mp = scalar multiplication, H = hash call; "caching" reuses each counterpart's X\_i, K\_j and ψ·P\_pub across messages.

## Consistent specification

The repaired scheme changes four things: Ω\_j becomes a scalar, ω\_j is masked directly, second-level ciphertexts carry D\_i, and aggregation keeps only valid elements with batch-bound weights. Everything else is the published scheme with explicit types. Checks C1, C9b and C15 confirm it is correct on honest inputs; they test correctness only, and second-level aggregation is not yet implemented. It is a candidate under investigation, not a validated construction.

**Types.** G is the P-256 group of prime order q with generator P; scalars lie in Z\_q\*; κ = 256; k⁻¹·Q denotes the scalar inverse of k mod q times the point Q, replacing the manuscript's "Q/k". ⟨ω⟩ is the 32-byte encoding of ω < q, so decoding is exact.

**Hash functions.** H1: {0,1}\* × G² → Z\_q\*; H2: {0,1}\* × G → Z\_q\*; H3: {0,1}\* × G → {0,1}^κ; H4: (m, ID, E, D, Λ, R, P) → Z\_q\*; H5: (D, E, Δ, θ) → Z\_q\*; new H6: (i, (ID\_k, D\_k, E\_k) for every k in the batch) → Z\_q\*.

**Keys.** Unchanged generation. Each user has a signing key x\_i = Φ\_i + d\_i with X\_i = P\_i + R\_i + ψ\_i·P\_pub, and a decryption key k\_i = d\_i + H2(ID\_i, P\_pub)·Φ\_i with K\_i = R\_i + ψ\_i·P\_pub + H2(ID\_i, P\_pub)·P\_i. V\_i is dropped from the public key because it always equals R\_i + ψ\_i·P\_pub. Full-key generation keeps d\_i·P = R\_i + ψ\_i·P\_pub, the only meaningful validation: it checks the KGC's partial key.

1. **Signcryption** (sender i to receiver j). Unchanged: Λ = λP, Δ = μP, D = λ·K\_j, E = m ⊕ H3(ID\_i, Λ), h = H4(m, ID\_i, E, D, Λ, R\_i, P\_i), θ = λ + h·x\_i, Ψ = H5(D, E, Δ, θ), f = μ + Ψ·x\_i. Output σ = (D, E, Δ, f, θ) ∈ G × {0,1}^κ × G × Z\_q × Z\_q.
2. **Cloud check.** Accept iff f·P = Δ + Ψ·X\_i.
3. **Unsigncryption1.** Λ = k\_j⁻¹·D, m = E ⊕ H3(ID\_i, Λ), h as above; accept iff θ·P = Λ + h·X\_i.
4. **Re-key generation** (j to ℓ). ω, t ← Z\_q\*; T = tP; C = ⟨ω⟩ ⊕ H3(ID\_j, T); Ω = ω·k\_j mod q; γ = t·K\_ℓ. Output RK = (C, Ω, γ) ∈ {0,1}^κ × Z\_q\* × G.
5. **Re-encryption.** Run the cloud check, then D̄ = Ω⁻¹·D = ω⁻¹·Λ. Output σ′ = (D, D̄, E, θ, C, γ).
6. **Unsigncryption2.** T = k\_ℓ⁻¹·γ; ω = C ⊕ H3(ID\_j, T) read as an integer; Λ = ω·D̄; m = E ⊕ H3(ID\_i, Λ); h = H4(m, ID\_i, E, D, Λ, R\_i, P\_i); accept iff θ·P = Λ + h·X\_i.
7. **Aggregation.** Run the cloud check on each element and keep the valid set S; report the rest separately. Hash the batch manifest once, δ = H6′((ID\_k, D\_k, E\_k) for k ∈ S), then set z\_i = H6(δ, i) and Θ = Σ z\_i·θ\_i. What the manifest must bind (public keys, recipient, delegation context, order) is a model decision still open. Output Σ = ((ID\_i, D\_i, E\_i) for i ∈ S, Θ). Second-level batches add one (C, γ) and carry D̄\_i beside D\_i.
8. **Aggregate unsigncryption.** Decrypt every element, then check once, after the loop:

```latex
\Theta \cdot P \;=\; \sum_{i \in S} z_i\,\bigl(\Lambda_i + h_i X_i\bigr)
```

On rejection, fetch the stored θ\_i from the cloud and run Unsigncryption1 per element; f binds θ, so the sender of a poisoned element is identifiable (C8). This assumes the cloud retains and returns the θ\_i, an availability assumption the model must state. Because each z\_i depends on the whole batch, a compressed aggregate cannot be extended by adding one term; re-aggregation needs the individual θ\_i (C20). The original public incremental aggregation is therefore lost, and C10's extension attack does not transfer unchanged.

**Cost of the repair.** Sending D\_i adds 33 bytes per second-level ciphertext; dropping D\_i from H4 avoids this but changes the proof. Factoring the weighted check per sender costs 2n + u + 1 scalar multiplications for u distinct senders, against 3n for cached individual checks: 18 vs 24 when eight records share one sender, 25 vs 24 when all eight senders differ (C18). Crowdsourced batches sit near the second case. Hashing the manifest once keeps the weights linear in n (C19). Aggregation also saves (n − 1) scalars of 32 bytes in transit. These are operation counts, not run times.

**Not fixed by this specification.** Cloud–delegatee collusion (C4), ephemeral leakage (C6), forward secrecy and replay. These are model decisions, covered next.

## Security model corrections

The model needs five changes before any proof can be written: a CCA notion that tolerates aggregation, an aggregate forgery game with insider receivers, named collusion targets, one hardness assumption, and an honest list of non-goals.

**1. CCA security for aggregates.** In the unweighted construction, anyone can extend a valid aggregate with their own valid ciphertext and obtain a different aggregate that decrypts to the challenge messages (C10). So a CCA2 game that excludes only the exact challenge cannot hold for it; this does not rule out PRE-CCA, RCCA or generalized CCA notions. The manuscript's Phase 2 instead forbids aggregate-unsigncryption queries for j, which removes adaptive aggregate decryption for that receiver. A candidate fix, still to be justified, is a decryption-respecting restriction: refuse decryption of any aggregate, or re-encryption of one, that shares a component (D\_i\*, E\_i\*) with the challenge. That rule is syntactic and over-excludes: an invalid batch containing a challenge record releases nothing yet would be refused. This follows the "derivatives" of Canetti–Hohenberger and the gCCA2 relation of An–Dodis–Rabin. The games should also give the adversary the senders' keys (insider security); the current games forbid them.

**2. Aggregate unforgeability against insiders.** Games 3 and 4 only consider single ciphertexts. Add an aggregate chosen-key game in the style of Boneh–Gentry–Lynn–Shacham, where the adversary may be the receiver, knows k\_j, registers its own sender keys, and wins if an aggregate verifies while attributing to an honest sender a message that sender never signcrypted. The naive sum loses this game (C9). Batch-bound weights z\_i resist the naive attack (C9b) and resemble non-interactive Schnorr half-aggregation (Chalkias–Garillot–Kondi–Nikolaenko, CT-RSA 2021, not yet verified; Chen–Zhao, ESORICS 2022, ePrint 2022/222, which also treats incremental aggregation), but here Λ\_i is hidden inside D\_i, so a proof is still required.

**3. Collusion targets.** A proxy and a delegatee who collude can always read every ciphertext the proxy can re-encrypt; that is inherent to proxy re-encryption. Under an unrestricted grant they can also run Dec(sk\_ℓ, ReEnc(rk, c)) themselves on any ciphertext to j, so reading such ciphertexts, keeping access after the server copy of the re-key is deleted, and forwarding plaintexts are not extra harms of recovering k\_j. What k\_j recovery (C4, C16) adds:

- it breaks key-recovery (master-secret) security for the decryption scalar, a precise game in its own right;
- once delegation is scoped, it would decrypt ciphertexts outside the grant, so scoped delegation must not be built on this re-key;
- revocation cannot rely on deleting the re-key; it needs epoch or key updates.

The signing scalar x\_j is not revealed by this attack (C4); that is a test result, not a proof that x\_j stays secret. If the KGC joins, it knows d\_j, so Φ\_j = (k\_j − d\_j)·H2⁻¹ and x\_j follow: the full private key falls (C13). We found no attack from KGC–cloud collusion alone, the case the manuscript excludes. Options: state these targets and prove the signing key stays safe; adopt split delegation keys as in pairing-free unidirectional PRE (Chow–Weng–Yang–Deng, AFRICACRYPT 2010, under a relaxed CCA definition that must be compared first) to protect a non-delegatable ciphertext class; or scope delegation by condition as in Chen–Fan–Tseng.

**4. One assumption, and proofs the simulator can run.** Decryption computes Λ = k⁻¹·D from K = kP and D. Breaking it is the divisible Diffie–Hellman problem (given aP and bP, compute (b/a)P), which is equivalent to CDH (Bao–Deng–Zhu, ICICS 2003, DOI 10.1007/978-3-540-39927-8\_28; the equivalence does not by itself supply the simulator, oracle programming or forking argument). The supplement instead sets λ\* = ab\_i and needs D\* = ab\_i·K\_j, which the simulator cannot compute. Embed a into k\_j and set D\* = bP. Programming H4 at the unknown Λ\* will probably need a gap (decisional) oracle. For unforgeability, both forks share one key, so the correct extractions are as follows; C14 checks the algebra numerically against the manuscript's versions, though obtaining two suitably related forks is a separate proof obligation:

```latex
\text{Type I } (x_i = \Phi_i + a\,d_i):\quad a = \Bigl(\tfrac{f^{*} - f}{\Psi^{*} - \Psi} - \Phi_i\Bigr)\, d_i^{-1}
```

```latex
\text{Type II } (x_i = a(\Phi_i + d_i)):\quad a = \frac{f^{*} - f}{(\Psi^{*} - \Psi)(\Phi_i + d_i)}
```

**5. Non-goals stated plainly.** Forward secrecy is impossible here: SK\_j decrypts every past ciphertext. Ephemeral leakage of λ\_i or μ\_i reveals x\_i (C6). Replay needs a timestamp or counter inside H4 and H5. Also align terminology: Libert–Vergnaud-style papers, including Chen–Fan–Tseng, call re-encrypted ciphertexts "first level", the opposite of ADS-PRE.

## Literature comparison

None of the seven papers combines aggregation, re-encryption and authentication. Together, though, they supply every definition ADS-PRE is missing and a generic route to each of its functions.

| Paper | Model and corruptions | Assumptions | Delegation scope | Authentication | What it means for ADS-PRE |
| --- | --- | --- | --- | --- | --- |
| [An–Dodis–Rabin, EUROCRYPT 2002](https://eprint.iacr.org/2002/046) | Signcryption, two- and multi-user; insider vs outsider; IND-gCCA2 + UF-CMA | Generic: any IND-gCCA2 encryption + UF-CMA signature | None | Sender signature; non-repudiation only for sign-then-encrypt | θ plays the inner sign-then-encrypt signature. Multi-user security needs sender ID inside the encryption and receiver ID inside the signature; gCCA2 is the template for aggregate CCA |
| [Canetti–Hohenberger, CCS 2007](https://eprint.iacr.org/2007/171) | PRE-CCA game with "derivatives"; static corruption; registered keys; two UC formulations | DBDH; standard model; bidirectional, multi-hop | Every ciphertext under the key | None | Derivatives fix the challenge-query restriction (C10). Listed pairing-free unidirectional CCA PRE as open in 2007 |
| [Boneh–Gentry–Lynn–Shacham, EUROCRYPT 2003](https://eprint.iacr.org/2002/175) | Aggregate chosen-key model; rogue-key attack; distinct messages | co-CDH in bilinear groups; random oracle | Not applicable | n signatures in one group element | The aggregate forgery game ADS-PRE lacks; C9 is a cancellation attack of the rogue-key family |
| [Bauer–Fuchsbauer, SCN 2020](https://eprint.iacr.org/2020/524) | Signatures on randomizable ciphertexts; strengthened unforgeability | Generic group model; pairings; 4 group elements | Randomization only, same key | Signature adapts as the ciphertext is re-randomized | Shows authentication can survive a permitted transformation; key-switching re-encryption is not covered |
| [Chase–Kohlweiss–Lysyanskaya–Meiklejohn, CSF 2014](https://www.microsoft.com/en-us/research/publication/malleable-signatures-new-definitions-and-delegatable-anonymous-credentials/) | Malleable signatures for an allowed transformation class; simulation unforgeability, context hiding | Generic from controlled-malleable NIZK | Any expressible class | Signature on the derived message | Treating re-encryption as an allowed transformation gives public verifiability after re-encryption, at the cost of NIZKs |
| [Döttling–Nishimaki, PKC 2021](https://eprint.iacr.org/2018/840) | Universal PRE across arbitrary encryption schemes; HRA and CRA security | Probabilistic iO, or garbled circuits | Every ciphertext; multi- or constant-hop | None | Honest-re-encryption-attack security (after Cohen 2019) is the right baseline beyond CPA; CRA models a delegator corrupted after re-encryption |
| [Chen–Fan–Tseng, arXiv 2024](https://arxiv.org/abs/2410.08120) | Key-aggregate conditional PRE; Libert–Vergnaud-style IND-1/2PRE-CCA, adaptive | 3-wDBDHI; standard model; pairings | Per condition, fine-grained | None | Aggregates delegation keys, not authentication. Notes that proxy + delegatee convert everything, which motivates scoped delegation |

Five of the papers rely on pairings, NIZKs or the generic group model. The other two are generic but carry no authentication through delegation: An–Dodis–Rabin has no delegation, and Döttling–Nishimaki's garbled-circuit route is far heavier than ECC.

## Generic baseline and the research question

Every function ADS-PRE offers has a plausible generic route through known primitives, so a new result cannot be "these properties together". It has to be a better cost under a precise model, a new characterization, or a proved limitation. Compact multi-user authentication alone is already achieved under standard assumptions by fully-succinct multi-key homomorphic signatures (\[Anthoine–Balbás–Fiore, CRYPTO 2024\](https://eprint.iacr.org/2024/895)), so it cannot carry the novelty claim.

The baseline, built only from the papers above:

1. **Sender.** c = PRE.Enc(pk\_j, (m, ID\_i, s\_in)) with s\_in = Sig\_i(m, ID\_j): multi-user sign-then-encrypt (An–Dodis–Rabin) inside a unidirectional CCA-secure PRE.
2. **Public tag.** s\_out = Sig\_i(c, ID\_j), so the cloud can reject invalid submissions without decrypting; this is ADS-PRE's f.
3. **Aggregation.** Aggregate the s\_out tags into one group element (Boneh–Gentry–Lynn–Shacham). The inner s\_in are encrypted, so they are verified, and can be batch-verified, after decryption.
4. **Delegation.** The cloud re-encrypts c for ℓ, who decrypts and checks s\_in. Origin authentication survives re-encryption by construction.
5. **Public verifiability after re-encryption.** The cloud attaches a NIZK that it re-encrypted correctly, or uses malleable signatures with re-encryption as the allowed transformation (Chase–Kohlweiss–Lysyanskaya–Meiklejohn).

The baseline costs pairings for aggregation and NIZKs for step 5. ADS-PRE avoids both but currently has no valid proofs. One modelling question surfaces immediately: s\_in names j as the recipient, so after delegation ℓ holds a signature addressed to j. The model must say what authentication then establishes, for example "i authored m for j, and j delegated".

The baseline is a comparator, not a theorem: step 5 needs a precise NIZK relation, witness and authorization binding, and aggregating outer tags must be reconciled with verifying encrypted inner tags. Three candidate directions remain; whether any reaches STOC's bar depends on a new technical idea not yet identified:

- **(a) Definitions and an impossibility.** Public aggregation rules out IND-CCA2 (C10). Characterize the strongest achievable notion, for instance aggregate-gCCA with respect to sharing a component, and achieve it. It sits close to RCCA, HCCA and the PRE derivative notion, so the observation alone is not a substantial result.
- **(b) Pairing-free, NIZK-free efficiency.** Aggregate signcryption with re-encryption that is insider-unforgeable for aggregates (C9), with a tight proof. On its own this is an efficiency improvement over the baseline.
- **(c) Scoped collusion resistance.** Pairing-free delegation that protects messages outside the grant against proxy–delegatee collusion (C4).

## Next steps

The first decision is which paper this becomes; every later step depends on it.

1. **Choose the target:** STOC, as decided; the next deliverable is a research note with the formal model, a baseline matrix and one candidate theorem marked UNPROVEN.
2. **Freeze the specification:** adopt the repaired algorithms and decide whether to send D\_i or drop it from H4.
3. **Choose the collusion target:** signing key only, or messages outside the grant, which needs split or scoped delegation keys.
4. **Write the model before any proof:** aggregate CCA with derivatives, insider aggregate unforgeability, collusion targets, insider sender keys.
5. **Rewrite the proofs:** confidentiality from divisible CDH (with a gap oracle if needed), unforgeability from ECDL with the corrected extraction, and a proof for the weighted aggregate.
6. **Re-measure costs** from the counted operations, then benchmark on constrained hardware with enough repetitions.
7. **Verify the citations marked "from memory"** and read Libert–Vergnaud (PKC 2008), Cohen's HRA paper (PKC 2019), the Schnorr half-aggregation papers, and Ohata et al. on verifiable re-encryption (CT-RSA 2015).
