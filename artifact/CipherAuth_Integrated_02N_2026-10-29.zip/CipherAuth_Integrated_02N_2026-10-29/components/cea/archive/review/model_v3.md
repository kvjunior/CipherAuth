# Delegable Aggregate Signcryption: Model and Candidate Theorem

Oct 24, 2026 · @kfgateway

## Status

No security theorem is established in this note. It contains definitions, a candidate construction (v3), three short lemmas with complete proofs whose scope is stated exactly (Lemmas A–C), and listed proof obligations; everything else is marked conjecture or UNPROVEN.

- **Behavioural evidence:** checks C1–C23 on the audited scheme and V1–V12 on candidate v3. Two independent reruns matched the audit results exactly. Tests show behaviour, never security.
- **Corrected after independent review (24 October 2026):** prefix weighting is credited to Chen–Zhao; G2–G4 are redefined; G3's impossible "no offline capability" goal is removed; Q1 is narrowed; the candidate now uses a decoupled representation.
- **Target:** STOC 2027, as you decided (papers due 2 November 2026 AoE, with complete proofs). Readiness is judged from what is proved; no contribution of the required kind is established yet.

## Design space

Prefix-dependent coefficients for incremental Schnorr half-aggregation are published and are not a contribution here. In Chen–Zhao ([ePrint 2022/222](https://eprint.iacr.org/2022/222)), Section 4, scheme IASchnorr (Figure 2), each coefficient is a\_i = H2(L\_i) with L\_i = ((R\_1, X\_1, m\_1), …, (R\_i, X\_i, m\_i)). Theorem 2 (p. 15) reduces chosen-key aggregate unforgeability tightly to Schnorr EUF-CMA in the algebraic group model plus random oracle (AGM+ROM). What changes in signcryption is that the commitments R\_i are encrypted, so a public aggregator can hash only ciphertext data.

| Aggregation | Coefficients | Append to a compressed aggregate | Receiver forgery (C9 family) | Extension of a challenge | Verification multiplications, cached |
| --- | --- | --- | --- | --- | --- |
| Unweighted (manuscript) | None | Yes | Succeeds (C9) | Decrypts to the challenge (C10) | n + u + 1 |
| Batch-weighted (analogue of Chalkias et al., Chen–Zhao Theorem 1) | From the whole batch | No; re-aggregate from the θ\_i (C20) | Naive attack rejected (C9b) | Not by appending | 2n + u + 1 (C18) |
| Prefix-weighted (analogue of IASchnorr, over ciphertext records) | From records 1..i | Yes; 2 hash calls per append with cached chain state (V5) | Naive attack rejected (C22, V10) | Decrypts to the challenge (C23) | 2n + u + 1 (V12) |

Individual checks cost 3n under the same caching, so weighting uses strictly fewer multiplications only when u < n − 1; u = n − 1 ties. Counts are not run times. Two consequences shape the model:

- Public append makes aggregates malleable (C23), and in v3 even single ciphertexts are re-randomizable (V9). Confidentiality must therefore be replayable-CCA in spirit.
- Rejecting a naive attack says nothing about ROS- or Wagner-style attacks over many records. For public commitments, Chen–Zhao's AGM proof is what excludes them.

## Syntax

The model is stated in the public-key setting with identity registration but no assumed secret-key extraction; Lemma C needs none. Certificateless keys are an extension to add only if a theorem needs them, with Type I and Type II adversaries layered on top.

A scheme consists of the following algorithms. Tags τ come from a tag space 𝒯 (epochs, labels or counters) and a scope S is a subset of 𝒯.

1. **Setup**(1^λ) → pp; **KeyGen**(pp) → (pk, sk); registration binds an identity to pk with a proof of knowledge of sk.
2. **Signcrypt**(sk\_i, pk\_r, m, τ) → c, a ciphertext from sender i to recipient r.
3. **Check**(pk\_i, pk\_r, c) → 0 or 1, the public submission check run by the cloud.
4. **ReKeyGen**(sk\_j, pk\_ℓ, S) → rk, authorizing re-encryption from j to ℓ of ciphertexts whose tag lies in S. S = 𝒯 is unrestricted delegation, the manuscript's case.
5. **ReEnc**(rk, pk\_i, c) → c′ or ⊥; it rejects when Check fails or τ ∉ S. Single-hop and unidirectional.
6. **Agg**(pk\_r, ((pk\_i, c\_i)) for i = 1..n) → Σ, keyless and public. Where supported, **Append**(Σ, (pk\_i, c\_i)) → Σ′ extends a compressed aggregate; merging two aggregates is a separate operation, not assumed. An aggregate carries its context (level, recipient, original recipient, re-key group) and, for Append, a cached chain value.
7. **Dec**(sk\_r, pk\_i, c) → (m, τ) or ⊥, and **ADec**(sk\_r, (pk\_i), Σ) → ((m\_i, τ\_i)) for every i, or ⊥.

**Blame**(sk\_r, Σ, evidence) → a set of parties drawn from the senders and the aggregator. Evidence is the ordered list of submitted ciphertexts, each with its sender-signed outer tag, that the aggregator claims to have aggregated into Σ.

**What authentication certifies.** Acceptance by recipient r of a first-level ciphertext certifies the statement Stmt(i, m, r, τ): "i authored m for recipient r under tag τ". Acceptance by ℓ of a re-encrypted ciphertext certifies Stmt(i, m, j, τ) together with τ ∈ S. The delegatee therefore learns the original recipient j; the sender never authored anything "for ℓ". Verification uses the recipient's secret key and is not transferable by default. Third-party non-repudiation requires the recipient to reveal evidence (for ADS-PRE, Λ\_i), as in An–Dodis–Rabin's insider setting.

**Cost parameters.** n records, u distinct senders, message length |m|. Authentication size, metadata, verification work and preprocessing are reported separately, never as one "O(1)" figure.

## Security games

Four games, corrected after review. G1 is unchanged in substance. G2 now masks both challenge alternatives and fixes every oracle rule. G3 separates key recovery from scope. G4 attributes faults to the aggregator as well as to senders. Corruption is static throughout.

**G1. Aggregate insider unforgeability (AIUF).** The challenger creates one honest sender key pk\*. The adversary registers every other key, recipients included, and may act as the cloud.

- Oracle: Signcrypt(sk\*, pk\_r, m, τ) for any registered pk\_r; each query (m, ID\_r, pk\_r, τ) is recorded in Q.
- Output: a recipient key pair (pk\_r, sk\_r), a sender list (pk\_1, …, pk\_n) with pk\_k = pk\* for some k, and an aggregate Σ. At second level, the delegatee's (pk\_ℓ, sk\_ℓ), the re-key components (C, γ) and the original recipient j. Revealing the opening key models a malicious recipient, as in An–Dodis–Rabin's insider notion; no extraction is assumed.
- Win: the aggregate verifies and its k-th record certifies a statement (m\_k, original recipient, τ\_k) not in Q.

n = 1 is individual insider unforgeability. The unweighted design loses G1 (C9).

**G2. Aggregate replayable-CCA confidentiality (A-RCCA).** The starting point is IND-RCCA ([Canetti–Krawczyk–Nielsen, ePrint 2003/174](https://eprint.iacr.org/2003/174)), adapted to vectors and recipient change; the adaptation is not yet checked against their exact definition.

1. **Corruption.** The adversary names corrupted users; the challenger generates every key and hands over the corrupted secrets.
2. **Delegation set.** Del\* is j\* plus every honest user reachable from j\* through queried re-keys whose scope contains τ\*. In every phase, no re-key may be issued from a member of Del\* to a corrupted user with a scope containing τ\*.
3. **Challenge, once.** The adversary names an honest j\*, a tag τ\*, senders s\_1..s\_n (honest or corrupted, giving insider security) and two vectors M\_0, M\_1 of n messages each. The challenger returns Σ\*, the aggregate of Signcrypt(sk\_{s\_i}, pk\_{j\*}, M\_b\[i\], τ\*). Let 𝓜\* be the set of all entries of both M\_0 and M\_1.
4. **Decryption oracles** Dec and ADec for honest recipients. ADec is all-or-nothing: a failed aggregate check returns ⊥ for the whole batch. After the challenge, for recipients in Del\*, every returned position whose plaintext lies in 𝓜\* is replaced by test, whatever its tag; positions stay visible.
5. **Re-encryption oracle** ReEnc(j, ℓ, c): if j ∈ Del\*, ℓ is corrupted and c decrypts under j to a plaintext in 𝓜\*, return test; otherwise re-encrypt honestly.
6. **Signcryption oracle** for honest senders to any recipient, unrestricted.
7. **Win:** guess b. Message equality is on strings; duplicates are masked position by position.

Masking both alternatives is essential: masking only M\_b lets the adversary signcrypt a known entry of M\_0 from a corrupted sender and watch for test. The game as stated needs no large message space (Canetti–Hohenberger need one only for their UC equivalence). A public tag adds no hidden entropy, so the earlier remark that τ supplies it is withdrawn.

**G3. Collusion: key recovery and scope.** A coalition holds rk(j → ℓ, S) for honest j, the delegatee's secret, and any corrupted users other than j.

- **Inherent capability.** On in-scope ciphertexts the coalition computes Dec(sk\_ℓ, ReEnc(rk, c)) offline. No game may forbid this, and deleting the server's copy of rk revokes nothing.
- **G3-KR (key recovery).** The coalition wins by outputting j's decryption scalar k\_j; separately, j's signing scalar x\_j. The repaired re-key loses the first (C4, C16). The second is open: x\_j − k\_j = (1 − H2)·Φ\_j ties it to Φ\_j, but a reduction must simulate the coalition's correlated view.
- **G3-OOS (out-of-scope confidentiality).** G2 with a corrupted proxy and challenge tag τ\* ∉ S. The token itself must be cryptographically unusable outside S; a software check of τ ∈ S does not stop a colluding proxy. Vacuous for S = 𝒯.
- **Revocation** needs epoch keys or key updates and is not modelled.

**G4. Fault attribution.** Blame(sk\_r, Σ, evidence) must satisfy:

- **Sender soundness:** an honest sender is never blamed.
- **Aggregator soundness:** an honest aggregator that supplies its evidence is never blamed.
- **Completeness:** if ADec rejects, at least one party is blamed; missing or inconsistent evidence counts against the aggregator.

The candidate procedure (V7) blames the aggregator if evidence is missing, fails an outer check or differs from Σ's records. Otherwise it blames each sender whose record has a valid outer tag but an invalid inner signature. Otherwise it recomputes Θ from the evidence and blames the aggregator on a mismatch. This handles the review's counterexample: Θ + 1 with all signatures valid blames the aggregator. Limits: Blame needs sk\_r, so it convinces only the recipient. Transferable blame needs an aggregator signature on Σ and revealed openings. Omitted records and replay are not detected.

## Baseline matrix

No established result covers G1 and G2 together under recipient change; one composition plausibly might, and the decoupled candidate's individual unforgeability is a specialization of a known argument. Status: "established" means a published theorem read from the paper (sections cited) or, where marked, from its abstract only; "plausible" means an unproved composition.

| Approach | Status | Confidentiality | Authentication across aggregation | Across re-encryption | Model and assumptions | Gap for G1–G4 |
| --- | --- | --- | --- | --- | --- | --- |
| [Multi-user sign-then-encrypt](https://eprint.iacr.org/2002/046) (An–Dodis–Rabin) | Established (Thm 1; §7) | Insider IND-gCCA2 | None | Not applicable | Generic | No aggregation or delegation |
| [CCA-secure PRE](https://eprint.iacr.org/2007/171) (Canetti–Hohenberger, Def 2.4–2.5); pairing-free [Chow–Weng–Yang–Deng](https://link.springer.com/chapter/10.1007/978-3-642-12678-9_19) | Established | PRE-CCA with derivatives; relaxed CCA | None | None | DBDH (standard model); DL-type (ROM) | No authentication |
| [IND-RCCA](https://eprint.iacr.org/2003/174) (Canetti–Krawczyk–Nielsen) | Established | Replayable CCA | None | Not applicable | Generic | Starting point for G2 only |
| [Aggregate signatures](https://eprint.iacr.org/2002/175) (Boneh–Gentry–Lynn–Shacham) | Established (Def 3.1, Thm 3.2) | None | One group element, chosen-key | Breaks unless re-signed | Pairings, ROM | Not encryption |
| [Schnorr half-aggregation](https://eprint.iacr.org/2022/222) (Chen–Zhao) | Established: Thm 1 (batch coefficients) and Thm 2 (prefix, incremental), both AGM+ROM, tight, chosen-key; Thm 3 sequential scheme, ROM only, different interface | None | n commitments + one scalar | Not addressed | Schnorr EUF-CMA | Commitments are public; ours are encrypted |
| [Fully-succinct multi-key homomorphic signatures](https://eprint.iacr.org/2024/895) (Anthoine–Balbás–Fiore) | Established per abstract; not audited | None | Fully succinct in the number of users | Not addressed | Standard assumptions | No encryption or delegation |
| [Signatures on randomizable ciphertexts](https://eprint.iacr.org/2020/524) (Bauer–Fuchsbauer) | Established | Inherits encryption | None | Randomization only, same key | Generic group, pairings | No key switching |
| [Malleable signatures](https://www.microsoft.com/en-us/research/publication/malleable-signatures-new-definitions-and-delegatable-anonymous-credentials/) (Chase–Kohlweiss–Lysyanskaya–Meiklejohn) | Established, generic | None | None | Any allowed transformation | Controlled-malleable NIZK | Cost; no aggregation |
| [Signed ElGamal in the AGM](https://www.microsoft.com/en-us/research/publication/blind-schnorr-signatures-and-signed-elgamal-encryption-in-the-algebraic-group-model/) (Fuchsbauer–Plouviez–Seurin) | Established per abstract; proof technique to compare | Chosen-ciphertext, AGM | None | None | AGM+ROM | Technique reference for Q1′ |
| Sign-then-encrypt in CCA-PRE + aggregate outer tags + NIZK of correct re-encryption | Plausible | Unknown whether A-RCCA survives tag aggregation | Outer tags yes; inner per record | Inner signature checked after decryption | Pairings + NIZK | NIZK relation, authorization binding, RCCA compatibility unproved |
| Audited ADS-PRE (compact D = λ·K\_r) | Refuted claims (C1–C23) | Claimed IND-CCA2 | Unweighted: forgeable (C9) | Correct only after repair | ECC, ROM | See the audit |
| Candidate v3, decoupled (this note) | Lemma C proved for n = 1; aggregates UNPROVEN | Target A-RCCA | Target AIUF | Yes, inner signature names j | Schnorr EUF-CMA; AGM+ROM conjectured for aggregates | Fails G3-KR for k\_j (C16); no authorization binding |

Still to inspect before any novelty claim: Zhao–Wang–Li, "Composable Aggregation of Schnorr Signatures via Transcript Rebinding" (ICICS 2026), and recent HRA-secure and group-action PRE.

## Candidate v3 and its theorem (UNPROVEN except part 1)

Candidate v3 changes the audited scheme in one structural way: the Schnorr commitment Λ is encrypted with independent randomness t, as (A, B) = (t·K\_r, Λ + t·P), instead of the compact D = λ·K\_r that reuses the signature nonce. It costs one extra point per record, and it is what makes Lemma B and Lemma C go through.

**Construction (implemented in candidate\_v3.py).**

1. **Signcrypt**(sk\_i, pk\_r, m, τ): obtain a Schnorr signature (Λ, θ) on the inner statement ("inner", m, τ, sender ID and key, recipient ID and key); choose t; set A = t·K\_r, B = Λ + t·P, E = m ⊕ H3(ID\_i, Λ); obtain a second Schnorr signature (Δ, f) on ("outer", sender, recipient, τ, A, B, E, θ). The challenge hash is H\_S(R, statement), with the two statement types domain-separated.
2. **Check:** verify the outer signature. **Unsigncrypt:** tP = k\_r⁻¹·A, Λ = B − tP, m = E ⊕ H3(ID\_i, Λ), verify (Λ, θ) on the inner statement.
3. **Delegation:** the audit's repaired re-key (C, Ω = ω·k\_j, γ). ReEnc outputs Ā = Ω⁻¹·A with B, E, τ, θ unchanged. The delegatee recovers ω, then tP = ω·Ā, and verifies the inner statement naming j.
4. **Aggregation:** prefix coefficients over public records (ID, A or Ā, B, E, τ), chained from a start value that binds the context (level, recipient, original recipient, re-key group). The chain value is cached, so Append costs 2 hash calls (V5).

**Theorem.** In the public-key model with identity registration and no key extraction:

1. **Proved (Lemma C):** individual insider unforgeability (G1, n = 1) at first and second level, with advantage equal to that against Schnorr EUF-CMA. Certificateless keys are not covered.
2. **Conjecture:** aggregate insider unforgeability (G1) reduces to Schnorr EUF-CMA in AGM+ROM by adapting Chen–Zhao Theorem 2 to coefficients over ciphertext records. Obligations are listed below.
3. **Conjecture:** A-RCCA (G2) under a gap divisible-Diffie–Hellman-type assumption in the ROM. The proof must handle V9's re-randomization. Nothing is written.
4. **Not met:** G3-KR for k\_j fails (C16). G3-KR for x\_j is open. G3-OOS does not apply (S = 𝒯).
5. **Straightforward, to be written:** G4. Sender soundness follows from unforgeability of the outer Schnorr signature; aggregator soundness and completeness follow from the correctness of the recomputation.

No numerical bounds are stated beyond part 1 until the proofs exist.

**Costs** (P-256, 33-byte points, 32-byte scalars and E, 8-byte tag, 16-byte identities; V11, V12).

| Object or operation | Size or work |
| --- | --- |
| Ciphertext submitted to the cloud (A, B, E, τ, Δ, f, θ) | 203 bytes |
| Aggregate, per record (ID, A or Ā, B, E, τ) | 122 bytes; the compact representation would need 89 |
| Aggregate, fixed part (Θ, cached chain value, context identities) | 112 bytes |
| Second level, per re-key group | (C, γ), 65 bytes; one group per aggregate |
| Aggregate verification | 2n + u + 1 scalar multiplications with cached sender points; O(n) hash calls (4 per record: chain, coefficient, challenge, mask) |
| Append one record | outer check (2 multiplications, cached) and 2 hash calls |
| Merge two compressed aggregates | Not supported |

## Lemmas

Three short lemmas with complete proofs, and the open obligations for aggregates. Lemma A is the review's observation, proved here; Lemmas B and C concern v3. None is a deep result: together they show that the extraction obstacle belongs to the compact representation, not to aggregate signcryption.

**Lemma A (local CDH equivalence, compact representation).** Let X = xP, K = kP, θ ∈ Z\_q, h ∈ Z\_q\* and Λ = θP − hX. Let T = kX = CDH(X, K). Then

```latex
k\Lambda \;=\; \theta K - hT, \qquad T \;=\; h^{-1}\,(\theta K - k\Lambda).
```

*Proof.* kΛ = kθP − khX = θK − hT; solve for T using h ≠ 0. ∎

*Scope.* A simulator that fixes (θ, h) before forming Λ, in the compact representation D = k\_r·Λ, must solve one CDH(X\*, K\_r) instance per query toward a recipient whose key it does not know. The lemma says nothing about other simulators or about the scheme's security (checked numerically: V3).

**Lemma B (simulation from a Schnorr oracle, v3).** For any recipient public key K\_r, the v3 ciphertext Signcrypt(sk\_i, pk\_r, m, τ) is produced by two calls to a Schnorr signing oracle for x\_i, on the inner and the outer statement, plus public operations on K\_r. The output has exactly the real distribution.

*Proof.* The real algorithm is this procedure with the oracle instantiated by Schnorr signing under x\_i, and the encryption randomness t is sampled independently in both. No step uses k\_r. ∎ (Executed in V2 against an adversarially generated recipient key.)

**Lemma C (individual insider unforgeability, v3).** Use public-key keys (signing X = xP, decryption k) and the Schnorr challenge H\_S(R, statement) with domain-separated inner and outer statements. If an adversary wins G1 with n = 1, at first or second level, with probability ε after q\_S signcryption queries, an adversary against Schnorr EUF-CMA for X\* succeeds with probability ε, using 2q\_S signing queries and O(q\_S) extra group operations.

*Proof.*

1. The reduction receives X\* and a Schnorr signing oracle, and sets the honest sender's signing key to X\*. Every other key is the adversary's.
2. It answers each signcryption query (m, r, τ) as in Lemma B, querying its oracle on inner(m, τ, pk\*, pk\_r) and on one outer statement. By Lemma B the adversary's view is identical to G1.
3. First-level forgery: the adversary outputs sk\_r and c whose inner statement (m, r, τ) is not in Q. The reduction computes Λ = B − k\_r⁻¹·A. Acceptance means θP = Λ + hX\* with h = H\_S(Λ, inner(m, τ, pk\*, pk\_r)), so (Λ, θ) is a valid Schnorr signature on that statement.
4. Second-level forgery: the adversary outputs sk\_ℓ, (C, γ), origin j and a re-encrypted ciphertext. The reduction computes T = k\_ℓ⁻¹·γ, ω = C ⊕ H3(ID\_j, T), tP = ω·Ā and Λ = B − tP. Acceptance gives a Schnorr signature on inner(m, τ, pk\*, pk\_j) with (m, j, τ) not in Q.
5. Freshness: inner statements are length-prefixed tuples, injective in (m, τ, sender, recipient identity and key). The oracle signed an inner statement only for queries in Q, and outer statements begin with a different tag. So the output is a Schnorr signature on a never-queried message. ∎

*Scope.*

- No key extraction is needed, because the adversary's output contains the opening key.
- The argument is An–Dodis–Rabin's sign-then-encrypt insider authenticity, specialized to an encrypted commitment; it is not a new technique.
- Certificateless keys (X\* = P\* + R\* + ψ·P\_pub) need H1 programmed to embed X\*, plus a Type I/II treatment; not done.
- It says nothing about aggregates, confidentiality or delegation authorization.

**Obligations for aggregate G1 (conjecture 2).**

1. **Coefficient inputs.** Ours hash ciphertext records and a context, not (R, X, m). Adapt Chen–Zhao's Theorem 2 AGM argument: in the AGM, A\_i and B\_i come with representations, and Λ\_i = B\_i − k\_r⁻¹·A\_i inherits one once k\_r is output.
2. **Online consistency.** The reduction answers coefficient and challenge queries during the run, before k\_r is known; show that the adaptation keeps this consistent.
3. **Signing oracle.** Chen–Zhao reduce to Schnorr EUF-CMA through its signing oracle; Lemma B supplies signcryption from the same oracle, so no extraction is needed.
4. **Rewinding.** Chen–Zhao's Theorem 2 bound has no forking loss in the AGM. A ROM-only proof would need forking with prefix-dependent coefficients; not attempted.
5. **Second level and authorization.** The delegatee's acceptance certifies "i authored m for j", not that j authorized ℓ. Authorization binding needs, for example, j's signature on the grant, which v3 lacks.
6. **Certificateless keys** and Type I/II adversaries, as for Lemma C.

## Q1 narrowed, and what remains open

Q1 as first posed ("do hidden commitments require key extraction?") was too broad, and Lemmas A–C answer its general form negatively. Decoupling the commitment from the encryption randomness removes the obstacle for individual unforgeability at a cost of 33 bytes per record. What remains is a question about one compact representation.

**Q1′ (open question, construction class fixed).** Consider schemes whose per-record ciphertext element is D = k\_r·Λ, where Λ is the Schnorr commitment, with one group element per record. Is individual insider unforgeability provable from DL- or CDH-type assumptions, in the ROM or AGM+ROM, without extractable recipient keys?

- **AGM attempt (not a proof).** An algebraic adversary outputs K\_r = aP + bX\* (+ terms in other seen elements). For a simulated Λ = θP − hX\*, k\_r·Λ contains the term −bh·x*X*, which needs x\*²P. When b = 0 and the remaining terms are elements whose discrete logs the reduction knows, the simulation is immediate. The difficulty is therefore confined to recipient keys correlated with the honest sender's key.
- **Possible outcomes:** a proof handling b ≠ 0, a meta-reduction showing algebraic reductions fail, or an attack exploiting correlated recipient keys.
- **Nearest technique:** Fuchsbauer–Plouviez–Seurin's signed ElGamal analysis in the AGM; whether it applies is unchecked.

**Q2 (mergeable aggregates).** Prefix weights allow appending but not merging two compressed aggregates. Check Chen–Zhao and later work before investing.

**Q3 (scope without pairings or NIZKs).** Achieve G3-OOS for arbitrary scopes, with G1 and G2, under DL-type assumptions. Closest area: conditional PRE.

**Contribution status.** Lemma C specializes a known argument. Q1′ is a narrow question whose practical stake is 33 bytes per record. Neither is, at present, a contribution of STOC's kind; that judgment concerns the mathematics, not the venue, and would change with a strong answer to Q1′ or Q3.

## Next steps

1. **Q1′ in the AGM (2–3 days):** settle the b ≠ 0 case — proof, meta-reduction or attack — starting from Fuchsbauer–Plouviez–Seurin.
2. **Aggregate G1 for v3:** work through obligations 1–4 against Chen–Zhao's Theorem 2 proof (Section 4.2).
3. **G2 proof for v3**, including re-randomization (V9), or locate where it fails.
4. **Authorization binding:** add j's signature on the grant and state what the delegatee's acceptance then certifies.
5. **Literature:** inspect Zhao–Wang–Li (ICICS 2026) and recent HRA and group-action PRE before any novelty claim.
6. **Decide** after steps 1–3 whether a result of the required strength exists. The name follows the result.
