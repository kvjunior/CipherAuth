# Supplied research notes

review/model_v3.md and review/audit_v3.md preserve Claude's latest supplied notes.
They are historical input, not the accepted specification or proof of the new direction.
The original filenames and byte hashes are recorded in uploaded_inputs.json.
