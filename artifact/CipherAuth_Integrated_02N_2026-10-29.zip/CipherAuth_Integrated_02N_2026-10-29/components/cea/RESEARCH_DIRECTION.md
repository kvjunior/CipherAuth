# Chosen direction

**Commuting Aggregation and Delegation for Encrypted Authentication**

> **Status update, 25 Oct 2026 (novelty gate result).** The question as posed is answered by a
> known generic composition (CEA: commit-then-encrypt-and-sign + single-hop PRE + Chen–Zhao
> IASchnorr; `spec/cea_construction.md`). Commutation is therefore not a contribution
> (`claims/claims.json`, N-COMMUTATION). The refined, still-unverified question Q-R and an
> honest assessment are in `proofs/commutation_target.md`. Title and target venue unchanged;
> the title names the investigation, not a result.

This title is provisional. It names the intended problem, not an established theorem.
There is no new protocol acronym to defend before the contribution exists.

## Why choose this question

The v3 diagnostics pass, and its decoupled commitment supports a familiar individual
Schnorr authenticity argument. Its aggregation coefficients, however, bind public
ciphertext records and the recipient/level context. Re-encryption changes those inputs.
A compressed scalar formed under the old coefficients cannot simply be carried into the
new batch. The supplied v3 code re-encrypts individual ciphertexts, retains their theta
values, and aggregates again; that is a different interface from delegating a compressed
aggregate after individual signature scalars have been discarded.

The included diagnostic demonstrates that the direct carry-Theta transformation fails
and rebuilding with individual scalars succeeds. It is not an impossibility proof.

The primary research task is to characterize the compatibility conditions and develop
a construction with explicit costs and proofs. The compact-representation correlated-key
question Q1-prime is a supporting proof issue, not the proposed paper's entire contribution.

## Frozen initial scope

- Ordinary public keys with explicit identity, role, key version, and fingerprint.
- Static corruptions, including malicious recipients, senders, and proxy.
- Single-hop, unidirectional recipient delegation.
- One original recipient, one grant group, and one tag/epoch class per initial batch.
- Ordered, noninteractive public aggregation and public append.
- Delegation of an already compressed aggregate, without individual theta values.
- Sender authenticity and origin-recipient grant authenticity are distinct requirements.
- Confidentiality tolerates only precisely specified authorized transformations.
- Cryptographic scope enforcement is required for out-of-scope confidentiality.

The policy layer represents finite tag sets for future extension, but arbitrary access
policies, multi-hop delegation, adaptive corruptions, merging independent batches,
certificateless Type I/II security, forward secrecy, and post-deletion revocation are
outside the initial target. Adding any of these requires a new explicit scope decision.
Fault attribution is a supporting property and must not delay the central theorem.

## Intended theoretical contribution

A substantial result would identify nontrivial conditions under which encrypted
authentication supports public aggregation and authenticated recipient change in either
order, and establish sender-insider authenticity, grant authenticity, and the chosen
confidentiality notion with explicit overhead. A limitation result needs a precise
construction/reduction class and a valid proof.

This is a research objective, not a theorem. Do not describe it as first, optimal, tight,
pairing-free, NIZK-free, constant-size, or standard-model until those claims are established.
In particular, a direct composition of existing tools with the same guarantees and costs
would defeat the intended novelty claim.

## Mandatory novelty gate

Compare the exact interface, models, and total overhead against:

1. Published incremental Schnorr half-aggregation.
2. Generic sign-then-encrypt plus PRE plus aggregate authentication and transformation proofs.
3. Fully succinct multi-key homomorphic signatures and controlled-malleable signatures.
4. Policy aggregate signatures and verifiable/conditional PRE.
5. The direct 2026 IDASR baseline, whose institutional abstract already describes aggregate
   signcryption, re-encryption, and proxy/recipient collusion.
6. Recent transcript-rebinding and HRA work.

The 2026 direct baseline has only been examined through primary metadata/abstract here.
Obtain its exact games and construction before claiming a gap. If it or a generic compiler
already provides the proposed interface at comparable cost, record that fact and revise the
precise question. Do not add applications or rename the same combination to manufacture novelty.

## Work order and exit conditions

1. Complete the novelty matrix with exact theorem references and clearly marked unknowns.
2. Finalize the games and canonical statements. Resolve the plain-key/legacy-key mismatch.
3. State the new technical lemma needed for compressed delegation and prove it, or find an attack.
4. Implement only the construction justified by that analysis. Register every unproved property.
5. Establish full security reductions; use tests as diagnostics, not substitutes.
6. Then measure costs and write the paper around the actual theorem.

The venue target stays STOC 2027. No code layout or test count predicts acceptance.
