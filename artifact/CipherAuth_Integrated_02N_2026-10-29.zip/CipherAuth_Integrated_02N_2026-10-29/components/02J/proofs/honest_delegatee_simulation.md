# Honest-delegatee token simulation: correction to D1

Status: restricted simulation lemma and executable algebra, pending independent
review. It corrects the object type used in the earlier D1 drafts; it is not a
complete G-CONF proof.

## Implementation-level correction

The frozen code sets the proxy secret to the nonzero scalar

`Omega = omega*k mod q`

and transforms any body point by `Abar = Omega^{-1} A`. The public token includes
`C`, `gamma` and `W=H_Omega(Omega)`; Omega itself stays with the honest proxy.
Several earlier drafts instead wrote `Omega=omega*K`, a group point, and then tried
to invert it as a scalar. That is not the implemented scheme. The 02E audit already
flagged this scalar/point confusion, but the subsequent D1 analysis continued to
reason through `Abar=omega^{-1}Q` and overlooked the directly computable map.

## Restricted lemma

Let the target class public key be `K=kP`, with k unknown to the reduction. For a
grant to a statically honest delegatee, condition on the adversary not querying the
mask oracle at `T=k_l^{-1} gamma`. Replace

`C = encode(omega) xor Hmask(T, class-ref)`

by an independent uniform 32-byte string. This is a perfect ROM hop until the T
query: Hmask(T) is uniform and unobserved, so XOR makes C uniform independently of
omega. The exposure event is a delegatee divisible-DH event and must receive its
own reduction and query loss.

In this hybrid, sample Omega directly and uniformly from `F_q^*`. This has the real
distribution because multiplication by fixed nonzero k maps uniform omega
bijectively to uniform Omega. Set `W=H_Omega(Omega)`, generate gamma honestly, and
retain scalar Omega as the proxy state. For every adversarial input, including the
challenge and non-extractable signed bodies, return

`Abar = Omega^{-1} A`.

This is exact, requires neither k nor the opening `Q=k^{-1}A`, and preserves all
same-grant affine, repeated-query and cross-grant relations automatically. The
challenge reply is therefore computable. No random-point/DDH hybrid is used.

For an ordinary delegated `DecO` query, the simulator computes
`A = Omega*Abar` and invokes the target-class opening simulation on A. Registered
challenge derivatives remain refused. The simulated public C need not make the
actual recipient algorithm succeed internally; until T is queried, the adversary's
only honest-recipient opening interface is DecO, whose answer is simulated this way.
Static corruption is essential.

## Corrupted-delegatee path

The CT path is different. The reduction chooses and knows omega but cannot form
scalar Omega without k. For a proxy-accepted non-derivative record, the intake
extraction lemma must provide Q, after which the exact reply is `omega^{-1}Q`.
The registered challenge and its derivatives are refused. Thus the two paths are:

- honest delegatee: know Omega; transform every A directly;
- corrupted delegatee: know omega; transform only records whose Q is extracted.

This split is why intake extraction remains necessary for G-CONF-CT even though it
is unnecessary for the honest-delegatee challenge reply.

## Remaining obligations

1. Reduce the Hmask(T) exposure event for all honest grants to the exact named
   divisible-DH assumption and account for grant guessing/loss.
2. Extend extraction from `{K,X}` to every algebraic input in the actual game.
3. Version and resolve CT grant/admissibility semantics.
4. Complete target-class DecO/ROM bookkeeping and the final reduction bound.
5. Independently review this correction and settle the novelty/literature gate.

Accordingly, D1 is no longer established as a structural impossibility. The
earlier D1 gate should be treated as superseded by this candidate exact simulation,
subject to independent proof review and completion of the exposure reduction.
