# Simulation split fixed by recipient corruption

| Recipient | Hidden from adversary | Simulator chooses/knows | Proxy reply |
|---|---|---|---|
| Honest delegatee | delegatee secret, T, omega, Omega | scalar Omega, t2, uniform hybrid C | `Omega^{-1}A` for every input |
| Corrupted delegatee | target class secret k and proxy scalar Omega | omega, t2; extracted Q for served input | `omega^{-1}Q` |

For the honest row, the real-to-uniform-C hop aborts on `Hmask(T)` exposure. The
simulator restores `A=Omega*Abar` for ordinary DecO bookkeeping. The frozen game
refuses challenge derivatives at DecO.

For the corrupted row, the CT policy refuses registered derivatives at ReEncO.
The augmented intake proof is intended to make every served non-derivative input
extractable. The unresolved full-basis lemma and grant-admissibility wording remain.

The split uses the static corruption set fixed before key generation. An adaptive
corruption of an honest delegatee would reveal its secret, expose T/omega and
invalidate the uniform-C hybrid.
