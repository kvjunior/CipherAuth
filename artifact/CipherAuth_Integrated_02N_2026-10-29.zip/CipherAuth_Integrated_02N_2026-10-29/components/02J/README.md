# CipherAuth Batch 02J — honest-delegatee token simulation

Batch 02J corrects the earlier D1 model to match the frozen implementation's
scalar proxy secret `Omega=omega*k`. It supplies an exact transformed-point
simulation for an honest delegatee, a uniform-C hybrid argument, recipient-path
split, and tests against the actual CEA token implementation.

Run:

```sh
python scripts/reproduce.py
```

This is a candidate restricted simulation lemma pending independent review. It
does not prove G-CONF-CLASS or G-CONF-CT. The next gates are the Hmask(T) exposure
reduction, the full algebraic basis, and the versioned grant/admissibility game.
