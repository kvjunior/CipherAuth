import unittest

from cipherauth import group as g
from cipherauth.cea import CEA, Directory, SUITE, parse_body
from cipherauth.encoding import digest, encode
from cipherauth.models import BatchContext
from token_simulation import (corrupted_delegatee_reply, known_witness_consistency,
                              make_real_view, make_simulated_view, real_relation,
                              recover_masked_omega, toy_uniformity)


class TokenSimulationTests(unittest.TestCase):
    def setUp(self):
        self.k = 37
        self.omega = 41
        self.Omega = self.k * self.omega % g.q
        self.ell_secret = 43
        self.Kell = g.mul(self.ell_secret, g.G)
        self.t2 = 47
        self.mask = bytes(range(32))

    def test_real_scalar_relation_and_public_fields(self):
        view = make_real_view(self.k, self.Kell, omega=self.omega,
                              t2=self.t2, mask=self.mask)
        self.assertIsInstance(view.Omega, int)
        self.assertTrue(real_relation(self.k, self.omega, view.Omega))
        self.assertEqual(recover_masked_omega(view.C, self.mask), self.omega)
        self.assertEqual(len(view.public), 3)

    def test_challenge_transform_needs_A_and_Omega_not_Q(self):
        A_star = g.mul(1234567, g.G)  # embedded group point; no opening supplied
        view = make_simulated_view(self.Kell, Omega=self.Omega,
                                   t2=self.t2, C=b"R" * 32)
        result = view.transform(A_star)
        self.assertEqual(g.mul(view.Omega, result), A_star)

    def test_same_grant_affine_consistency_is_exact(self):
        view = make_simulated_view(self.Kell, Omega=self.Omega,
                                   t2=self.t2, C=b"R" * 32)
        K = g.mul(self.k, g.G)
        A = g.mul(101, K)
        r = 17
        self.assertEqual(view.transform(A + g.mul(r, K)),
                         view.transform(A) + g.mul(r, view.transform(K)))

    def test_cross_grant_relations_are_preserved_without_DDH_hybrid(self):
        K = g.mul(self.k, g.G)
        A = g.mul(101, K)
        views = [make_simulated_view(self.Kell, Omega=value,
                                     t2=self.t2, C=bytes([index]) * 32)
                 for index, value in enumerate((53, 59), 1)]
        outputs = [view.transform(A) for view in views]
        # Both outputs are derived from the same A by exact linear maps.
        self.assertEqual(g.mul(views[0].Omega, outputs[0]), A)
        self.assertEqual(g.mul(views[1].Omega, outputs[1]), A)

    def test_known_witness_relation_real_view(self):
        K = g.mul(self.k, g.G)
        witness = 101
        view = make_real_view(self.k, self.Kell, omega=self.omega,
                              t2=self.t2, mask=self.mask)
        self.assertTrue(known_witness_consistency(self.omega,
                                                  view.transform(g.mul(witness, K)), witness))

    def test_uniform_C_hybrid_can_be_detected_after_mask_exposure(self):
        K = g.mul(self.k, g.G)
        witness = 101
        view = make_simulated_view(self.Kell, Omega=self.Omega,
                                   t2=self.t2, C=b"\0" * 32)
        exposed = int.from_bytes(self.mask, "big")
        if exposed == 0 or exposed >= g.q:
            self.skipTest("chosen controlled mask did not encode a scalar")
        self.assertFalse(known_witness_consistency(exposed,
                                                   view.transform(g.mul(witness, K)), witness))

    def test_simulator_DecO_restores_origin_component(self):
        view = make_simulated_view(self.Kell, Omega=self.Omega,
                                   t2=self.t2, C=b"R" * 32)
        for scalar in (1, 2, 101, g.q - 1):
            A = g.mul(scalar, g.G)
            self.assertEqual(view.restore_origin_component(view.transform(A)), A)

    def test_corrupted_delegatee_path_matches_real_transform(self):
        witness = 101
        K = g.mul(self.k, g.G)
        Q = g.mul(witness, g.G)
        view = make_real_view(self.k, self.Kell, omega=self.omega,
                              t2=self.t2, mask=self.mask)
        self.assertEqual(corrupted_delegatee_reply(self.omega, Q),
                         view.transform(g.mul(witness, K)))

    def test_corrupted_delegatee_path_refuses_missing_opening(self):
        with self.assertRaisesRegex(ValueError, "extracted opening"):
            corrupted_delegatee_reply(self.omega, None)

    def test_toy_joint_distribution_is_uniform(self):
        for q, width, k in ((5, 3, 2), (7, 3, 3), (13, 4, 5)):
            result = toy_uniformity(k, q, width)
            self.assertTrue(result["support_complete"])
            self.assertEqual(result["multiplicity"], [1])
            self.assertEqual(result["outcomes"], (q - 1) * 2**width)

    def test_invalid_toy_parameters(self):
        for args in ((0, 7, 3), (7, 7, 3), (1, 17, 4)):
            with self.assertRaises(ValueError):
                toy_uniformity(*args)

    def test_actual_CEA_token_uses_scalar_Omega_and_exact_transform(self):
        directory = Directory()
        system = CEA(directory)
        owner = directory.new_signing_key("owner")
        origin = directory.new_decryption_key("owner", tag=b"t", epoch=1)
        ell = directory.new_decryption_key("ell")
        sender = directory.new_signing_key("sender")
        submission = system.signcrypt(sender, "owner", b"secret", b"t", 1)
        aggregate = system.aggregate(BatchContext(SUITE, "origin", origin.ref, origin.ref, 1),
                                     [submission])
        token, grant = system.issue_grant(owner, origin, ell.ref, b"t", 1)
        delegated = system.delegate_aggregate(token, grant, aggregate)
        A = parse_body(submission.record.body)[2]
        Abar = parse_body(delegated.aggregate.records[0].body)[2]
        self.assertIsInstance(token.Omega, int)
        C, gamma, W = token.public_part()
        T = g.mul(g.inv(ell.k), g.decode_point(gamma))
        mask = g.hash_bytes("cea/rk-mask", encode((g.encode_point(T), origin.ref.fields())))
        omega = int.from_bytes(bytes(a ^ b for a, b in zip(C, mask)), "big")
        self.assertEqual(token.Omega, omega * origin.k % g.q)
        self.assertEqual(W, digest("cea-token-omega", token.Omega))
        self.assertEqual(Abar, g.mul(g.inv(token.Omega), A))
        self.assertEqual(system.open_aggregate(ell, delegated)[0].message, b"secret")


if __name__ == "__main__":
    unittest.main(verbosity=2)
