"""Exact transformed-point simulation for an honest delegatee.

The frozen CEA implementation stores the proxy secret as a scalar
Omega = omega*k mod q.  Earlier drafts accidentally replaced it by the point
omega*K.  This module keeps the implemented scalar type explicit.
"""
from dataclasses import dataclass
from collections import Counter

from cipherauth import group as g
from cipherauth.encoding import digest


def xor(left, right):
    if type(left) is not bytes or type(right) is not bytes or len(left) != len(right):
        raise ValueError("equal-length byte strings required")
    return bytes(a ^ b for a, b in zip(left, right))


@dataclass(frozen=True)
class HonestTokenView:
    """Simulator state plus the public fields sent to the adversary."""
    Omega: int
    C: bytes
    gamma: bytes
    W: bytes

    def __post_init__(self):
        g.validate_scalar(self.Omega, nonzero=True)
        if type(self.C) is not bytes or len(self.C) != 32:
            raise ValueError("C must be 32 bytes")
        g.decode_point(self.gamma)
        if type(self.W) is not bytes or len(self.W) != 32:
            raise ValueError("W must be 32 bytes")

    @property
    def public(self):
        return self.C, self.gamma, self.W

    def transform(self, A):
        return g.mul(g.inv(self.Omega), g.validate_point(A))

    def restore_origin_component(self, Abar):
        """Simulator-side DecO bookkeeping; does not use C or delegatee secret."""
        return g.mul(self.Omega, g.validate_point(Abar))


def make_simulated_view(delegatee_public, *, Omega, t2, C):
    """H1 view: C is uniform; Omega is sampled directly and retained privately."""
    g.validate_scalar(Omega, nonzero=True)
    g.validate_scalar(t2, nonzero=True)
    gamma = g.encode_point(g.mul(t2, g.validate_point(delegatee_public)))
    return HonestTokenView(Omega, C, gamma, digest("cea-token-omega", Omega))


def make_real_view(k, delegatee_public, *, omega, t2, mask):
    """Real token fields for a fixed 32-byte Hmask(T) answer."""
    for value in (k, omega, t2):
        g.validate_scalar(value, nonzero=True)
    if type(mask) is not bytes or len(mask) != 32:
        raise ValueError("mask must be 32 bytes")
    Omega = omega * k % g.q
    C = xor(omega.to_bytes(32, "big"), mask)
    return make_simulated_view(delegatee_public, Omega=Omega, t2=t2, C=C)


def recover_masked_omega(C, mask):
    value = int.from_bytes(xor(C, mask), "big")
    return g.validate_scalar(value, nonzero=True)


def real_relation(k, omega, Omega):
    return Omega == omega * k % g.q


def known_witness_consistency(omega, Abar, witness):
    """Public test available after omega is exposed for A=witness*K."""
    g.validate_scalar(omega, nonzero=True)
    g.validate_scalar(witness, nonzero=True)
    return g.mul(omega, g.validate_point(Abar)) == g.mul(witness, g.G)


def corrupted_delegatee_reply(omega, Q):
    """Separate CT path: requires the extracted opening Q and known mask omega."""
    if Q is None:
        raise ValueError("corrupted-delegatee reply requires an extracted opening")
    g.validate_scalar(omega, nonzero=True)
    return g.mul(g.inv(omega), g.validate_point(Q))


def toy_uniformity(k, q, width):
    """Enumerate the H1 distribution in a small scalar/XOR space.

    For every nonzero omega and every width-bit mask, Omega=omega*k mod q and
    C=encode(omega) xor mask.  Multiplication by nonzero k permutes F_q^*, and
    XOR with a uniform mask makes C uniform and independent of Omega.
    """
    if not (2 < q <= 2**width) or not 0 < k < q:
        raise ValueError("invalid toy parameters")
    counts = Counter()
    for omega in range(1, q):
        Omega = omega * k % q
        for mask in range(2**width):
            counts[(Omega, omega ^ mask)] += 1
    expected = {(Omega, C) for Omega in range(1, q) for C in range(2**width)}
    return {"support_complete": set(counts) == expected,
            "multiplicity": sorted(set(counts.values())),
            "outcomes": sum(counts.values()), "support_size": len(counts)}
