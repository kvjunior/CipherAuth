# Independent review request for Batch 02J

Check the frozen `Token.Omega` type and transformation code first. Verify that the
lemma samples the scalar Omega rather than the point omega*K and that multiplication
by unknown nonzero k makes uniform omega and uniform Omega identically distributed.

Audit the uniform-C hop: it is valid only until the adversary queries Hmask at the
honest delegatee's T. Check whether all honest-recipient observations are covered,
including W, arbitrary/repeated proxy replies, cross-grant relations and DecO.
Check that `A=Omega*Abar` suffices for simulated ordinary DecO and that derivatives
remain refused. Assess the exact assumption and loss for the T-exposure event.

Keep the corrupted-delegatee CT path separate: it knows omega, needs extracted Q,
and refuses challenge derivatives. Do not call the full games proved. Identify any
view or oracle through which an honest delegatee's real C consistency is testable
without querying T.
