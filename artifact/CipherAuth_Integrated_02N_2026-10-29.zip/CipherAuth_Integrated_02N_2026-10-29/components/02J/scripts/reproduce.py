#!/usr/bin/env python3
import hashlib
import json
import stat
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "vendor")]
from token_simulation import toy_uniformity


def extract_safe(archive, destination):
    with zipfile.ZipFile(archive) as handle:
        for item in handle.infolist():
            path = Path(item.filename)
            if path.is_absolute() or ".." in path.parts or stat.S_ISLNK(item.external_attr >> 16):
                raise RuntimeError("unsafe baseline archive member")
        handle.extractall(destination)


def main():
    archive = ROOT / "baseline/CipherAuth_Batch02I_Adaptive_2026-10-28.zip"
    with tempfile.TemporaryDirectory() as folder:
        extract_safe(archive, folder)
        base = Path(folder) / "CipherAuth_Batch02I_Adaptive"
        expected = {name: (base / "results" / name).read_bytes()
                    for name in ("observed.json", "traces.json")}
        subprocess.run([sys.executable, str(base / "scripts/verify_manifest.py")],
                       check=True, capture_output=True)
        subprocess.run([sys.executable, str(base / "scripts/reproduce.py")],
                       check=True, capture_output=True)
        for name, data in expected.items():
            if data != (base / "results" / name).read_bytes():
                raise RuntimeError("02I baseline result changed")
    # The vendored package is an exact source snapshot, checked again by the
    # integrated runner against components/cea/src/cipherauth.
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    tests = unittest.TextTestRunner(verbosity=2).run(suite)
    distribution = {f"q{q}": toy_uniformity(k, q, width)
                    for q, width, k in ((5, 3, 2), (7, 3, 3), (13, 4, 5))}
    result = {
        "batch": "02J",
        "tests_run": tests.testsRun,
        "failures": len(tests.failures),
        "errors": len(tests.errors),
        "skips": len(tests.skipped),
        "prior_tests_02I": 27,
        "prior_results_byte_identical": True,
        "toy_uniformity": distribution,
        "scalar_Omega_matches_implementation": True,
        "honest_delegatee_transform_simulated_exactly": True,
        "uniform_C_hybrid": "WRITTEN_PENDING_EXPOSURE_REDUCTION_REVIEW",
        "D1": "CANDIDATE_CORRECTED_PENDING_INDEPENDENT_REVIEW",
        "full_AGM_basis": "OPEN",
        "grant_admissibility": "OPEN",
        "full_security_proved": False
    }
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results/observed.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if tests.wasSuccessful() and not tests.skipped else 1


if __name__ == "__main__":
    sys.exit(main())
