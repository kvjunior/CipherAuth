# CipherAuth status — Batch 01r2

CipherAuth is the working name; the target remains STOC 2027.

## Evidence

The supplied b baseline contains an executable CEA comparator, half-aggregation,
P-256 arithmetic, canonical wire encoding, attacks and tests. In isolated replay,
85 source hashes matched, all 39 baseline tests passed without skips, and the frozen
v3 report matched at 12/12. These are reproducibility checks, not security proofs.

The original Batch 01 independently reproduced at 15 tests. Claude's patch reproduced
at 19 tests, and all reviewer probe output matched exactly. This revision retains
those controls and adds corrected proxy-policy cases; consult results/observed.json
for the actual current test count, environment and experiment outcomes.

## Scientific status

| Item | Status |
| --- | --- |
| CEA functional commutation | Implemented known composition |
| CEA aggregate/grant authenticity | Sketches; no completed reviewed reduction |
| CEA class-granularity confidentiality | Open |
| CEA stated per-ciphertext target | Refuted for the unguarded comparator |
| In-class proxy/delegatee key recovery | Demonstrated; unchanged |
| Individual intake-proof baseline | Implemented; original code independently reviewed |
| Batch 01 review verdict | Accept for research use, with repairs |
| Batch 01r1 repairs | Independently accepted for research use with minor repairs |
| Batch 01r2 | Minor repairs and conditional algebra note; awaits review |
| Compressed origin-level validity proof | Not implemented; extraction unproved |
| Post-delegation proof preservation | Outside chosen single-hop requirement |
| Complete CipherAuth security theorem | None |
| New STOC main contribution | Not established |

The next work must settle the precisely stated proof/extraction question and its
novelty. More passing tests alone cannot establish the paper's main contribution.
ChatGPT implements bounded batches, Claude reviews independently, and human authors
verify the security proofs and all final claims.


## 01r2 update

All three latest reviewer controls are integrated; the unit suite now has 29 tests.
The 20 original attack/control cases remain. Six additional adaptive proxy-reply
comparisons illustrate the conditional equality Abar=omega^-1*Q. They assume known
request randomness and do not implement aggregate extraction or token simulation.
See REVIEW_R1_RESPONSE.md and research/PROXY_EXTRACTION_NOTE.md.
