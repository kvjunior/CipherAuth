# CipherAuth: what proxy replies add to the extraction problem

Status: elementary algebra and a conditional simulation lemma, with complete proofs
below. No novelty, aggregate extraction, token simulator, or full security theorem
is claimed. This note refines the next research question rather than supplying the
missing main contribution.

## Fixed setting

Let G be a prime-order additive group of order q, with generator P. Let k and omega
be nonzero scalars, K=kP, and Omega=omega*k. An origin record uses A=tK and an
opening point Q=tP. The one-hop proxy replaces A by Abar=Omega^-1*A. All inverses
below are in F_q. The authenticated commitment and sender data are not modified.

The honest-proxy/corrupted-delegatee experiment withholds Omega and k from the
adversary. The delegatee can recover omega using its own secret and the public
masking token. If a coalition gets both Omega and omega, it recovers k; no lemma
below repairs that inherited in-class collusion limitation.

## Lemma 1: exact scope of the scalar/affine attack

Assume the proxy refuses only an exact registered point A*, while its public
sender-authentication check does not bind A or E. Let the challenge opening be
Q*=k^-1*A*. An adversary chooses public scalars a!=0 and b such that

    A' = a*A* + b*K

is nonidentity and differs from A*. If the unguarded proxy serves this request
under the challenge class's token, the corrupted delegatee recovers Q* and hence
the challenge plaintext from its original public E.

Proof. The returned point is Abar'=Omega^-1*A'. The delegatee knows omega, so

    omega*Abar' = k^-1*A' = a*Q* + b*P.

It computes Q*=a^-1*(omega*Abar' - b*P) and applies the original record's KDF mask
to the original E. No origin secret, private proxy scalar, or hidden challenge bit
is used. Ordinary opening/commitment rejection of the altered ciphertext does not
restrict this local computation by the corrupted party. QED.

For pure scaling (b=0), every a in F_q excluding 0 and 1 meets the two point
conditions when A* is nonidentity. This includes 2 and -1 for P-256. The zero map
is excluded, and the identity map is refused. Thus the phrase "any linear map"
requires qualification. The original shift attack is a=1,b!=0 subject to the
same point conditions. Tests demonstrate particular instances; the algebra
establishes the conditional general statement. No novel attack technique is claimed.

## Lemma 2: replying after the opening is available

Given a query's correct opening point Q=k^-1*A and the token mask omega, the exact
transformed group component can be computed as

    Abar = omega^-1*Q.

If instead the simulator knows t with A=tK, it first computes Q=tP. Neither formula
requires k or Omega.

Proof. Omega=omega*k, so omega^-1*Q=(omega*k)^-1*A. If A=t*kP then k^-1*A=tP.
These are equalities in the prime-order group, so the predicted point is identical
to the real proxy's point, without statistical or computational loss. QED.

This is a sufficient condition. A simulator need not necessarily recover the
scalar t if it can compute the correct Q through legitimate query bookkeeping
or another reduction. Conversely, a claimed or guessed Q is not publicly checked
by the two-line formula; obtaining the correct Q is the substantive premise.

## Conditional adaptive corollary

Consider a bounded adaptive sequence of accepted queries, possibly containing
multiple records. Suppose, before each response, a polynomial-time reduction:

1. obtains every correct Q_i needed for that response, by a proven online extractor
   or explicitly permitted bookkeeping;
2. knows the corresponding token mask omega;
3. can consistently generate or reuse all other visible grant, token, context and
   authentication fields, with the required distribution and validation outcomes.

Then replacing each actual returned Abar_i by omega^-1*Q_i leaves the entire
visible response sequence unchanged. Conditional on these premises, the response
points add no independent unknown generator to the reduction's existing basis:
when Q_i=t_i*P with known t_i, each is the known multiple (t_i/omega)*P.

Proof. Fix all parties' random tapes and the auxiliary token/grant data. The first
query's response points agree by Lemma 2; its remaining fields agree by premise 3.
The identical first response produces the same next adaptive query. Apply the
same argument to each subsequent response. Induction gives pointwise equality
of the full finite transcript. The stated polynomial bound follows from the
premises and polynomially many point operations. QED.

The premises include the difficult extraction/consistency tasks; this corollary
does not establish them. In particular it is not a reduction for the full game.

## Consequence for the review's proposed novelty location

It is correct that a proxy exposes further related points. It is too early to
identify their appearance alone as a new technical obstacle. Once the reduction
has the correct openings and omega, those specific response points follow from
Lemma 2. Before that, a proof must explain how to obtain the openings from an
accepted compressed equation. This is the central unresolved step.

The formal target should therefore be online simulation of every accepted
aggregate's decapsulation outputs, with a precise list of allowed prior-query
exceptions. Raw witness extraction is one sufficient route, not a definitionally
equivalent requirement. A statement that merely prohibits every representation
having a "challenge coefficient" also needs a specified representation normal
form, challenge distribution and treatment of honest/simulated oracle outputs.

Additional unresolved tasks include consistent public token/grant simulation:
W=H(Omega) is present in the inherited token, and its joint distribution with
hash queries and the signed grant cannot be skipped. Lemma 2 conditions on
correct auxiliary data; it does not compute W without Omega. Registration,
malicious issuers, proxy corruptions, multi-class/multi-token queries, challenge
exclusions and sender authentication still need explicit game rules and reductions.

## Relation to signed hashed ElGamal

Algebraically one can set generator G0=K, public key Y=P, and secret x=k^-1.
Then A=tG0 and Q=tY=xA, and the intake proof concerns randomness t relative to G0.
This is the signed hashed-ElGamal shape. Transferring a published theorem also
requires the correct input distribution after swapping the roles of generator
and public key, plus treatment of the commitment, sender signatures, tokens,
proxy outputs and every oracle. The relabeling proves no security theorem.

## Executable control

research/proxy_reply_control.py compares Lemma 2 with six actual guarded proxy
responses across both challenge bits and three adaptive requests. The requester
chooses t and knows it; later requests depend on the preceding public response.
The requests reuse the challenge's signed commitment with an independently known
point, so correctness of their plaintext opening is deliberately not claimed.
This illustrates exactly the valid-intake/malicious-opening distinction.

The helper reads no origin key or private proxy scalar. It recovers omega with
the corrupted delegatee's own key and the public returned token, and compares
only Abar. It is not an aggregate extractor or a full grant/token simulator.
The written proofs, rather than passing these finite cases, justify the algebra.

## Decision

Keep the implemented individual proof comparator and the name CipherAuth.
Do not advertise the compressed template or adaptive proxy service as a new
STOC contribution yet. The next deliverable is a proof/counterexample or a
known-technique classification for online aggregate decapsulation simulation,
with the literature and exact game fixed first.
