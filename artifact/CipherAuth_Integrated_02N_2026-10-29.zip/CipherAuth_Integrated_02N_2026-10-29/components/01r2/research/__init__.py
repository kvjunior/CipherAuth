"""Conditional algebra controls, not a new CipherAuth construction."""
