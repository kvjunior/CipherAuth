"""Check the conditional reply identity against real one-record proxy replies.

The requester chooses and knows t. This does NOT extract t from a compressed
proof or simulate a grant/token. No origin key or private token scalar is read.
"""
from dataclasses import replace

from cipherauth import group as g
from cipherauth.cea import parse_body, _body, _xor
from cipherauth.encoding import encode
from batch01 import intake_pok
from batch01.cea_adapter import binding
from batch01.experiment import Scenario
from batch01.oracle_experiment import Policy


def reply_from_opening(opening, omega):
    """Assuming Q=k^-1 A is correct, return Abar=omega^-1 Q.

    This checks the point/scalar types, not the unprovided relation to A.
    The caller must obtain Q through extraction or legitimate bookkeeping.
    """
    g.validate_point(opening)
    g.validate_scalar(omega, nonzero=True)
    return g.mul(g.inv(omega), opening)


def delegatee_mask(view, public_token):
    """Recover omega using only the delegatee's own key and public token."""
    C, gamma, _ = public_token
    T = g.mul(g.inv(view.delegatee_secret.k), g.decode_point(gamma))
    mask = g.hash_bytes("cea/rk-mask", encode((g.encode_point(T), view.origin.fields())))
    omega = int.from_bytes(_xor(C, mask), "big")
    g.validate_scalar(omega, nonzero=True)
    return omega


def run():
    checks = []
    for bit in (0, 1):
        fixture = Scenario(bit, Policy.REGISTERED_POINT, True)
        view = fixture.view
        source = view.challenge_aggregate.records[0]
        Lam, c, challenge_A, E = parse_body(source.body)
        K = g.decode_point(view.origin_public)
        t = 19
        previous_reply = None
        for step in range(3):
            if previous_reply is not None:
                # Later public requests depend on the previous actual reply.
                t = g.hash_to_scalar("cipherauth/research/reply-chain/v1",
                                     g.encode_point(previous_reply)) or 1
            while g.mul(t, K) == challenge_A:
                t = (t + 1) % g.q or 1
            A = g.mul(t, K)
            record = replace(source, body=_body(Lam, c, A, E))
            proof = intake_pok.prove(t, view.origin_public, g.encode_point(A), binding(record))
            request = replace(view.challenge_aggregate, records=(record,))
            decision = fixture.oracle.query(request, proof)
            if decision.output is None:
                raise AssertionError("known-witness request unexpectedly refused")
            omega = delegatee_mask(view, decision.output.token_public)
            predicted = reply_from_opening(g.mul(t, g.G), omega)
            actual = parse_body(decision.output.aggregate.records[0].body)[2]
            if predicted != actual:
                raise AssertionError("conditional reply identity failed")
            previous_reply = actual
            checks.append({"bit": bit, "step": step, "served": True,
                           "predicted_point_equals_actual": True})
    return {"cases": checks, "all_six_equal": len(checks) == 6,
            "scope": "Requester knows t; comparison checks only the reply point. Records reuse a signed commitment, so valid opening is not claimed.",
            "aggregate_extractor": "NOT_IMPLEMENTED",
            "full_token_simulator": "NOT_IMPLEMENTED",
            "new_security_theorem": "NONE"}
