# CipherAuth Batch 01r1 — response to independent review

Claude's verdict on Batch 01 was **accept for research use, with repairs**.
The code and claims were checked against the supplied review package in a separate
workspace. The original batch, reviewer package, and nested CEA baseline remain
byte-preserved inputs. This response and revision are authored by ChatGPT; they
are not a second independent approval of the revision.

## Independent reproduction

On Python 3.12.14 with cryptography 50.0.2:

- Original Batch 01: 15 tests, no failures/errors/skips.
- Claude's patch applied without changes: 19 tests, no failures/errors/skips.
- Both runs: 85 baseline hashes matched, 39 baseline tests with no skips, frozen v3 12/12.
- All reviewer probe output matched probe_output.json exactly, including both-bit E-only
  recovery without the guard and refusal with the guard.

The three actual replay outputs are preserved under results/review_replay/. They differ
from the reviewer's environment versions as expected. Current revision results are in
results/observed.json and results/unit_tests.txt.

## Repairs and qualifications

| Finding | Revision |
| --- | --- |
| M1: missing extraction-model boundary | State the BFW limitations and separate stand-alone proof behavior from adaptive extraction; identify AGM+ROM as a candidate model, not a theorem inherited from FPS20. |
| M2: wrong proxy refusal input | Add Policy.REGISTERED_POINT with (origin,A) refusal. Keep Policy.REGISTERED_CORE solely as a legacy negative control. Include E-only and A-shift experiments under both rules. |
| M3: unnecessary single-hop preservation requirement | Target compressed origin-level verification before delegation. Post-delegation preservation is a separate optional multi-hop/audit goal. |
| L1: misnamed 2A test | Rename it as a doubling-A mutation control; retain Claude's distinct actual-transform test. |
| L2: costs incomplete | Report 65 added proof bytes, 130 authentication/validity field bytes, and two counted scalar multiplications per intake check. No timing or implemented batch-MSM claim. |
| L3: incomplete source audit | Add BFW and SJ00; mark AFM as abstract/metadata only and identify Kondi–shelat as a directly relevant pending full-text comparison. |
| L4: adversary-view test is limited | Preserve the limited field-name check and the actual probe evidence; do not describe it as a type-system or full information-flow guarantee. |

The M1 wording is intentionally narrower than two phrases in the review. A metareduction
excluding a class of reductions is not an unconditional impossibility of ROM-only security;
we also do not assert a universal 2^n extraction lower bound from the short description.
Likewise, the expectation that FPS20 and Chen–Zhao can be combined is a research hypothesis,
not a completed reduction or evidence of novelty. The source reading limits are explicit.

## Revision coverage

The four reviewer tests are retained unchanged. Seven additional tests cover the corrected
point refusal, the residual A-shift attack without the guard, guard rejection with continued
ordinary service, missing-proof/exact-input refusal, a fresh adversarial-sender request,
combined A/E mutation, and the two-multiplication intake-check cost.

The demonstration now runs 20 cases: two bits, two attack forms, and five configurations
(class denial; legacy refusal without/with guard; current point refusal without/with guard).
Successful attacks are expected negative controls. No all-adversary theorem follows.

The intake proof and sender adapter were not changed. No aggregate proof was implemented.
The frozen b baseline is not patched: its old ledger/game text remains historical input,
and its proxy-refusal defect is documented here. A future integrated workspace must keep
recipient-decryption rules separate from proxy rules rather than treating its old
(origin,A,E) ledger as a proxy security definition.

## Decision for subsequent work

Keep CipherAuth and STOC 2027. The next research task is the proof and novelty gate in
NEXT_RESEARCH_GATE.md, before implementing or advertising a new main construction.
A theory paper's secure construction requires a complete reduction and a contribution
beyond known composition. This repaired test baseline does not yet supply either.
