# Assistance and review log — CipherAuth Batch 01r1

- The supplied b CEA workspace was authored with Claude assistance and independently
  inspected/reproduced by ChatGPT in the preceding work. It remains a frozen input.
- ChatGPT authored Batch 01, a standard individual intake-proof comparator and experiment.
- Claude independently reviewed Batch 01, reproduced it, wrote probes and four additional
  tests, and accepted it for research use with repairs. The exact review is preserved
  under provenance/CipherAuth_Batch01_Review_2026-10-25.zip.
- ChatGPT independently replayed the original, reviewer patch, and probes, then authored
  Batch 01r1's policy/experiment repairs and revised explanations. The original intake
  proof, sender adapter, and the four reviewer tests are unchanged. Revision changes
  await independent review.
- All security, novelty and final submission claims require human authors' verification.
  Passing tests certify neither security nor publication readiness. No main theorem exists.

Human authors should adapt this factual log to the conference's disclosure requirements.


## 01r2

Claude independently accepted 01r1 for research use with minor repairs, authored three
additional tests and reported detailed source reading. ChatGPT reproduced its outputs,
integrated those tests, and authored the conditional algebra note and six-query control.
The new note/control and revisions await independent and human proof review. Source
reading claims are attributed separately; blocked direct PDF checks remain pending.
No aggregate extractor, new main construction or main security theorem was produced.
