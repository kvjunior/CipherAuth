# Exact scope of CipherAuth Batch 01r2

## Statement and proof baseline

K and A are valid nonidentity P-256 points. The sender knows t with A=tK, samples w,
computes U=wK, derives c=H(K,U,A,context), and returns z=w-ct mod q.
Verification checks U=zK+cA. The context binds suite, complete origin/sender references,
tag, epoch, and the complete current record body including A and E.

This is a known Schnorr/Fiat–Shamir proof pattern, not a new technique. The proof must
be generated while the sender knows t. The aggregator is not given t. The proof code
and sender adapter are byte-identical to the independently reviewed original batch.

## Extraction and confidentiality models

Stand-alone knowledge proofs do not automatically give the adaptive extraction required
by a chosen-ciphertext reduction. BFW15/648 gives a negative result for adaptive
Fiat–Shamir–Schnorr proofs under its stated assumptions. BFW15/649 excludes a substantial
class of reductions for signed ElGamal; this is not a proof of ciphertext insecurity or
an unconditional impossibility of every ROM-only proof. We do not assert a universal
2^n bound on all possible extractors.

FPS20 gives signed-ElGamal and signed-hashed-ElGamal results in AGM+ROM, while SJ00 uses
a generic-group/random-oracle setting. Those are results for specified schemes/games,
not inherited theorems for CEA or this guard. A future reduction must state its precise
model, assumptions, extraction task and oracle rules. An alternative straight-line proof
system would be a changed construction with its own costs. Sources/read limits are in
sources.md. No full security or extraction reduction is supplied here.

## Proxy refusal versus recipient opening

The proxy transforms A. Its current registered-input refusal key is (origin,A), so merely
flipping E does not obtain the challenge's transformed point. The old (origin,A,E) rule
remains explicitly available as a flawed negative control. It is not the current proxy rule.

This distinguishes two failures: E-only mutation defeats the legacy refusal, whereas
A-shifting defeats either exact-equality refusal when the proof guard is absent.
With the guard, the tested A-shift replays, transplanted proofs, and unrelated-witness
proofs are rejected. The proof, rather than an expanding refusal list, addresses the
demonstrated A-shift attack. This is experimental evidence, not a general security proof.

The frozen baseline's DerivativeLedger is unchanged. Its origin/A/E bookkeeping must
not be read as adequate proxy-side derivative handling. Recipient opening checks its
commitment; proxy service and local decryption by a corrupted delegatee are distinct.
A complete game's derivative rules still require a reduction-specific definition.

## Experiment scope and service controls

The harness is deliberately restricted to one record. It is not a complete PRE/RCCA
experiment or a claimed formal equivalence to the Canetti–Hohenberger game. It tests
both challenge bits under class denial, legacy core refusal, and current point refusal,
with the specified proof-guard settings. The attack receives public input and the
delegatee's own secret; origin key, token scalar, encryption witness and bit stay in
trusted fixtures.

Serving fresh honest and adversarial-sender requests is a useful positive control.
It does not establish a theorem that every admissible request is served. Denying the
whole class is explicitly reported as a separate control.

## Single-hop target

For the chosen single-hop flow, the proxy checks the proof before transforming A.
The delegatee then checks the opened commitment; this flow does not require the intake
proof to verify after delegation. The next question is verification of a compressed
origin-level proof at the proxy, with adaptive extraction sufficient for confidentiality.
Proof preservation after delegation is an optional additional requirement for multi-hop
verification or audit, outside the current single-hop target.

The 2A test is labeled as a record-mutation control. The separate actual-transform
test checks Abar=Omega^-1*A and the transformed verification equation. Keeping the
original challenge scalar makes that equation hold, but the Fiat–Shamir hash binds
the original inputs. These tests neither provide a new transformed proof nor prove
that proof preservation is impossible.

## Costs and remaining limitations

One proof encodes U (33 bytes) and z (32 bytes): 65 bytes added per record. Together
with Lambda and c, authentication/validity field data total 130 bytes per record;
A,E,metadata and the existing aggregate scalar are accounted for separately. This
extension has no new canonical aggregate wire format. Intake verification adds two
counted scalar multiplications per record. No timings or batch-MSM implementation
are claimed.

Still open: aggregate adaptive extraction, integrated confidentiality, a complete
batch game, and novelty after comparing the exact relevant constructions. In-class
key recovery and revocation limitations of the inherited token remain. Knowing t
does not prove that a malicious sender formed a correct opening. No theorem here
repairs these limitations.

## 01r2: precise provenance of the theorem refinements

Claude reports checking BFW15/648 Theorem 3 in its Definition 6 game: an appropriate
n-proof prover forces the stated extractor either to use at least 2^n rewound copies
or to yield an OMDL solver. This is a claim for that specified prover, extractor/game
and assumptions, not every extractor for every protocol. ChatGPT's direct full-text
fetches were blocked in this pass, so this detailed formulation remains reviewer-
reported rather than independently verified here.

Claude also reports FPS20 Section 6, Theorem 5, for signed-ElGamal IND-CCA2 against
algebraic adversaries, with DL/DDH terms and a per-query proof analysis. The numerical
bound remains unverified; the garbled extracted fraction is deliberately not restated
as a certified theorem. Primary abstracts confirm AGM+ROM positive results. The
publisher's notes warn that a general extraction claim alone did not replace the
scheme-specific proof. SJ00's generic-group/ROM characterization is abstract-level
only in this project's source audit, not a checked full theorem.

The three review controls cover doubling, negation and continued service after
refusals. The general algebraic statement requires nonzero, nonidentity scaling,
or an invertible affine map producing a new nonidentity point. See the complete
proof in research/PROXY_EXTRACTION_NOTE.md.

That note also proves a conditional response identity: given correct Q=k^-1*A and
omega, the reply is omega^-1*Q. It does not extract Q, simulate the public token,
or prove an aggregate confidentiality theorem. The main unresolved question is
online simulation of every accepted compressed query's decapsulation outputs.
