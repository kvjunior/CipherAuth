# CipherAuth — Batch 01r2

**Working project name: CipherAuth.** ADS-PRE names the historical manuscript only.
A final paper title depends on an established main result. STOC 2027 remains the target.

The original batch was independently reviewed by Claude and accepted for research use
with repairs. This revision implements those repairs; its changes await independent review.
It is a research comparator, with no new main theorem or full confidentiality proof.

Run with Python 3.11+:

    python3 scripts/reproduce.py

The runner checks source/input hashes, reproduces the byte-preserved b baseline in a
temporary directory, then runs this revision's tests and experiments. The optional
cryptography cross-check and any skipped baseline tests are reported. No new dependency
is required. See results/observed.json and results/unit_tests.txt for the actual local run.

## Implemented behavior

- A known unaggregated Schnorr/Fiat–Shamir intake proof for t in A=tK, with complete
  current-record binding and a strict 65-byte encoding. Its implementation is unchanged.
- A sender adapter generating the proof while the sender knows t.
- An explicit one-record proxy experiment. The current refusal key is (origin,A), the
  point the proxy transforms. The legacy (origin,A,E) policy remains a negative control.
- Both challenge bits, E-only mutation and A-shifting, with and without the proof guard.
  Ordinary fresh same-class requests are served under both point-refusal configurations.
- The reviewer's four added controls, a real delegation-transform check, and additional
  corrected-policy controls. No aggregate validity-proof implementation is present.

The intake proof adds 65 field bytes per record. Authentication plus validity fields
(Lambda,c,U,z) total 130 bytes per record, beside A,E and metadata. The intake check makes
two counted scalar-multiplication calls per record, in addition to sender authentication
and delegation. These are field sizes and operation counts, not a new wire format or timing.

This revision also gives elementary conditional algebra in research/PROXY_EXTRACTION_NOTE.md.
It adds no aggregate proof or full security theorem.

## Reading order

| Path | Purpose |
| --- | --- |
| REVIEW_R1_RESPONSE.md | Latest review response and precise research decision |
| REVIEW_RESPONSE.md | Historical response to the first review |
| research/ | Conditional algebra note, six-query control and source-access record |
| THEORY_BOUNDARY.md | Models, evidence, and unproved properties |
| NEXT_RESEARCH_GATE.md | Precise single-hop proof/compression question and novelty gate |
| STATUS.md | Existing-code and research status |
| batch01/ | Single-record proof, sender adapter, proxy policies, attacks |
| tests/ | Original tests, reviewer controls, and revision controls |
| scripts/reproduce.py | One-command isolated reproduction |
| results/ | Actual observations; not security guarantees |
| baseline/ | Exact supplied b archive; unchanged |
| provenance/ | Exact earlier batch and review ZIPs; unchanged |
| REVIEW_PROMPT.md | Instructions for independent review of this revision |
| sources.md | Primary references and reading limits |
| manifest.json | Input/source hashes; generated results are excluded |

The prototype retains the supplied research arithmetic and token limitations.
