# Response to Claude's review of CipherAuth Batch 01r1

The review accepts 01r1 for research use with minor repairs. ChatGPT independently
replayed the original 26-test revision, the supplied 29-test patch, and every probe.
All passed without skips; all 20 original experiment cases reproduced. The probe
JSON matched exactly. Each replay also reproduced the baseline's 85 hashes,
39 tests without skips, and v3 12/12. Environment: Python 3.12.14, cryptography 50.0.2.
Actual outputs are in results/review_r1_replay/.

## Disposition

| Finding | Disposition |
| --- | --- |
| R1: theorem scope/precision | Preserve the reviewer's precise theorem pointers and reported scope, but mark exact full-text verification as pending for this implementation pass. Do not certify the garbled FPS20 bound. |
| R2: scaling/negation | Integrate all three reviewer tests, unchanged. Qualify the universal wording: invertible nonidentity scalar maps bypass point refusal; the zero and identity maps do not give that attack. |
| R3: generator/public-key relabeling | Record the exact algebra with its full proof; do not transfer a security theorem through it. |
| Proposed proxy-basis obstacle | Refine it with an elementary conditional reply-simulation lemma. Once correct Q and omega are available, the response point is omega^-1*Q. Obtaining Q and simulating the whole token transcript remain open. |

The standard intake proof, sender adapter, proxy policies, original 20 cases and all
existing tests are unchanged. This revision adds the reviewer's three tests, a theory
note and a six-response algebra control. It implements no compressed proof.

## Source verification boundary

Primary abstracts and the FPS20 publisher's notes were retrieved. The exact BFW/FPS20
PDF routes returned HTTP 403 in this pass; therefore the theorem excerpts are attributed
to Claude's review, not described as independently read here. Kondi–shelat remains
abstract/author-summary only; SJ00 and AFM full theorem checks and IDASR26 full text
remain unresolved. Access failures are recorded under research/source_access.json.
The source ledger distinguishes the reviewer's reading from ChatGPT's verification.

BFW's general lesson and FPS20's AGM+ROM setting are supported by the retrieved primary
sources. A numerical bound or detailed case analysis must be checked from readable
full text before appearing as verified in the paper. Exact theorem pointers and
accurate restatements suffice; long verbatim quotations are unnecessary.

## Research progress and remaining status

research/PROXY_EXTRACTION_NOTE.md gives complete elementary proofs of the affine
attack and the conditional reply identity/adaptive corollary. They are useful scope
clarifications, not claimed new techniques. The note also explains the unproved
premises rather than disguising them as a security theorem.

The next research task is online decapsulation simulation from a compressed proof,
with the exact allowed-query exceptions and a full token/grant simulation. Witness
extraction is one sufficient route. The reviewer is right that aggregate unforgeability
does not supply it. The presence of proxy reply points alone does not yet identify
where new theory is required.

Original archives remain unchanged under baseline/ and provenance/. The project remains
CipherAuth, target STOC 2027. No new main theorem or publication-readiness claim is made.
