# CipherAuth Batch 01r2 changes

- Integrate Claude's three 01r1-review tests without modification; retain existing code/tests.
- Attribute detailed theorem formulations to their actual reviewer; mark the exact FPS20
  bound and independent full-text checks pending instead of certifying garbled extraction.
- Add complete elementary affine-attack and conditional proxy-reply proofs, with explicit
  token/transcript assumptions and no claimed novelty or full security reduction.
- Add a six-response known-randomness comparison without changing the main protocol.
- Preserve both review archives and preceding batch ZIPs, update current entry points,
  record actual replay/source access results, and regenerate intentional source hashes.

The prior revision history follows.

# CipherAuth Batch 01r1 changes

## From the independently reviewed Batch 01

- Retain the standard proof and sender adapter without byte changes.
- Integrate Claude's four review controls without byte changes.
- Add an explicit current proxy-input refusal key (origin,A). Retain the flawed legacy
  (origin,A,E) rule under its original policy name solely for attack reproduction.
- Add E-only and corrected-policy attack controls, including continued ordinary service
  and combined A/E mutation; run both bits across the expanded demonstration matrix.
- Recover using the original public E when the request changes that field.
- Rename the original 2A test and retain the separate real-transform test.
- Check the two scalar-multiplication intake cost; report full authentication/validity
  field counts without inventing a revised wire format or benchmark timing.
- Replace claim/status/prompt text with the narrower single-hop extraction target and
  explicit model/source limits. Add REVIEW_RESPONSE.md and NEXT_RESEARCH_GATE.md.
- Preserve the exact baseline, original Batch 01 ZIP and reviewer ZIP. Actual original,
  patched and probe replay results are included. Regenerate source hashes and revision
  observations only after intentional edits.

No aggregate proof, new theorem, full CEA security repair, or novelty claim was added.
