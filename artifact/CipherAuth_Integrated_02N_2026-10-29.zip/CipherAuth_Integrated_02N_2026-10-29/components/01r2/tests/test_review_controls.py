"""Controls added by the independent review (Claude, 25 Oct 2026). Passing them is not a proof."""
import unittest
from dataclasses import replace
from cipherauth import group as g
from cipherauth.cea import parse_body, _body, _kdf, _xor
from cipherauth.encoding import encode
from batch01 import intake_pok as p
from batch01.cea_adapter import binding, verify_record_proof
from batch01.experiment import Scenario, MESSAGES
from batch01.oracle_experiment import Policy


def _open_locally(view, delegated, E):
    C, gamma, _ = delegated.token_public
    T = g.mul(g.inv(view.delegatee_secret.k), g.decode_point(gamma))
    mask = g.hash_bytes("cea/rk-mask", encode((g.encode_point(T), view.origin.fields())))
    omega = int.from_bytes(_xor(C, mask), "big")
    Abar = parse_body(delegated.aggregate.records[0].body)[2]
    return _xor(E, _kdf(g.mul(omega, Abar), len(E)))


class ReviewControls(unittest.TestCase):
    def _E_only(self, s):
        rec = s.view.challenge_aggregate.records[0]
        Lam, c, A, E = parse_body(rec.body)
        flipped = replace(rec, body=_body(Lam, c, A, bytes([E[0] ^ 1]) + E[1:]))
        return replace(s.view.challenge_aggregate, records=(flipped,)), E

    def test_E_only_mutation_bypasses_registered_core_refusal_without_guard(self):
        """The registered core (origin, A, E) is the wrong key for proxy-side refusal: only A is
        transformed, so changing E (no group operation) already yields a non-registered core."""
        for bit in (0, 1):
            s = Scenario(bit, Policy.REGISTERED_CORE, False)
            agg, E = self._E_only(s)
            d = s.oracle.query(agg, s.view.challenge_proof)
            self.assertEqual(d.reason, "served")
            self.assertEqual(_open_locally(s.view, d.output, E), MESSAGES[bit])

    def test_E_only_mutation_is_refused_with_guard(self):
        for bit in (0, 1):
            s = Scenario(bit, Policy.REGISTERED_CORE, True)
            agg, _ = self._E_only(s)
            self.assertEqual(s.oracle.query(agg, s.view.challenge_proof).reason, "intake-proof-invalid-or-missing")

    def test_transplanted_and_own_witness_proofs_are_refused(self):
        s = Scenario(0, Policy.REGISTERED_CORE, True)
        ordinary, ordinary_proof = s.ordinary_request()
        rec = s.view.challenge_aggregate.records[0]
        Lam, c, A, E = parse_body(rec.body)
        K = g.decode_point(s.view.origin_public)
        t_own = g.random_scalar()
        combined = replace(rec, body=_body(Lam, c, A + g.mul(t_own, K), E))
        own_proof = p.prove(t_own, s.view.origin_public, g.encode_point(g.mul(t_own, K)), binding(combined))
        agg = replace(s.view.challenge_aggregate, records=(combined,))
        self.assertEqual(s.oracle.query(agg, ordinary_proof).reason, "intake-proof-invalid-or-missing")
        self.assertEqual(s.oracle.query(agg, own_proof).reason, "intake-proof-invalid-or-missing")

    def test_actual_delegation_transform_and_why_the_proof_does_not_carry(self):
        """Uses the real transform Abar = Omega^-1 A (trusted fixture), not 2A. The verification
        equation transforms with U -> Omega^-1 U, K -> Omega^-1 K and the SAME challenge c, but c
        binds the original (K, U, A, record), which a post-delegation verifier does not have.
        Single-hop note: after delegation no party needs this proof (the delegatee checks the
        commitment); survival matters only for multi-hop or third-party audit."""
        s = Scenario(0, Policy.REGISTERED_CORE, True)
        tok = s.oracle._token
        d = s.system.delegate_aggregate(tok, s.oracle._grant, s.view.challenge_aggregate)
        drec, orec = d.aggregate.records[0], s.view.challenge_aggregate.records[0]
        self.assertFalse(verify_record_proof(s.system, drec, s.view.challenge_proof))
        old = p.Proof.decode(s.view.challenge_proof)
        inv = g.inv(tok.Omega)
        c = p.challenge(s.view.origin_public, old.commitment, g.encode_point(parse_body(orec.body)[2]), binding(orec))
        lhs = g.mul(inv, g.decode_point(old.commitment))
        rhs = g.mul(old.response, g.mul(inv, g.decode_point(s.view.origin_public))) + g.mul(c, parse_body(drec.body)[2])
        self.assertEqual(lhs, rhs)


if __name__ == "__main__":
    unittest.main()
