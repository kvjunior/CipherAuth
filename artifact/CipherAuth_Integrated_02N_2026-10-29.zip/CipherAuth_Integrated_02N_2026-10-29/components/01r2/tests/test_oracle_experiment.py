import unittest
from dataclasses import replace, fields
from batch01.experiment import Scenario, AttackView, run_case, mauled_request
from batch01.oracle_experiment import Policy
from batch01.cea_adapter import verify_record_proof
from cipherauth.cea import parse_body, _body
from cipherauth import group as g

class OracleExperimentTests(unittest.TestCase):
    def test_unknown_policy_and_nonboolean_guard_are_rejected(self):
        with self.assertRaises(ValueError):
            Scenario(0,"typo-in-policy",False)
        with self.assertRaises(ValueError):
            Scenario(0,Policy.REGISTERED_CORE,1)

    def test_class_denial_is_distinct_from_a_cryptographic_fix(self):
        for bit in (0,1):
            result=run_case(bit,Policy.CLASS_DENY,False)
            self.assertFalse(result["ordinary_same_class_request_served"])
            self.assertFalse(result["challenge_message_recovered"])

    def test_unprotected_registered_core_experiment_reproduces_attack(self):
        for bit in (0,1):
            result=run_case(bit,Policy.REGISTERED_CORE,False)
            self.assertTrue(result["ordinary_same_class_request_served"])
            self.assertTrue(result["challenge_message_recovered"])

    def test_intake_proof_blocks_old_proof_replay_and_keeps_service(self):
        for bit in (0,1):
            result=run_case(bit,Policy.REGISTERED_CORE,True)
            self.assertTrue(result["ordinary_same_class_request_served"])
            self.assertEqual(result["mauling_decision"],"intake-proof-invalid-or-missing")
            self.assertFalse(result["challenge_message_recovered"])

    def test_missing_proof_is_not_silently_accepted(self):
        s=Scenario(0,Policy.REGISTERED_CORE,True)
        ordinary,_=s.ordinary_request()
        decision=s.oracle.query(ordinary,None)
        self.assertIsNone(decision.output)
        self.assertEqual(decision.reason,"intake-proof-invalid-or-missing")

    def test_adversary_view_excludes_origin_and_token_secrets(self):
        self.assertEqual({f.name for f in fields(AttackView)},
                         {"origin","origin_public","delegatee_secret","challenge_aggregate",
                          "challenge_proof","messages"})

    def test_doubling_A_rejects_the_original_proof(self):
        # A distinct transformed point changes the challenge transcript. This
        # negative control is not the actual delegation transform.
        s=Scenario(0,Policy.REGISTERED_CORE,True)
        record=s.challenge.submission.record; Lam,c,A,E=parse_body(record.body)
        transformed=replace(record,body=_body(Lam,c,g.mul(2,A),E))
        self.assertFalse(verify_record_proof(s.system,transformed,s.challenge.proof))
