"""Controls added by Claude's review of Batch 01r1. Passing them is not a proof."""
import unittest
from dataclasses import replace
from cipherauth import group as g
from cipherauth.cea import parse_body, _body, _kdf, _xor
from cipherauth.encoding import encode
from batch01.experiment import Scenario, MESSAGES
from batch01.oracle_experiment import Policy


def _request(s, A_new):
    rec = s.view.challenge_aggregate.records[0]
    Lam, c, _, E = parse_body(rec.body)
    return replace(s.view.challenge_aggregate, records=(replace(rec, body=_body(Lam, c, A_new, E)),))


def _recover_after_linear_map(view, delegated, scale_inv):
    """Adversary undoes a known scalar map A' = s*A*: Q* = s^-1 * (omega * Abar)."""
    C, gamma, _ = delegated.token_public
    T = g.mul(g.inv(view.delegatee_secret.k), g.decode_point(gamma))
    mask = g.hash_bytes("cea/rk-mask", encode((g.encode_point(T), view.origin.fields())))
    omega = int.from_bytes(_xor(C, mask), "big")
    Abar = parse_body(delegated.aggregate.records[0].body)[2]
    E = parse_body(view.challenge_aggregate.records[0].body)[3]
    Q = g.mul(scale_inv, g.mul(omega, Abar))
    return _xor(E, _kdf(Q, len(E)))


class ReviewR1Controls(unittest.TestCase):
    def test_any_known_scalar_map_of_A_defeats_point_refusal_without_guard(self):
        for bit in (0, 1):
            for s_ in (2, g.q - 1):                      # doubling and negation
                sc = Scenario(bit, Policy.REGISTERED_POINT, False)
                A = parse_body(sc.view.challenge_aggregate.records[0].body)[2]
                d = sc.oracle.query(_request(sc, g.mul(s_, A)), sc.view.challenge_proof)
                self.assertEqual(d.reason, "served")
                self.assertEqual(_recover_after_linear_map(sc.view, d.output, g.inv(s_)), MESSAGES[bit])

    def test_guard_refuses_scaled_negated_and_shifted_points(self):
        sc = Scenario(1, Policy.REGISTERED_POINT, True)
        A = parse_body(sc.view.challenge_aggregate.records[0].body)[2]
        K = g.decode_point(sc.view.origin_public)
        for A_new in (g.mul(2, A), g.mul(g.q - 1, A), A + g.mul(7, K)):
            self.assertEqual(sc.oracle.query(_request(sc, A_new), sc.view.challenge_proof).reason,
                             "intake-proof-invalid-or-missing")

    def test_service_continues_after_refusals(self):
        sc = Scenario(0, Policy.REGISTERED_POINT, True)
        A = parse_body(sc.view.challenge_aggregate.records[0].body)[2]
        K = g.decode_point(sc.view.origin_public)
        for r in (3, 4, 5):
            sc.oracle.query(_request(sc, A + g.mul(r, K)), sc.view.challenge_proof)
        ordinary, proof = sc.ordinary_request()
        self.assertEqual(sc.oracle.query(ordinary, proof).reason, "served")


if __name__ == "__main__":
    unittest.main()
