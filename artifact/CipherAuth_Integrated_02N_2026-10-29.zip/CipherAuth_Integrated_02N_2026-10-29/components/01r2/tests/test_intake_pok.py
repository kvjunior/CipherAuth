import unittest
from dataclasses import replace
from cipherauth import group as g
from cipherauth.cea import CEA, Directory, parse_body, _body
from cipherauth.errors import EncodingError
from batch01 import intake_pok as p
from batch01.cea_adapter import create_submission, verify_record_proof, binding

class IntakeProofTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.D=Directory(); cls.S=CEA(cls.D)
        cls.sender=cls.D.new_signing_key("sender")
        cls.origin=cls.D.new_decryption_key("origin",tag=b"tag",epoch=1)
        cls.checked=create_submission(cls.S,cls.sender,"origin",b"message",b"tag",1)

    def test_honest_submission_and_proof_verify(self):
        self.assertTrue(self.S.check_submission(self.checked.submission))
        self.assertTrue(verify_record_proof(self.S,self.checked.submission.record,self.checked.proof))

    def test_exact_proof_roundtrip(self):
        self.assertEqual(len(self.checked.proof),65)
        self.assertEqual(p.Proof.decode(self.checked.proof).encode(),self.checked.proof)

    def test_malformed_proofs_are_rejected(self):
        r=self.checked.submission.record
        variants=[b"",self.checked.proof[:-1],self.checked.proof+b"x",
                  b"\x04"+self.checked.proof[1:],
                  self.checked.proof[:33]+g.q.to_bytes(32,"big")]
        for proof in variants:
            self.assertFalse(verify_record_proof(self.S,r,proof))
        self.assertFalse(verify_record_proof(self.S,r,None))

    def test_wrong_witness_is_rejected(self):
        base=g.encode_point(g.mul(11,g.G)); point=g.encode_point(g.mul(13,g.decode_point(base)))
        with self.assertRaises(EncodingError):
            p.prove(14,base,point,b"context")

    def test_origin_and_payload_context_are_bound(self):
        r=self.checked.submission.record
        Lam,c,A,E=parse_body(r.body)
        changes=[replace(r,epoch=2), replace(r,tag=b"other"),
                 replace(r,body=_body(Lam,c,A,bytes([E[0]^1])+E[1:]))]
        for changed in changes:
            self.assertFalse(verify_record_proof(self.S,changed,self.checked.proof))

    def test_changed_encryption_point_rejects_original_proof(self):
        r=self.checked.submission.record; Lam,c,A,E=parse_body(r.body)
        K=self.D.point(r.origin)
        changed=replace(r,body=_body(Lam,c,A+g.mul(7,K),E))
        self.assertFalse(verify_record_proof(self.S,changed,self.checked.proof))

    def test_obvious_linear_response_translation_is_rejected(self):
        r=self.checked.submission.record; Lam,c,A,E=parse_body(r.body)
        base=self.D.registry.resolve(r.origin).encoded_key
        old=p.Proof.decode(self.checked.proof)
        challenge=p.challenge(base,old.commitment,g.encode_point(A),binding(r))
        changed=replace(r,body=_body(Lam,c,A+g.mul(7,g.decode_point(base)),E))
        translated=p.Proof(old.commitment,(old.response-7*challenge)%g.q).encode()
        self.assertFalse(verify_record_proof(self.S,changed,translated))

    def test_wrong_base_rejects_the_proof(self):
        r=self.checked.submission.record; A=parse_body(r.body)[2]
        wrong=g.encode_point(g.mul(23,g.G))
        self.assertFalse(p.verify(wrong,g.encode_point(A),binding(r),self.checked.proof))
