"""Revision controls for the proxy-input policy; these are not a security proof."""
from dataclasses import replace
import unittest

from cipherauth import group as g
from cipherauth.cea import parse_body, _body
from batch01.cea_adapter import create_submission, verify_record_proof
from batch01.experiment import Scenario, run_case, MESSAGES, local_recovery
from batch01.oracle_experiment import Policy


class ProxyPolicyRevisionTests(unittest.TestCase):
    def test_proxy_point_refusal_blocks_E_only_without_the_proof_guard(self):
        for bit in (0, 1):
            result = run_case(bit, Policy.REGISTERED_POINT, False, attack="E-only")
            self.assertEqual(result["mauling_decision"], "registered-proxy-point-refused")
            self.assertFalse(result["challenge_message_recovered"])
            self.assertTrue(result["ordinary_same_class_request_served"])

    def test_proxy_point_refusal_alone_still_allows_point_shift_attack(self):
        for bit in (0, 1):
            result = run_case(bit, Policy.REGISTERED_POINT, False)
            self.assertTrue(result["challenge_message_recovered"])

    def test_proof_guard_blocks_point_shift_with_corrected_policy(self):
        for bit in (0, 1):
            result = run_case(bit, Policy.REGISTERED_POINT, True)
            self.assertEqual(result["mauling_decision"], "intake-proof-invalid-or-missing")
            self.assertTrue(result["ordinary_same_class_request_served"])

    def test_corrected_refusal_also_applies_when_proof_is_missing(self):
        scenario = Scenario(0, Policy.REGISTERED_POINT, True)
        decision = scenario.oracle.query(scenario.view.challenge_aggregate, None)
        self.assertEqual(decision.reason, "registered-proxy-point-refused")
        self.assertIsNone(decision.output)

    def test_fresh_adversarial_sender_request_is_served(self):
        scenario = Scenario(0, Policy.REGISTERED_POINT, True)
        sender = scenario.directory.new_signing_key("adversarial-sender")
        record = scenario.view.challenge_aggregate.records[0]
        checked = create_submission(scenario.system, sender, "origin", b"known fresh data",
                                    record.tag, record.epoch)
        aggregate = scenario.system.aggregate(scenario.context, [checked.submission])
        decision = scenario.oracle.query(aggregate, checked.proof)
        self.assertEqual(decision.reason, "served")

    def test_combined_point_and_E_changes_need_the_guard(self):
        for bit in (0, 1):
            for guard in (False, True):
                scenario = Scenario(bit, Policy.REGISTERED_POINT, guard)
                aggregate = scenario.view.challenge_aggregate
                original = aggregate.records[0]
                Lam, c, A, E = parse_body(original.body)
                K = g.decode_point(scenario.view.origin_public)
                altered_E = bytes([E[0] ^ 1]) + E[1:]
                record = replace(original, body=_body(Lam, c, A + g.mul(7, K), altered_E))
                request = replace(aggregate, records=(record,))
                decision = scenario.oracle.query(request, scenario.view.challenge_proof)
                if guard:
                    self.assertEqual(decision.reason, "intake-proof-invalid-or-missing")
                    self.assertIsNone(decision.output)
                else:
                    self.assertEqual(decision.reason, "served")
                    self.assertEqual(local_recovery(scenario.view, decision.output), MESSAGES[bit])

    def test_intake_verifier_uses_two_counted_scalar_multiplications(self):
        scenario = Scenario(0, Policy.REGISTERED_POINT, True)
        record = scenario.view.challenge_aggregate.records[0]
        g.reset_counts()
        self.assertTrue(verify_record_proof(scenario.system, record, scenario.view.challenge_proof))
        self.assertEqual(g.COUNTS["mul"], 2)
