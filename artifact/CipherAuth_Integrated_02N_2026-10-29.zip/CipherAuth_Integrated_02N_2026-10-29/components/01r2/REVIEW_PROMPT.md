# CipherAuth 01r2 — review the theory decision, then the small integration

Use CipherAuth and retain STOC 2027. The original single-record proof and policies
are frozen in this revision. Do not start another cosmetic repair cycle or implement
an unproved main construction merely to increase the test count.

1. Run python3 scripts/reproduce.py in a separate copy. Expect 29 unit tests, the same
   20 attack/control cases, six additional conditional reply comparisons, and the
   unchanged baseline (85 hashes, 39 tests, v3 12/12). Report actual versions/skips.
2. Check the integration of your three tests and verify that no previous test, proof
   module, sender adapter, proxy policy, or immutable archive was changed.
3. Read research/PROXY_EXTRACTION_NOTE.md critically. Check the general affine attack
   conditions, the formula Abar=omega^-1*Q, and the adaptive induction. Look for an
   omitted assumption. Distinguish an elementary conditional equality from an extractor,
   complete token simulator, security reduction or new technique.
4. Check whether, once t_i or correct Q_i is available, a proxy response really adds
   a new unknown basis element. If you still believe it necessarily does, give an
   exact counterexample to the lemma's stated premises. The W=H(Omega), grant, corruption
   and random-oracle consistency tasks are explicitly not solved by the lemma.
5. Move the theory gate forward: specify a single exact online aggregate-decapsulation
   simulation lemma, including prior honest/simulated proof exceptions, growing transcripts,
   chosen keys, grants and proxy replies. Either prove it with complete loss accounting,
   give a counterexample, or explain exactly which proof step remains open. Do not
   substitute IASchnorr unforgeability for extraction or count unknown premises as proved.
6. Compare exact full-text FPS20/CZ22/BFW/Kondi–shelat results and IDASR26 where available.
   Keep per-reviewer source provenance: this pass could not fetch the BFW/FPS20 PDFs.
   Do not turn a garbled bound or a previous model's claimed reading into independent
   verification. Report inaccessible sources explicitly without guessing their theorems.
7. Classify the candidate as known composition / possible new lemma, proof incomplete /
   contradicted by an attack. State what distinguishes any claimed new theorem from
   existing machinery. A short unsuccessful search is not evidence of a literature gap.

Return a concise integration verdict and a substantive theory decision, with precise
proofs or counterexamples and primary-source locations. Keep new protocol code out
until the proof/novelty decision warrants it. Preserve all immutable archives and never
claim that passing tests establish security or STOC acceptance.
