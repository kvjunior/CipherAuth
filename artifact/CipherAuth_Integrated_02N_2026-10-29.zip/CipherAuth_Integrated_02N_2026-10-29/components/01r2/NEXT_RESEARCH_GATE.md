# Next research gate: proxy verification of compressed origin-level proofs

The single-hop target is a proxy that validates an origin aggregate before delegation.
Independent senders generate proofs with independent witnesses t_i, using the same
class base K. The aggregator receives their records/proofs, holds none of their
witnesses, and should retain a compressed proof without retaining individual responses.
No post-delegation proof-preservation requirement is imposed at this gate.

## Known-technique candidate, not a contribution claim

Each intake proof has U_i=z_i*K+c_i*A_i. Prefix coefficients b_i over a fully specified
transcript suggest retaining U_i and one scalar z_tilde=sum b_i*z_i. The algebraic
verification equation is:

    z_tilde*K = sum_i b_i*(U_i-c_i*A_i).

This is the natural half-aggregation template. The proposed validity payload would be
33n+32 field bytes, compared with 65n for the individual proofs, excluding all record
and batch framing. It adds that payload to the existing authentication data; it does
not remove Lambda,c or the sender aggregate scalar. No code or security theorem for
this candidate is included.

Chen–Zhao's aggregate unforgeability theorem is not an adaptive knowledge-extraction
theorem for these encryption points. FPS20's signed-encryption result is not a generic
theorem for compressing its proofs. Their proof techniques may suffice; that must be
demonstrated rather than assumed or presented as novelty.

## Required outputs before a main-construction batch

1. Specify one exact game, including malicious senders/aggregator/recipient, registration,
   grants, corruptions, challenge exclusions, aggregation queries and proxy service rules.
   Explain ordinary service and derivative handling without silently denying the class.
2. State the extraction task and all transcript exceptions. Previously supplied honest
   proofs, simulated challenge proofs, replays and newly crafted proofs cannot be conflated.
   Give a reduction that handles all accepted aggregate records, with polynomial costs
   and explicit loss; include the A-shift and E-only attack cases.
3. Fix the model before proving a bound. AGM+ROM is a candidate setting, not a completed
   reduction. Document every use of algebraic representations and every hash input.
   Do not drop record binding to obtain an easier equation.
4. Check the precise FPS20 and Chen–Zhao theorems, the BFW extraction limitations, and
   relevant straight-line-extraction/aggregation work including Kondi–shelat 2022/393.
   Resolve the IDASR26 full-text comparison. Shared-base, many-witness, independent-sender
   aggregation must be distinguished from one prover holding every witness.
5. Identify what the resulting theorem proves beyond known composition. If it follows
   directly from established machinery, retain it as a comparator and record that the
   novelty gate failed. An implementation or a missing search hit does not establish novelty.

An acceptable next theory deliverable is a complete lemma/reduction, a counterexample,
or a clearly documented known-composition result. A draft equation plus passing tests
is insufficient for a security or STOC contribution claim.


## Refinement after the 01r1 review

Read research/PROXY_EXTRACTION_NOTE.md before defining a new lemma. The simulator's
sufficient online task is obtaining correct decapsulation points Q_i for all accepted
records (or an explicitly permitted table entry), together with consistent token/grant
handling. Once Q_i and omega are available, reply points are omega^-1*Q_i even for
adaptive queries; the note proves this conditional statement. Raw scalar extraction
is sufficient but need not be the only route. Do not claim novelty merely because
further proxy-related points appear in the transcript.
