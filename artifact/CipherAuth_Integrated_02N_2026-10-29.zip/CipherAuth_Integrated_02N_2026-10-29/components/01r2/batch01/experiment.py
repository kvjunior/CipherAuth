"""Both-bit mauling experiments, positive controls, and explicit remaining limitations."""
from dataclasses import dataclass, replace
from cipherauth import group as g
from cipherauth.cea import CEA, Directory, SUITE, parse_body, _body, _kdf, _xor
from cipherauth.encoding import encode
from cipherauth.models import BatchContext
from .cea_adapter import create_submission, verify_record_proof
from .oracle_experiment import ProxyOracle, Policy

TAG, EPOCH = b"batch001", 1
MESSAGES = (b"challenge-left".ljust(32,b"\0"), b"challenge-right".ljust(32,b"\0"))

@dataclass(frozen=True)
class AttackView:
    """No origin secret, signing secret, re-key scalar, or encryption witness."""
    origin: object
    origin_public: bytes
    delegatee_secret: object
    challenge_aggregate: object
    challenge_proof: bytes
    messages: tuple[bytes, bytes]

class Scenario:
    def __init__(self, bit, policy, require_proof):
        if bit not in (0,1):
            raise ValueError("bit must be zero or one")
        self.bit = bit
        self.directory = Directory()
        self.system = CEA(self.directory)
        self.sender = self.directory.new_signing_key("sender")
        self.owner = self.directory.new_signing_key("origin")
        self.origin = self.directory.new_decryption_key("origin", tag=TAG, epoch=EPOCH)
        self.delegatee = self.directory.new_decryption_key("corrupted-delegatee")
        self.context = BatchContext(SUITE, "origin", self.origin.ref, self.origin.ref, EPOCH)
        self.challenge = create_submission(self.system, self.sender, "origin", MESSAGES[bit], TAG, EPOCH)
        agg = self.system.aggregate(self.context, [self.challenge.submission])
        token, grant = self.system.issue_grant(self.owner, self.origin, self.delegatee.ref, TAG, EPOCH)
        self.oracle = ProxyOracle(self.system, token, grant, self.challenge.submission.record,
                                  policy=policy, require_proof=require_proof)
        self.view = AttackView(self.origin.ref, self.directory.registry.resolve(self.origin.ref).encoded_key,
                               self.delegatee, agg, self.challenge.proof, MESSAGES)

    def ordinary_request(self):
        checked = create_submission(self.system, self.sender, "origin", b"ordinary request", TAG, EPOCH)
        aggregate = self.system.aggregate(self.context, [checked.submission])
        return aggregate, checked.proof

def mauled_request(view, shift=7):
    """Only public data, the challenge aggregate, and its old proof are used."""
    g.validate_scalar(shift, nonzero=True)
    original = view.challenge_aggregate.records[0]
    Lam, c, A, E = parse_body(original.body)
    K = g.decode_point(view.origin_public)
    record = replace(original, body=_body(Lam, c, A + g.mul(shift, K), E))
    return replace(view.challenge_aggregate, records=(record,)), view.challenge_proof

def masked_request(view):
    """Replay the challenge point with one flipped byte of its public E."""
    original = view.challenge_aggregate.records[0]
    Lam, c, A, E = parse_body(original.body)
    changed = bytes([E[0] ^ 1]) + E[1:]
    record = replace(original, body=_body(Lam, c, A, changed))
    return replace(view.challenge_aggregate, records=(record,)), view.challenge_proof

def local_recovery(view, delegated, shift=7):
    """Corrupted delegatee uses only its own key and the returned public token."""
    C, gamma, _ = delegated.token_public
    T = g.mul(g.inv(view.delegatee_secret.k), g.decode_point(gamma))
    mask = g.hash_bytes("cea/rk-mask", encode((g.encode_point(T), view.origin.fields())))
    omega = int.from_bytes(_xor(C, mask), "big")
    _, _, Abar, _ = parse_body(delegated.aggregate.records[0].body)
    # The adversary already has the original public E, even if the query altered it.
    E = parse_body(view.challenge_aggregate.records[0].body)[3]
    original_Q = g.mul(omega, Abar) - g.mul(shift, g.G)
    return _xor(E, _kdf(original_Q, len(E)))

def run_case(bit, policy, require_proof, *, attack="point-shift"):
    if attack not in ("point-shift", "E-only"):
        raise ValueError("explicit supported attack required")
    scenario = Scenario(bit, policy, require_proof)
    exact = scenario.oracle.query(scenario.view.challenge_aggregate, scenario.view.challenge_proof)
    if exact.output is not None:
        raise AssertionError("registered challenge was served")
    ordinary, ordinary_proof = scenario.ordinary_request()
    ordinary_decision = scenario.oracle.query(ordinary, ordinary_proof)
    should_serve_ordinary = policy is not Policy.CLASS_DENY
    if (ordinary_decision.output is not None) != should_serve_ordinary:
        raise AssertionError("ordinary admissible-request control failed")
    if attack == "point-shift":
        request, old_proof = mauled_request(scenario.view)
        shift = 7
    else:
        request, old_proof = masked_request(scenario.view)
        shift = 0
    decision = scenario.oracle.query(request, old_proof)
    recovered = None if decision.output is None else local_recovery(scenario.view, decision.output, shift)
    expected_recovery = (not require_proof and policy is not Policy.CLASS_DENY and
                         (attack == "point-shift" or policy is Policy.REGISTERED_CORE))
    if (recovered == MESSAGES[bit]) != expected_recovery:
        raise AssertionError("mauling outcome differed from the declared experiment")
    return {
        "challenge_bit": bit, "policy": policy.value, "require_intake_proof": require_proof,
        "attack": attack,
        "registered_challenge_refused": exact.output is None,
        "ordinary_same_class_request_served": ordinary_decision.output is not None,
        "mauling_decision": decision.reason,
        "challenge_message_recovered": recovered == MESSAGES[bit],
        "meaning": "Specific attack/control outcome only; no CCA, extraction, or aggregation theorem."
    }

def run_all():
    configurations = [(Policy.CLASS_DENY, False), (Policy.REGISTERED_CORE, False),
                      (Policy.REGISTERED_CORE, True), (Policy.REGISTERED_POINT, False),
                      (Policy.REGISTERED_POINT, True)]
    return [run_case(bit, policy, guard, attack=attack)
            for policy, guard in configurations for bit in (0,1)
            for attack in ("point-shift", "E-only")]
