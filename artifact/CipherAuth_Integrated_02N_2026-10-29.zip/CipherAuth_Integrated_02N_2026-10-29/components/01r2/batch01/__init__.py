"""CipherAuth Batch 01: known intake-proof baseline and explicit attack experiments.
Not an aggregated or delegation-stable proof construction.
"""
