"""Separate sender/proxy adapters; the supplied CEA source is not modified.

The sender creates a CEA submission while it still knows encryption randomness t.
The new proof cannot be added later by an aggregator that does not know t.
"""
from dataclasses import dataclass
from cipherauth import group as g, schnorr
from cipherauth.cea import (Submission, SUITE, statement_bytes, parse_body,
                            _opening, _kdf, _commit, _xor, _body)
from cipherauth.encoding import encode
from cipherauth.models import EncryptedRecord
from . import intake_pok

@dataclass(frozen=True)
class CheckedSubmission:
    submission: Submission
    proof: bytes

def binding(record):
    return encode(("cipherauth/intake-record/v1", SUITE, record.sender.fields(),
                   record.origin.fields(), record.tag, record.epoch, record.body))

def create_submission(system, sender, origin_identity, message, tag, epoch):
    """Known CEA operations plus the independent intake proof; no aggregate-proof claim."""
    origin = system.dir.class_key(origin_identity, tag, epoch)
    encoded_K = system.dir.registry.resolve(origin).encoded_key
    K = g.decode_point(encoded_K)
    t = g.random_scalar()
    Q, A = g.mul(t, g.G), g.mul(t, K)
    c = _commit(message, _opening(Q))
    E = _xor(message, _kdf(Q, len(message)))
    statement = statement_bytes(sender.ref, origin, tag, epoch, c)
    Lam, theta = schnorr.sign(sender.x, system.dir.point(sender.ref), statement)
    record = EncryptedRecord(sender.ref, origin, tag, epoch, _body(Lam, c, A, E))
    proof = intake_pok.prove(t, encoded_K, g.encode_point(A), binding(record))
    return CheckedSubmission(Submission(record, theta), proof)

def verify_record_proof(system, record, proof):
    try:
        system._record_consistent(record)
        encoded_K = system.dir.registry.resolve(record.origin).encoded_key
        _, _, A, _ = parse_body(record.body)
        return intake_pok.verify(encoded_K, g.encode_point(A), binding(record), proof)
    except (ValueError, TypeError, KeyError, AttributeError):
        return False
