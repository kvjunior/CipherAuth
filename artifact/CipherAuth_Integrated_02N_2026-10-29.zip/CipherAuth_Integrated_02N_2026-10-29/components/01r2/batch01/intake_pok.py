"""Schnorr/Fiat-Shamir proof baseline for knowledge of t in A=tK.

U=wK; c=H(K,U,A,context); z=w-c*t mod q; verify U=zK+cA.
This is a standard discrete-log proof pattern, not a new technique or a proof
of CEA confidentiality. Public interfaces use strict byte encodings.
"""
from dataclasses import dataclass
from cipherauth import group as g
from cipherauth.encoding import encode
from cipherauth.errors import EncodingError

DOMAIN = "cipherauth/batch01/intake-pok/v1"
PROOF_BYTES = g.POINT_BYTES + g.SCALAR_BYTES

@dataclass(frozen=True)
class Proof:
    commitment: bytes
    response: int

    def __post_init__(self):
        g.decode_point(self.commitment)
        g.validate_scalar(self.response)

    def encode(self):
        return self.commitment + g.encode_scalar(self.response)

    @classmethod
    def decode(cls, data):
        if not isinstance(data, bytes) or len(data) != PROOF_BYTES:
            raise EncodingError("intake proof must have exactly 65 bytes")
        return cls(data[:g.POINT_BYTES], int.from_bytes(data[g.POINT_BYTES:], "big"))

def challenge(base, commitment, point, context):
    if not isinstance(context, bytes) or not context:
        raise EncodingError("nonempty canonical context bytes required")
    # Validate all externally supplied group encodings before hashing.
    for value in (base, commitment, point):
        g.decode_point(value)
    return g.hash_to_scalar(DOMAIN, encode((base, commitment, point, context)))

def prove(witness, base, point, context):
    g.validate_scalar(witness, nonzero=True)
    K, A = g.decode_point(base), g.decode_point(point)
    if g.mul(witness, K) != A:
        raise EncodingError("witness does not match A=tK")
    nonce = g.random_scalar()
    U = g.encode_point(g.mul(nonce, K))
    c = challenge(base, U, point, context)
    return Proof(U, (nonce - c*witness) % g.q).encode()

def verify(base, point, context, proof_bytes):
    try:
        K, A = g.decode_point(base), g.decode_point(point)
        proof = Proof.decode(proof_bytes)
        U = g.decode_point(proof.commitment)
        c = challenge(base, proof.commitment, point, context)
        return U == g.mul(proof.response, K) + g.mul(c, A)
    except (ValueError, TypeError, OverflowError):
        return False
