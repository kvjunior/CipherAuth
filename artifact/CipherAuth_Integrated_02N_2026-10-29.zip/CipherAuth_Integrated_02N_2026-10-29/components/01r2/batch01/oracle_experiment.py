"""An explicit one-record experiment, NOT a complete published PRE/RCCA security game.

Policies: deny the target class, replay the legacy (origin,A,E) refusal, or
refuse the registered proxy input (origin,A). The legacy policy is a negative
control retained to reproduce the review, not the current proxy rule.
Optional unaggregated intake proofs are checked before the proxy transforms anything.
The oracle retains its token; its caller receives only the normal delegated object.
"""
from dataclasses import dataclass
from enum import Enum
from cipherauth.cea import parse_body
from .cea_adapter import verify_record_proof

class Policy(Enum):
    CLASS_DENY = "target-class-service-denied"
    REGISTERED_CORE = "registered-core-refusal"
    REGISTERED_POINT = "proxy-point-refusal"

@dataclass(frozen=True)
class Decision:
    reason: str
    output: object | None = None

def core(record):
    """Legacy refusal key, retained only for attack reproduction."""
    _, _, A, E = parse_body(record.body)
    return record.origin, A, E

def proxy_point(record):
    """The origin class and point actually transformed by this proxy."""
    _, _, A, _ = parse_body(record.body)
    return record.origin, A

class ProxyOracle:
    """Trusted experiment fixture. Token internals are not adversary inputs."""
    def __init__(self, system, token, grant, challenge_record, *, policy, require_proof):
        if not isinstance(policy, Policy) or type(require_proof) is not bool:
            raise ValueError("explicit Policy and Boolean proof-guard setting required")
        self._system, self._token, self._grant = system, token, grant
        self._challenge_origin = challenge_record.origin
        self._registered_cores = {core(challenge_record)}
        self._registered_points = {proxy_point(challenge_record)}
        self._policy, self._require_proof = policy, require_proof
        self.log = []

    def query(self, aggregate, proof=None):
        try:
            if len(aggregate.records) != 1:
                return self._deny("single-record-experiment-only")
            record = aggregate.records[0]
            if record.origin != self._challenge_origin:
                return self._deny("wrong-origin-class")
            if self._policy is Policy.CLASS_DENY:
                return self._deny("target-class-service-denied")
            if not self._system.verify_public(aggregate):
                return self._deny("public-authentication-invalid")
            if (self._policy is Policy.REGISTERED_CORE and
                    core(record) in self._registered_cores):
                return self._deny("registered-core-refused")
            if (self._policy is Policy.REGISTERED_POINT and
                    proxy_point(record) in self._registered_points):
                return self._deny("registered-proxy-point-refused")
            if self._require_proof and not verify_record_proof(self._system, record, proof):
                return self._deny("intake-proof-invalid-or-missing")
            delegated = self._system.delegate_aggregate(self._token, self._grant, aggregate)
            self.log.append("served")
            return Decision("served", delegated)
        except (ValueError, TypeError, KeyError, AttributeError, ZeroDivisionError):
            return self._deny("malformed-or-inadmissible")

    def _deny(self, reason):
        self.log.append(reason)
        return Decision(reason)
