# Primary sources and reading limits — CipherAuth Batch 01r2

These sources delimit the research question; none transfers a theorem to this prototype.
No exhaustive claim about the absence of later results is made.

- Hao, RFC 8235, Schnorr Non-interactive Zero-Knowledge Proof (2017):
  https://www.rfc-editor.org/rfc/rfc8235.html
  EC proof/validation/context sections consulted. Informational RFC, not standards-track.
  The code uses its own domain and encoding; no RFC wire interoperability is claimed.
- Bernhard–Fischlin–Warinschi, On the Hardness of Proving CCA-security of Signed ElGamal,
  ePrint 2015/649; conference version PKC 2016:
  https://eprint.iacr.org/2015/649
  Primary abstract verified. It excludes a class of reductions; this is not ciphertext
  insecurity or an unconditional impossibility theorem. Full PDF was not accessible
  through the retrieved ePrint/author-host routes in this review pass.
- Bernhard–Fischlin–Warinschi, Adaptive Proofs of Knowledge in the Random Oracle Model,
  ePrint 2015/648; PKC 2015 and subsequent IET Information Security version:
  https://eprint.iacr.org/2015/648
  https://research-information.bris.ac.uk/en/publications/adaptive-proofs-of-knowledge-in-the-random-oracle-model-2/
  Primary abstracts verified: adaptive Fiat–Shamir–Schnorr has a negative result under
  the paper's assumptions; Fischlin's construction provides a positive alternative.
  Exact extractor bounds and full theorem hypotheses remain to be checked in full text.
- Fuchsbauer–Plouviez–Seurin, Blind Schnorr Signatures and Signed ElGamal Encryption
  in the Algebraic Group Model, EUROCRYPT 2020, ePrint 2019/877:
  https://eprint.iacr.org/2019/877
  Primary abstract checked: signed-ElGamal CCA2 under DDH and signed-hashed-ElGamal KEM
  under DL in AGM+ROM. No theorem-by-theorem mapping to this prototype has been completed.
- Schnorr–Jakobsson, Security of Signed ElGamal Encryption, ASIACRYPT 2000:
  https://markus-jakobsson.com/papers/jakobsson-asiacrypt00.pdf
  Author-hosted abstract/intro retrieved in search, describing combined random-oracle
  and generic models. Not a complete proof audit.
- Chen–Zhao, Half-Aggregation of Schnorr Signatures with Tight Reductions, ESORICS 2022:
  https://eprint.iacr.org/2022/222
  https://yanbo-chen.github.io/pdfs/2022_agg.pdf
  Author-hosted 20-page version: Section 4, Figure 3, Theorem 2 examined. The theorem is
  aggregate unforgeability in AGM+ROM, not extraction for CipherAuth encryption proofs.
  The longer ePrint version has different pagination/figure numbering.
- Kondi–shelat, Improved Straight-Line Extraction in the Random Oracle Model With
  Applications to Signature Aggregation, ASIACRYPT 2022, ePrint 2022/393:
  https://eprint.iacr.org/2022/393
  Primary abstract checked: extraction and Schnorr/EdDSA aggregation are explicit topics.
  A full-text comparison is needed before any gap or new-technique claim.
- Alwen–Fuchsbauer–Mularczyk, Updatable Public-Key Encryption, Revisited,
  revised EUROCRYPT 2024 publication, ePrint 2025/175:
  https://eprint.iacr.org/2025/175
  Primary abstract/metadata rechecked: pairing-based UPKE, ROM and AGM. A neighboring
  comparator only; its exact relevance to this pairing-free many-witness task is unverified.
- Choi–Jeong–Byun, IDASR26, Information Sciences, article 123676:
  https://doi.org/10.1016/j.ins.2026.123676
  Primary metadata/abstract previously checked. Full text remains unavailable here;
  pairings, security models and comparison details must not be guessed.

The frozen input contains additional historical references. Its annotations are not
silently upgraded to independently checked proofs by being included in this package.

## 01r2 verification provenance

- Claude's 01r1 review reports reading BFW15/648 Theorem 3 and Definition 6, and FPS20
  Section 6, Theorem 5. Those are reviewer-reported full-text checks. ChatGPT could not
  independently retrieve those full PDFs in this pass; no exact numerical FPS20 bound
  is certified here. See provenance/CipherAuth_Batch01r1_Review_2026-10-25.zip.
- FPS20's publisher abstract and Notes 2–4 were independently read:
  https://link.springer.com/chapter/10.1007/978-3-030-45724-2_3
  The notes distinguish established extraction results from the complete encryption
  proof and caution against assuming the latter follows automatically.
- Kondi's author summary of the 2022/393 work was independently checked:
  https://www.ykondi.net/
  It concerns improving Fischlin-style extraction and EdDSA aggregation computation.
  This is not a full-text audit or proof that its aggregation model matches CipherAuth.
- The original archive and public full-text fetch results are preserved separately;
  missing sources are not upgraded from abstract-level to theorem-level verification.
