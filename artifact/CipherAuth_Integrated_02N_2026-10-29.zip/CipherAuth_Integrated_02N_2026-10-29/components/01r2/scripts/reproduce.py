"""Verify the unchanged baseline and execute Batch 01 in isolated extraction."""
from pathlib import Path
import hashlib,json,zipfile,tempfile,stat,sys,subprocess,unittest,io,platform

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def main():
    manifest=json.loads((ROOT/"manifest.json").read_text())
    for name,sha in manifest["sha256"].items():
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=sha:
            raise RuntimeError("source/input changed: "+name)
    baseline_zip=ROOT/manifest["baseline_archive"]
    with tempfile.TemporaryDirectory(prefix="cipherauth-batch01-") as temp:
        with zipfile.ZipFile(baseline_zip) as z:
            for item in z.infolist():
                p=Path(item.filename)
                if p.is_absolute() or ".." in p.parts or stat.S_ISLNK(item.external_attr>>16):
                    raise RuntimeError("unsafe baseline archive")
            z.extractall(temp)
        baseline=Path(temp)/"encrypted_auth_research"
        process=subprocess.run([sys.executable,"scripts/reproduce.py"],cwd=baseline,
                               capture_output=True,text=True,timeout=120)
        if process.returncode:
            raise RuntimeError(process.stdout+process.stderr)
        previous=json.loads(process.stdout)
        if previous["unit_tests"]["count"]!=39 or not previous["v3_baseline"]["exact_report_match"]:
            raise RuntimeError("baseline reproduction differed")
        sys.path.insert(0,str(baseline/"src"))
        suite=unittest.defaultTestLoader.discover(str(ROOT/"tests"))
        stream=io.StringIO()
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
        if not result.wasSuccessful():
            raise RuntimeError(stream.getvalue())
        from batch01.experiment import run_all
        cases=run_all()
        from research.proxy_reply_control import run as run_reply_control
        reply_control=run_reply_control()
        out={
            "project":"CipherAuth",
            "batch":"01r2",
            "implementation_status":"MINOR_REVIEW_REPAIRS_AND_CONDITIONAL_ALGEBRA_REVISION_AWAITING_REVIEW",
            "python":platform.python_version(),
            "baseline_archive_sha256":hashlib.sha256(baseline_zip.read_bytes()).hexdigest(),
            "baseline":{
                "source_integrity":previous["source_integrity"],
                "unit_tests":previous["unit_tests"],
                "v3_baseline":previous["v3_baseline"],
                "mauling_attack":previous["cea_reencryption_mauling"]},
            "batch01_tests":{"run":result.testsRun,"failures":len(result.failures),
                             "errors":len(result.errors),"skipped":len(result.skipped)},
            "experiments":cases,
            "conditional_proxy_reply_control":reply_control,
            "single_record_proof_bytes":65,
            "field_level_authentication_and_validity_bytes_per_record":130,
            "intake_verification_scalar_multiplication_calls_per_record":2,
            "proxy_refusal_rule":"(origin,A); legacy (origin,A,E) kept as a negative control",
            "aggregated_proof":"NOT_IMPLEMENTED",
            "delegation_stable_proof":"NOT_IMPLEMENTED",
            "single_hop_requires_post_delegation_proof":"NO",
            "full_per_ciphertext_confidentiality":"UNPROVEN",
            "new_theorem":"NONE",
            "meaning":"Specific baseline/control experiments; no general security or novelty certification."
        }
        target=ROOT/"results";target.mkdir(exist_ok=True)
        (target/"observed.json").write_text(json.dumps(out,indent=2)+"\n")
        (target/"unit_tests.txt").write_text(stream.getvalue())
        print(json.dumps(out,indent=2))

if __name__=="__main__":
    main()
