import unittest
from fractions import Fraction

from final_bound import Budgets, candidate_bound, hybrid_sequence, statistical_terms


class FinalBoundTests(unittest.TestCase):
    def setUp(self):
        self.b = Budgets(group_order=101, hash_bits=16, honest_delegatees=3,
                         intake_prequeries=5, commit_queries=7,
                         ordinary_decryption_records=11)

    def test_exact_statistical_terms(self):
        terms = statistical_terms(self.b)
        self.assertEqual(terms["intake_programming"], Fraction(5, 100))
        self.assertEqual(terms["challenge_commit_prequery"], Fraction(7, 2**16))
        self.assertEqual(terms["decryption_without_point_query"], Fraction(88, 2**16))

    def test_gap_terms_are_separate_reductions(self):
        total, terms = candidate_bound(self.b, Fraction(1, 1000), Fraction(1, 2000))
        self.assertEqual(terms["challenge_GapDivDH"], Fraction(1, 1000))
        self.assertEqual(terms["mask_GapDivDH"], Fraction(3, 2000))
        self.assertEqual(total, sum(terms.values(), Fraction(0)))

    def test_bound_caps_at_one(self):
        total, _ = candidate_bound(self.b, 1, 1)
        self.assertEqual(total, 1)

    def test_zero_budgets_leave_only_solver_terms(self):
        b = Budgets(101, 256, 0, 0, 0, 0)
        total, terms = candidate_bound(b, Fraction(1, 7), Fraction(1, 9))
        self.assertEqual(total, Fraction(1, 7))
        self.assertEqual(terms["mask_GapDivDH"], 0)

    def test_no_kdf_or_hd_query_count_loss(self):
        # Gap recognition scans the query table; it does not guess an index.
        self.assertNotIn("point_query_guess", statistical_terms(self.b))

    def test_no_agm_or_intake_extraction_term(self):
        keys = set(statistical_terms(self.b))
        self.assertNotIn("AGM_extraction", keys)
        self.assertNotIn("intake_knowledge", keys)

    def test_hybrid_order_is_fixed(self):
        sequence = hybrid_sequence()
        self.assertEqual(sequence[0], "G0_REAL_CLASS_V1")
        self.assertEqual(sequence[-1], "G5_CHALLENGE_BIT_INDEPENDENT")
        self.assertEqual(len(sequence), len(set(sequence)))

    def test_invalid_budget_values_are_rejected(self):
        with self.assertRaises(ValueError): Budgets(2, 256, 1, 1, 1, 1)
        with self.assertRaises(ValueError): Budgets(101, 0, 1, 1, 1, 1)
        with self.assertRaises(ValueError): Budgets(101, 256, -1, 1, 1, 1)

    def test_invalid_solver_success_is_rejected(self):
        with self.assertRaises(ValueError): candidate_bound(self.b, -0.1, 0)
        with self.assertRaises(ValueError): candidate_bound(self.b, 0, 1.1)


if __name__ == "__main__": unittest.main(verbosity=2)
