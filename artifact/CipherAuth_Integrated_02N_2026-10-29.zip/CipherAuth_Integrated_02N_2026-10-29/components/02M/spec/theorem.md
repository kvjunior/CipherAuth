# Candidate G-CONF-CLASS-v1 theorem

Work in the ideal random-oracle model with prime-order group `G` of order `q`,
the static-corruption and oracle interface of Batch 02L, and the
Gap-Divisible-DH assumption from Batch 02K. Define confidentiality advantage as
`|Pr[b'=b]-1/2|` and solver success as the probability of outputting the required
Divisible-DH point.

Let:

- `N_H` be the number of statically honest delegatees;
- `q_pre` be the number of distinct 02F challenge inputs queried before installing
  the challenge intake proof;
- `q_c` be the number of distinct commitment-oracle queries;
- `Q_D` be the total number of record-opening attempts across ordinary, non-refused
  decryption queries;
- `lambda=256` be the opening/commitment hash length.

Then the candidate reduction gives

`Adv_CLASS(A) <= Succ_GDivDH(B_chal) + N_H Succ_GDivDH(B_mask)`

`                 + q_pre/(q-1) + q_c/2^lambda`

`                 + Q_D(q_c+1)/2^lambda`, capped at one.

`B_chal` and `B_mask` are different legitimate reductions. No DDH oracle is
given to `A`; each solver receives the decision oracle included in the named Gap-
Divisible-DH problem. The statement is for G-CONF-CLASS-v1 only, not G-CONF-CT,
G-SCOPE, authenticity, concrete SHA-256 security, or adaptive corruption.
