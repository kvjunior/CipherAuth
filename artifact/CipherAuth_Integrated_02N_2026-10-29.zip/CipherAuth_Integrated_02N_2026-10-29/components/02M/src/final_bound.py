"""Exact symbolic loss ledger for the candidate G-CONF-CLASS-v1 theorem."""
from dataclasses import dataclass
from fractions import Fraction


@dataclass(frozen=True)
class Budgets:
    group_order: int
    hash_bits: int
    honest_delegatees: int
    intake_prequeries: int
    commit_queries: int
    ordinary_decryption_records: int

    def __post_init__(self):
        if not isinstance(self.group_order, int) or self.group_order < 3:
            raise ValueError("group_order must be at least three")
        if not isinstance(self.hash_bits, int) or self.hash_bits < 1:
            raise ValueError("hash_bits must be positive")
        for name in ("honest_delegatees", "intake_prequeries", "commit_queries",
                     "ordinary_decryption_records"):
            value = getattr(self, name)
            if not isinstance(value, int) or value < 0:
                raise ValueError(name + " must be a nonnegative integer")


def statistical_terms(budgets):
    if not isinstance(budgets, Budgets):
        raise TypeError("Budgets required")
    q, H = budgets.group_order, 2 ** budgets.hash_bits
    return {
        "intake_programming": Fraction(budgets.intake_prequeries, q - 1),
        "challenge_commit_prequery": Fraction(budgets.commit_queries, H),
        "decryption_without_point_query": Fraction(
            budgets.ordinary_decryption_records * (budgets.commit_queries + 1), H),
    }


def candidate_bound(budgets, main_gap_success, mask_gap_success):
    """Return a capped exact bound under the documented advantage convention."""
    if not isinstance(main_gap_success, Fraction):
        main_gap_success = Fraction(main_gap_success)
    if not isinstance(mask_gap_success, Fraction):
        mask_gap_success = Fraction(mask_gap_success)
    if not 0 <= main_gap_success <= 1 or not 0 <= mask_gap_success <= 1:
        raise ValueError("solver success probabilities must lie in [0,1]")
    terms = statistical_terms(budgets)
    terms["challenge_GapDivDH"] = main_gap_success
    terms["mask_GapDivDH"] = budgets.honest_delegatees * mask_gap_success
    return min(Fraction(1), sum(terms.values(), Fraction(0))), terms


def hybrid_sequence():
    return (
        "G0_REAL_CLASS_V1",
        "G1_UNIFORM_TARGET_GRANT_C_AND_SAMPLED_OMEGA",
        "G2_PROGRAMMED_CHALLENGE_INTAKE_PROOF",
        "G3_RANDOM_CHALLENGE_KDF_OPENING_AND_COMMITMENT",
        "G4_QUERY_TABLE_DECRYPTION_SIMULATION",
        "G5_CHALLENGE_BIT_INDEPENDENT",
    )
