# CipherAuth Batch 02M — candidate final CLASS reduction

Batch 02M assembles the prior restricted lemmas into one candidate
G-CONF-CLASS-v1 hybrid and explicit loss. The theorem uses two separate Gap-
Divisible-DH solvers and contains no AGM-extraction term. It remains pending
independent cryptographic review; `full_security_proved` stays false.

Run `python3 scripts/reproduce.py`, then read `spec/theorem.md` and
`proofs/final_reduction.md`.
