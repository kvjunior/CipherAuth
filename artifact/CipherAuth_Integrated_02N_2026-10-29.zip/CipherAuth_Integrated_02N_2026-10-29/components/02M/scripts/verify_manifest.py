#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; manifest=ROOT/'manifest.json'
expected=json.loads(manifest.read_text())
actual={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
        for p in ROOT.rglob('*') if p.is_file() and p!=manifest
        and '__pycache__' not in p.parts and p.suffix!='.pyc'}
if actual!=expected:
    missing=sorted(set(expected)-set(actual));extra=sorted(set(actual)-set(expected))
    changed=sorted(k for k in set(actual)&set(expected) if actual[k]!=expected[k])
    raise SystemExit(f'manifest mismatch: missing={missing}, extra={extra}, changed={changed}')
print(f'Verified {len(actual)} files.')
