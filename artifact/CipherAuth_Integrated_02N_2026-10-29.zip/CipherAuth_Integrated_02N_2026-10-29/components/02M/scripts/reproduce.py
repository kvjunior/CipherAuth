#!/usr/bin/env python3
import json,stat,subprocess,sys,tempfile,unittest,zipfile
from fractions import Fraction
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'vendor')]
from final_bound import Budgets,candidate_bound

def extract_safe(archive,destination):
    with zipfile.ZipFile(archive) as handle:
        for item in handle.infolist():
            p=Path(item.filename)
            if p.is_absolute() or '..' in p.parts or stat.S_ISLNK(item.external_attr>>16):
                raise RuntimeError('unsafe baseline archive member')
        handle.extractall(destination)

def main():
    archive=ROOT/'baseline/CipherAuth_Batch02L_ClassClosure_2026-10-28.zip'
    with tempfile.TemporaryDirectory() as folder:
        extract_safe(archive,folder); base=Path(folder)/'CipherAuth_Batch02L_ClassClosure'
        expected=(base/'results/observed.json').read_bytes()
        subprocess.run([sys.executable,str(base/'scripts/verify_manifest.py')],check=True,capture_output=True)
        subprocess.run([sys.executable,str(base/'scripts/reproduce.py')],check=True,capture_output=True)
        if expected!=(base/'results/observed.json').read_bytes():
            raise RuntimeError('02L baseline result changed')
    suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'))
    tests=unittest.TextTestRunner(verbosity=2).run(suite)
    demo=Budgets(101,16,3,5,7,11); total,terms=candidate_bound(demo,Fraction(1,1000),Fraction(1,2000))
    result={'batch':'02M','tests_run':tests.testsRun,'failures':len(tests.failures),
            'errors':len(tests.errors),'skips':len(tests.skipped),'prior_tests_02L':14,
            'prior_results_byte_identical':True,'target_game':'G-CONF-CLASS-v1',
            'candidate_theorem':'WRITTEN_PENDING_INDEPENDENT_REVIEW',
            'assumption':'Gap-Divisible-DH','AGM_extraction_term':False,
            'symbolic_bound_terms':sorted(terms),'demo_bound':str(total),
            'G_CONF_CT':'KNOWN_FALSE','full_security_proved':False}
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results/observed.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))
    return 0 if tests.wasSuccessful() and not tests.skipped else 1
if __name__=='__main__':sys.exit(main())
