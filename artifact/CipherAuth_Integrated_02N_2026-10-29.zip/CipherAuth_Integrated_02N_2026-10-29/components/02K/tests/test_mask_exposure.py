import unittest

from cipherauth import group as g
from mask_exposure import (MaskQuery, embed_all_grants, gap_extract,
                           honest_delegatee_loss, joint_scaled_challenge_distribution,
                           plain_divdh_loss)


class MaskExposureTests(unittest.TestCase):
    def setUp(self):
        self.a = 37
        self.b = 41
        self.U = g.mul(self.a, g.G)
        self.V = g.mul(self.b, g.G)
        self.context = b"target-class-ref"
        self.grants = embed_all_grants(self.V, (3, 5, 11, 17))

    def ddh(self, base, U, X, Y):
        self.assertEqual(base, g.G)
        self.assertEqual(U, self.U)
        return g.mul(self.a, X) == Y

    def target(self, scale):
        return g.mul(scale * self.b * g.inv(self.a) % g.q, g.G)

    def test_divisible_dh_target_identity(self):
        target = g.mul(self.b * g.inv(self.a) % g.q, g.G)
        self.assertEqual(g.mul(self.a, target), self.V)

    def test_every_scaled_grant_has_correct_target(self):
        for grant in self.grants:
            self.assertEqual(g.mul(self.a, self.target(grant.scale)), grant.gamma)

    def test_gap_scan_extracts_from_any_grant_without_grant_guess(self):
        expected = g.mul(self.b * g.inv(self.a) % g.q, g.G)
        for grant in self.grants:
            queries = (MaskQuery(g.mul(19, g.G), self.context),
                       MaskQuery(self.target(grant.scale), self.context))
            self.assertEqual(gap_extract(self.U, self.grants, queries,
                                         self.context, self.ddh), expected)

    def test_wrong_context_is_not_exposure(self):
        query = MaskQuery(self.target(self.grants[0].scale), b"other-class")
        self.assertIsNone(gap_extract(self.U, self.grants, (query,),
                                      self.context, self.ddh))

    def test_prequery_is_detected_when_grant_is_installed(self):
        # The query may precede grant creation.  The simulator retains its RO
        # list and tests it transactionally before releasing the new token.
        prior = (MaskQuery(self.target(5), self.context),)
        later_grant = embed_all_grants(self.V, (5,))
        expected = g.mul(self.b * g.inv(self.a) % g.q, g.G)
        self.assertEqual(gap_extract(self.U, later_grant, prior,
                                     self.context, self.ddh), expected)

    def test_nonmatching_queries_return_none(self):
        queries = tuple(MaskQuery(g.mul(x, g.G), self.context) for x in (2, 7, 13))
        self.assertIsNone(gap_extract(self.U, self.grants, queries,
                                      self.context, self.ddh))

    def test_query_order_does_not_change_extracted_solution(self):
        q1 = MaskQuery(self.target(self.grants[1].scale), self.context)
        q2 = MaskQuery(self.target(self.grants[3].scale), self.context)
        self.assertEqual(gap_extract(self.U, self.grants, (q1, q2), self.context, self.ddh),
                         gap_extract(self.U, self.grants, (q2, q1), self.context, self.ddh))

    def test_scaled_challenges_are_jointly_uniform_in_toy_groups(self):
        for q, count in ((5, 1), (5, 2), (7, 3)):
            result = joint_scaled_challenge_distribution(q, count)
            self.assertTrue(result["support_complete"])
            self.assertEqual(result["multiplicity"], [q - 1])
            self.assertEqual(result["support_size"], (q - 1) ** count)

    def test_gap_bound_has_delegatee_loss_only(self):
        self.assertEqual(honest_delegatee_loss(4, 0.01), 0.04)
        self.assertEqual(honest_delegatee_loss(4, 0.4), 1)

    def test_plain_bound_records_query_and_grant_guessing(self):
        self.assertEqual(plain_divdh_loss(2, 3, 5, 0.001), 0.03)

    def test_loss_inputs_are_validated(self):
        for n in (0, -1, 1.5):
            with self.assertRaises(ValueError):
                honest_delegatee_loss(n, 0.1)
        with self.assertRaises(ValueError):
            honest_delegatee_loss(1, 1.1)
        with self.assertRaises(ValueError):
            plain_divdh_loss(1, 0, 1, 0.1)

    def test_empty_grant_list_is_rejected(self):
        with self.assertRaises(ValueError):
            embed_all_grants(self.V, ())

    def test_invalid_query_context_is_rejected(self):
        with self.assertRaises(ValueError):
            MaskQuery(g.G, b"")


if __name__ == "__main__":
    unittest.main(verbosity=2)
