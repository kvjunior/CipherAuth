"""Restricted Hmask(T) exposure reduction for honest delegatees.

This executable model keeps the assumption interface explicit.  The injected
``ddh_test`` represents the decision oracle supplied to a Gap-Divisible-DH
reduction; it is not implemented by the construction or given to the adversary.
"""
from collections import Counter
from dataclasses import dataclass

from cipherauth import group as g


@dataclass(frozen=True)
class EmbeddedGrant:
    """One grant derived from a shared Divisible-DH challenge point V=bP."""
    scale: int
    gamma: g.Point

    def __post_init__(self):
        g.validate_scalar(self.scale, nonzero=True)
        g.validate_point(self.gamma)


@dataclass(frozen=True)
class MaskQuery:
    point: g.Point
    origin_context: bytes

    def __post_init__(self):
        g.validate_point(self.point)
        if type(self.origin_context) is not bytes or not self.origin_context:
            raise ValueError("origin context must be nonempty bytes")


def embed_all_grants(challenge_V, scales):
    """Set gamma_j=r_j*V for every grant to the selected delegatee."""
    V = g.validate_point(challenge_V)
    values = tuple(scales)
    if not values:
        raise ValueError("at least one grant is required")
    return tuple(EmbeddedGrant(r, g.mul(g.validate_scalar(r, nonzero=True), V))
                 for r in values)


def gap_extract(U, grants, queries, target_context, ddh_test):
    """Return (b/a)P after the first matching Hmask query, or None.

    U=aP and each grant has gamma_j=r_j*bP.  A matching query X satisfies
    gamma_j=aX; multiplying X by r_j^-1 gives (b/a)P.
    """
    U = g.validate_point(U)
    if type(target_context) is not bytes or not target_context:
        raise ValueError("target context must be nonempty bytes")
    for query in queries:
        if query.origin_context != target_context:
            continue
        for grant in grants:
            if ddh_test(g.G, U, query.point, grant.gamma):
                return g.mul(g.inv(grant.scale), query.point)
    return None


def honest_delegatee_loss(n_honest_delegatees, gap_advantage):
    """Multi-user guessing bound for the Gap-Divisible-DH reduction."""
    if not isinstance(n_honest_delegatees, int) or n_honest_delegatees < 1:
        raise ValueError("positive honest-delegatee count required")
    if not 0 <= gap_advantage <= 1:
        raise ValueError("advantage must lie in [0,1]")
    return min(1, n_honest_delegatees * gap_advantage)


def plain_divdh_loss(n_honest_delegatees, grants_to_selected,
                     mask_queries, divdh_advantage):
    """Fallback bound without a decision oracle.

    A plain Divisible-DH solver must guess both a matching grant and a mask-query
    index, unlike the gap solver, which tests all pairs without advantage loss.
    """
    for name, value in (("n_honest_delegatees", n_honest_delegatees),
                        ("grants_to_selected", grants_to_selected),
                        ("mask_queries", mask_queries)):
        if not isinstance(value, int) or value < 1:
            raise ValueError(name + " must be positive")
    if not 0 <= divdh_advantage <= 1:
        raise ValueError("advantage must lie in [0,1]")
    return min(1, n_honest_delegatees * grants_to_selected *
               mask_queries * divdh_advantage)


def joint_scaled_challenge_distribution(q, grants):
    """Enumerate gamma_j=r_j*b in a toy prime-order exponent group."""
    if not isinstance(q, int) or q < 3 or not isinstance(grants, int) or grants < 1:
        raise ValueError("invalid toy parameters")
    counts = Counter()

    # Enumerate b and all r_j, then map the vector through multiplication by
    # the fixed nonzero b.
    from itertools import product
    for b in range(1, q):
        for rs in product(range(1, q), repeat=grants):
            counts[tuple(r * b % q for r in rs)] += 1
    expected = (q - 1) ** grants
    return {
        "support_complete": len(counts) == expected,
        "support_size": len(counts),
        "multiplicity": sorted(set(counts.values())),
        "expected_multiplicity": q - 1,
        "outcomes": sum(counts.values()),
    }
