# Assumption interface

| Item | Batch 02K meaning |
| --- | --- |
| Instance | `(P,U=aP,V=bP)` |
| Target | `(b/a)P` |
| Gap oracle | decides whether `Y=aX` for `(P,U,X,Y)` |
| Adversary access to gap oracle | none |
| Corruption | delegatee set fixed before the challenge; embedded delegatee never corrupted |
| Hmask bad event | exact point and exact origin-class context queried |
| Multi-grant handling | `gamma_j=r_j*V`; all grants covered jointly |
| Advantage loss | `N_H`; no grant or Hmask-query loss in the gap interface |

This table is normative for the restricted lemma. Any final theorem must copy
the same assumption instead of renaming it gap-CDH.
