#!/usr/bin/env python3
import json
import stat
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "vendor")]
from mask_exposure import joint_scaled_challenge_distribution


def extract_safe(archive, destination):
    with zipfile.ZipFile(archive) as handle:
        for item in handle.infolist():
            path = Path(item.filename)
            if path.is_absolute() or ".." in path.parts or stat.S_ISLNK(item.external_attr >> 16):
                raise RuntimeError("unsafe baseline archive member")
        handle.extractall(destination)


def main():
    archive = ROOT / "baseline/CipherAuth_Batch02J_HonestDelegatee_2026-10-28.zip"
    with tempfile.TemporaryDirectory() as folder:
        extract_safe(archive, folder)
        base = Path(folder) / "CipherAuth_Batch02J_HonestDelegatee"
        expected = (base / "results/observed.json").read_bytes()
        subprocess.run([sys.executable, str(base / "scripts/verify_manifest.py")],
                       check=True, capture_output=True)
        subprocess.run([sys.executable, str(base / "scripts/reproduce.py")],
                       check=True, capture_output=True)
        if expected != (base / "results/observed.json").read_bytes():
            raise RuntimeError("02J baseline result changed")

    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    tests = unittest.TextTestRunner(verbosity=2).run(suite)
    distribution = {f"q{q}_g{count}": joint_scaled_challenge_distribution(q, count)
                    for q, count in ((5, 1), (5, 2), (7, 3))}
    result = {
        "batch": "02K",
        "tests_run": tests.testsRun,
        "failures": len(tests.failures),
        "errors": len(tests.errors),
        "skips": len(tests.skipped),
        "prior_tests_02J": 12,
        "prior_results_byte_identical": True,
        "joint_scaled_gamma_distribution": distribution,
        "Hmask_exposure": "RESTRICTED_REDUCTION_PENDING_INDEPENDENT_REVIEW",
        "assumption": "Gap-Divisible-DH",
        "gap_loss": "N_H",
        "grant_guess_loss": 0,
        "mask_query_guess_loss": 0,
        "static_honesty_required": True,
        "full_AGM_basis": "OPEN",
        "grant_admissibility": "OPEN",
        "full_security_proved": False
    }
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results/observed.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if tests.wasSuccessful() and not tests.skipped else 1


if __name__ == "__main__":
    sys.exit(main())
