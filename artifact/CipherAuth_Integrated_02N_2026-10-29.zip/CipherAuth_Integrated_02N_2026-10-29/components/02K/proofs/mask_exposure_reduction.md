# Hmask(T) exposure for honest delegatees

Status: restricted Gap-Divisible-DH lemma, pending independent review. This
closes the exposure term used by Batch 02J under the stated static-honesty and
oracle interfaces. It is not the complete G-CONF-CLASS proof.

## Assumption

`Gap-Divisible-DH` gives the reduction `(P,U=aP,V=bP)` for independent nonzero
`a,b`, plus a decision oracle for tuples `(P,U,X,Y)` that returns one exactly
when `Y=aX`. The task is to output `(b/a)P`. The decision oracle belongs only to
the reduction; neither the construction nor the game adversary receives it.

This is the exact named assumption. It is not ordinary CDH and is not called
gap-CDH here.

## Identical-until-bad hop

For an honest delegatee, the real token has

`gamma=t2*K_l`, `T=k_l^-1*gamma=t2*P`,
`C=encode(omega) xor Hmask(T,origin-ref)`, and `Omega=k*omega`.

Until the adversary makes the exact, context-bound query
`Hmask(T,origin-ref)`, its answer is an unseen uniform string. Consequently
`C` is uniform independently of `(omega,Omega,W)` and can be sampled directly.
The real and uniform-C games are identical until that first query, so their
probabilities of the first bad event are equal. Static honesty is necessary:
later disclosure of the delegatee secret would reveal `T` without solving the
problem.

## One embedded delegatee, all of its grants

The reduction selects one of at most `N_H` statically honest delegatees and
publishes `K_l=U`. It does not know `a`. For the j-th target-class grant to this
delegatee it samples independent `r_j` and publishes

`gamma_j = r_j*V`.

These gammas have exactly the required joint distribution. For any tuple of
nonzero output exponents, every nonzero `b` determines one and only one vector
of scales `(r_1,...,r_s)`, so the tuple is uniform over `(G\{0})^s`.

The grant's hidden mask point is

`T_j = (r_j*b/a)P`.

The rest of the Batch 02J simulation is unchanged: sample `Omega_j` and `C_j`
uniformly, set `W_j=H_Omega(Omega_j)`, sign the public token digest, and answer
every proxy transformation exactly as `Omega_j^-1*A`.

For each context-correct mask query `X`, the reduction tests every stored grant
with its Gap oracle. When a new grant is installed, it also tests the complete
prior Hmask query list before releasing the token; an exact prequery therefore
causes the same transactional bad event. If `gamma_j=aX`, then `X=T_j` and it outputs

`r_j^-1*X = (b/a)P`.

Thus no grant guess and no mask-query-index guess is required. Testing all
query/grant pairs costs polynomial time and oracle calls but no advantage
factor. Only the selected honest-delegatee guess remains:

`Pr[Bad_mask] <= N_H * Adv_GDivDH(B)`.

If the theorem instead uses plain Divisible-DH without a decision oracle, a
direct guessing reduction incurs the conservative factor
`N_H*q_G*q_mask`; Batch 02K does not silently substitute that weaker interface.

## Scope and remaining obligations

The lemma covers target-class grants to statically honest delegatees and the
exact Hmask domain `(encoded point, origin KeyRef fields)`. It relies on Batch
02J's exact scalar-Omega proxy simulation. It does not cover adaptive corruption,
the full AGM input basis, final target-class decryption bookkeeping, or the
unresolved versioned grant/admissibility interface. Those remain separate gates.
