# CipherAuth Batch 02K — honest-grant mask exposure

Batch 02K reduces the `Hmask(T)` exposure event left by 02J to the explicitly
named Gap-Divisible-DH assumption. A scaled embedding covers every grant to the
selected honest delegatee, so the restricted bound loses only a factor equal to
the number of statically honest delegatees.

Run `python3 scripts/reproduce.py`, then read
`proofs/mask_exposure_reduction.md`. This is a restricted proof component,
not a complete confidentiality theorem.
