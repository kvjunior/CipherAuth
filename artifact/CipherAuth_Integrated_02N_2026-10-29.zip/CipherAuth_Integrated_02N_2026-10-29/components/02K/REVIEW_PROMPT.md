# Independent review request for Batch 02K

Verify the assumption first: `(P,aP,bP)` with a tuple-decision oracle, target
`(b/a)P`. Check that it is never mislabeled ordinary gap-CDH.

Audit the multi-grant embedding `gamma_j=r_j*bP`: prove its joint distribution
matches independently generated token gammas, and verify that a matching mask
query yields `r_j^-1*T_j=(b/a)P`. Confirm that scanning all grants and queries
uses polynomially many Gap-oracle calls without an advantage loss.

Finally check the exact bad-event domain, the `N_H` multi-user loss, static
honesty, and compatibility with 02J's scalar-Omega simulation. Look for any
oracle or honest-recipient observation that needs the embedded delegatee secret.

Do not treat this lemma as the full AGM/game transfer or final security theorem.
