# CipherAuth Batch 02E — extraction attempt and corrective audit

**Verdict: FULL EXTRACTION UNRESOLVED.** This batch supersedes the unsupported
security interpretations of Batches 02A–02D, while leaving those archives untouched.

Run with Python 3.10+ and no external packages:

    python scripts/reproduce.py

Contents:
- `proofs/n2_attempt.md`: full proofs of two restricted formal-vector lemmas, their
  union bound, and the exact missing transfer to an adaptive AGM+ROM extractor.
- `proofs/audit_corrections.md`: concrete mistakes in earlier code and proof claims.
- `proofs/obligations.md`: status and checked-source scope.
- `src/model.py`: formal-vector diagnostics and corrected game-policy fixtures.
- `tests/test_gate.py`: 13 regression/diagnostic tests.
- `results/observed.json`: deterministic output of this package's runner.
- `provenance/input_hashes.json`: hashes of earlier batch archives and frozen inputs.

These are mathematical diagnostics and policy fixtures, not real cryptographic
oracles, a production protocol, a full extractor, or a machine-checked security proof.

NEXT: freeze a precise transcript and implement the compressed-only verifier with
recomputed proof challenges/prefix weights and valid honest/simulated challenge
fixtures; use that to attempt the missing adaptive representation reduction.
Do not begin deployment or claim a STOC contribution on these results.
