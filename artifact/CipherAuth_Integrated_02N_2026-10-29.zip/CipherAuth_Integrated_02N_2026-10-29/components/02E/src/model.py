"""Restricted formal-vector diagnostics, not an AGM security implementation."""
from dataclasses import dataclass
from fractions import Fraction

@dataclass(frozen=True)
class Core:
    origin: str
    point: str
    ciphertext: str

class Ledger:
    def __init__(self, challenge):
        self.protected = {challenge}
        self.edges = []
    def derive(self, parent, child):
        self.edges.append((parent, child))
        if parent in self.protected:
            self.protected.add(child)
    def refuses(self, cores):
        return any(c in self.protected for c in cores)

def proxy_policy(ledger, core, *, corrupted_recipient, intake_valid):
    """Policy only: intake_valid is a fixture verdict, not cryptographic validation."""
    if corrupted_recipient and ledger.refuses((core,)):
        return 'REFUSE_DERIVATIVE'
    if not intake_valid:
        return 'REFUSE_INTAKE'
    return 'SERVE'

def dec_policy(ledger, cores, *, verified_messages, alternatives):
    """Real-game policy after a supplied full opener result; no RO-list dependency."""
    if ledger.refuses(cores):
        return 'REFUSE_DERIVATIVE'
    if verified_messages is None:
        return None
    return tuple('MASK.TEST' if m in alternatives else m for m in verified_messages)

def residual(a, r, c, q):
    if len(a) != len(r):
        raise ValueError('dimension mismatch')
    return tuple((y + c*x) % q for x, y in zip(a, r))

def weighted_residual(v1, v2, b, q):
    if len(v1) != len(v2):
        raise ValueError('dimension mismatch')
    return tuple((x+b*y) % q for x, y in zip(v1, v2))

def prefix_cancellation_count(v1, v2, q):
    """Enumerate nonzero fresh b for already fixed formal residual vectors."""
    return sum(not any(weighted_residual(v1, v2, b, q)) for b in range(1,q))

def challenge_root_count(a, r, q):
    return sum(not any(residual(a,r,c,q)) for c in range(q))

def restricted_bound(challenge_trials, prefix_trials, q):
    """Proved only for fresh, independent, fixed-before-query vector trials."""
    if q < 3 or min(challenge_trials,prefix_trials)<0:
        raise ValueError('invalid budget')
    return min(Fraction(1), Fraction(challenge_trials,q)+Fraction(prefix_trials,q-1))
