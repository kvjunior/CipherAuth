import unittest
from itertools import product
from model import *

class GateTests(unittest.TestCase):
    def test_ordinary_child_is_not_protected(self):
        ch=Core('j','A*','E*'); a=Core('j','A','E'); child=Core('j','B','E')
        ledger=Ledger(ch); ledger.derive(a,child)
        self.assertFalse(ledger.refuses((child,)))
        self.assertEqual(dec_policy(ledger,(child,),verified_messages=('ordinary',),alternatives={'m0','m1'}),('ordinary',))
    def test_challenge_child_is_protected(self):
        ch=Core('j','A*','E*'); child=Core('j','B*','E*'); ledger=Ledger(ch)
        ledger.derive(ch,child)
        self.assertTrue(ledger.refuses((child,)))
    def test_challenge_validity_and_authorization_are_distinct(self):
        ch=Core('j','A*','E*'); ledger=Ledger(ch)
        self.assertEqual(proxy_policy(ledger,ch,corrupted_recipient=True,intake_valid=True),'REFUSE_DERIVATIVE')
        self.assertEqual(proxy_policy(ledger,ch,corrupted_recipient=False,intake_valid=True),'SERVE')
    def test_reorder_replay_and_mask(self):
        ch=Core('j','A*','E*'); a=Core('j','A','E'); ledger=Ledger(ch)
        for cores in ((ch,a),(a,ch),(ch,ch)):
            self.assertEqual(dec_policy(ledger,cores,verified_messages=('m0',),alternatives={'m0','m1'}),'REFUSE_DERIVATIVE')
        self.assertEqual(dec_policy(ledger,(a,),verified_messages=('m1',),alternatives={'m0','m1'}),('MASK.TEST',))
        self.assertIsNone(dec_policy(ledger,(a,),verified_messages=None,alternatives=set()))
    def test_hash_query_is_not_full_opening(self):
        # A malformed commitment must fail even if its opening point was queried.
        a=Core('j','A','E'); ledger=Ledger(Core('j','A*','E*'))
        self.assertIsNone(dec_policy(ledger,(a,),verified_messages=None,alternatives=set()))
    def test_missing_R_terms_change_equation(self):
        q=101; c=7; alpha=3; rho=(-c*alpha)%q
        self.assertNotEqual(c*alpha%q,0)
        self.assertEqual(residual((alpha,),(rho,),c,q),(0,))
    def test_fixed_vector_prefix_bound_exhaustive(self):
        q=5; vectors=list(product(range(q),repeat=2))
        for u in vectors:
            for v in vectors:
                if any(u) or any(v):
                    self.assertLessEqual(prefix_cancellation_count(u,v,q),1)
    def test_fixed_vector_challenge_bound_exhaustive(self):
        q=5; vectors=list(product(range(q),repeat=2))
        for a in vectors:
            for r in vectors:
                if any(a):
                    self.assertLessEqual(challenge_root_count(a,r,q),1)
    def test_post_hash_choice_invalidates_fixedness(self):
        q=101; a=(3,5)
        for c in range(q):
            r=tuple(-c*x%q for x in a)
            self.assertFalse(any(residual(a,r,c,q)))
    def test_simulated_challenge_proof_passes(self):
        # Real scalar-group fixture, not an extractor: A=tK, R=zK-cA.
        q=101; K=7; A=13; z=19; c=23
        R=(z*K-c*A)%q
        self.assertEqual(z*K%q,(R+c*A)%q)
    def test_formal_coordinates_are_not_independent_group_elements(self):
        # In a cyclic group K=7P; vector (7,-1) is nonzero yet evaluates to zero.
        self.assertEqual((7*1-7)%101,0)
        self.assertTrue(any((7,-1)))
    def test_affine_proxy_consistency_requires_no_DDH(self):
        q=101; omega_k=17; A=19; K=7; shift=3
        F=lambda x:x*pow(omega_k,-1,q)%q
        self.assertEqual(F(A+shift*K),(F(A)+shift*F(K))%q)
        self.assertNotEqual((F(A+shift*K)+1)%q,(F(A)+shift*F(K))%q)
    def test_scoped_bound(self):
        self.assertEqual(restricted_bound(2,1,101),Fraction(2,101)+Fraction(1,100))
        self.assertEqual(restricted_bound(101,1,101),1)
        with self.assertRaises(ValueError): restricted_bound(-1,1,101)

if __name__=='__main__': unittest.main()
