from pathlib import Path
import sys, unittest, json, hashlib
from itertools import product
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from model import *
suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'))
run=unittest.TextTestRunner(verbosity=2).run(suite)
if not run.wasSuccessful(): sys.exit(1)
vectors=list(product(range(5),repeat=2))
pairs=[(u,v) for u in vectors for v in vectors if any(u) or any(v)]
challenge=[(a,r) for a in vectors for r in vectors if any(a)]
result={'verdict':'FULL_EXTRACTION_UNRESOLVED', 'tests_run':run.testsRun,
        'failures':len(run.failures),'errors':len(run.errors),'skips':len(run.skipped),
        'fixed_prefix_vector_pairs':len(pairs),
        'fixed_prefix_max_roots':max(prefix_cancellation_count(u,v,5) for u,v in pairs),
        'fixed_challenge_vector_pairs':len(challenge),
        'fixed_challenge_max_roots':max(challenge_root_count(a,r,5) for a,r in challenge),
        'scope':'Formal-vector diagnostics and policy fixtures; no real-group security claim'}
(ROOT/'results').mkdir(exist_ok=True)
(ROOT/'results'/'observed.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
