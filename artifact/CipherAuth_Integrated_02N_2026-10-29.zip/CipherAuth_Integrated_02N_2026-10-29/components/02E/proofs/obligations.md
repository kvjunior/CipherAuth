# Proof and novelty ledger

| Item | Status |
|---|---|
| Fixed-vector challenge-root lemma | Proved in n2_attempt.md |
| Fixed-vector prefix-root lemma | Proved in n2_attempt.md |
| Restricted union bound | Proved under explicitly stated fresh-query hypotheses |
| Mapping adaptive AGM+ROM transcripts to those hypotheses | OPEN |
| Hardness solver for nonzero formal relations | OPEN |
| Challenge proof simulation and exceptions | OPEN |
| Consistent scalar token/grant distribution | OPEN |
| Full G-CONF-CT and G-CONF-CLASS confidentiality | OPEN |
| Counterexample to full prefix-weighted candidate | NOT ESTABLISHED |
| Novel main result | NOT ESTABLISHED |

Do not sum undefined terms into an advantage inequality and label it a preliminary bound.
Separate confirmation-tag guessing, scalar-root events, RO programming collisions,
hardness reductions and any key-selection losses; derive each from the precise experiment.
No numerical end-to-end security bound is supplied in this batch.

Primary source scope checked 2026-10-25:
- https://eprint.iacr.org/2022/222 : primary abstract states tight signature security
  reductions for incremental half-aggregation in AGM+ROM. This alone does not prove
  per-record adaptive extraction for this encryption construction.
- https://eprint.iacr.org/2019/877 : primary abstract states signed ElGamal CCA2 under
  DDH and signed hashed ElGamal KEM security under DL, in AGM+ROM. It does not state
  the present aggregate-PRE theorem.
Full proof transfer, Kondi–shelat full-text comparison and IDASR26 comparison remain open.
The simple vector lemmas above are elementary algebra and are not claimed novel.
