# n=2 extraction attempt: precise restricted result and unresolved transfer

## Verdict

UNRESOLVED for the full augmented CipherAuth G-CONF-CT game. The earlier reviewer phrase
“provable, not attackable” is a conjecture supported by a sketch, not a completed proof.
This batch proves two elementary formal-vector lemmas below. It gives counterexamples to
intermediate proof claims, not a cryptanalytic break of the prefix-weighted construction.

## Correct equation

Use the plus-sign convention z_i K = R_i + c_i A_i and b_1=1. (The historical
reviewer's probe uses a minus-sign response convention; formulas must be translated.)
Let A_i have coordinate alpha_ij and R_i have coordinate rho_ij on a formal
unknown symbol X_j. The aggregate residual at that coordinate is

    (rho_1j + c_1 alpha_1j) + b_2 (rho_2j + c_2 alpha_2j).

The earlier formula c_1 alpha_1j + b_2 c_2 alpha_2j omitted both R coordinates.
That omission excludes precisely the way a malicious proof commitment can cancel a
challenge contribution. No hypothesis in the full game forces the R coordinates to zero.

## Lemma 1: fixed-vector challenge roots

Let q be prime and alpha,rho be vectors over F_q, fixed before uniform c in F_q.
If alpha is nonzero, Pr[rho+c alpha=0] <= 1/q.

Proof. Pick j with alpha_j != 0. The j-th equation fixes at most one value
c=-rho_j/alpha_j. All remaining equations can only remove that value. QED.
If alpha=0 and rho !=0 there are no roots. If both vanish every c is a root.

## Lemma 2: fixed-vector prefix roots

Let v_1,v_2 be vectors fixed before uniform b in F_q^*. If at least one is nonzero,
Pr[v_1+b v_2=0] <= 1/(q-1).

Proof. If v_2=0 and v_1!=0 there are no roots. Otherwise a nonzero coordinate
of v_2 fixes at most one b; all other coordinates impose additional constraints. QED.

These proofs hold for arbitrary dimension. The included exhaustive checks over F_5^2
cover 600 nonzero-alpha challenge pairs and 624 nontrivial prefix pairs; each has at
most one root. The written arguments, not those finite checks, prove the lemmas.

## Corollary for a restricted online experiment

Suppose every challenge trial fixes (alpha,rho) before its own fresh independent c;
every prefix trial fixes (v_1,v_2) before its own fresh independent nonzero b;
queries that repeat return cached values and do not count as fresh trials; and
success requires a nontrivial zero residual in one of these trials. With at most
T_c challenge trials and T_b prefix trials, the union bound is

    Pr[success] <= min(1, T_c/q + T_b/(q-1)).

This includes adaptive selection based on the past, because the next fresh answer
is independent conditional on that past. It does NOT allow the current vectors to
be selected after their own hash answer. The test choosing rho=-c alpha after c
succeeds for every c, demonstrating the necessity of this hypothesis.

## Why this is not an AGM extraction theorem

1. Group equality does not imply equality of formal coordinate vectors. A cyclic
   group has one dimension over F_q, even if the adversary was given many points.
   An AGM representation provides known coefficients, not independent basis elements.
   Nontrivial formal relations must lead to an explicitly constructed hardness solver;
   they cannot just be declared impossible. This batch deliberately checks symbolic
   identities only, not all accepted real-group equations.
2. The full ROM adversary can query coefficient hashes before the c hashes used in
   final verification. A public encoding or a prover's normal algorithm does not
   impose the adversary's query order. Guessing, cached queries, selection among
   prefixes, and reordered entries require an exact experiment and reduction.
3. A simulated challenge proof may use R*=z*K-c*A* followed by RO programming.
   It is valid despite having an unknown witness. It violates the freshness condition
   in Lemma 1 deliberately. Honest proofs, simulated proofs, and replays must have
   precise exceptions and extraction tables. No blanket per-record claim covers them.
4. A numerically known group point need not have a known discrete logarithm. Requiring
   zero coefficients on every unknown-log point is stronger than requiring a computable
   Q. Conversely an arbitrary representation of A does not give k^{-1}A. An extractor
   must supply actual algorithms for computing the required openings, possibly from
   a table of previously known openings, without using hidden challenge data.
5. Prior oracle-output points, multiple keys, grants and re-encryption replies must
   be reduced to a justified representation system with an online extraction invariant.
6. There is no complete reduction for the fixed implementation's scalar token Omega,
   its public hash W, or the delegated decryption interface yet.

## Challenge validity versus refusal

An honest challenge is generated with a valid intake proof. A reduction lacking its
witness must simulate that proof with the correct distribution. It cannot issue an
invalid proof and claim the intake gate excludes the challenge. G-CONF-CT refusal for
corrupted recipients comes from the challenge-derivative policy, not proof invalidity.
The frozen G-CONF-CLASS interface permits visible challenge transformation to an honest
recipient. Adding a proof alone does not remove that permitted query or close D1.

## Required next mathematical deliverable

Freeze the exact encoded statement, proof-challenge hash, prefix hash and registration
experiment; give the extractor's information at every query; handle a simulated challenge
proof and one ordinary proof in either list position; then either construct the AGM
hardness solver for nonzero formal relations or exhibit a legal adversary. Only after
this transfer is proved can the restricted bound be used in a confidentiality theorem.
