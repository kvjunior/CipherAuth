# Corrections to previous deliverables

I wrote and accepted earlier claims too quickly. This note supersedes those claims;
it does not alter the frozen archives or claim that the candidate scheme is broken.

- 02A verify_record checked an equation with the supplied c but did not recompute
  the Fiat–Shamir challenge. Its cancellation routine changes A while retaining c.
  That is not a valid full-transcript forgery demonstration. Its aggregate verifier
  also requires individual responses, contradicting a compressed-only verifier.
  Its witness extractor reads fixture secrets, and K=1 reveals the witness as A.
- 02A coefficients were externally supplied byte strings, not derived from canonical
  records. Map-zero-to-one is biased. None of its tests establishes cryptographic binding.
- 02B treats formal vectors as independent bases and calculates the aggregate response
  from retained individual z_i. It tests symbolic consistency, not a full AGM adversary
  or the compressed verifier interface. Cancellation chosen after coefficients is not
  by itself a legal Fiat–Shamir attack.
- 02C omits R_i coefficients from its proposed extraction equation. Its fixed SHA-256
  experiment with formal-coordinate encodings, fixed c1, and small q is not the full
  group/ROM experiment. “Exhaustive search” stopped at the first root; 112 trials was
  an observed stopping point, not an asymptotic work factor or a completed enumeration.
- 02D proxy_reencrypt marks EVERY served child's core as a challenge derivative. This
  incorrectly refuses ordinary decryptions. The replacement ledger marks a child only
  when its parent is protected. It retains the frozen restriction for corrupt recipients
  while permitting honest-recipient transformations with valid intake.
- 02D dec_origin and dec_delegatee decide acceptance by query-list flags alone. A real
  opener checks the commitment and authentication. A simulator's query-list lookup
  needs proof; missing queries are not intrinsically a successful guess or an attack.
  The replacement policy consumes a labelled fixture opener verdict, not a secret-key
  decryption implementation, and separately applies derivative refusal and RCCA masking.
- 02D's sum of all RO queries divided by group order is withdrawn. Commitment guessing
  depends on hash bit lengths; scalar challenges and prefix weights have other domains.
  The included bound applies ONLY to the restricted fixed-vector experiment.
- Earlier class drafts confuse scalar Omega=omega*k mod q with point omega*K.
  Frozen cea.py hashes the scalar Omega in W; hashing omega*K changes the scheme.
  A simulator cannot substitute that point and call W honestly generated.
- The random-point hybrid has a direct same-grant affine consistency obligation:
  F(A+rK)=F(A)+rF(K), for F(X)=Omega^{-1}X. This equality is checkable without a
  DDH oracle whenever those queries are served. Independent random substitutions
  fail it. Cross-grant DDH observations do not repair this same-grant problem.
- A generic signature-simulation term is unnecessary when the reduction can generate
  honest signing keys itself. Where signing keys are embedded or forgery exclusions
  are used, the corresponding reduction and event must be specified.
- Gap and ordinary decisional assumptions can appear in separate hybrids using separate
  reductions. The actual D1 concern is missing oracle simulation for a particular hybrid,
  not a general rule that all hybrid proofs require a single reducing machine.

The 13 new tests include regression witnesses for the policy mistakes, omitted R terms,
post-query vector selection, valid simulated challenge proofs, dependent group coordinates,
and affine proxy consistency. They do not validate the unimplemented full extractor.
