import unittest
from dataclasses import replace

from cipherauth import group as g
from cipherauth.cea import CEA, Directory, SUITE, parse_body, _body
from cipherauth.models import BatchContext
from class_game import (Honesty, decrypt_decision, find_opening_from_queries,
                        grant_decision, reencrypt_decision, restore_with_omega,
                        target_class_needs_intake_extraction, transform_with_omega)


class ClassGameTests(unittest.TestCase):
    def test_target_grant_to_honest_returns_public_part_only(self):
        decision = grant_decision(target_class=True, delegatee=Honesty.HONEST)
        self.assertTrue(decision.allowed)
        self.assertFalse(decision.reveal_secret_token)

    def test_target_grant_to_corrupted_is_refused(self):
        self.assertFalse(grant_decision(target_class=True,
                                        delegatee=Honesty.CORRUPTED).allowed)

    def test_off_target_grant_is_not_the_embedded_case(self):
        decision = grant_decision(target_class=False, delegatee=Honesty.CORRUPTED)
        self.assertTrue(decision.allowed)
        self.assertTrue(decision.reveal_secret_token)

    def test_target_reencrypt_to_honest_is_allowed(self):
        decision = reencrypt_decision(target_class=True, delegatee=Honesty.HONEST,
                                      admissible=True, registered_core=False)
        self.assertTrue(decision.allowed)
        self.assertFalse(decision.register_derivative)

    def test_target_challenge_reencrypt_to_honest_registers_derivative(self):
        decision = reencrypt_decision(target_class=True, delegatee=Honesty.HONEST,
                                      admissible=True, registered_core=True)
        self.assertTrue(decision.allowed)
        self.assertTrue(decision.register_derivative)

    def test_target_reencrypt_to_corrupted_is_always_refused(self):
        for registered in (False, True):
            self.assertFalse(reencrypt_decision(target_class=True,
                                                delegatee=Honesty.CORRUPTED,
                                                admissible=True,
                                                registered_core=registered).allowed)

    def test_inadmissible_pair_is_refused(self):
        self.assertFalse(reencrypt_decision(target_class=True,
                                            delegatee=Honesty.HONEST,
                                            admissible=False,
                                            registered_core=False).allowed)

    def test_decryption_refuses_core_and_derivative(self):
        self.assertFalse(decrypt_decision(registered_core=True,
                                          registered_derivative=False).allowed)
        self.assertFalse(decrypt_decision(registered_core=False,
                                          registered_derivative=True).allowed)
        self.assertTrue(decrypt_decision(registered_core=False,
                                         registered_derivative=False).allowed)

    def test_exact_transform_and_restore_for_arbitrary_points(self):
        for Omega in (3, 17, 101):
            for scalar in (1, 2, 999, g.q - 1):
                A = g.mul(scalar, g.G)
                self.assertEqual(restore_with_omega(Omega,
                                                    transform_with_omega(Omega, A)), A)

    def test_query_table_gap_test_finds_opening(self):
        k, t = 37, 41
        K, Q, A = g.mul(k, g.G), g.mul(t, g.G), g.mul(k * t, g.G)
        def ddh(_P, supplied_K, candidate, supplied_A):
            return supplied_K == K and supplied_A == A and g.mul(k, candidate) == A
        candidates = (g.mul(7, g.G), Q, g.mul(9, g.G))
        self.assertEqual(find_opening_from_queries(K, A, candidates, ddh), Q)

    def test_query_table_absence_returns_none(self):
        k, t = 37, 41
        K, A = g.mul(k, g.G), g.mul(k * t, g.G)
        ddh = lambda _P, _K, candidate, supplied_A: g.mul(k, candidate) == supplied_A
        self.assertIsNone(find_opening_from_queries(K, A,
                                                     (g.mul(7, g.G), g.mul(9, g.G)), ddh))

    def test_class_routes_do_not_request_intake_extraction(self):
        for operation in ("grant", "reencrypt", "decrypt"):
            for party in Honesty:
                self.assertFalse(target_class_needs_intake_extraction(operation, party))

    def test_actual_proxy_transforms_adversarial_body_point_exactly(self):
        directory = Directory(); system = CEA(directory)
        owner = directory.new_signing_key("owner")
        origin = directory.new_decryption_key("owner", tag=b"t", epoch=1)
        ell = directory.new_decryption_key("ell")
        sender = directory.new_signing_key("sender")
        sub = system.signcrypt(sender, "owner", b"secret", b"t", 1)
        aggregate = system.aggregate(BatchContext(SUITE, "origin", origin.ref,
                                                  origin.ref, 1), [sub])
        Lam, c, _old_A, E = parse_body(aggregate.records[0].body)
        arbitrary_A = g.mul(123456789, g.G)
        changed_record = replace(aggregate.records[0], body=_body(Lam, c, arbitrary_A, E))
        changed = replace(aggregate, records=(changed_record,))
        # Sender authentication intentionally does not bind A.
        self.assertTrue(system.verify_public(changed))
        token, grant = system.issue_grant(owner, origin, ell.ref, b"t", 1)
        delegated = system.delegate_aggregate(token, grant, changed)
        Abar = parse_body(delegated.aggregate.records[0].body)[2]
        self.assertEqual(Abar, transform_with_omega(token.Omega, arbitrary_A))

    def test_unknown_operations_are_rejected_by_dependency_check(self):
        with self.assertRaises(ValueError):
            target_class_needs_intake_extraction("novelty", Honesty.HONEST)


if __name__ == "__main__":
    unittest.main(verbosity=2)
