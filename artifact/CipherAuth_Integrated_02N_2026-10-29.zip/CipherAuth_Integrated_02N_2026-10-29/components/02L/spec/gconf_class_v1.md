# G-CONF-CLASS-v1 oracle interface

This version selects the class-granularity notion already identified by the
frozen game as CEA's intended target. It does not modify the construction and it
does not claim G-CONF-CT.

## Setup and corruption

The adversary fixes the target origin class `(origin KeyRef, tag, epoch)` and the
set of honest and corrupted recipients before the challenge. The target class key,
target proxy and designated honest delegatees remain uncorrupted. Other keys may
be generated or corrupted according to the existing game. Adaptive corruption of
a target honest delegatee is outside v1.

## Oracles

| Oracle | Target-class rule |
| --- | --- |
| `GrantO(class,ell)` | Refuse corrupted `ell`. For honest `ell`, record admissibility and return only the signed grant and public `(C,gamma,W)`; retain scalar `Omega` at the proxy. |
| `ReEncO(class,ell,Z)` | Require admissibility and public/intake acceptance. Refuse corrupted `ell` for every `Z`. For honest `ell`, transform every body point exactly; if the input contains a registered core, register the returned core as a derivative. |
| `DecO(party,Z)` | Refuse any registered challenge core or derivative. Otherwise run the ordinary opening simulation and replace either challenge message with `TEST`. |
| `CorruptProxyO` | Unavailable for the target class. |

The challenge registers `(full class KeyRef,A*,E*)`. Exact challenge re-encryption
to an honest delegatee is allowed and its output becomes a derivative. No target-
class authorization or service path exists for a corrupted delegatee.

## Explicit non-target

G-CONF-CT is not inherited, repaired or proved here. The existing `A`-mauling
attack shows that the current construction does not meet that per-ciphertext
notion. Consequently its earlier grant/admissibility ambiguity is not a premise
of the v1 theorem.
