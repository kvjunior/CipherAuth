# G-CONF-CLASS dependency closure

Status: proof-architecture lemma and frozen oracle mapping, pending independent
review. This removes the full AGM extraction lemma from the dependency graph of
G-CONF-CLASS-v1; it does not yet assemble the final confidentiality reduction.

## Why target-class extraction is unnecessary

The only target-class `ReEncO` outputs in v1 go to statically honest delegatees.
After the uniform-C hop, the simulator samples and retains the scalar `Omega`.
For every adversarial body point `A`—including the challenge, a repeated point, a
point with any AGM representation, or a point with no extracted opening—it returns

`Abar = Omega^-1 A`.

This is the exact implemented map. It requires no witness `t`, no opening
`Q=k^-1 A`, and no representation vector. Repeated, affine and cross-grant
relations are preserved automatically. Target-class service to corrupted
delegatees, the only path that would need `omega^-1 Q`, is forbidden by the
CLASS game and is already known to be insecure in the CT game.

The intake proof is still verified by the real proxy interface. Its knowledge
soundness is not used as a confidentiality reduction premise: accepting more
adversarial points can only enlarge the set on which the exact transform simulator
operates. Sender authenticity and intake soundness remain separate claims.

## Decryption without representation extraction

For an ordinary target-origin decryption query with body point `A`, enumerate the
recorded `KDF/Hd` point queries `Q` and use the decision oracle supplied to the
Gap-Divisible-DH reduction to test `A=kQ`, i.e. the tuple `(P,K,Q,A)`. If a match
exists, compute and verify the opening exactly. If none exists, reject. The ROM
difference when a valid opening succeeds without the necessary queries is an
explicit guessing term for the final bound.

For an ordinary delegated query, first restore `A=Omega*Abar`, then use the same
query-table procedure. Registered challenge cores and derivatives are refused by
the game before this path. Thus neither origin nor delegated `DecO` needs an AGM
opening extractor.

## Remaining reduction work

The final proof must still supply one ordered hybrid sequence and a quantitative
bound for challenge programming, KDF/opening/commitment guesses, mask exposure,
signature simulation where applicable, and multi-user losses. It must verify that
each hybrid uses its own legitimate reduction interface. These are bookkeeping
and review obligations, not permission to claim security before the proof is
written and checked.
