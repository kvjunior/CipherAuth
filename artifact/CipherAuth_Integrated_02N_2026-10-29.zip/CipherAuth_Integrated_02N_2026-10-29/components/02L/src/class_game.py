"""Executable routing model for frozen G-CONF-CLASS-v1.

This module separates service policy from cryptographic acceptance.  ``allowed``
means the oracle interface permits the request; public verification, intake
verification and opening checks remain mandatory in the real construction.
"""
from dataclasses import dataclass
from enum import Enum

from cipherauth import group as g


class Honesty(Enum):
    HONEST = "honest"
    CORRUPTED = "corrupted"


@dataclass(frozen=True)
class OracleDecision:
    allowed: bool
    reveal_secret_token: bool = False
    register_derivative: bool = False
    reason: str = ""


def grant_decision(*, target_class, delegatee):
    if target_class and delegatee is Honesty.CORRUPTED:
        return OracleDecision(False, reason="target class is never granted to a corrupted delegatee")
    # The target-class proxy retains Omega.  Only the signed grant and public
    # token part are returned for an honest delegatee.
    return OracleDecision(True, reveal_secret_token=not target_class,
                          reason="admissible class/delegatee pair recorded")


def reencrypt_decision(*, target_class, delegatee, admissible, registered_core):
    if not admissible:
        return OracleDecision(False, reason="pair is not admissible")
    if target_class and delegatee is Honesty.CORRUPTED:
        return OracleDecision(False, reason="G-CONF-CLASS forbids target service to corrupted parties")
    return OracleDecision(True, register_derivative=bool(target_class and registered_core),
                          reason="honest proxy service")


def decrypt_decision(*, registered_core, registered_derivative):
    if registered_core or registered_derivative:
        return OracleDecision(False, reason="challenge core or derivative refused")
    return OracleDecision(True, reason="ordinary opening subject to TEST masking")


def transform_with_omega(Omega, A):
    """Exact honest-proxy transform, independent of any AGM representation."""
    g.validate_scalar(Omega, nonzero=True)
    return g.mul(g.inv(Omega), g.validate_point(A))


def restore_with_omega(Omega, Abar):
    """Undo the simulated honest-proxy transform before target-class DecO."""
    g.validate_scalar(Omega, nonzero=True)
    return g.mul(Omega, g.validate_point(Abar))


def find_opening_from_queries(K, A, candidates, ddh_test):
    """Find Q with A=kQ using the reduction's Gap decision oracle.

    The function returns no fabricated point: absence from the query table is a
    rejection path whose ROM guessing difference belongs in the final bound.
    """
    K, A = g.validate_point(K), g.validate_point(A)
    for Q in candidates:
        Q = g.validate_point(Q)
        if ddh_test(g.G, K, Q, A):
            return Q
    return None


def target_class_needs_intake_extraction(operation, delegatee):
    """Dependency check for the v1 CLASS simulator, not a soundness claim."""
    if operation not in ("grant", "reencrypt", "decrypt"):
        raise ValueError("unknown operation")
    if delegatee not in (Honesty.HONEST, Honesty.CORRUPTED):
        raise ValueError("invalid delegatee status")
    # Corrupted target service is refused. Honest transformation uses Omega;
    # decryption uses the Gap query-table test after restoring A.
    return False
