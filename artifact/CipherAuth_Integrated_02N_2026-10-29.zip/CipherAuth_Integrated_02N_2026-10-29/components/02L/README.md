# CipherAuth Batch 02L — G-CONF-CLASS-v1 closure

Batch 02L freezes the class-granularity oracle interface and removes full AGM
opening extraction from that theorem's dependency graph. Honest target-class
re-encryption uses the exact scalar-Omega map; ordinary decryption uses the Gap-
Divisible-DH query-table test. G-CONF-CT is explicitly out of scope and false for
the current construction.

Run `python3 scripts/reproduce.py`, then review `spec/gconf_class_v1.md` and
`proofs/dependency_closure.md`. Full security remains unproved until the final
hybrid reduction and loss are assembled and independently reviewed.
