#!/usr/bin/env python3
import json, stat, subprocess, sys, tempfile, unittest, zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'vendor')]

def extract_safe(archive,destination):
    with zipfile.ZipFile(archive) as handle:
        for item in handle.infolist():
            path=Path(item.filename)
            if path.is_absolute() or '..' in path.parts or stat.S_ISLNK(item.external_attr>>16):
                raise RuntimeError('unsafe baseline archive member')
        handle.extractall(destination)

def main():
    archive=ROOT/'baseline/CipherAuth_Batch02K_MaskExposure_2026-10-28.zip'
    with tempfile.TemporaryDirectory() as folder:
        extract_safe(archive,folder)
        base=Path(folder)/'CipherAuth_Batch02K_MaskExposure'
        expected=(base/'results/observed.json').read_bytes()
        subprocess.run([sys.executable,str(base/'scripts/verify_manifest.py')],check=True,capture_output=True)
        subprocess.run([sys.executable,str(base/'scripts/reproduce.py')],check=True,capture_output=True)
        if expected!=(base/'results/observed.json').read_bytes():
            raise RuntimeError('02K baseline result changed')
    suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'))
    tests=unittest.TextTestRunner(verbosity=2).run(suite)
    result={
        'batch':'02L','tests_run':tests.testsRun,'failures':len(tests.failures),
        'errors':len(tests.errors),'skips':len(tests.skipped),'prior_tests_02K':13,
        'prior_results_byte_identical':True,'target_game':'G-CONF-CLASS-v1',
        'G_CONF_CT':'OUT_OF_SCOPE_AND_KNOWN_FALSE_FOR_CURRENT_CONSTRUCTION',
        'target_class_AGM_extraction_required':False,
        'honest_transform':'EXACT_WITH_SCALAR_OMEGA',
        'ordinary_DecO':'GAP_QUERY_TABLE_TEST_AFTER_OPTIONAL_RESTORE',
        'final_hybrid_reduction':'OPEN','full_security_proved':False}
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results/observed.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))
    return 0 if tests.wasSuccessful() and not tests.skipped else 1

if __name__=='__main__': sys.exit(main())
