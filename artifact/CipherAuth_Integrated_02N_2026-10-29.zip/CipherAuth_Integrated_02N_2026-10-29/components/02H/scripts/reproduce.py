#!/usr/bin/env python3
import hashlib,json,subprocess,sys,tempfile,unittest,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'vendor')]
from cases import all_cases
from replay_challenge import replay

def main():
    archive=ROOT/'baseline/CipherAuth_Batch02G_Adaptive_2026-10-25.zip'
    with tempfile.TemporaryDirectory() as folder:
        with zipfile.ZipFile(archive) as z:z.extractall(folder)
        base=Path(folder)/'CipherAuth_Batch02G_Adaptive'
        expected={name:(base/'results'/name).read_bytes() for name in ('observed.json','traces.json')}
        subprocess.run([sys.executable,str(base/'scripts/verify_manifest.py')],check=True,capture_output=True)
        subprocess.run([sys.executable,str(base/'scripts/reproduce.py')],check=True,capture_output=True)
        for name,data in expected.items():
            if data!=(base/'results'/name).read_bytes():raise RuntimeError('baseline results changed')
        for name in ('adaptive.py','replay.py'):
            if (base/'src'/name).read_bytes()!=(ROOT/'vendor'/name).read_bytes():raise RuntimeError('vendor changed')
        for p in (base/'vendor/cipherauth02f').glob('*.py'):
            if p.read_bytes()!=(ROOT/'vendor/cipherauth02f'/p.name).read_bytes():raise RuntimeError('kernel changed')
    tests=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.discover(str(ROOT/'tests')))
    cases=all_cases()
    for item in cases:replay(item)
    raw=json.dumps(cases,indent=2,sort_keys=True)+'\n'
    (ROOT/'results/traces.json').write_text(raw)
    result={'batch':'02H','tests_run':tests.testsRun,'failures':len(tests.failures),'errors':len(tests.errors),
            'skips':len(tests.skipped),'prior_tests_02G':23,'prior_tests_02F':34,
            'prior_results_byte_identical':True,'cases':len(cases),'traces_replayed':len(cases),
            'trace_sha256':hashlib.sha256(raw.encode()).hexdigest(),
            'case_statuses':{item['name']:item['result']['status'] for item in cases},
            'full_security_proved':False,'frozen_games_changed':False}
    (ROOT/'results/observed.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))
    return 0 if tests.wasSuccessful() and not tests.skipped else 1

if __name__=='__main__':sys.exit(main())
