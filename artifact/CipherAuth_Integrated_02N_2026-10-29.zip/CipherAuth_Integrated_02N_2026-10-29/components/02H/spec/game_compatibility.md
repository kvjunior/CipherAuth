# Exact proof exceptions versus frozen core policy

The source is `provenance/frozen_games.md`, copied byte-for-byte from the existing
workspace's `spec/games.md`. This note records a mapping and an ambiguity; it does
not revise or silently weaken that source.

## Distinct predicates

| Predicate | Compared fields | Role |
|---|---|---|
| 02H exact exception | Whole canonical 02F challenge input, including context, sender, commitment, body, A and R | Which entries may lack an extracted opening |
| Frozen challenge core | Full class ref, A and E | Registered challenge/derivative refusal |
| Executable core projection | 02F origin/tag/epoch/key encoding, A and body | Tests the core-policy logic only |

02F does not implement the full KeyRef with identity, role, version and fingerprint.
Its context therefore is not a lossless replacement for the frozen game's types.
The projection does not implement sender signatures, authenticated grants, opening
checks, or message masking. `POLICY_PERMITS` means only that a policy filter did
not refuse; it is neither cryptographic validity nor successful decryption.

The projection takes recipient corruption and grant admissibility as trusted
external inputs. It does not implement an adaptive corruption oracle or permit
an adversary to choose its own authorization. Similarly, `observe_transform` is
called by a trusted harness after a transformation, not an adversary endpoint.

## Cases checked

- Changing sender or R alone changes the exact proof input, but preserves A,E and
  thus the challenge core. CT service to a corrupted target-class delegatee and
  DecO remain blocked on that registered core.
- Changing A or E creates an unregistered core under the frozen definition. This
  does not imply acceptance: validity/commitment checks are still necessary.
- A transformed child is added to the derivative ledger only when its parent was
  registered. Ordinary transformations do not become challenge derivatives.
- A batch containing any registered core is denied by the projected decryption
  filter. The simulation still owes a proof of its separate opening/masking behavior.
- CLASS forbids target-class service to corrupted recipients even on ordinary
  records. CT's intended per-ciphertext filter permits ordinary non-derivative
  records only under the separately supplied admissibility precondition.
- Target-class transformation to an honest delegatee is permitted, including the
  registered challenge. The resulting derivative is registered and remains
  excluded from DecO. This is not removed by the intake-proof lemma.

## Frozen G-CONF-CT grant/admissibility ambiguity

The frozen CLASS text prohibits target-class `GrantO` to a corrupted delegatee and
says ReEncO is defined only for admissible pairs recorded by GrantO. The CT paragraph
says it is "As G-CONF-CLASS, except" the specified ReEncO service rule. It does not
explicitly say whether target-class GrantO for corrupted delegatees becomes available,
whether such pairs can be provisioned another way, or whether "answered whenever"
overrides the earlier admissibility condition.

Under a literal inheritance of the GrantO prohibition AND the admissibility
precondition, no such target pair can be established through GrantO. Under the
intended service interpretation, the honest proxy presumably can hold the token
and serve eligible records without exposing a secret token to the adversary.
Those are different formal oracle interfaces. Neither is selected silently here.

The tests therefore make admissibility explicit and test both values; they do not
claim to be a complete executable version of the frozen CT game. A future versioned
game specification must state how the proxy obtains/authorizes the target-class
token for a corrupted recipient and exactly which public/secret fields each oracle
reveals. Full target-class token disclosure must not be casually introduced: it
would let a corrupted delegatee perform transformations locally.

The ambiguity does not affect the restricted algebraic lemma, which has no grants
or service oracle. It remains a required clarification before a full confidentiality
reduction can be claimed. No new permission from the user is needed to continue
the remaining research; the issue is mathematical specification, not approval.
