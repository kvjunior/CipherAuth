# Batch 02H implementation scope

This batch extends the 02G restricted harness. It does not modify the 02F
compressed verifier or its exact transcript, and it does not integrate a new CEA
scheme. The prior archive and imported source files are byte-identical copies.

`OneChallengeOracle.install(record,c,z)` installs one designated challenge before
any other registrations or oracle answers. It checks A=X, canonical scalars,
nonidentity R=zK-cX and no initial K/X collision, then registers the known
representation and programs only that fresh input. Other programming calls fail.
`sample_setup` samples seeded fixture coins, retries identity, and aborts on K/X
collisions. Neither seeded fixture randomness nor explicit fixture coins are
production cryptographic randomness.

`extract_nonexempt` checks the designated ticket, verifies the compressed batch,
classifies exact exceptions, and uses the 02G relation diagnostic to compute
openings for non-exempt entries. In a mixed batch it also calculates the ordinary
response by subtracting the designated proof's weighted response and verifies
that resulting individual equation. It never reads a secret class key or fixture
witness. It leaves a truly unresolved non-exempt opening null.

`replay_challenge` rebuilds the setup from public c,z and bytes, checks that the
initial trace prefix exactly matches that setup, forbids later programming, validates
registrations/caches, and checks final-oracle completeness before verification.
It recomputes the final result. It validates concrete consistency, not uniformity
of the recorded oracle answers, adversary legality in a full game, or a theorem.

Thirteen cases cover both challenge positions and c-before-b/b-before-c orders,
accepted witness-aware relabelled/new-proof fixtures, rejected reuse after changing
A, duplicate exact challenges, a batch containing no exception, and a controlled
fresh-hash collision that must remain unresolved. The policy tests separately
exercise core equality, derivative propagation and honest/corrupted recipient rules.

The harness uses ordinary Python objects; it is not an isolation boundary against
code that mutates internal mappings. Public methods define the experimental API.
The scoped loss and model restrictions are in `proofs/challenge_extension.md`.
