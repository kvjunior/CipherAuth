# Setup-first programmed-challenge extension for two records

Status: written restricted proof, pending independent review. No full CipherAuth
confidentiality theorem or novelty claim follows. The statement deliberately does
not cover a challenge issued after adversarial pre-challenge queries.

## 1. Experiment and exception set

Retain Batch 02G's immutable two-point representation experiment over a prime-order
group, with distinct nonidentity public points K and X=xK and prime q>3. The
extractor is not given x. A point Y has a registered representation Y=aK+alpha X,
fixed before any query using it. Encodings and the verifier are exactly Batch 02F.
There is one context, one designated record A*=X, and two entries per final batch.
This is a stronger interface restriction than an unqualified claim of the AGM.

Before any adversarial queries or registrations, the simulator installs ONE valid
challenge proof. Its record's other fields are fixed before simulation coins.
Sample c*,z* uniformly in F_q, compute R*=z*K-c*X, and retry the pair if R* is the
identity. If R* equals K or X, abort this restricted setup to avoid an alternate
representation of an already registered initial point. Otherwise register

    A* = 0 K + 1 X,
    R* = z* K - c* X,

and program the fresh challenge input H_c(Context,Record*,R*) to c*. The simulator
knows z*,c* and the public points, but neither x nor the class secret k.

After setup, every other challenge input is answered by a fresh uniform F_q value
on first query; weight inputs use fresh uniform F_q^* values. Answers are cached.
Further programming is forbidden. Query orders and non-challenge entries may be
adaptive. All final-verifier queries count toward the query budgets.

**Exact exception:** an entry is exempt precisely when its entire canonical
challenge-hash input equals the designated input. Equality of A alone, sender
alone, record core alone, or a caller-supplied exemption flag is insufficient.
The exception is fixed by the simulator's ticket, not by the adversary or a set
of arbitrarily programmable inputs. Repeated identical entries are all exempt.

The extractor must return a numerical t_i with A_i=t_i K for every NON-exempt
entry in an accepted two-record batch. It may leave exempt positions null even
if it could compute them. This exception set is for the extraction statement;
Section 6 separates it from security-game refusal and derivative rules.

## 2. Setup distribution and its explicit abort

Consider an honest proof for the same fixed record and A*=xK. Choose r uniformly
in F_q^*, let R=rK, obtain a fresh uniform c from the initially empty oracle,
and set z=r+cx. For each fixed x, the map

    (r,c) -> (c,z=r+cx)

is a bijection between F_q^* x F_q and the pairs (c,z) for which z-cx is nonzero.
Thus the simulated (c,z,R) distribution after retrying identity matches the honest
one exactly. The programmed oracle table also matches: its input is fresh at
setup and its assigned c has precisely the distribution of a fresh honest query.
Future lazy answers at other inputs remain independent. This is a mathematical
scalar-ROM statement; seeded Python fixtures do not provide cryptographic randomness.

The additional registry-collision abort occurs for r=1 or r=x. Those are distinct
nonzero scalars, so its probability is exactly 2/(q-1). Conditional on not aborting,
the simulated view matches the corresponding honest view with those R values
excluded. A coupling to the unrestricted honest proof charges at most 2/(q-1).
Identity retry is already incorporated in the bijection and is not charged again.

This argument uses an empty oracle table and no other registered points at setup.
For adaptive challenge timing, prequeried inputs, prefix queries involving future
challenge bytes, and collisions with a larger registry need separate treatment.
The implementation rejects such timing rather than claiming it has analysed it.

## 3. Exact subtraction in a mixed batch

Let the weights be w1=1,w2=b, with b nonzero. Suppose one entry s is the exact
designated challenge and the other is j. Accepted verification gives

    ZK = w_s(R*+c*X) + w_j(R_j+c_j A_j).

Since R*+c*X=z*K, calculate from PUBLIC data and the known challenge response

    z_j = (Z-w_s z*) / w_j mod q.

Both possible w_j are invertible. Subtracting yields

    z_j K = R_j + c_j A_j.

Therefore the compressed batch exposes a numerically computable ordinary response
for its non-exempt entry; neither an individual stored z_j nor x was assumed.
The code calculates z_j and checks this equation in both list positions. This
algebra works regardless of whether b or c_j was queried first.

For A_j=a_j K+alpha_j X and R_j=r_j K+rho_j X, define

    d_j = r_j+c_j a_j-z_j,
    e_j = rho_j+c_j alpha_j.

If e_j!=0, group equality gives x=-d_j/e_j, which the extractor checks. Then
t_j=a_j+alpha_j x. If alpha_j=0, t_j=a_j already works. The remaining failure
case has alpha_j!=0 and e_j=0. The non-exempt entry's hash input is not programmed;
its coefficients were fixed before its fresh c_j. This event has probability
at most 1/q per fresh ordinary challenge input. A union bound gives N_c/q.

This is a concrete relation solver, not a declaration that formal group coordinates
are independent. The aggregate diagnostic uses the equivalent residual over the
whole batch; the exempt entry's X residual is exactly zero.

## 4. All output cases and a conservative bound

Let N_c bound all distinct NON-programmed challenge queries and N_b bound all
distinct two-entry prefix-weight queries, including verification. Budgets are
deterministic upper bounds, not measured averages. Condition on successful setup.

- Two exact exempt entries: there is no non-exempt extraction requirement.
- One exact exempt entry: Section 3 fails only at an ordinary nonzero-alpha root,
  already charged by the global N_c/q individual-root event.
- No exact exempt entry: neither output challenge is programmed. Apply 02G's
  four-event argument to all such prefixes. The programmed setup transcript is
  fixed prior information, and the later normal challenge/weight answers are still
  fresh. Reusing R* as an algebraic point is allowed with its known representation.
  The adversary may also construct new entries using A*=X; their new hash inputs
  are normal, not exempt.

The same shared individual-root event covers mixed and non-exempt-only outputs;
it need not be counted twice. The resulting conditional failure bound is

    delta_H = min(1, (N_c+N_b)/q + 2 N_b/(q-1)).

The remaining 02G events are the duplicate shared-challenge coefficient degeneracy
b=-1, weight-last roots, and challenge-last roots across all queried prefixes.
Those bounds and the immutable-representation hypothesis are unchanged. A
conservative total that also counts setup abort is

    min(1, 2/(q-1) + (N_c+N_b)/q + 2 N_b/(q-1)).

This is a written restricted extraction proof. It has not been independently
reviewed or machine-checked. It is not a concrete SHA-256 security bound and it
does not cover extra oracle-output points or additional programmed proofs.

## 5. Why the tests retain an unresolved case

The controlled-collision fixture relabels the challenge sender while keeping A*,R*.
It forces the NEW hash input to receive c*, so the old response z* verifies again.
Its new entry is not exempt. Its unknown X residual is zero and the diagnostic
correctly returns `UNRESOLVED_NONEXEMPT` rather than fabricating a witness.
For a genuinely fresh uniform challenge answer this has probability 1/q and is
one of the counted root events. Forcing that answer with a test tape is a negative
control, not an efficient attack on SHA-256 or a random oracle.

Other accepted relabelled/new-proof fixtures use known witness scalars in fixture
construction only. The extraction code receives public data and representations,
not those witness scalars. Recovering the known fixture logarithm in those tests
checks the reduction algebra; it is not a real-world discrete-log attack.

## 6. Relation to confidentiality games: not a completed transfer

Exact proof equality is narrower than the frozen core `(class ref,A,E)`. Altering
R, sender or commitment while retaining A,E changes an intake-proof input but
does not change that core. Such an entry can be non-exempt in the extraction lemma
yet still forbidden by the game's derivative policy. That is consistent: the
lemma may prove extraction for more inputs than a particular oracle must serve.

An honest-delegatee transformation of the exact challenge remains permitted by
the frozen games. It produces a challenge derivative and remains excluded from
DecO, but a reduction must still generate its correct visible transformation.
Exempting its opening in this lemma does not simulate that reply or close D1.

The frozen CT grant/admissibility ambiguity and the limits of the executable policy
projection are documented in `spec/game_compatibility.md`. No frozen game is edited.
The full theorem still needs adaptive challenge timing, additional algebraic bases,
precise registration interfaces, tokens/grants, decryption and transformation
simulation, and the exact prior-theorem/novelty comparison.
