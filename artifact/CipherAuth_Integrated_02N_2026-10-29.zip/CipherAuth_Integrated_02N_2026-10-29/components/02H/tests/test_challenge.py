import copy
from dataclasses import replace
from fractions import Fraction
import unittest
from adaptive import Registry,Rep
from cipherauth02f import group as g
from cipherauth02f.oracle import CHALLENGE
from cipherauth02f.transcript import challenge_input,decode,Context
from challenge_extension import (OneChallengeOracle,SetupAbort,sample_setup,validate_ticket,
                                 setup_error,total_error)
from cases import setup,mixed,duplicate,no_exempt,all_cases
from replay_challenge import replay
from policy_projection import Core,core,Ledger


class ChallengeTests(unittest.TestCase):
    def test_both_positions_and_both_orders(self):
        for p in (0,1):
            for order in ('weight_first','challenge_first'):
                item=mixed(p,order)
                result=replay(item)
                self.assertEqual(result['status'],'EXTRACTED_NONEXEMPT')
                self.assertEqual(result['exempt_positions'],[p])
                self.assertEqual(result['missing_nonexempt'],[])
                self.assertIsNone(result['openings'][p])
                self.assertEqual(result['remainder']['position'],1-p)
                self.assertTrue(result['remainder']['equation_verified'])

    def test_same_point_relabel_is_not_exact_exception(self):
        for p in (0,1):
            item=mixed(p,kind='relabelled')
            result=replay(item)
            self.assertEqual(result['exempt_positions'],[p])
            self.assertEqual(result['relation_solution'],997)
            self.assertEqual(result['status'],'EXTRACTED_NONEXEMPT')

    def test_new_proof_same_core_still_extracts_if_accepted(self):
        for p in (0,1):
            item=mixed(p,kind='new_proof_same_core')
            result=replay(item)
            self.assertEqual(result['exempt_positions'],[p])
            self.assertEqual(result['relation_solution'],997)

    def test_changed_point_reusing_response_rejected(self):
        for p in (0,1):
            self.assertEqual(replay(mixed(p,kind='changed_A_reused_response'))['status'],'REJECTED')

    def test_duplicate_exact_challenge_all_exempt(self):
        result=replay(duplicate())
        self.assertEqual(result['status'],'ALL_EXEMPT')
        self.assertEqual(result['openings'],[None,None])
        self.assertNotIn('remainder',result)

    def test_no_exact_challenge_extracts_both(self):
        result=replay(no_exempt())
        self.assertEqual(result['status'],'EXTRACTED_NONEXEMPT')
        self.assertEqual(result['exempt_positions'],[])
        self.assertTrue(all(result['openings']))

    def test_controlled_new_hash_collision_never_silently_exempted(self):
        item=mixed(0,'challenge_first','controlled_hash_collision')
        result=replay(item)
        self.assertEqual(result['status'],'UNRESOLVED_NONEXEMPT')
        self.assertEqual(result['exempt_positions'],[0])
        self.assertEqual(result['missing_nonexempt'],[1])
        self.assertTrue(any(e.get('source')=='controlled_tape' for e in item['trace']))

    def test_setup_cannot_install_twice(self):
        _,_,ro,t=setup()
        with self.assertRaises(SetupAbort):ro.install(t.entry.record,53,107)

    def test_later_arbitrary_programming_forbidden(self):
        ctx,_,ro,t=setup()
        with self.assertRaises(ValueError):ro.program(CHALLENGE,challenge_input(ctx,t.entry),t.c)

    def test_ticket_relabelling_not_allowed(self):
        _,reg,ro,t=setup()
        ro.ticket=replace(t,entry=replace(t.entry,record=replace(t.entry.record,sender=b'other')))
        with self.assertRaises(ValueError):validate_ticket(reg,ro)

    def test_setup_collision_and_identity_aborts(self):
        ctx,reg,_,t=setup()
        for c,z in ((0,0),(0,1),(g.q-1,0)):
            fresh=Registry(ctx,g.encode_point(reg.X));ro=OneChallengeOracle(fresh)
            with self.assertRaises(SetupAbort):ro.install(t.entry.record,c,z)
            self.assertEqual(fresh.events,[])

    def test_setup_rejects_prior_registration(self):
        ctx,reg,_,t=setup()
        fresh=Registry(ctx,g.encode_point(reg.X));ro=OneChallengeOracle(fresh)
        fresh.register_point(g.encode_point(g.mul(2,fresh.K)),Rep(2,0))
        with self.assertRaises(SetupAbort):ro.install(t.entry.record,47,109)

    def test_sampled_setup_equation(self):
        ctx,reg,_,t=setup()
        fresh=Registry(ctx,g.encode_point(reg.X));ro=OneChallengeOracle(fresh)
        ticket=sample_setup(ro,t.entry.record,seed=405)
        validate_ticket(fresh,ro)
        self.assertEqual(g.mul(ticket.z,fresh.K),g.decode_point(ticket.entry.R)+g.mul(ticket.c,fresh.X))

    def test_small_field_setup_bijection_and_abort_count(self):
        # This checks the finite algebra; the proof applies to every prime q>2.
        for q in (5,7):
            for x in range(2,q):
                counts={}
                for c in range(q):
                    for z in range(q):
                        r=(z-c*x)%q
                        if r:counts[(r,c)]=counts.get((r,c),0)+1
                self.assertEqual(len(counts),q*(q-1))
                self.assertEqual(set(counts.values()),{1})
                self.assertEqual(sum(v for (r,c),v in counts.items() if r in (1,x)),2*q)

    def test_explicit_bounds(self):
        self.assertEqual(setup_error(101),Fraction(2,100))
        self.assertEqual(total_error(101,2,1),Fraction(3,101)+Fraction(4,100))
        self.assertEqual(total_error(5,100,100),1)

    def test_replay_bad_ticket_response(self):
        item=mixed();item['ticket']['z']+=1
        with self.assertRaises(ValueError):replay(item)

    def test_replay_late_program_rejected(self):
        item=mixed()
        e=copy.deepcopy(next(e for e in item['trace'] if e['kind']=='program'))
        e['step']=len(item['trace']);item['trace'].append(e)
        with self.assertRaises(ValueError):replay(item)

    def test_replay_no_missing_answer_sampling(self):
        item=mixed()
        payload=next(e['payload'] for e in item['trace'] if e['kind']=='fresh' and e['domain']==CHALLENGE.decode())
        item['trace']=[e for e in item['trace'] if not(e['kind'] in ('fresh','cache') and e['payload']==payload)]
        for i,e in enumerate(item['trace']):e['step']=i
        with self.assertRaisesRegex(ValueError,'incomplete trace'):replay(item)

    def test_replay_detects_false_exception(self):
        item=mixed(kind='relabelled');item['result']['exempt_positions']=[0,1]
        with self.assertRaises(ValueError):replay(item)


class PolicyTests(unittest.TestCase):
    def setUp(self):
        self.ctx,self.reg,self.ro,self.ticket=setup()
        self.star=core(self.ctx,self.ticket.entry);self.ledger=Ledger(self.star)

    def test_relabel_and_new_proof_share_core(self):
        changed=replace(self.ticket.entry,record=replace(self.ticket.entry.record,sender=b'other'),
                        R=g.encode_point(g.mul(313,self.reg.K)))
        self.assertEqual(core(self.ctx,changed),self.star)
        self.assertFalse(self.ledger.decrypt_allowed([core(self.ctx,changed)]))

    def test_A_and_E_changes_are_not_auto_registered(self):
        for changed in (replace(self.star,E=b'changed'),replace(self.star,A=g.encode_point(g.mul(13,self.reg.K)+self.reg.X))):
            self.assertTrue(self.ledger.decrypt_allowed([changed]))
            # Policy permission is not commitment/proof validity or a successful decryption.

    def test_CT_corrupt_challenge_blocked_honest_allowed(self):
        self.assertEqual(self.ledger.proxy_decision('CT',[self.star],target_class=True,corrupted=True,admissible=True),'REFUSE_DERIVATIVE')
        self.assertEqual(self.ledger.proxy_decision('CT',[self.star],target_class=True,corrupted=False,admissible=True),'POLICY_PERMITS')

    def test_CLASS_target_corrupt_blocked_even_ordinary(self):
        ordinary=replace(self.star,E=b'ordinary')
        self.assertEqual(self.ledger.proxy_decision('CLASS',[ordinary],target_class=True,corrupted=True,admissible=True),'REFUSE_TARGET_CLASS')

    def test_CT_ordinary_requires_explicit_admissibility(self):
        ordinary=replace(self.star,E=b'ordinary')
        self.assertEqual(self.ledger.proxy_decision('CT',[ordinary],target_class=True,corrupted=True,admissible=False),'NO_ADMISSIBLE_GRANT')
        self.assertEqual(self.ledger.proxy_decision('CT',[ordinary],target_class=True,corrupted=True,admissible=True),'POLICY_PERMITS')

    def test_only_registered_parent_propagates_derivative(self):
        ordinary=replace(self.star,E=b'ordinary');child=replace(ordinary,A=g.encode_point(g.mul(14,self.reg.K)))
        self.assertFalse(self.ledger.observe_transform(ordinary,child))
        self.assertTrue(self.ledger.decrypt_allowed([child]))
        derivative=replace(self.star,A=g.encode_point(g.mul(15,self.reg.K)))
        self.assertTrue(self.ledger.observe_transform(self.star,derivative))
        self.assertFalse(self.ledger.decrypt_allowed([derivative]))

    def test_mixed_batch_containing_derivative_denied(self):
        ordinary=replace(self.star,E=b'ordinary')
        self.assertFalse(self.ledger.decrypt_allowed([ordinary,self.star]))
        self.assertFalse(self.ledger.decrypt_allowed([self.star,ordinary]))

    def test_class_context_preserved_by_transform(self):
        with self.assertRaises(ValueError):self.ledger.observe_transform(self.star,replace(self.star,class_bytes=b'other'))


if __name__=='__main__':unittest.main()
