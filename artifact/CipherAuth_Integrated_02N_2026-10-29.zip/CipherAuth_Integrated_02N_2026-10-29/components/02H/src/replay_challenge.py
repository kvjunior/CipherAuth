"""Validate a setup-first challenge trace using public data only."""
from adaptive import Registry,Rep
from cipherauth02f import group as g
from cipherauth02f.oracle import CHALLENGE,WEIGHT
from cipherauth02f.transcript import VERSION,MAGIC,decode,encode_context,challenge_input,prefix_input
from challenge_extension import OneChallengeOracle,extract_nonexempt


def replay(item):
    agg=decode(bytes.fromhex(item['wire'])); ctx=agg.context; encoded_ctx=encode_context(ctx)
    if ctx.key.hex()!=item['context_key']:raise ValueError('context mismatch')
    reg=Registry(ctx,bytes.fromhex(item['public_X']));ro=OneChallengeOracle(reg)
    def tail(payload):
        data=bytes.fromhex(payload)
        if not data.startswith(VERSION+encoded_ctx):raise ValueError('wrong context/version')
        return data[len(VERSION+encoded_ctx):]
    designated=decode(MAGIC+encoded_ctx+(1).to_bytes(4,'big')+tail(item['ticket']['entry'])+bytes(32)).entries[0]
    ticket=ro.install(designated.record,item['ticket']['c'],item['ticket']['z'])
    if ticket.entry!=designated:raise ValueError('ticket commitment not derived from c,z')
    initial=list(reg.events)
    if item['trace'][:len(initial)]!=initial:raise ValueError('setup prefix differs or was not first')
    for i,event in enumerate(item['trace'][len(initial):],len(initial)):
        if event['step']!=i:raise ValueError('bad event order')
        kind=event['kind']
        if kind=='point_register':
            reg.register_point(bytes.fromhex(event['point']),Rep(event['a'],event['b']))
        elif kind=='entry_register':
            e=decode(MAGIC+encoded_ctx+(1).to_bytes(4,'big')+tail(event['payload'])+bytes(32)).entries[0]
            reg.register_entry(e,Rep(*event['A']),Rep(*event['R']))
        elif kind=='prefix_register':
            entries=decode(MAGIC+encoded_ctx+tail(event['payload'])+bytes(32)).entries
            reg.register_prefix(entries)
        elif kind in ('fresh','cache'):
            key=ro._key(event['domain'].encode(),bytes.fromhex(event['payload']),event['nonzero'])
            value=g.validate_scalar(event['value'],nonzero=event['nonzero'])
            if kind=='cache':
                if ro.table.get(key)!=value:raise ValueError('cache mismatch')
            else:
                if key in ro.table:raise ValueError('oracle overwrite')
                ro.table[key]=value
        else:raise ValueError('late programming or unknown event')
    required=[(WEIGHT,prefix_input(ctx,agg.entries),True)]
    required += [(CHALLENGE,challenge_input(ctx,e),False) for e in agg.entries]
    if any(k not in ro.table for k in required):raise ValueError('incomplete trace')
    result=extract_nonexempt(agg,reg,ro)
    if result!=item['result']:raise ValueError('claimed result differs')
    return result
