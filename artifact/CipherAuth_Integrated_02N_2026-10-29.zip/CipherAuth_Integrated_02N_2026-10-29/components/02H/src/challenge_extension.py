"""Setup-first single programmed challenge; restricted two-point experiment only."""
from dataclasses import dataclass
from fractions import Fraction
import random
from adaptive import Rep, TraceOracle, diagnostic, conservative_error
from cipherauth02f import group as g
from cipherauth02f.oracle import CHALLENGE
from cipherauth02f.transcript import Entry, challenge_input
from cipherauth02f.kernel import verify_compressed, challenge, coefficients


class SetupAbort(ValueError):
    pass


@dataclass(frozen=True)
class Ticket:
    entry: Entry
    c: int
    z: int


class OneChallengeOracle(TraceOracle):
    def __init__(self, registry, seed=0, *, tape=None):
        super().__init__(registry, seed, allow_programming=True, tape=tape)
        self.ticket = None

    def program(self, *args, **kwargs):
        raise ValueError("only setup challenge installation may program an input")

    def install(self, record, c, z):
        """c,z supplied explicitly for auditable deterministic fixtures.

        The mathematical experiment samples them uniformly. This method rejects
        identity rather than retrying; sample_setup handles the identity retry.
        """
        reg=self.registry
        if self.ticket is not None or self.table or reg.events or len(reg.points)!=2:
            raise SetupAbort("setup must precede all registrations and oracle queries")
        g.validate_scalar(c); g.validate_scalar(z)
        if g.decode_point(record.A)!=reg.X:
            raise ValueError("designated challenge must have A=X")
        R=g.mul(z,reg.K)-g.mul(c,reg.X)
        if R.is_identity:
            raise SetupAbort("identity proof commitment")
        if R==reg.K or R==reg.X:
            raise SetupAbort("initial registry collision")
        entry=Entry(record,g.encode_point(R))
        reg.register_entry(entry,Rep(0,1),Rep(z,(-c)%g.q))
        TraceOracle.program(self,CHALLENGE,challenge_input(reg.context,entry),c)
        self.ticket=Ticket(entry,c,z)
        return self.ticket


def sample_setup(oracle, record, *, seed):
    """Seeded simulation fixture. Uniform-sampling argument is in the written proof."""
    rng=random.Random(seed)
    while True:
        c,z=rng.randrange(g.q),rng.randrange(g.q)
        R=g.mul(z,oracle.registry.K)-g.mul(c,oracle.registry.X)
        if not R.is_identity:
            return oracle.install(record,c,z)  # K/X collisions abort, not retry.


def validate_ticket(reg,oracle):
    ticket=oracle.ticket
    if ticket is None:
        raise ValueError("missing designated challenge")
    payload=challenge_input(reg.context,ticket.entry)
    if oracle.programmed!={payload} or oracle.table.get((CHALLENGE,payload,False))!=ticket.c:
        raise ValueError("programming does not match exactly one designated challenge")
    if (g.decode_point(ticket.entry.record.A)!=reg.X or
        g.decode_point(ticket.entry.R)!=g.mul(ticket.z,reg.K)-g.mul(ticket.c,reg.X)):
        raise ValueError("invalid challenge ticket equation")
    return ticket,payload


def extract_nonexempt(agg,reg,oracle):
    ticket,payload=validate_ticket(reg,oracle)
    if len(agg.entries)!=2:
        raise ValueError("two records required")
    if not verify_compressed(reg.context,agg,oracle=oracle):
        return {"status":"REJECTED"}
    exempt=[i for i,e in enumerate(agg.entries) if challenge_input(reg.context,e)==payload]
    raw=diagnostic(agg,reg,oracle)
    openings=list(raw['openings'])
    for i in exempt:openings[i]=None
    missing=[i for i in range(2) if i not in exempt and openings[i] is None]
    result={"exempt_positions":exempt,"openings":openings,"missing_nonexempt":missing,
            "formal_K_residual":raw['formal_K_residual'],"formal_X_residual":raw['formal_X_residual']}
    if 'x' in raw:result['relation_solution']=raw['x']
    if len(exempt)==2:
        result['status']='ALL_EXEMPT'
    elif missing:
        result['status']='UNRESOLVED_NONEXEMPT'
    else:
        result['status']='EXTRACTED_NONEXEMPT'
    if len(exempt)==1:
        weights=coefficients(reg.context,agg.entries,oracle)
        s=exempt[0]; j=1-s
        z=((agg.response-weights[s]*ticket.z)*pow(weights[j],-1,g.q))%g.q
        entry=agg.entries[j]
        c=challenge(reg.context,entry,oracle)
        if g.mul(z,reg.K)!=g.decode_point(entry.R)+g.mul(c,g.decode_point(entry.record.A)):
            raise AssertionError("remainder response does not verify")
        result['remainder']={'position':j,'response':z,'equation_verified':True}
    return result


def setup_error(q):
    if q<3:raise ValueError("q must exceed two")
    return min(Fraction(1),Fraction(2,q-1))


def total_error(q,n_c,n_b):
    return min(Fraction(1),setup_error(q)+conservative_error(q,n_c,n_b))
