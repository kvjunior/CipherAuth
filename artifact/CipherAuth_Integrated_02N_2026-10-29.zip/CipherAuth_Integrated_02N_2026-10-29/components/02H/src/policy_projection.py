"""Projection of frozen core/derivative rules, NOT a complete game implementation.

02F context is not the frozen full KeyRef type. Grant admissibility is an external
precondition; this module does not resolve the frozen G-CONF-CT grant ambiguity.
"""
from dataclasses import dataclass
from cipherauth02f.transcript import encode_context


@dataclass(frozen=True)
class Core:
    class_bytes: bytes
    A: bytes
    E: bytes


def core(context,entry):
    return Core(encode_context(context),entry.record.A,entry.record.body)


class Ledger:
    def __init__(self,challenge_core):
        self.registered={challenge_core}
        self.edges=[]

    def observe_transform(self,parent,child):
        if parent.class_bytes!=child.class_bytes:
            raise ValueError("transform changed origin class")
        if parent in self.registered:
            self.registered.add(child)
            self.edges.append((parent,child))
            return True
        return False

    def decrypt_allowed(self,cores):
        return not any(c in self.registered for c in cores)

    def proxy_decision(self,game,cores,*,target_class,corrupted,admissible):
        if game not in ('CLASS','CT'):raise ValueError("unknown game")
        if not admissible:return 'NO_ADMISSIBLE_GRANT'
        if target_class and corrupted:
            if game=='CLASS':return 'REFUSE_TARGET_CLASS'
            if any(c in self.registered for c in cores):return 'REFUSE_DERIVATIVE'
        return 'POLICY_PERMITS'  # Proof/authentication validation is still required.
