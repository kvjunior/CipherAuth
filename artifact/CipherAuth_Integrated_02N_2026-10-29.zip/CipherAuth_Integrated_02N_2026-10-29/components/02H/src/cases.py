from dataclasses import replace
from adaptive import Registry,Rep
from cipherauth02f import group as g
from cipherauth02f.transcript import Context,Record,Entry,Compressed,challenge_input,prefix_input,encode
from cipherauth02f.oracle import CHALLENGE,WEIGHT
from challenge_extension import OneChallengeOracle,extract_nonexempt


def setup(seed=19,tape=None):
    K=g.mul(17,g.G); X=g.mul(997,K)
    ctx=Context(b'origin-j',b'class-tag',7,g.encode_point(K))
    reg=Registry(ctx,g.encode_point(X)); ro=OneChallengeOracle(reg,seed,tape=tape)
    record=Record(b'sender-challenge',b'C'*32,b'challenge-body',g.encode_point(X))
    ticket=ro.install(record,47,109)
    return ctx,reg,ro,ticket


def entry(reg,index,alpha,rho,record=None):
    A=g.encode_point(reg.evaluate(alpha)); R=g.encode_point(reg.evaluate(rho))
    record=Record(f'sender-{index}'.encode(),bytes([index])*32,f'body-{index}'.encode(),A) if record is None else replace(record,A=A)
    e=Entry(record,R); reg.register_entry(e,alpha,rho)
    return e


def bundle(name,agg,reg,ro):
    result=extract_nonexempt(agg,reg,ro)
    t=ro.ticket
    return {'name':name,'wire':encode(agg).hex(),'context_key':reg.context.key.hex(),
            'public_X':g.encode_point(reg.X).hex(),
            'ticket':{'entry':challenge_input(reg.context,t.entry).hex(),'c':t.c,'z':t.z},
            'result':result,'trace':reg.events}


def mixed(position=0,order='weight_first',kind='ordinary'):
    ctx,reg,ro,t=setup(tape=[47,13] if kind=='controlled_hash_collision' else None)
    if kind=='ordinary':
        other=entry(reg,2,Rep(102,0),Rep(212,0)); witness=102; nonce=212
    elif kind in ('relabelled','controlled_hash_collision'):
        other=entry(reg,2,Rep(0,1),Rep(t.z,(-t.c)%g.q),replace(t.entry.record,sender=b'changed-sender'))
        witness=997; nonce=(t.z-t.c*997)%g.q
    elif kind=='new_proof_same_core':
        other=entry(reg,2,Rep(0,1),Rep(313,0),t.entry.record); witness=997; nonce=313
    elif kind=='changed_A_reused_response':
        other=entry(reg,2,Rep(13,1),Rep(t.z,(-t.c)%g.q),t.entry.record)
        witness=None; nonce=None
    else:raise ValueError('unknown case')
    entries=(t.entry,other) if position==0 else (other,t.entry)
    p=reg.register_prefix(entries)
    if order=='weight_first':
        b=ro.scalar(WEIGHT,p,nonzero=True); c=ro.scalar(CHALLENGE,challenge_input(ctx,other))
    elif order=='challenge_first':
        c=ro.scalar(CHALLENGE,challenge_input(ctx,other)); b=ro.scalar(WEIGHT,p,nonzero=True)
    else:raise ValueError('unknown order')
    other_z=t.z if witness is None else (nonce+c*witness)%g.q
    Z=(t.z+b*other_z if position==0 else other_z+b*t.z)%g.q
    agg=Compressed(ctx,entries,Z)
    name=f'{kind}_pos{position}_{order}'
    return bundle(name,agg,reg,ro)


def duplicate():
    ctx,reg,ro,t=setup()
    entries=(t.entry,t.entry);p=reg.register_prefix(entries)
    b=ro.scalar(WEIGHT,p,nonzero=True)
    return bundle('duplicate_exact_challenge',Compressed(ctx,entries,(1+b)*t.z%g.q),reg,ro)


def no_exempt():
    ctx,reg,ro,t=setup()
    entries=(entry(reg,2,Rep(102,0),Rep(212,0)),entry(reg,3,Rep(103,0),Rep(213,0)))
    p=reg.register_prefix(entries);b=ro.scalar(WEIGHT,p,nonzero=True)
    cs=[ro.scalar(CHALLENGE,challenge_input(ctx,e)) for e in entries]
    Z=(212+cs[0]*102+b*(213+cs[1]*103))%g.q
    return bundle('no_exempt_ordinary_pair',Compressed(ctx,entries,Z),reg,ro)


def all_cases():
    cases=[mixed(p,o) for p in (0,1) for o in ('weight_first','challenge_first')]
    cases += [mixed(p,'weight_first',k) for p in (0,1) for k in ('relabelled','new_proof_same_core','changed_A_reused_response')]
    return cases+[duplicate(),no_exempt(),mixed(0,'challenge_first','controlled_hash_collision')]
