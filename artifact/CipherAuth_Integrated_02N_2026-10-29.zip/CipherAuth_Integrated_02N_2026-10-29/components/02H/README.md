# CipherAuth Batch 02H — programmed challenge exceptions

**Batch implemented and tested. Full CipherAuth security remains unproved.**
The new written proof covers one setup-first programmed challenge in the restricted
two-point, two-record experiment. It still needs independent review.

Run with Python 3.10+ and no third-party dependencies:

    python scripts/reproduce.py

The runner executes 27 new tests, reruns 23 tests from 02G and 34 from 02F,
checks prior results byte-for-byte, and generates/replays 13 new traces. The shipped
run has zero failures, errors or skips. Seeded fixtures are research diagnostics.

The main progress is simple and explicit: when one aggregate entry is the exact
programmed challenge, its known response can be subtracted, leaving a verifiable
ordinary response for the other entry. The exception rule compares the full proof
input, so relabelled records do not silently inherit the exception.

Read:

1. `proofs/challenge_extension.md` — experiment, subtraction proof, error bound,
   setup-distribution argument and remaining gaps.
2. `spec/game_compatibility.md` — proof exceptions versus frozen challenge cores,
   plus the unresolved CT grant/admissibility wording.
3. `spec/experiment.md` — implemented interface and test scope.
4. `src/challenge_extension.py`, `src/replay_challenge.py`, `src/policy_projection.py`
   and `src/cases.py` — implementation and reproducible cases.
5. `results/observed.json`, `results/traces.json`, `tests/test_challenge.py`.

The controlled collision case intentionally returns `UNRESOLVED_NONEXEMPT`.
Forcing one random-oracle answer tests an exceptional event; it is not claimed
as an efficient attack. A clean test run does not prove confidentiality.

The frozen games are copied under `provenance/` and remain unchanged. Full KeyRef
mapping, grant/token generation, encryption/decryption, sender authentication and
RCCA message masking are absent from the policy projection. Honest-recipient
challenge transformation remains a required simulation obligation.

`manifest.json` covers all shipped files except itself; verify it using
`python scripts/verify_manifest.py`. The prior archive and copied modules have
explicit hashes. `REVIEW_PROMPT.md` supports the planned independent Claude review.

**Next: Batch 02I — adaptive challenge timing, with explicit prequery/programming
abort accounting and registry-alias handling.** Then address additional algebraic
points and the full game interface before any complete security or novelty claim.
