# Candidate G-SCOPE-v1 composition

Status: complete candidate composition from G-CONF-CLASS-v1, pending independent
review. It introduces no new computational assumption or additive loss.

Given a G-SCOPE-v1 adversary, the reduction forwards the phase-0 fixed target class
to its G-CONF-CLASS-v1 challenger. It generates every other class key independently,
retains each scalar, and registers the resulting canonical KeyRefs. It therefore
answers non-target grants, complete token disclosure, proxy corruption,
re-encryption and decryption exactly, including the documented recovery of a
non-target class key by a proxy/delegatee coalition.

Target-class oracles are answered by the Batch 02M simulator. A point submitted to
global `KDF` or `Hd` tables is always checked by the main Gap-Divisible-DH decision
oracle; if a non-target computation happens to expose `Q*`, the existing challenge
solver succeeds. This creates no query-index or collision term.

Cross-class substitution fails before transformation or opening:

- the registry checks the full KeyRef fingerprint;
- sender statements bind origin KeyRef, tag and epoch;
- batch verification requires one origin class and epoch;
- grants bind issuer, origin, delegatee, tag set, epoch, token digest and grant id;
- token digests bind the origin and delegatee KeyRefs and public token fields;
- proxy checks require the token origin and signed grant to match the batch.

The `Hmask` input additionally includes the full origin class KeyRef, so even the
same group point under two classes is a distinct oracle input. `KDF` and `Hd` are
global by design, but their target-point exposure is already handled by the main
CLASS solver.

The simulated view is exact. Therefore, for a target fixed before setup,

`Adv_G-SCOPE-v1(A) <= Adv_G-CONF-CLASS-v1(B)`.

Substituting Batch 02M's candidate bound gives the same right-hand side and no
additional term. This statement does not provide in-class collusion resistance,
adaptive target selection, revocation, G-CONF-CT, or a concrete SHA-256 theorem.
