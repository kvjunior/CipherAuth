import unittest
from fractions import Fraction

from cipherauth import group as g
from cipherauth.cea import CEA, Directory, SUITE, parse_body
from cipherauth.encoding import encode
from cipherauth.errors import InvalidContext
from cipherauth.models import BatchContext
from scope_composition import (ClassId, ScopeLedger, adaptive_target_scope_bound,
                               fixed_target_scope_bound, recover_colluded_class_key,
                               target_point_exposed)


class ScopeCompositionTests(unittest.TestCase):
    def setUp(self):
        self.directory=Directory(); self.system=CEA(self.directory)
        self.owner=self.directory.new_signing_key("owner")
        self.class_a=self.directory.new_decryption_key("owner",tag=b"a",epoch=1)
        self.class_b=self.directory.new_decryption_key("owner",tag=b"b",epoch=1)
        self.ell=self.directory.new_decryption_key("ell")
        self.sender=self.directory.new_signing_key("sender")

    def aggregate(self, tag, secret, message=b"m"):
        sub=self.system.signcrypt(self.sender,"owner",message,tag,1)
        ctx=BatchContext(SUITE,"origin",secret.ref,secret.ref,1)
        return self.system.aggregate(ctx,[sub])

    def test_non_target_secrets_are_known_and_immutable(self):
        target=ClassId(b"target-ref",b"t",1); other=ClassId(b"other-ref",b"u",1)
        ledger=ScopeLedger(target)
        public=ledger.register_non_target(other,37)
        self.assertEqual(public,g.mul(37,g.G)); self.assertTrue(ledger.knows(other))
        self.assertEqual(ledger.secret(other),37)
        with self.assertRaises(ValueError): ledger.register_non_target(other,41)

    def test_target_secret_cannot_enter_non_target_ledger(self):
        target=ClassId(b"target-ref",b"t",1); ledger=ScopeLedger(target)
        with self.assertRaises(ValueError): ledger.register_non_target(target,37)

    def test_collusion_recovers_only_granted_class_key(self):
        token,grant=self.system.issue_grant(self.owner,self.class_a,self.ell.ref,b"a",1)
        C,gamma,_W=token.public_part()
        T=g.mul(g.inv(self.ell.k),g.decode_point(gamma))
        mask=g.hash_bytes("cea/rk-mask",encode((g.encode_point(T),self.class_a.ref.fields())))
        omega=int.from_bytes(bytes(x^y for x,y in zip(C,mask)),"big")
        recovered=recover_colluded_class_key(token.Omega,omega)
        self.assertEqual(recovered,self.class_a.k)
        self.assertEqual(recover_colluded_class_key(37*41%g.q,41),37)
        self.assertNotEqual(37,43)  # independent class secret in the controlled model
        self.assertEqual(grant.payload.origin,self.class_a.ref)

    def test_token_from_other_class_is_rejected_on_target_aggregate(self):
        agg_b=self.aggregate(b"b",self.class_b)
        token_a,grant_a=self.system.issue_grant(self.owner,self.class_a,self.ell.ref,b"a",1)
        with self.assertRaises(InvalidContext):
            self.system.delegate_aggregate(token_a,grant_a,agg_b)

    def test_token_grant_cross_pair_is_rejected(self):
        agg_b=self.aggregate(b"b",self.class_b)
        token_a,_grant_a=self.system.issue_grant(self.owner,self.class_a,self.ell.ref,b"a",1)
        _token_b,grant_b=self.system.issue_grant(self.owner,self.class_b,self.ell.ref,b"b",1)
        with self.assertRaises(InvalidContext):
            self.system.delegate_aggregate(token_a,grant_b,agg_b)

    def test_mixed_class_batch_is_rejected(self):
        sub_a=self.system.signcrypt(self.sender,"owner",b"a",b"a",1)
        sub_b=self.system.signcrypt(self.sender,"owner",b"b",b"b",1)
        ctx=BatchContext(SUITE,"origin",self.class_a.ref,self.class_a.ref,1)
        with self.assertRaises(InvalidContext): self.system.aggregate(ctx,[sub_a,sub_b])

    def test_origin_statement_binds_class_ref_tag_and_epoch(self):
        from cipherauth.cea import statement_bytes
        c=b"c"*32
        self.assertNotEqual(statement_bytes(self.sender.ref,self.class_a.ref,b"a",1,c),
                            statement_bytes(self.sender.ref,self.class_b.ref,b"b",1,c))

    def test_mask_oracle_input_is_class_separated(self):
        T=g.mul(17,g.G)
        left=encode((g.encode_point(T),self.class_a.ref.fields()))
        right=encode((g.encode_point(T),self.class_b.ref.fields()))
        self.assertNotEqual(left,right)

    def test_token_digest_binds_origin_class(self):
        from cipherauth.cea import token_digest
        token,_=self.system.issue_grant(self.owner,self.class_a,self.ell.ref,b"a",1)
        self.assertNotEqual(token_digest(self.class_a.ref,self.ell.ref,token.public_part()),
                            token_digest(self.class_b.ref,self.ell.ref,token.public_part()))

    def test_fixed_target_adds_no_loss(self):
        self.assertEqual(fixed_target_scope_bound(Fraction(3,100)),Fraction(3,100))

    def test_adaptive_fallback_records_class_guess(self):
        self.assertEqual(adaptive_target_scope_bound(5,Fraction(1,100)),Fraction(1,20))
        self.assertEqual(adaptive_target_scope_bound(5,Fraction(1,2)),1)

    def test_global_point_query_can_solve_target_even_if_triggered_elsewhere(self):
        a,b=37,41;K=g.mul(a,g.G);A=g.mul(b,g.G);Q=g.mul(b*g.inv(a)%g.q,g.G)
        ddh=lambda _P,supplied_K,candidate,supplied_A: supplied_K==K and g.mul(a,candidate)==supplied_A
        self.assertTrue(target_point_exposed(K,A,Q,ddh))
        self.assertFalse(target_point_exposed(K,A,g.mul(7,g.G),ddh))

    def test_class_ids_include_epoch(self):
        self.assertNotEqual(ClassId(b"r",b"t",1),ClassId(b"r",b"t",2))

    def test_invalid_scope_inputs_are_rejected(self):
        with self.assertRaises(ValueError): ClassId(b"",b"t",1)
        with self.assertRaises(ValueError): fixed_target_scope_bound(Fraction(2,1))
        with self.assertRaises(ValueError): adaptive_target_scope_bound(0,Fraction(1,2))


if __name__=="__main__":unittest.main(verbosity=2)
