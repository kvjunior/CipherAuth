# G-SCOPE-v1

G-SCOPE-v1 is G-CONF-CLASS-v1 with the additional permission that the adversary
may receive complete tokens and collude with the proxy and corrupted delegatees
for every class of the same origin owner except the phase-0 fixed target class.

Each class is identified by the full origin decryption `KeyRef`, tag and epoch.
Target-class grant/service restrictions remain unchanged. Non-target collusion may
recover that granted class key, as documented by G-KR; it does not authorize use
of the recovered value under another class identifier.

The target is fixed before class keys are generated. An adaptive-target variant is
not claimed; the elementary random-index fallback would lose the number of eligible
classes.
