import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1] / "src"))
from cipherauth_case3.oracle_game import Core, GameState
from cipherauth_case3.loss import QueryBudget, LossLedger


def state():
    c = Core("j", "A*", "E*")
    return GameState(c), c


def test_challenge_and_derivative_refusal():
    g, c = state()
    assert g.dec_origin(c) == "REFUSE_DERIVATIVE"
    child = Core("j", "Abar*", "E*")
    g.register_challenge_derivative(child)
    assert g.dec_delegatee(child, True) == "REFUSE_DERIVATIVE"


def test_proxy_requires_intake_proof_and_serves_valid_core():
    g, _ = state()
    core = Core("j", "A1", "E1")
    assert g.proxy_reencrypt(core, "grant-1") == "REFUSE_INTAKE"
    g.mark_intake_valid(core)
    g.note_opening_queries(core, "Q1")
    child_a = g.proxy_reencrypt(core, "grant-1")
    assert child_a.startswith("Abar[grant-1")
    assert g.dec_delegatee(Core("j", child_a, "E1"), True) == "REFUSE_DERIVATIVE"


def test_later_delegated_open_without_query_is_explicit_guess_event():
    g, _ = state()
    core = Core("j", "A2", "E2")
    assert g.dec_delegatee(core, False) == "REJECT_GUESS_EVENT"
    assert "delegated-opening-without-RO-query" in g.guess_events


def test_reordering_does_not_remove_derivative_ledger_entries():
    g, _ = state()
    c1, c2 = Core("j", "A1", "E1"), Core("j", "A2", "E2")
    assert g.reorder((c1, c2)) == (c2, c1)
    g.register_challenge_derivative(c1)
    assert g.is_refused(c1)


def test_symbolic_loss_keeps_open_terms_visible():
    ledger = LossLedger(QueryBudget(q_pok=2, q_hd=3, q_hc=4, q_kdf=5))
    assert ledger.random_oracle_guessing.numerator == 14
    assert "L_ext" in ledger.symbolic_bound()
    assert "Adv_Schnorr_sim" in ledger.symbolic_bound()
