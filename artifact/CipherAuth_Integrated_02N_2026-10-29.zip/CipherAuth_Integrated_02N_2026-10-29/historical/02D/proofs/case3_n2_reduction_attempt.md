# Case-3 n=2 oracle-game and reduction attempt

## Game skeleton

The harness models the G-CONF-CT restrictions required for the candidate augmented construction:

- the challenge core and registered derivatives are refused by decryption;
- the proxy serves only origin aggregates that pass the intake proof;
- non-intake delegated objects are handled by a separate delegated-decryption rule;
- reordering does not erase per-core derivative bookkeeping;
- successful opening requires the relevant `H_d`, `H_c`, and `KDF` events, except for an explicit guessing event.

The harness is an executable specification of query order. It is not a security proof.

## Reduction attempt

The intended reduction embeds the target class in a Gap-Divisible-DH instance. It uses the intake-proof extractor to obtain each non-challenge `Q_i=t_iP` before returning `Abar_i=omega^{-1}Q_i`. The challenge cannot pass the proxy intake proof because the reduction does not provide an encryption witness for the challenge point; challenge and derivative cores are refused.

The proof still requires a complete AGM+ROM extraction lemma. In particular, the extractor must exclude unknown challenge coordinates from each individual `A_i`, not merely cancel them in the final weighted equation. It must also simulate honest-origin decryption queries and corrupted-delegatee queries on objects that bypass intake.

## Loss status

The symbolic bound is recorded as

    Adv_GCONF_CT <= Adv_GapDCDH(R)
                      + L_ext(n=2, AGM, ROM)
                      + Adv_Schnorr_sim
                      + (q_pok + q_hd + q_hc + q_kdf)/q.

`L_ext` and the signature-simulation term remain open. The displayed expression is a ledger of obligations, not a proven bound.
