# Case-3 query-order obligations

The final proof must handle these orderings without changing prior answers:

1. `H_pok` queried before the proof is submitted;
2. a proof is submitted before `H_pok` is queried;
3. `ReEncO` is called before `H_d/H_c/KDF` opening queries;
4. a later delegated decryption query exposes a guessed opening;
5. a challenge core is re-aggregated or reordered;
6. a valid origin aggregate is transformed more than once or under multiple grants;
7. the same non-challenge core is submitted repeatedly.

The executable harness records these cases and makes derivative refusal and guessing events explicit. It does not decide whether a proposed reduction can answer every ordering.
