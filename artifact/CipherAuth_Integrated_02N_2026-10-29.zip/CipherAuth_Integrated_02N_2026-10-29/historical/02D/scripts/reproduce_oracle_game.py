import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1] / "src"))
from cipherauth_case3.oracle_game import Core, GameState
from cipherauth_case3.loss import QueryBudget, LossLedger
challenge=Core("j","A*","E*")
g=GameState(challenge)
summary={
 "challenge_dec": g.dec_origin(challenge),
 "unknown_delegatee_dec": g.dec_delegatee(Core("j","A2","E2"), False),
 "events": [{"kind": e.kind, "core": e.core.__dict__ if e.core else None, "detail": e.detail} for e in g.events],
 "guess_events": g.guess_events,
 "loss": LossLedger(QueryBudget(q_pok=2,q_hd=3,q_hc=4,q_kdf=5)).symbolic_bound(),
}
print(json.dumps(summary,indent=2))
Path(__file__).parents[1].joinpath("results","oracle_game.json").write_text(json.dumps(summary,indent=2)+"\n")
