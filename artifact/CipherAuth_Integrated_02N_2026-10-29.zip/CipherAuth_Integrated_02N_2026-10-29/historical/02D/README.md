# CipherAuth Batch 02D: oracle game and loss ledger

This batch provides an executable bookkeeping harness for G-CONF-CT query order, challenge/derivative refusal, proxy intake, delegated opening, and symbolic reduction loss.

It does not prove the extraction lemma or the security theorem. Open terms remain visible in the loss ledger.
