"""Symbolic loss ledger for the Case-3 reduction attempt.

No unexplained placeholder is silently converted into a security claim. The
ledger separates explicit random-oracle guessing terms from unresolved
extraction and signature-simulation terms.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction

@dataclass(frozen=True)
class QueryBudget:
    q_pok: int = 0
    q_hd: int = 0
    q_hc: int = 0
    q_kdf: int = 0
    q_sig: int = 0
    q_aggregate: int = 0
    field_order: int = 1000003

@dataclass(frozen=True)
class LossLedger:
    budget: QueryBudget
    extraction_term: str = "L_ext(n=2, AGM, ROM) [OPEN]"
    signature_term: str = "Adv_Schnorr_sim [OPEN if honest sender/grant signatures are simulated]"

    @property
    def random_oracle_guessing(self) -> Fraction:
        b = self.budget
        return Fraction(b.q_pok + b.q_hd + b.q_hc + b.q_kdf, b.field_order)

    def symbolic_bound(self) -> str:
        b = self.budget
        return (
            "Adv_GCONF_CT <= Adv_GapDCDH(R) + "
            f"{self.extraction_term} + {self.signature_term} + "
            f"({b.q_pok}+{b.q_hd}+{b.q_hc}+{b.q_kdf})/{b.field_order}"
        )
