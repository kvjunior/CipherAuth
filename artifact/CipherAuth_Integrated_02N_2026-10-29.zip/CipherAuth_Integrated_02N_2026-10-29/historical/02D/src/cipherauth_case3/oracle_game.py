"""Executable oracle-game skeleton for the Case-3 n=2 proof gate.

This is a deterministic bookkeeping harness. It models query order, derivative
refusal, proof-gated proxy service, and later delegated-opening events. It is
not an implementation of the cryptographic scheme.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import hashlib
from typing import Any

@dataclass(frozen=True)
class Core:
    origin: str
    A: str
    E: str

@dataclass(frozen=True)
class QueryEvent:
    kind: str
    core: Core | None
    detail: str

@dataclass
class RandomOracle:
    domain: str
    table: dict[bytes, bytes] = field(default_factory=dict)
    queries: list[bytes] = field(default_factory=list)

    def query(self, x: bytes) -> bytes:
        if x not in self.table:
            self.table[x] = hashlib.sha256(self.domain.encode() + b"|" + x).digest()
        self.queries.append(x)
        return self.table[x]

@dataclass
class GameState:
    challenge: Core
    challenge_derivatives: set[Core] = field(default_factory=set)
    events: list[QueryEvent] = field(default_factory=list)
    ro: dict[str, RandomOracle] = field(default_factory=lambda: {
        "pok": RandomOracle("H_pok"),
        "hd": RandomOracle("H_d"),
        "hc": RandomOracle("H_c"),
        "kdf": RandomOracle("KDF"),
    })
    opening_queries: dict[Core, str] = field(default_factory=dict)
    intake_valid: set[Core] = field(default_factory=set)
    guess_events: list[str] = field(default_factory=list)

    def register_challenge_derivative(self, core: Core) -> None:
        self.challenge_derivatives.add(core)

    def is_refused(self, core: Core) -> bool:
        return core == self.challenge or core in self.challenge_derivatives

    def note_opening_queries(self, core: Core, q_label: str) -> None:
        self.opening_queries[core] = q_label

    def mark_intake_valid(self, core: Core) -> None:
        self.intake_valid.add(core)

    def dec_origin(self, core: Core) -> str:
        if self.is_refused(core):
            self.events.append(QueryEvent("DecO", core, "refused-derivative"))
            return "REFUSE_DERIVATIVE"
        if core not in self.opening_queries:
            self.guess_events.append("origin-opening-without-RO-query")
            self.events.append(QueryEvent("DecO", core, "guess-event"))
            return "REJECT_GUESS_EVENT"
        self.events.append(QueryEvent("DecO", core, "opened"))
        return "OPEN"

    def proxy_reencrypt(self, core: Core, grant: str) -> str:
        if self.is_refused(core):
            self.events.append(QueryEvent("ReEncO", core, "challenge-or-derivative-refused"))
            return "REFUSE_DERIVATIVE"
        if core not in self.intake_valid:
            self.events.append(QueryEvent("ReEncO", core, "proof-failed"))
            return "REFUSE_INTAKE"
        child = Core(core.origin, f"Abar[{grant},{core.A}]", core.E)
        self.register_challenge_derivative(child)
        self.events.append(QueryEvent("ReEncO", core, f"served:{grant}"))
        return child.A

    def dec_delegatee(self, core: Core, has_opening_query: bool) -> str:
        if self.is_refused(core):
            self.events.append(QueryEvent("DecO_delegatee", core, "refused-derivative"))
            return "REFUSE_DERIVATIVE"
        if not has_opening_query:
            self.guess_events.append("delegated-opening-without-RO-query")
            self.events.append(QueryEvent("DecO_delegatee", core, "guess-event"))
            return "REJECT_GUESS_EVENT"
        self.events.append(QueryEvent("DecO_delegatee", core, "commitment-opened"))
        return "OPEN"

    def reorder(self, cores: tuple[Core, ...]) -> tuple[Core, ...]:
        self.events.append(QueryEvent("Aggregate", None, "reorder-preserves-core-ledger"))
        return tuple(reversed(cores))
