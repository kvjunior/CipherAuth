import importlib.util
from pathlib import Path
p = Path(__file__).with_name('test_prefix_gate.py')
s = importlib.util.spec_from_file_location('tests', p)
m = importlib.util.module_from_spec(s); s.loader.exec_module(m)
for name in sorted(n for n in dir(m) if n.startswith('test_')):
    getattr(m, name)(); print(name + ': PASS')
print('3 tests: PASS')
