import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1] / "src"))
from cipherauth_case3.prefix_gate import Q, cancellation_search, transcript_change


def test_prefix_binds_later_record():
    assert transcript_change(7, 8)


def test_fixed_point_search_is_explicitly_toy_sized():
    result = cancellation_search(max_alpha=Q)
    assert 1 <= result["queries"] <= Q - 1
    assert result["found"] in (True, False)
    if result["found"]:
        assert result["residual"] == 0


def test_bounded_search_is_not_a_security_claim():
    result = cancellation_search(max_alpha=32)
    assert result["queries"] == 31
