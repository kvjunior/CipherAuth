import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1] / "src"))
from cipherauth_case3.prefix_gate import Q, cancellation_search, transcript_change
result = {
    "toy_field_order": Q,
    "prefix_changes_on_later_record_mutation": transcript_change(7, 8),
    "exhaustive_toy_search": cancellation_search(max_alpha=Q),
    "bounded_32_search": cancellation_search(max_alpha=32),
    "interpretation": "diagnostic fixed-point search; not a real-group security proof",
}
print(json.dumps(result, indent=2))
Path(__file__).parents[1].joinpath("results", "prefix_gate.json").write_text(json.dumps(result, indent=2) + "\n")
