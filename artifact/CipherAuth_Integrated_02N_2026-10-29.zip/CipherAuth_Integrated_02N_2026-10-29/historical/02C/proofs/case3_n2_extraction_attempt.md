# Case-3 n=2 prefix-bound extraction attempt

## Algebraic setup

Let `K=kP` be the common class base. Let an adversary output two records and an aggregate response satisfying

    z_tilde K = b_1(R_1+c_1 A_1) + b_2(R_2+c_2 A_2),

where `b_1=1` and `b_2` is a random-oracle value over the complete transcript prefix containing the second record. The proof challenges `c_i` also bind each complete record.

An AGM representation writes every output point as a linear combination of the basis elements received by the adversary. Let `A*` denote an unknown challenge point. If the coefficient of `A*` in record `A_2` is `alpha`, coefficient matching gives the challenge-coordinate equation

    c_1 * coeff(A*, A_1) + b_2*c_2*alpha = 0.

For an honest non-challenge record, the desired representation has zero coefficient on `A*` and is a known multiple of `K`, which yields a numerically computable opening. The extraction obligation is therefore per record, not merely a zero residual in the final aggregate equation.

## Adaptive prefix issue

The adversary can choose `A_2` as a linear combination involving `A*`, but `b_2` and `c_2` are random-oracle outputs that bind the chosen `A_2`. Choosing `alpha` after seeing those values creates a fixed-point problem. The toy search in this batch exhausts a field of size 1009 and tests

    c_1 + b_2(A_2)c_2(A_2)*alpha = 0.

A result in the toy field is not an attack on the real scheme: exhaustive search is polynomial only because the toy field is tiny. The relevant proof step is to show that a real adversary making q adaptive attempts succeeds with at most an explicit random-oracle/field-probability term, unless it produces a representation that exposes every accepted record as a known multiple of K.

## What remains unproved

This attempt does not establish the extraction lemma. A full proof must define the AGM representation experiment, account for coefficient and challenge queries made before and after aggregation, handle reordering/replay/append, and show that the extractor can compute each `Q_i=t_iP` without an unknown challenge coefficient. It must also include the honest-origin decryption oracle and the corrupted-delegatee delegated-decryption oracle.
