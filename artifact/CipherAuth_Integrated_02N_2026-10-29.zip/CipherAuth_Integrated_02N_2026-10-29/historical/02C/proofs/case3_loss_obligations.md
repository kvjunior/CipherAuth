# Case-3 n=2 loss obligations

The final reduction must account separately for:

- the number of random-oracle attempts that instantiate a candidate fixed point;
- a guessed coefficient or challenge value;
- zero coefficients and coefficient collisions;
- a transcript hash queried before the simulator programs it;
- AGM representation failure or an unknown coefficient on `A*`;
- replay, reorder, and append queries;
- honest-origin decryption queries;
- corrupted-delegatee queries on delegated objects that bypass intake.

The toy exhaustive search records its number of candidate queries. It is diagnostic only and is not the final bound.
