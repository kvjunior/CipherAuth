"""Toy adaptive prefix-coefficient gate for the n=2 Case-3 question.

The finite field is intentionally small. Exhaustive search here demonstrates
that a cancellation equation can be viewed as a random-oracle fixed-point
condition; it does not establish security for a real group.
"""
from __future__ import annotations
import hashlib
from dataclasses import dataclass

Q = 1009


def h(*parts: bytes, domain: bytes) -> int:
    raw = domain + b"|" + b"|".join(parts)
    return int.from_bytes(hashlib.sha256(raw).digest(), "big") % Q or 1


def enc_int(x: int) -> bytes:
    return (x % Q).to_bytes(2, "big")

@dataclass(frozen=True)
class Candidate:
    alpha: int
    beta: int
    c2: int
    b2: int
    residual: int


def prefix_coefficients(a2_encoding: bytes, r2_encoding: bytes, c2: int) -> tuple[int, int]:
    b1 = 1
    state = hashlib.sha256(b"case3-prefix-start|sender1|A1|R1|c1|e1").digest()
    state = hashlib.sha256(b"case3-prefix-next|" + state + b"sender2|" + a2_encoding + b"|" + r2_encoding + enc_int(c2)).digest()
    b2 = h(state, domain=b"case3-b2")
    return b1, b2


def cancellation_search(c1: int = 17, beta: int = 23, r2: int = 29, max_alpha: int = Q) -> dict:
    """Search the toy fixed-point equation b1*c1+b2*c2*alpha=0.

    The attacker would set A2 = alpha*A* + beta*K. Hashes bind A2, so alpha
    cannot be selected after b2 and c2 without solving a fixed-point search.
    """
    for alpha in range(1, max_alpha):
        a2 = enc_int(alpha) + enc_int(beta)
        c2 = h(b"sender2", a2, enc_int(r2), domain=b"case3-pok")
        b1, b2 = prefix_coefficients(a2, enc_int(r2), c2)
        residual = (b1 * c1 + b2 * c2 * alpha) % Q
        if residual == 0:
            return {"found": True, "alpha": alpha, "beta": beta, "c2": c2, "b2": b2, "residual": residual, "queries": alpha}
    return {"found": False, "alpha": None, "beta": beta, "c2": None, "b2": None, "residual": None, "queries": max_alpha - 1}


def transcript_change(a2_a: int, a2_b: int) -> bool:
    c_a = h(b"sender2", enc_int(a2_a), enc_int(29), domain=b"case3-pok")
    c_b = h(b"sender2", enc_int(a2_b), enc_int(29), domain=b"case3-pok")
    return prefix_coefficients(enc_int(a2_a), enc_int(29), c_a) != prefix_coefficients(enc_int(a2_b), enc_int(29), c_b)
