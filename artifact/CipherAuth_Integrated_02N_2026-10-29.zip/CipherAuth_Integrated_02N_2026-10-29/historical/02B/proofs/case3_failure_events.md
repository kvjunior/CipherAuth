# Case-3 failure events and accounting

The final reduction must account for at least:

- a random-oracle query that guesses an opening without querying the relevant oracle;
- a zero or repeated coefficient;
- a coefficient programmed after the adversary has already queried the same transcript point;
- a challenge-coordinate cancellation that leaves an accepted but non-extractable record;
- a replay or re-aggregation of a registered proof;
- a malformed delegated object submitted without proxy intake;
- a representation containing an unknown challenge element.

This batch records a simple field-level guessing term `q_H / q` for the reference model. It is not the final cryptographic bound.
