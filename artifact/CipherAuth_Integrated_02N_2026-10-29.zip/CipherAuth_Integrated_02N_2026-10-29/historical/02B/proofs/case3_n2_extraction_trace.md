# Case-3 n=2 extraction trace

This batch implements a transcript-level AGM analyzer. It represents each group element as a formal linear combination of basis labels such as `K` and the unknown challenge element `A*`.

The analyzer checks two separate conditions:

1. the compressed verification equation is satisfied; and
2. every record's `A_i` has a representation containing only the known class-base basis `K`, so a numerical scalar `t_i` and opening `Q_i=t_iP` can be computed.

The second condition is strictly stronger. The `test_aggregate_challenge_coordinate_can_cancel_without_per_record_extraction` control constructs an accepted compressed equation whose challenge coordinates cancel while the individual records remain non-extractable. This demonstrates why coefficient matching must be performed per record, not only on the final weighted equation.

The analyzer does not prove that prefix random-oracle coefficients prevent this cancellation. That requires a full adaptive AGM+ROM reduction, including coefficient ordering, random-oracle programming, and the exact extraction loss.
