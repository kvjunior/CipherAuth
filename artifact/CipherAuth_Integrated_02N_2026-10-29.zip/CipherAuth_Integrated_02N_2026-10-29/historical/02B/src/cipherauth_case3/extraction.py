"""Extraction-trace analysis for the n=2 Case-3 proof obligation.

This analyzer does not extract discrete logarithms. It checks whether the AGM
representations supplied in a transcript contain enough information for a
per-record opening extraction, and whether unknown challenge coordinates cancel
in the compressed verification equation.
"""
from __future__ import annotations
from dataclasses import dataclass
from .agm import Q, Rep, linear_combination

@dataclass(frozen=True)
class ProofRep:
    R: Rep
    c: int
    z: int

@dataclass(frozen=True)
class RecordRep:
    A: Rep
    proof: ProofRep
    label: str

@dataclass(frozen=True)
class ExtractionTrace:
    accepted: bool
    per_record_extractable: tuple[bool, ...]
    extracted_scalars: tuple[int | None, ...]
    aggregate_residual_support: frozenset[str]
    challenge_coordinate: int
    failure_events: tuple[str, ...]


def aggregate_equation(records: tuple[RecordRep, ...], coefficients: tuple[int, ...]) -> tuple[Rep, Rep]:
    lhs = Rep.basis("K", sum(b * r.proof.z for b, r in zip(coefficients, records)) % Q)
    rhs = linear_combination([
        (b, r.proof.R + r.A.scale(r.proof.c))
        for b, r in zip(coefficients, records)
    ])
    return lhs, rhs


def analyze(records: tuple[RecordRep, ...], coefficients: tuple[int, ...], *, challenge="A*") -> ExtractionTrace:
    lhs, rhs = aggregate_equation(records, coefficients)
    residual = lhs - rhs
    extractable = tuple(r.A.is_known_multiple("K") for r in records)
    scalars = tuple(r.A.known_multiple("K") for r in records)
    failures: list[str] = []
    if residual.support():
        failures.append("aggregate-equation-fails")
    if any(not x for x in extractable):
        failures.append("per-record-opening-not-numerically-extractable")
    challenge_coordinate = residual.coefficient(challenge)
    if challenge_coordinate:
        failures.append("challenge-coordinate-survives")
    return ExtractionTrace(
        accepted=not residual.support(),
        per_record_extractable=extractable,
        extracted_scalars=scalars,
        aggregate_residual_support=residual.support(),
        challenge_coordinate=challenge_coordinate,
        failure_events=tuple(failures),
    )


def guessing_bound(random_oracle_queries: int, field_order: int = Q) -> float:
    return random_oracle_queries / field_order
