"""Minimal AGM representation algebra for the Case-3 extraction gate."""
from __future__ import annotations
from dataclasses import dataclass
from collections import defaultdict

Q = 1000003

@dataclass(frozen=True)
class Rep:
    terms: tuple[tuple[str, int], ...] = ()

    @staticmethod
    def basis(name: str, coefficient: int = 1) -> "Rep":
        return Rep(((name, coefficient % Q),))

    def as_dict(self) -> dict[str, int]:
        return {k: v for k, v in self.terms if v % Q}

    def __add__(self, other: "Rep") -> "Rep":
        d = defaultdict(int)
        for k, v in self.terms + other.terms:
            d[k] += v
        return Rep(tuple(sorted((k, v % Q) for k, v in d.items() if v % Q)))

    def __neg__(self) -> "Rep":
        return self.scale(-1)

    def __sub__(self, other: "Rep") -> "Rep":
        return self + (-other)

    def scale(self, scalar: int) -> "Rep":
        return Rep(tuple((k, (scalar * v) % Q) for k, v in self.terms if scalar * v % Q))

    def coefficient(self, name: str) -> int:
        return self.as_dict().get(name, 0)

    def support(self) -> frozenset[str]:
        return frozenset(self.as_dict())

    def is_known_multiple(self, base: str) -> bool:
        return all(k == base for k, _ in self.terms)

    def known_multiple(self, base: str) -> int | None:
        if not self.is_known_multiple(base):
            return None
        return self.coefficient(base)


def linear_combination(items: list[tuple[int, Rep]]) -> Rep:
    out = Rep()
    for scalar, rep in items:
        out = out + rep.scale(scalar)
    return out
