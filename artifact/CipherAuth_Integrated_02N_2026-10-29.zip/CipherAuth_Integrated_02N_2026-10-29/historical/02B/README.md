# CipherAuth Batch 02B: n=2 AGM extraction trace

This batch adds a formal-vector AGM transcript analyzer and tests the difference between aggregate-equation acceptance and per-record numerical extractability.

It deliberately does not claim that prefix coefficients are knowledge-sound. Its principal result is a negative control: challenge-coordinate cancellation can leave the compressed equation accepted while per-record extraction fails.
