import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1] / "src"))
from cipherauth_case3.agm import Rep, Q
from cipherauth_case3.extraction import ProofRep, RecordRep, analyze, guessing_bound


def honest_record(t: int, r: int, c: int, label: str):
    A = Rep.basis("K", t)
    R = Rep.basis("K", r)
    z = (r + c*t) % Q
    return RecordRep(A, ProofRep(R, c, z), label)


def test_honest_n2_is_per_record_extractable():
    records = (honest_record(17, 23, 5, "r1"), honest_record(31, 41, 7, "r2"))
    tr = analyze(records, (11, 13))
    assert tr.accepted
    assert tr.per_record_extractable == (True, True)
    assert tr.extracted_scalars == (17, 31)
    assert not tr.failure_events


def test_unknown_challenge_coordinate_is_reported():
    records = (RecordRep(Rep.basis("A*"), ProofRep(Rep(), 5, 0), "challenge"),
               honest_record(31, 41, 7, "r2"))
    tr = analyze(records, (11, 13))
    assert not tr.per_record_extractable[0]
    assert "per-record-opening-not-numerically-extractable" in tr.failure_events
    assert tr.extracted_scalars[0] is None


def test_aggregate_challenge_coordinate_can_cancel_without_per_record_extraction():
    # Build two A coordinates with opposite challenge terms. The compressed
    # equation can accept even though neither record is individually extractable.
    c1, c2, b1, b2 = 5, 7, 11, 13
    alpha = 1
    beta = (-b1*c1 * pow(b2*c2, -1, Q)) % Q
    a1 = Rep.basis("A*")
    a2 = Rep.basis("A*", beta) + Rep.basis("K", 19)
    # Choose R=0 and z to match the K component of the weighted RHS.
    zsum = (b2 * c2 * 19) % Q
    r1 = RecordRep(a1, ProofRep(Rep(), c1, 0), "r1")
    r2 = RecordRep(a2, ProofRep(Rep(), c2, (zsum * pow(b2, -1, Q)) % Q), "r2")
    tr = analyze((r1, r2), (b1, b2))
    assert tr.accepted
    assert tr.challenge_coordinate == 0
    assert not all(tr.per_record_extractable)
    assert "per-record-opening-not-numerically-extractable" in tr.failure_events


def test_guessing_bound_is_explicit():
    assert guessing_bound(100) == 100 / Q
