import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1] / "src"))
from cipherauth_case3.agm import Rep, Q
from cipherauth_case3.extraction import ProofRep, RecordRep, analyze, guessing_bound

def h(t,r,c,label):
    A=Rep.basis("K",t); R=Rep.basis("K",r); z=(r+c*t)%Q
    return RecordRep(A,ProofRep(R,c,z),label)

honest=(h(17,23,5,"r1"),h(31,41,7,"r2"))
unknown=(RecordRep(Rep.basis("A*"),ProofRep(Rep(),5,0),"challenge"),honest[1])
print(json.dumps({
 "honest": analyze(honest,(11,13)).__dict__,
 "unknown": analyze(unknown,(11,13)).__dict__,
 "guess_bound_qH_100": guessing_bound(100),
}, indent=2, default=lambda x: sorted(x) if isinstance(x,frozenset) else x))
