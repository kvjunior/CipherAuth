# Case-3 per-record proof relation

For a class base `K=kP`, record encryption uses `A_i=t_iK`. The intake proof proves knowledge of `t_i`:

    R_i = r_i K
    c_i = H_pok(context, A_i, R_i, commitment, ciphertext)
    z_i = r_i + c_i t_i
    z_i K = R_i + c_i A_i

The hash input must bind the complete statement used by the proxy and delegatee, including the origin class, sender, tag, epoch, A, commitment, ciphertext fields, and position/transcript prefix. This file specifies a relation only; it does not prove knowledge soundness.
