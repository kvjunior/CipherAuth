# G-CONF-CT candidate specification (n=2 gate)

G-CONF-CT serves non-derivative target-class aggregates to a corrupted delegatee. The proxy must validate the origin aggregate before applying A -> Abar = Omega^{-1} A. A challenge core and its derivatives are refused by the decryption oracle.

The candidate adds an origin-level Schnorr proof of knowledge of t_i for every A_i=t_iK and compresses two proofs with transcript-bound coefficients b_i:

    z_tilde K = b_1(R_1+c_1 A_1) + b_2(R_2+c_2 A_2).

The proof payload is origin-certified and need not remain valid after single-hop delegation. Correctness after delegation is checked by the commitment. Security nevertheless must define decryption queries on adversary-crafted delegated objects that never passed proxy intake.

This specification is a research candidate, not an implemented secure scheme.
