# Case-3 candidate assumptions and model

The candidate extraction claim is stated in the algebraic group model and random-oracle model (AGM+ROM). Every group element output by the adversary must carry an algebraic representation over the elements it has received.

The candidate does not assume extraction from a registered malicious sender key. It must extract each accepted record's encryption witness, or at least a numerically computable opening point Q_i=t_iP whose representation contains no unknown challenge element.

The current batch intentionally does not select a final hardness assumption. The n=2 gate must first determine whether the extraction follows from existing AGM/ROM techniques, whether it requires a stronger assumption, or whether a counterexample exists.
