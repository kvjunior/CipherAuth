import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1] / "src"))
from cipherauth_case3.model import *

r1 = make_record(b"s1", 17, 23, b"c1", b"e1")
r2 = make_record(b"s2", 31, 41, b"c2", b"e2")
cs = coeff_chain((b"s1|A17|c1|e1", b"s2|A31|c2|e2"))
z = aggregate((r1, r2), cs)
attack_records, attack_z = unweighted_cancellation_attack()
result = {
    "model_prime": P,
    "honest_record_proofs_verify": all(verify_record(r) for r in (r1, r2)),
    "prefix_aggregate_accepts": verify_aggregate((r1, r2), cs, z),
    "prefix_coefficients": list(cs),
    "unweighted_attack_accepts": verify_aggregate(attack_records, (1, 1), attack_z),
    "per_record_extraction_trace": list(extract_known_witnesses((r1, r2))),
    "aggregate_only_extraction_claim": "not implemented; obligation remains open",
}
print(json.dumps(result, indent=2))
Path(__file__).parents[1].joinpath("results", "case3_n2.json").write_text(json.dumps(result, indent=2) + "\n")
