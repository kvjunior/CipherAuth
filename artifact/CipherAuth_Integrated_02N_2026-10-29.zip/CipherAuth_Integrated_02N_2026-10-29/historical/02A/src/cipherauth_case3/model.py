"""Small deterministic reference model for the Case-3 n=2 gate.

This is a finite-field transcript model, not an elliptic-curve implementation and
not a security proof. It checks the algebraic equations, prefix binding, and the
unweighted cancellation control used by the theory gate.
"""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
from typing import Iterable

P = 1000003  # prime used only for deterministic algebraic tests


def scalar(data: bytes, *, domain: bytes = b"case3") -> int:
    x = hashlib.sha256(domain + b"|" + data).digest()
    return int.from_bytes(x, "big") % P


def coeff_chain(records: Iterable[bytes]) -> tuple[int, ...]:
    state = hashlib.sha256(b"case3-prefix-start").digest()
    out: list[int] = []
    for i, record in enumerate(records, 1):
        state = hashlib.sha256(b"case3-prefix-next|" + state + record).digest()
        b = int.from_bytes(hashlib.sha256(b"case3-coeff|" + i.to_bytes(4, "big") + state).digest(), "big") % P
        out.append(b or 1)
    return tuple(out)


@dataclass(frozen=True)
class Proof:
    R: int
    c: int
    z: int


@dataclass(frozen=True)
class Record:
    sender: bytes
    A: int
    commitment: bytes
    ciphertext: bytes
    proof: Proof
    witness: int | None = None


def make_record(sender: bytes, t: int, r: int, commitment: bytes = b"c", ciphertext: bytes = b"e") -> Record:
    A = (t % P)
    R = r % P
    c = scalar(sender + A.to_bytes(8, "big") + R.to_bytes(8, "big") + commitment + ciphertext, domain=b"pok")
    z = (r + c * t) % P
    return Record(sender, A, commitment, ciphertext, Proof(R, c, z), t % P)


def verify_record(record: Record) -> bool:
    # K is represented by the scalar 1, so z*K = R+c*A becomes z=R+cA.
    return record.proof.z % P == (record.proof.R + record.proof.c * record.A) % P


def aggregate(records: tuple[Record, ...], coefficients: tuple[int, ...]) -> int:
    if len(records) != len(coefficients):
        raise ValueError("coefficient length mismatch")
    return sum(b * rec.proof.z for b, rec in zip(coefficients, records)) % P


def verify_aggregate(records: tuple[Record, ...], coefficients: tuple[int, ...], z_tilde: int) -> bool:
    if len(records) != len(coefficients) or not all(verify_record(r) for r in records):
        return False
    lhs = z_tilde % P
    rhs = sum(b * (rec.proof.R + rec.proof.c * rec.A) for b, rec in zip(coefficients, records)) % P
    return lhs == rhs


def extract_known_witnesses(records: tuple[Record, ...]) -> tuple[int, ...] | None:
    """Reference extractor: succeeds only when every record exposes a witness.

    The function intentionally does not infer per-record witnesses from the
    aggregate scalar. That limitation is the proof obligation under review.
    """
    if any(r.witness is None for r in records):
        return None
    return tuple(r.witness for r in records if r.witness is not None)


def unweighted_cancellation_attack() -> tuple[tuple[Record, Record], int]:
    """Two-record algebraic cancellation control.

    The first record is the target statement. The second record is a rogue
    registered sender record whose A coordinate is chosen after the fixed
    coefficients (1,1), allowing the attacker to force the aggregate equation.
    """
    honest = make_record(b"honest", 17, 23, b"target-c", b"target-e")
    rogue0 = make_record(b"rogue", 31, 41, b"rogue-c", b"rogue-e")
    c_h = honest.proof.c
    c_r = rogue0.proof.c
    # Choose a rogue A so the unweighted public equation can be balanced.
    target_rhs = honest.proof.R + c_h * honest.A
    desired_rogue_rhs = (-target_rhs) % P
    rogue_A = ((desired_rogue_rhs - rogue0.proof.R) * pow(c_r, -1, P)) % P
    rogue = Record(rogue0.sender, rogue_A, rogue0.commitment, rogue0.ciphertext,
                   Proof(rogue0.proof.R, c_r, desired_rogue_rhs), None)
    z = (honest.proof.z + rogue.proof.z) % P
    return (honest, rogue), z
