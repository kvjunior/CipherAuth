# Case-3 n=2 extraction obligation

## Required statement

For two independent sender witnesses t_1,t_2 under a common class base K, prove in AGM+ROM that any accepted prefix-bound aggregate either yields numerically computable Q_1=t_1P and Q_2=t_2P, or solves the declared hardness assumption. The extractor must not return a representation containing an unknown challenge element A* or any other unknown-log point.

A weighted-sum witness is insufficient: the corrupted delegatee needs each Q_i to compute Abar_i=Omega^{-1}Q_i. The proof must account for honest proofs, simulated challenge proofs, replays, malicious sender keys, record reordering, and adaptive proxy/decryption queries.

## Current status

The reference model tests honest equations, prefix sensitivity, and the fixed-coefficient cancellation control. It does not prove this lemma. The next proof attempt must explicitly fold all oracle-output points (including prior transformed points) before coefficient matching and state the exact 1/q and random-oracle failure terms.
