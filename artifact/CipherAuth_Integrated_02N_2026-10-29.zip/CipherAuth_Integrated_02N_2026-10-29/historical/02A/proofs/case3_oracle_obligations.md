# Case-3 oracle obligations

1. Simulate honest-origin decryption queries, including the inherited confirmation oracle.
2. Simulate proxy intake: reject malformed or failed aggregate proofs before transformation.
3. For every accepted non-challenge aggregate, extract each Q_i numerically before returning transformed points.
4. Refuse challenge cores and registered derivatives exactly as G-CONF-CT specifies.
5. Define delegated decryption for adversary-crafted delegated objects that bypass intake.
6. State the random-oracle programming order for H_pok, H_d, H_c, KDF, and grant-related hashes.
7. Give a complete loss in the number of records, oracle queries, aggregation queries, and extraction failures.
