import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1] / "src"))

from cipherauth_case3.model import (
    P, Proof, aggregate, coeff_chain, extract_known_witnesses,
    make_record, unweighted_cancellation_attack, verify_aggregate,
    verify_record,
)


def test_two_honest_proofs_and_prefix_aggregate():
    r1 = make_record(b"s1", 17, 23, b"c1", b"e1")
    r2 = make_record(b"s2", 31, 41, b"c2", b"e2")
    cs = coeff_chain((b"s1|A17|c1|e1", b"s2|A31|c2|e2"))
    assert all(verify_record(r) for r in (r1, r2))
    z = aggregate((r1, r2), cs)
    assert verify_aggregate((r1, r2), cs, z)


def test_prefix_changes_when_later_record_changes():
    a = coeff_chain((b"r1", b"r2"))
    b = coeff_chain((b"r1", b"r2-mutated"))
    assert a != b


def test_unweighted_control_accepts_cancellation():
    records, z = unweighted_cancellation_attack()
    assert verify_aggregate(records, (1, 1), z)


def test_extractor_refuses_aggregate_only_information():
    r1 = make_record(b"s1", 17, 23)
    r2 = make_record(b"s2", 31, 41)
    assert extract_known_witnesses((r1, r2)) == (17, 31)
    opaque = (r1, r2)
    opaque = (opaque[0].__class__(opaque[0].sender, opaque[0].A, opaque[0].commitment,
                                  opaque[0].ciphertext, opaque[0].proof, None), opaque[1])
    assert extract_known_witnesses(opaque) is None
