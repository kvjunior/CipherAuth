# CipherAuth Batch 02A: Case-3 n=2 gate

This batch contains the formal candidate specification, proof obligations, a finite-field reference model, and reproducible tests for the two-record Case-3 gate.

It validates algebra and negative controls only. It does not implement a secure Batch-02 protocol and does not prove the extraction lemma.
