# Authoritative checkpoint status

Date: 29 October 2026. Source: recovered project artifacts, Claude's memo, and local reruns.

| Item | Status |
|---|---|
| Frozen CEA and Batch 01r2 | Implemented research comparator; original sources preserved |
| 02A–02D | Implemented historical diagnostics; proof/policy claims superseded by 02E |
| 02E | Audit corrections and restricted algebra diagnostics implemented |
| 02F | Compressed-only transcript/verifier implemented and tested |
| 02G | Restricted two-point/two-record adaptive experiment and written lemma; independent review pending |
| 02H | Setup-first programmed-challenge extension; restricted written proof, independent review pending |
| 02I | Adaptive challenge timing, exact-prequery and representation-collision aborts implemented; restricted written extension pending independent review |
| 02J | Exact honest-delegatee transform simulation using scalar Omega; uniform-C hybrid written and tested, pending independent review; exposure term handled by 02K |
| 02K | Hmask(T) exposure reduced to Gap-Divisible-DH with an `N_H` multi-user loss; scaled embedding covers all grants, pending independent review |
| 02L | G-CONF-CLASS-v1 frozen; target-class AGM extraction removed from the dependency graph; CT explicitly known false |
| 02M | Candidate final G-CONF-CLASS-v1 hybrid and quantitative loss written; pending independent review |
| 02N | Candidate exact G-SCOPE-v1 composition written; fixed target adds no loss; pending independent review |
| New integration bridge | Functional CEA/02F sender-to-delegatee chain verified |
| Prior D1 honest-delegatee challenge transformation | Candidate corrected: earlier drafts confused scalar Omega with point omega*K; exact map `Omega^{-1}A` is simulatable after a uniform-C hybrid |
| Hmask(T) exposure | Restricted reduction written: `Pr[Bad] <= N_H Adv_GDivDH`; static honesty required; pending independent review |
| Full AGM input closure | Not a dependency of G-CONF-CLASS-v1 after exact scalar-Omega simulation; remains relevant only to other notions |
| Frozen game mapping | G-CONF-CLASS-v1 versioned in 02L; G-CONF-CT is known false and not targeted |
| Honest-recipient challenge transformation | Permitted by the game; candidate exact scalar-Omega simulation supplied in 02J and integrated in 02M |
| G-CONF-CLASS-v1 theorem and final loss | Candidate written in 02M; unproved pending independent review |
| G-SCOPE-v1 composition | Candidate written in 02N with zero additional fixed-target loss; unproved pending independent review |
| Machine-checked cryptographic proof | None |
| Literature/novelty gate | Not settled; no STOC-readiness conclusion |

The interface mapping added here encodes full CEA KeyRef fields into 02F's opaque
metadata and requires exact correspondence. This supplies a concrete honest-data
handoff; it does not establish a lossless adversarial-game simulation or settle
the grant ambiguity described in `components/02H/spec/game_compatibility.md`.

The new proxy wrapper deliberately has no challenge ledger. Real functionality
and a confidentiality game's refusal/masking policy are separate objects. The
02H policy projection remains a restricted harness, not the complete game.

Prior CLASS draft arguments are historical. The 02E audit corrects the claim that
all hybrids require one reducing machine: different hybrids may use different
reductions. The missing simulator is the actual obstacle. It also records affine
same-grant consistency and scalar-token-digest obligations that remain relevant.
Adding intake proofs does not, by itself, remove all challenge-transformation
obligations. Successful test runs do not close any of these proof gaps.

Batch 02I closes only the restricted timing gap identified by 02H: its challenge
may now be installed after registered phase-1 queries, with transactional aborts
and a conservative `(N_reg+q_pre)/(q-1)` term. The next technical work must target
the honest-delegatee path. Batch 02J then supplies a candidate exact simulation for
that path, matching the frozen scalar `Token.Omega`. Batch 02K supplies its mask-
exposure reduction. Batch 02L removes full-basis extraction from the CLASS proof
dependency and freezes that interface. Batch 02M assembles the candidate final
hybrid and loss. Batch 02N adds the exact fixed-target G-SCOPE composition;
independent review is now the blocking security step.
