#!/usr/bin/env python3
"""Run every implemented batch, then the actual CEA/02F handoff.

Nested 02N runs 02M through 02F; 01r2 runs CEA. We report unique tests once.
Historical experiments are executable controls, not accepted proof premises.
"""
from pathlib import Path
import hashlib, json, os, re, subprocess, sys, zipfile

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results'


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(name, cwd, args):
    env=os.environ.copy()
    env.pop('PYTHONPATH',None)
    env.pop('PYTHONOPTIMIZE',None)
    env['PYTHONDONTWRITEBYTECODE']='1'
    process=subprocess.run([sys.executable,*args],cwd=cwd,env=env,capture_output=True,text=True,timeout=300)
    (OUT/(name+'.log')).write_text(process.stdout+process.stderr)
    require(process.returncode==0, name+' failed; see results/'+name+'.log')
    print(name+': PASS',flush=True)
    return process


def snapshot_matches(archive, folder, prefix):
    count=0
    with zipfile.ZipFile(archive) as z:
        for item in z.infolist():
            rel=Path(item.filename).relative_to(prefix)
            if item.is_dir() or '__pycache__' in rel.parts or rel.suffix=='.pyc' or 'results' in rel.parts:
                continue
            p=folder/rel
            require(p.is_file() and p.read_bytes()==z.read(item), 'snapshot mismatch: '+str(p))
            count+=1
    return count


def preflight():
    manifest=ROOT/'SOURCE_MANIFEST.json'
    require(manifest.is_file(),'SOURCE_MANIFEST.json is required')
    expected=json.loads(manifest.read_text())
    actual={p.relative_to(ROOT).as_posix():sha(p) for p in ROOT.rglob('*')
            if p.is_file() and 'results' not in p.relative_to(ROOT).parts
            and '__pycache__' not in p.parts and p.suffix!='.pyc' and p!=manifest}
    require(actual==expected,'source manifest mismatch (missing, modified or unexpected source file)')
    matches={}
    for name,archive,prefix in [
        ('cea',ROOT/'components/01r2/baseline/Encrypted_Authentication_Research_Workspace_2026-10-25b.zip','encrypted_auth_research'),
        ('02M',ROOT/'components/02N/baseline/CipherAuth_Batch02M_FinalClass_2026-10-28.zip','CipherAuth_Batch02M_FinalClass'),
        ('02L',ROOT/'components/02M/baseline/CipherAuth_Batch02L_ClassClosure_2026-10-28.zip','CipherAuth_Batch02L_ClassClosure'),
        ('02K',ROOT/'components/02L/baseline/CipherAuth_Batch02K_MaskExposure_2026-10-28.zip','CipherAuth_Batch02K_MaskExposure'),
        ('02J',ROOT/'components/02K/baseline/CipherAuth_Batch02J_HonestDelegatee_2026-10-28.zip','CipherAuth_Batch02J_HonestDelegatee'),
        ('02I',ROOT/'components/02J/baseline/CipherAuth_Batch02I_Adaptive_2026-10-28.zip','CipherAuth_Batch02I_Adaptive'),
        ('02H',ROOT/'components/02I/baseline/CipherAuth_Batch02H_Challenge_2026-10-26.zip','CipherAuth_Batch02H_Challenge'),
        ('02G',ROOT/'components/02H/baseline/CipherAuth_Batch02G_Adaptive_2026-10-25.zip','CipherAuth_Batch02G_Adaptive'),
        ('02F',ROOT/'components/02G/baseline/CipherAuth_Batch02F_Transcript_2026-10-25.zip','CipherAuth_Batch02F_Transcript')]:
        matches[name]=snapshot_matches(archive,ROOT/'components'/name,prefix)
    for p in (ROOT/'components/02F/src/cipherauth02f').glob('*.py'):
        for batch in ('02G','02H','02I'):
            require(p.read_bytes()==(ROOT/f'components/{batch}/vendor/cipherauth02f'/p.name).read_bytes(),
                    'proof kernel copies differ: '+p.name)
    for name in ('adaptive.py','replay.py'):
        require((ROOT/'components/02G/src'/name).read_bytes()==(ROOT/'components/02H/vendor'/name).read_bytes(),
                'adaptive copies differ: '+name)
    require((ROOT/'components/02H/src/challenge_extension.py').read_bytes()==
            (ROOT/'components/02I/vendor/challenge_extension.py').read_bytes(),
            '02H challenge extension copy differs')
    require((ROOT/'components/02H/src/policy_projection.py').read_bytes()==
            (ROOT/'components/02I/vendor/policy_projection.py').read_bytes(),
            '02H policy projection copy differs')
    for p in (ROOT/'components/cea/src/cipherauth').glob('*.py'):
        for batch in ('02J','02K','02L','02M','02N'):
            require(p.read_bytes()==(ROOT/f'components/{batch}/vendor/cipherauth'/p.name).read_bytes(),
                    batch+' CEA source copy differs: '+p.name)
    require((ROOT/'components/02J/src/token_simulation.py').read_bytes()==
            (ROOT/'components/02K/vendor/token_simulation.py').read_bytes(),
            '02J token simulation copy differs')
    for batch in ('02L','02M','02N'):
        require((ROOT/'components/02J/src/token_simulation.py').read_bytes()==
                (ROOT/f'components/{batch}/vendor/token_simulation.py').read_bytes(),
                batch+' token simulation copy differs')
        require((ROOT/'components/02K/src/mask_exposure.py').read_bytes()==
                (ROOT/f'components/{batch}/vendor/mask_exposure.py').read_bytes(),
                batch+' mask exposure copy differs')
    require((ROOT/'components/02L/src/class_game.py').read_bytes()==
            (ROOT/'components/02M/vendor/class_game.py').read_bytes(),
            '02L class-game copy differs')
    require((ROOT/'components/02L/src/class_game.py').read_bytes()==
            (ROOT/'components/02N/vendor/class_game.py').read_bytes(),
            '02N class-game copy differs')
    require((ROOT/'components/02M/src/final_bound.py').read_bytes()==
            (ROOT/'components/02N/vendor/final_bound.py').read_bytes(),
            '02N final-bound copy differs')
    frozen=ROOT/'components/cea/spec/games.md'
    require(frozen.read_bytes()==(ROOT/'components/02H/provenance/frozen_games.md').read_bytes(),
            'frozen games changed')
    # Compile, but do not import mutually incompatible historical namespace packages.
    files=list(ROOT.rglob('*.py'))
    for p in files:
        compile(p.read_bytes(),str(p),'exec')
    return {'flattened_snapshot_files':matches,'python_files_compiled':len(files),
            'proof_kernel_copies_identical':True,'frozen_games_identical':True}


def main():
    OUT.mkdir(exist_ok=True)
    status_path=OUT/'integration_summary.json'
    status_path.write_text(json.dumps({'status':'RUNNING','security_proved':False})+'\n')
    checks=preflight()
    expected={str(p.relative_to(ROOT)):p.read_bytes() for b in ('02E','02F','02G','02H','02I','02J','02K','02L','02M','02N')
              for p in (ROOT/f'components/{b}/results').glob('*.json')}
    run('01r2',ROOT/'components/01r2',['scripts/reproduce.py'])
    # These two legacy integration tests were not covered by its unit-test runner.
    legacy=run('cea_integration',ROOT/'components/cea',
               ['-m','unittest','discover','-s','tests/integration','-v'])
    require('Ran 2 tests' in legacy.stderr,'unexpected legacy integration count')
    run('02E',ROOT/'components/02E',['scripts/reproduce.py'])
    # Run expanded F/G too: these are the visible modules used by the new bridge.
    for b in ('02F','02G','02H','02I','02J','02K','02L','02M','02N'):
        run(b+'_manifest',ROOT/f'components/{b}',['scripts/verify_manifest.py'])
        run(b,ROOT/f'components/{b}',['scripts/reproduce.py'])
    for name,data in expected.items():
        require((ROOT/name).read_bytes()==data,'deterministic component output changed: '+name)
    historical={}
    for b in ('02A','02B','02C','02D'):
        folder=ROOT/'historical'/b
        process=run(b+'_historical_tests',folder,['tests/run_tests.py'])
        m=re.search(r'(\d+) tests: PASS',process.stdout)
        require(m is not None,'historical test count missing: '+b)
        historical[b]=int(m.group(1))
        script=next((folder/'scripts').glob('reproduce*.py'))
        run(b+'_historical_experiment',folder,[str(script.relative_to(folder))])
    bridge=run('bridge',ROOT,['integration/test_bridge.py'])
    require('Ran 14 tests' in bridge.stderr,'unexpected bridge test count')
    require('skipped=' not in bridge.stderr,'bridge tests skipped')
    probe=run('class_decryption_probe',ROOT,
              ['research/CipherAuth_GCONF_CLASS_Draft05/dec_oracle_probe.py',str(ROOT/'components/01r2')])
    require('honest_delegated_open_recovers: True' in probe.stdout and
            'mauled_Abar_rejected_by_commitment: True' in probe.stdout,'CLASS probe failed')
    probe=run('ct_unweighted_probe',ROOT,
              ['research/CipherAuth_GCONF_CT_Draft01/aggregate_template_attack.py',str(ROOT/'components/01r2')])
    pd=json.loads(probe.stdout)
    require(all(pd['honest_aggregate_verifies'].values()),'honest template failure')
    require(all(x['accepted'] and x['challenge_recovered'] for x in pd['unweighted_attack']),
            'unweighted negative control did not reproduce')
    require(all(not x['accepted'] and not x['challenge_recovered'] for x in pd['prefix_weighted_same_attack']),
            'weighted template accepted the same attack')
    # This archived probe expects its old baseline beside it. Supply the identical
    # frozen modules explicitly without changing its bytes or relying on host paths.
    run('checkpoint_coefficient_probe',ROOT,['-c',
        "import sys,runpy;sys.path.insert(0,'components/cea/baselines/claude_v3/source');"
        "runpy.run_path('research/CipherAuth_Theory_Checkpoint01/probes/unbound_coefficient_v3.py',run_name='__main__')"])
    first=json.loads((ROOT/'components/01r2/results/observed.json').read_text())
    counts={'CEA_unit':first['baseline']['unit_tests']['count'],
            'CEA_integration':2,'01r2':first['batch01_tests']['run'],'bridge':14}
    skip_count=len(first['baseline']['unit_tests']['skipped'])+first['batch01_tests']['skipped']
    traces={}
    for b in ('02E','02F','02G','02H','02I','02J','02K','02L','02M','02N'):
        d=json.loads((ROOT/f'components/{b}/results/observed.json').read_text())
        require(d['errors']==d['failures']==0,'component test failure: '+b)
        counts[b]=d['tests_run']
        skip_count+=d.get('skips',d.get('skipped',0))
        if b in ('02G','02H','02I'):traces[b]=d['traces_replayed']
    require(first['batch01_tests']['failures']==first['batch01_tests']['errors']==0,'01r2 failure')
    summary={'status':'PASS' if skip_count==0 else 'PASS_WITH_SKIPS',
             'unique_current_tests':counts,'current_test_count':sum(counts.values()),
             'historical_diagnostics':historical,'historical_test_count':sum(historical.values()),
             'total_unique_test_count':sum(counts.values())+sum(historical.values()),
             'skipped':skip_count,'failures':0,'errors':0,'checks':checks,
             '02E_through_02N_results_byte_identical':True,'trace_replays':traces,
             'additional_research_probes':3,
             'functional_chain':'CEA sender -> 02F compressed intake -> proxy -> CEA wire -> delegatee opening',
             'implemented_batches':['01r2','02A','02B','02C','02D','02E','02F','02G','02H','02I','02J','02K','02L','02M','02N'],
             'missing':['independent review of candidate G-CONF-CLASS-v1 and G-SCOPE-v1 reductions',
                        'novelty decision'],
             'security_proved':False,'complete_protocol':False}
    status_path.write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps(summary,indent=2,sort_keys=True))
    return 0


if __name__=='__main__':
    try:
        sys.exit(main())
    except Exception as e:
        OUT.mkdir(exist_ok=True)
        (OUT/'integration_summary.json').write_text(json.dumps({'status':'FAIL','error':str(e),'security_proved':False},indent=2)+'\n')
        raise
