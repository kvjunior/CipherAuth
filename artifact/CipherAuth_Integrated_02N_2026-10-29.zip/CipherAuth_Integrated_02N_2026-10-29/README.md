# CipherAuth — integrated research codebase through Batch 02N, 29 October 2026

The available batches are integrated and reproducible through **02N**. This is
the complete collected codebase at this checkpoint, **not a complete or proved
cryptographic protocol**. Candidate G-CONF-CLASS-v1 and G-SCOPE-v1 reductions are written but remain pending independent review.

Run from this directory with Python 3.11+:

```sh
python3 scripts/reproduce_all.py
```

The current run passes **286 distinct tests**, with zero failures, errors or skips:
270 current tests, including 27 Batch 02I tests, 12 Batch 02J tests, 13 Batch 02K tests, 14 Batch 02L tests, 9 Batch 02M tests, 14 Batch 02N tests and 14 cross-component tests, and
16 superseded historical diagnostics. The runner also replays 12 Batch 02G, 13
Batch 02H and 8 Batch 02I traces, reruns older experiments and three research probes, checks source
hashes, and checks identical copies of the shared verifier and frozen games.
Nested baseline reruns are not counted twice. See `results/integration_summary.json`
for the machine-readable verdict and `INTEGRATION_REPORT.md` for its scope.

All primary operations use the Python standard library. An optional legacy P-256
cross-check uses `cryptography` if installed; without it the runner explicitly
reports skips. It was installed for the supplied validation. The affine Python
arithmetic is a research implementation and is not constant-time.

## Contents

| Directory | Purpose |
|---|---|
| `components/cea/` | Expanded frozen CEA comparator, v3 baseline, games, serialization and attacks |
| `components/01r2/` | Existing single-record intake proof and proxy-policy experiments |
| `components/02E/` | Audit corrections and restricted algebra diagnostics |
| `components/02F/` | Canonical compressed-proof transcript and verifier |
| `components/02G/` | Adaptive two-record restricted extraction experiment |
| `components/02H/` | Setup-first programmed-challenge extension and policy projection |
| `components/02I/` | Challenge-after-phase-1 extension, conflict accounting and public replay |
| `components/02J/` | Scalar-Omega honest-delegatee simulation and uniform-C hybrid |
| `components/02K/` | Gap-Divisible-DH reduction for honest-grant mask exposure |
| `components/02L/` | Frozen G-CONF-CLASS-v1 interface and extraction-dependency closure |
| `components/02M/` | Candidate final CLASS hybrid and explicit loss ledger |
| `components/02N/` | Exact fixed-target G-SCOPE-v1 composition |
| `integration/` | New CEA-to-02F adapter and 14 integration tests |
| `historical/02A/`–`02D/` | Superseded models, retained for reproducibility only |
| `research/` | Earlier checkpoint and CLASS/CT drafts with their probes |
| `scripts/reproduce_all.py` | Single fail-fast validation entry point |
| `STATUS.md` | Current authority for completed work and open obligations |
| `provenance/` | Recovered input hashes and per-file source lineage |

## What the new bridge demonstrates

Two senders generate real CEA encrypted records and Schnorr intake proofs while
they know their encryption randomness. Sender signatures and intake responses are
compressed separately. The proxy receives only the CEA aggregate and serialized
compressed intake proof, verifies their exact record/context correspondence,
checks the existing grant, transforms the aggregate, serializes it, and opens it
at the delegatee. The opened ordered statements match origin decryption.

This is a functional integration adapter. It does not define a new adversarial
oracle policy, prove knowledge extraction, or carry the intake proof across the
delegation boundary. CEA sender authentication remains unchanged across delegation;
the intake proof binds origin records and is consumed before transformation.

## Reading old material correctly

Top-level `STATUS.md` and `INTEGRATION_REPORT.md` control this integrated release.
`components/02E/proofs/audit_corrections.md` withdraws earlier errors; 02F–02H
contain the later restricted results. Historical statements such as “challenge
proof impossible,” zeroing every unknown coordinate, and a complete additive
security bound are not current conclusions. Old archives and source files remain
unchanged so their evidence can be reproduced. Their presence is not endorsement.

**Next:** obtain an independent line-by-line review of Batches 02M–02N. Do not broaden
the theorem to G-CONF-CT, which is known false for this construction. After review,
freeze the corrected theorem ledger and perform the novelty/positioning decision.
